Thank you for your contribution to the PIPE Templates repository
Before submitting this PR, please make sure:

- [ ] You correctly set the PR message with a < technology > for auto-versioning
- [ ] Your code builds clean without any errors or warnings
- [ ] You are using approved terminology
- [ ] You have added unit tests