[CmdLetBinding()]
Param (
    [Parameter(Mandatory = $true)]
    [String] $organization,
    [Parameter(Mandatory = $true)]
    [String] $project,
    [Parameter(Mandatory = $true)]
    [String] $accessToken,
    [Parameter(Mandatory = $true)]
    [String] $contentToUpdate,
    # The path to the page within the Wiki
    [Parameter(Mandatory = $true)]
    [String] $pagePath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# Encode the PAT for Basic Auth
$encodedPAT = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$accessToken"))

# Define the headers
$getHeaders = @{
    "Content-Type"  = "application/json"
    "Authorization" = "Basic $encodedPAT"
}
$wikiId = "$project.wiki"

# Retrieve current page metadata to get the version
$getUri = "https://dev.azure.com/$organization/$project/_apis/wiki/wikis/$wikiId/pages?path=$pagePath&includeContent=false&api-version=5.0"
Write-Host $getUri
$responseGet = Invoke-WebRequest -Uri $getUri -Method Get -Headers $getHeaders

# Extract the page version
$responseHeaders = $responseGet.Headers
$version = $($responseHeaders['ETag'])
Write-Host "Current Version: $version"

$getUri = "https://dev.azure.com/$organization/$project/_apis/wiki/wikis/$wikiId/pages?path=$pagePath&includeContent=true&api-version=5.0"
Write-Host "Current getUri: $getUri"

$responseGet = Invoke-RestMethod -Uri $getUri -Method Get -Headers $getHeaders
# Extract the existing content
$extContent = $responseGet.content

$contentToUpdate = $contentToUpdate -replace "LB", "`n"
$contentToUpdate = $contentToUpdate -replace '\\n', "`n"
$contentToUpdate = $contentToUpdate -replace ' "', ""
$contentToUpdate = $contentToUpdate -replace '"', ""
Write-Host "Current contentToUpdate: $contentToUpdate"

# This content is in Markdown format.
$contentJson = $extContent + "`n" + $contentToUpdate

# Define the headers
$headers = @{
    "Content-Type"  = "application/json"
    "Authorization" = "Basic $encodedPAT"
    "If-Match"      = $version
}
 
# If you're updating an existing page, you may need to fetch the current page version and increment it.
$body = @{
    "content" = $contentJson
} | ConvertTo-Json

# Define the REST API URI for updating a Wiki page
$uri = "https://dev.azure.com/$organization/$project/_apis/wiki/wikis/$wikiId/pages?path=$pagePath&api-version=7.1"

# Make the REST API call to update the Wiki page
$response = Invoke-RestMethod -Uri $uri -Method PUT -Headers $headers -Body ($body)

# Output the response
if ($response -ne $null) {
    Write-Output "Wiki page updated successfully!"
} else {
    Write-Output "Failed to update the Wiki page."
}
