# Key Vault Secret Expiry Scheduler
This Azure DevOps pipeline is responsible for automatically adding or updating the **expiry date** on Key Vault secrets for all configured teams and environments.

## Schedule
- **Runs automatically every day at 03:00 AM CET**
- Defined using the following cron expression: `0 3 * * *` (in CET time)

## Configuration
The pipeline uses a parameter called `teamsAndEnvironments`, which is an object that maps each team to its list of environments.
```yaml
parameters:
 - name: teamsAndEnvironments
   type: object
   default:
     {
       "advisor-assist": ["dev", "test", "acc", "prod"],
       "bottooling": ["dev", "test"]
     }


To Add a New Team:

Add a new key-value pair to the teamsAndEnvironments object:
"default": {
 "new-team-name": ["dev", "test"]
}

Important Notes
• Any time you add a new environment or a new team, the pipeline must be manually re-triggered once to reflect the changes.
• The next scheduled run will automatically pick up the latest values if committed before the scheduled time and if the always: true flag is used in the schedule block.