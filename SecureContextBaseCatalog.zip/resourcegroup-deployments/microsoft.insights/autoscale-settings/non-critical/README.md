# Description

This ARM template is intended to create a compliant **(Non-Critical)** Autoscale Setting for a target Azure resource, e.g. an App Service Plan.

# Prerequisites

- Resource Group
- Target Azure resource (e.g. App Service Plan)

# Usage Guidance

An autoscale setting is a JSON structure that defines policies that control when the instance count of an App Service Plan is increased or decreased. The JSON is either provided inline or using a file reference. To create the JSON it is recommended to perform a manual configuration of the autoscale setting in Azure Portal and then copy the JSON into the ARM template. If you want the setting to be active, set the `enabled` property to `true`. Else, manual scaling will take precedence.

``` json
{
    "location": "West Europe",
    "tags": {},
    "properties": {
        "name": "saskia-e-asp-autoscale-setting",
        "enabled": true,
       ...
    },
...
}
```

It is only possible to have one autoscale setting for an App Service Plan, but it can contain multiple policies to control scaling of instances. To replace an autoscale setting you can either apply a new autoscale setting using the same name, or remove the existing autoscale setting and then deploy a new autoscale setting with a different name.

>**Note:** If the JSON is created in one environment (e.g. in test) and then used in another environment, then the resource references in the JSON will have to be updated. You can make use of variables in your pipeline and reference those in the JSON to circumvent the need to manually update the JSON for every environment.

## Replicating autoscale settings to other environments

In order to be able to use the JSON schema in the ARM templates across multiple environments, you need to make some important changes to it. When copying the JSON content, it is important to leave only the "properties" JSON property in and remove everything else that is outside of its containing brackets. The resulting JSON **structure** should look similar to the following snippet.

``` json
{
    "properties": {
        "name": "$(AutoscaleSettingsName)",
        "enabled": true,
        "targetResourceUri": "$(TargetResourceUri)",
        "profiles": [
            {
                "name": "Default",
                "capacity": {
                    "minimum": "1",
                    "maximum": "2",
                    "default": "1"
                },
                "rules": [
                    {
                        "scaleAction": {
                            "direction": "Increase",
                            "type": "ChangeCount",
                            "value": "1",
                            "cooldown": "PT5M"
                        },
                        "metricTrigger": {
                            "metricName": "CpuPercentage",
                            "metricNamespace": "microsoft.web/serverfarms",
                            "metricResourceUri": "$(TargetResourceUri)",
                            "operator": "GreaterThan",
                            "statistic": "Average",
                            "threshold": 70,
                            "timeAggregation": "Average",
                            "timeGrain": "PT1M",
                            "timeWindow": "PT10M",
                            "Dimensions": [],
                            "dividePerInstance": false
                        }
                    },
                    {
                        "scaleAction": {
                            "direction": "Decrease",
                            "type": "ChangeCount",
                            "value": "1",
                            "cooldown": "PT5M"
                        },
                        "metricTrigger": {
                            "metricName": "CpuPercentage",
                            "metricNamespace": "microsoft.web/serverfarms",
                            "metricResourceUri": "$(TargetResourceUri)",
                            "operator": "LessThan",
                            "statistic": "Average",
                            "threshold": 40,
                            "timeAggregation": "Average",
                            "timeGrain": "PT1M",
                            "timeWindow": "PT10M",
                            "Dimensions": [],
                            "dividePerInstance": false
                        }
                    }
                ]
            }
        ],
        "notifications": [
            {
                "operation": "Scale",
                "email": {
                    "sendToSubscriptionAdministrator": false,
                    "sendToSubscriptionCoAdministrators": false,
                    "customEmails": [
                        "($CustomEmail)"
                    ]
                },
                "webhooks": []
            }
        ],
        "targetResourceLocation": "West Europe"
    }
}
```

Afterwards, it is imperative to change all occurrences of the  **"targetResourceUri"** & **"metricResourceUri"** property values. These values should be modified to an ARM Template function that retrieves the resource ID of the App Service Plan which is currently being deployed, with the function in question having a static set of values.

`
[resourceId('Microsoft.Web/sites', parameters('appServiceName'))]
`

Refrain from modifying the contents of this function and use it as it is depicted in the snippet above. Please refer to the following JSON snippet for usage example.

``` json
{
    "properties": {
        "name": "$(AutoscaleSettingsName)",
        "enabled": true,
        "targetResourceUri": "[resourceId('Microsoft.Web/sites', parameters('appServiceName'))]",
        "profiles": [
            {
                "name": "Default",
                "capacity": {
                    "minimum": "1",
                    "maximum": "2",
                    "default": "1"
                },
                "rules": [
                    {
                        "scaleAction": {
                            "direction": "Increase",
                            "type": "ChangeCount",
                            "value": "1",
                            "cooldown": "PT5M"
                        },
                        "metricTrigger": {
                            "metricName": "CpuPercentage",
                            "metricNamespace": "microsoft.web/serverfarms",
                            "metricResourceUri": "[resourceId('Microsoft.Web/sites', parameters('appServiceName'))]",
                            "operator": "GreaterThan",
                            "statistic": "Average",
                            "threshold": 70,
                            "timeAggregation": "Average",
                            "timeGrain": "PT1M",
                            "timeWindow": "PT10M",
                            "Dimensions": [],
                            "dividePerInstance": false
                        }
                    },
                    {
                        "scaleAction": {
                            "direction": "Decrease",
                            "type": "ChangeCount",
                            "value": "1",
                            "cooldown": "PT5M"
                        },
                        "metricTrigger": {
                            "metricName": "CpuPercentage",
                            "metricNamespace": "microsoft.web/serverfarms",
                            "metricResourceUri": "[resourceId('Microsoft.Web/sites', parameters('appServiceName'))]",
                            "operator": "LessThan",
                            "statistic": "Average",
                            "threshold": 40,
                            "timeAggregation": "Average",
                            "timeGrain": "PT1M",
                            "timeWindow": "PT10M",
                            "Dimensions": [],
                            "dividePerInstance": false
                        }
                    }
                ]
            }
        ],
        "notifications": [
            {
                "operation": "Scale",
                "email": {
                    "sendToSubscriptionAdministrator": false,
                    "sendToSubscriptionCoAdministrators": false,
                    "customEmails": [
                        "($CustomEmail)"
                    ]
                },
                "webhooks": []
            }
        ],
        "targetResourceLocation": "West Europe"
    }
}
```

# Notes

- [AAB Monitor v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/63706/AAB-Monitor-v1)
- [Azure PowerShell cmdlets for Azure Monitor](https://docs.microsoft.com/en-us/powershell/module/az.monitor)
- [Overview of autoscale in Microsoft Azure](https://docs.microsoft.com/en-us/azure/azure-monitor/autoscale/autoscale-overview)
