# Description

This ARM template is intended to create a compliant **(Non-Critical)** Database on a PostgreSQL Flexible Server.

It complies with the following Azure Policies:

- None

## Prerequisites

- Resource Group
- PostgreSQL Flexible Server

# Notes

- [AAB PostgreSQL v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/68271/AAB-PostgreSQL-v1)
- [Azure PowerShell cmdlets for PostgreSQL](https://learn.microsoft.com/en-us/powershell/module/az.postgresql)
