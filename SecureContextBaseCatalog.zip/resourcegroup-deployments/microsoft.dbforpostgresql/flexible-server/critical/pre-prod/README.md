# Description

This ARM template is intended to create a compliant **(Critical)** PostgreSQL Flexible Server.

It complies with the following Azure Policies:

- AAB Database for PostgreSQL Flexible Server - AAD Password Authentication DENY v1
- AAB Database for PostgreSQL Flexible Server - Checkpoints DINE v1
- AAB Database for PostgreSQL Flexible Server - Connections DINE v1
- AAB Database for PostgreSQL Flexible Server - Diagnostic Settings FSCP DINE v1
- AAB Database for PostgreSQL Flexible Server - Diagnostic Settings Sentinel DINE v1
- AAB Database for PostgreSQL Flexible Server - Disconnections Log DINE v1
- AAB Database for PostgreSQL Flexible Server - Duration Log DINE v1
- AAB Database for PostgreSQL Flexible Server - PG Audit Log DINE v1
- AAB Database for PostgreSQL Flexible Server - PG Shared Preload Libraries DINE v1
- AAB Database for PostgreSQL Flexible Server - SSL Settings DINE v1
- PostgreSQL flexible servers should use customer-managed keys to encrypt data at rest
- Public network access should be disabled for PostgreSQL flexible servers

# Prerequisites

- Resource Group
- Azure AD Group or Service Principal to be configured as Azure AD administrator of the PostgreSQL Flexible Server
- Virtual Network and [Subnet with Flexible Server Network pattern (via SSNS)](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/89653/Product-Description)
- Key Vault with Customer-Managed Key to be used for data encryption
- User-Assigned Identity with "get", "list", "unwrapKey", "wrapKey" Key permissions on the Key Vault
- When enabling geo-redundant storage for backup, an additional Key Vault, Customer-Managed Key and User-Assigned Identity are required in another region

# Notes

- [AAB PostgreSQL v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/68271/AAB-PostgreSQL-v1)
- [Azure PowerShell cmdlets for PostgreSQL](https://learn.microsoft.com/en-us/powershell/module/az.postgresql)
