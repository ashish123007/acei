﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileResource = $templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.DBforPostgreSQL/flexibleServers" }
    $templateFileResourceProperties = $templateFileResource.properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
}

Describe "Non-Critical Pre-Prod PostgreSQL Flexible Server" {
    Context "ARM template" {
        It "Should have User-Assigned Identity" {
            $templateFileResource.PSObject.Properties.Name | Should -Contain "identity" -ErrorAction Stop
            $templateFileResource.identity.PSObject.Properties.Name | Should -Contain "type" -ErrorAction Stop
            $templateFileResource.identity.type | Should -BeExactly "UserAssigned"
        }

        It "Should not use PostgreSQL authentication" {
            $templateFileResourcePropertyNames | Should -Not -Contain "administratorLogin"
            $templateFileResourcePropertyNames | Should -Not -Contain "administratorLoginPassword"

            $templateFileResourcePropertyNames | Should -Contain "authConfig" -ErrorAction Stop
            $templateFileResourceProperties.authConfig.PSObject.Properties.Name | Should -Contain "passwordAuth" -ErrorAction Stop
            $templateFileResourceProperties.authConfig.passwordAuth | Should -BeExactly "Disabled"
        }

        It "Should use Azure AD authentication" {
            $templateFileResourcePropertyNames | Should -Contain "authConfig" -ErrorAction Stop
            $templateFileResourceProperties.authConfig.PSObject.Properties.Name | Should -Contain "activeDirectoryAuth" -ErrorAction Stop
            $templateFileResourceProperties.authConfig.activeDirectoryAuth | Should -BeExactly "Enabled"
        }

        It "Should use customer-managed keys to encrypt data at rest" {
            $templateFileResourcePropertyNames | Should -Contain "dataEncryption" -ErrorAction Stop
            $templateFileResourceProperties.dataEncryption.PSObject.Properties.Name | Should -Contain "type" -ErrorAction Stop
            $templateFileResourceProperties.dataEncryption.type | Should -BeExactly "AzureKeyVault"
            $templateFileResourceProperties.dataEncryption.PSObject.Properties.Name | Should -Contain "primaryUserAssignedIdentityId"
            $templateFileResourceProperties.dataEncryption.PSObject.Properties.Name | Should -Contain "primaryKeyURI"

            if ($templateFileResourcePropertyNames -contains "backup" -and $templateFileResourceProperties.backup.PSObject.Properties.Name -contains "geoRedundantBackup") {
                $templateFileResourceProperties.dataEncryption.PSObject.Properties.Name | Should -Contain "geoBackupUserAssignedIdentityId"
                $templateFileResourceProperties.dataEncryption.PSObject.Properties.Name | Should -Contain "geoBackupKeyURI"
            }
        }

        It "Should use VNet Integration" {
            $templateFileResourcePropertyNames | Should -Contain "network" -ErrorAction Stop
            $templateFileResourceProperties.network.PSObject.Properties.Name | Should -Contain "delegatedSubnetResourceId" -ErrorAction Stop
            $templateFileResourceProperties.network.delegatedSubnetResourceId | Should -Not -BeNullOrEmpty
            $templateFileResourceProperties.network.delegatedSubnetResourceId | Should -Not -BeLike "*null*"
        }

        It "Should use Private DNS integration" {
            $templateFileResourcePropertyNames | Should -Contain "network" -ErrorAction Stop
            $templateFileResourceProperties.network.PSObject.Properties.Name | Should -Contain "privateDnsZoneArmResourceId" -ErrorAction Stop
            $templateFileResourceProperties.network.privateDnsZoneArmResourceId | Should -Not -BeNullOrEmpty
            $templateFileResourceProperties.network.privateDnsZoneArmResourceId | Should -Not -BeLike "*null*"
        }
    }
}
