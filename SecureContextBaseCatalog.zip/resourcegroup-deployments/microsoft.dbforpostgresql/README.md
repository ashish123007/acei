# Secure Context Azure Database for PostgreSQL Flexible Server

[[_TOC_]]

## Azure Database for PostgreSQL High-Level Description

[Azure Database for PostgreSQL Flexible Server](https://learn.microsoft.com/en-us/azure/postgresql/) is a relational database service based on the open-source Postgres database engine. It's a fully managed database-as-a-service that can handle mission-critical workloads with predictable performance, security, high availability, and dynamic scalability.

Some key features of Azure Database for PostgreSQL include:

- Built-in high availability.
- Data protection using automatic backups and point-in-time-restore for up to 35 days.
- Automated maintenance for underlying hardware, operating system and database engine to keep the service secure and up to date.
- Predictable performance, using inclusive pay-as-you-go pricing.
- Elastic scaling within seconds.
- Enterprise grade security and industry-leading compliance to protect sensitive data at-rest and in-motion.
- Monitoring and automation to simplify management and monitoring for large-scale deployments.

## Network topology

Azure Database for PostgreSQL Flexible Server requires to have a dedicated subnet. The database service is meant to be used internally so the preferred way to access the database is using 'Private access'.

## PowerShell Commands

Refer to the [Microsoft Documentation](https://learn.microsoft.com/en-us/powershell/module/az.postgresql) for all available Azure PowerShell cmdlets for Azure PostgreSQL.

## Deploying in Secure Context

For more information on how to consume and deploy this template, please visit the [Secure Context](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64636/Secure-Context) wiki page.
