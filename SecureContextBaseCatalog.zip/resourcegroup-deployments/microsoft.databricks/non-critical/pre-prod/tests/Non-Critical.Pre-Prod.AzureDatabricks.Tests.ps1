﻿Describe "Non-Critical Pre-Prod Databricks" {
    BeforeAll {
        $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
        $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
        $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
        $templateFileResource = $templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.Databricks/workspaces" }
        $templateFileResourceProperties = $templateFileResource.properties
        $templateFileDeploymentResource = $templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.Resources/deployments" }
        $templateFileDatabricksDeploymentResource = $templateFileDeploymentResource.properties.template.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.Databricks/workspaces" }
        $templateFileDatabricksDeploymentResourceProperties = $templateFileDatabricksDeploymentResource.properties
        $templateFileDatabricksDeploymentResourcePropertyNames = $templateFileDatabricksDeploymentResourceProperties.PSObject.Properties.Name
    }

    Context "ARM template" {
        It "Should have Customer-Managed Keys to encrypt data at rest" {
            $templateFileDatabricksDeploymentResourcePropertyNames | Should -Contain "parameters" -ErrorAction Stop
            $templateFileDatabricksDeploymentResourceProperties.parameters.PSObject.Properties.Name | Should -Contain "encryption" -ErrorAction Stop
            $templateFileDatabricksDeploymentResourceProperties.parameters.PSObject.Properties.Name | Should -Contain "prepareEncryption" -ErrorAction Stop
            $templateFileDatabricksDeploymentResourceProperties.parameters.prepareEncryption.value | Should -BeTrue

            $templateFileDatabricksDeploymentResourceProperties.parameters.encryption.value.PSObject.Properties.Name | Should -Contain "keySource"
            $templateFileDatabricksDeploymentResourceProperties.parameters.encryption.value.keySource | Should -BeExactly "Microsoft.Keyvault"
            $templateFileDatabricksDeploymentResourceProperties.parameters.encryption.value.PSObject.Properties.Name | Should -Contain "keyvaulturi"
            $templateFileDatabricksDeploymentResourceProperties.parameters.encryption.value.keyvaulturi | Should -Not -BeNullOrEmpty
            $templateFileDatabricksDeploymentResourceProperties.parameters.encryption.value.PSObject.Properties.Name | Should -Contain "KeyName"
            $templateFileDatabricksDeploymentResourceProperties.parameters.encryption.value.KeyName | Should -Not -BeNullOrEmpty
        }

        It "Should not be a Public Workspace" {
            $templateFileResourceProperties.parameters.PSObject.Properties.Name | Should -Contain "enableNoPublicIp" -ErrorAction Stop
            $templateFileResourceProperties.parameters.enableNoPublicIp.value | Should -BeTrue
        }

        It "Should use premium sku" {
            $templateFileResource.PSObject.Properties.Name | Should -Contain "sku"
            $templateFileResource.sku.name | Should -BeExactly "Premium"
        }

        It "Should use Subnet Integration" {
            $templateFileResourceProperties.parameters.PSObject.Properties.Name | Should -Contain "customPrivateSubnetName" -ErrorAction Stop
            $templateFileResourceProperties.parameters.PSObject.Properties.Name | Should -Contain "customPublicSubnetName" -ErrorAction Stop
            $templateFileResourceProperties.parameters.customPrivateSubnetName.value | Should -BeExactly "adbprivate01-subnet"
            $templateFileResourceProperties.parameters.customPublicSubnetName.value | Should -BeExactly "adbpublic01-subnet"
        }
    }
}
