# Description

This ARM template is intended to create a compliant **(Critical)** Databricks Workspace.

It complies with the following Azure Policies:

- AAB Databricks - Customer Managed Keys AUDIT
- AAB Databricks - Diagnostic Settings FSCP DINE
- AAB Databricks - Diagnostic Settings Sentinel DINE
- AAB Databricks - NSG Association DENY
- AAB Databricks - Public Workspace DENY
- AAB Databricks - SKU Setting DENY
- AAB Databricks - Subnet Integration DENY

# Prerequisites

- Resource Group
- Virtual Network and [Subnet with ADB Network pattern (via SSNS)](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/89653/Product-Description)
- Key Vault with Customer-Managed Key to be used for data encryption

# Notes

- [AAB Databricks v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/67486/AAB-Databricks-V1)
- [Azure PowerShell cmdlets for Databricks](https://learn.microsoft.com/en-us/powershell/module/az.databricks/?view=azps-11.2.0)
