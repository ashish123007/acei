# Secure Context Azure Databricks

[[_TOC_]]

## Azure Databricks High-Level Description

[Azure Databricks](https://learn.microsoft.com/en-us/azure/databricks/) is a fully managed service that enables an open data lakehouse in Azure. It is an open analytics platform for building, deploying, sharing, and maintaining enterprise-grade data, analytics, and AI solutions at scale.

Some key features of Azure Databricks:

- Data processing scheduling and management, in particular ETL.
- Generating dashboards and visualizations.
- Managing security, governance, high availability, and disaster recovery.
- Data discovery, annotation, and exploration.
- Machine Learning modeling, tracking, and model serving.
- Generative AI solutions.

## Network topology

Azure Databricks workspace can be deployed in one mode:

- Custom Bubble Virtual Network: This network will have no network connectivity to other Virtual Networks or to on-premises recources.

## PowerShell Commands

Refer to the [Microsoft Documentation](https://learn.microsoft.com/en-us/powershell/module/az.databricks) for all available Azure PowerShell cmdlets for Azure Databricks.

## Deploying in Secure Context

For more information on how to consume and deploy this template, please visit the [Secure Context](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64636/Secure-Context) wiki page.
