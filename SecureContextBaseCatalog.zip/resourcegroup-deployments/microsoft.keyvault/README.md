# Secure Context Key Vault

[[_TOC_]]

## Key Vault v1 High-Level Description

Azure Key Vault encrypts keys and secrets (such as authentication keys, storage account keys, data encryption keys, .PFX files, and passwords) by using keys that are software or hardware security modules (HSM) protected.
Out of the box, it includes enterprise-grade capabilities: security, manageability, scalability, reliability, and availability; essential for real-world enterprise use cases. More information can be found on the [Microsoft documentation page](https://docs.microsoft.com/en-us/azure/key-vault/)

## Network topology

Azure Key Vault resides within the Azure Public environment. Traffic flows to and from Azure Key Vault can be controlled using the local integrated firewall on the PaaS service (highly recommended). This firewall allows for white listing traffic from ABN AMRO public IP addresses and ranges, from specific virtual network/subnets and denying all other traffic. This makes the deployment more secure.

Following are the allowed traffic flows:

![KeyVaultConnectiviy.png](images/KeyVaultNetworking.png)

1. CBSP Azure Private connect to the Azure Key Vault via the service endpoint of ABN AMRO Secure Perimeter Firewall, to access Azure Key Vault through HTTPS (port 443). Customers with _Microsoft.Keyvault_ service endpoint already enabled for their subnet as part of their network solution, will be able to whitelist their subnet through the product and establish connectivity to Azure Key Vault. However, this connectivity pattern needs to be part of their solution intent and needs to be reviewed by CISO first.

1. ABN AMRO on premises connections to Key Vault are filtered through existing proxy services. Connections to the Key Vault are done over HTTPS (port 443)

1. Azure Private to Azure Key Vault connection pattern over Private Link. This is **not** in scope for MVP 1.

1. Azure Public to Azure Key Vault follow the connection pattern over the Microsoft backbone. Only traffic that comes from a specific set of IP addresses can access the Key Vault

# PowerShell Commands

Go to [Microsoft Documentation](https://docs.microsoft.com/en-us/powershell/module/az.keyvault) to get all the Key Vault PS Commands.

> **Note:** In FSCP 3.0 security and compliance of the resource is governed through Azure Policies. Therefore, please note that some PowerShell commands might not work due to different controls enforced at Policy level for the Key Vault Resource. You can consult [FSCP 3.0 Key Vault Policies](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/63594/AAB-Key-Vault-v1) list for more details

# Deploying in Secure Context

For more information on how to consume and deploy this template please visit the [Secure Context](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64636/Secure-Context) wiki page.
