# Description

This ARM template will deploy a **(Non-Critical)** Azure Key Vault resource in the given Resource Group. It applies to the following policies:

- Purge protection
- Soft Delete enabled
- Network Access not enabled
- Trusted Microsoft services

## Prerequisites

- Resource Group

## Documentation

- [AAB Key Vault v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/63594/AAB-Key-Vault-v1)
- [How to retrieve and set firewall IP ranges for Key Vault](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/93970/Firewall-Rules-Retrieve-and-set-firewall-IP-ranges)
- [Azure PowerShell cmdlets for Key Vault](https://docs.microsoft.com/en-us/powershell/module/az.keyvault)
