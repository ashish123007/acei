﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileParameters = $templateFileObject.parameters
    $templateFileResourceProperties = $templateFileObject.resources.properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
}

Describe "Critical Prod Key Vault" {
    Context "ARM template" {
        It "Should have Premium SKU" {
            $templateFileResourcePropertyNames | Should -Contain "sku" -ErrorAction Stop
            $templateFileResourceProperties.sku.PSObject.Properties.Name | Should -Contain "name" -ErrorAction Stop
            $templateFileResourceProperties.sku.name | Should -BeExactly "Premium"
        }

        It "Should have soft-delete enabled as default value" {
            $templateFileParameters.PSObject.Properties.Name | Should -Contain "enableSoftDelete" -ErrorAction Stop
            $templateFileParameters.enableSoftDelete.PSObject.Properties.Name | Should -Contain "defaultValue" -ErrorAction Stop
            $templateFileParameters.enableSoftDelete.defaultValue | Should -BeOfType [bool] -ErrorAction Stop
            $templateFileParameters.enableSoftDelete.defaultValue | Should -BeTrue
        }

        It "Should have purge protection enabled" {
            $templateFileResourcePropertyNames | Should -Contain "enablePurgeProtection" -ErrorAction Stop
            $templateFileResourceProperties.enablePurgeProtection | Should -BeOfType [bool] -ErrorAction Stop
            $templateFileResourceProperties.enablePurgeProtection | Should -BeTrue
        }

        It "Should have network ACL default action set to Deny" {
            $templateFileResourcePropertyNames | Should -Contain "networkAcls" -ErrorAction Stop
            $templateFileResourceProperties.networkAcls.PSObject.Properties.Name | Should -Contain "defaultAction" -ErrorAction Stop
            $templateFileResourceProperties.networkAcls.defaultAction | Should -BeExactly "Deny"
        }

        It "Should not have default IP rules configured" {
            $templateFileParameters.PSObject.Properties.Name | Should -Contain "ipRules" -ErrorAction Stop
            $templateFileParameters.ipRules.PSObject.Properties.Name | Should -Not -Contain "defaultValue"
        }
    }
}
