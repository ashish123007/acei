﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileResourceProperties = ($templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies" }).properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
    $templateFileResourcePolicySettingsPropertyNames = $templateFileResourceProperties.policySettings.PSObject.Properties.Name

}

Describe "Critical Application Gateway WAF Policy" {
    Context "ARM template" {
        It "Should have WAF Policy state set to Enabled" {
            $templateFileResourcePolicySettingsPropertyNames | Should -Contain "state" -ErrorAction Stop
            $templateFileResourceProperties.policySettings.state | Should -BeExactly "Enabled"
        }

        It "Should have WAF Policy mode set to Prevention" {
            $templateFileResourcePolicySettingsPropertyNames | Should -Contain "mode" -ErrorAction Stop
            $templateFileResourceProperties.policySettings.mode | Should -BeExactly "Prevention"
        }

        It "Should have WAF Policy request body check set to true" {
            $templateFileResourcePolicySettingsPropertyNames | Should -Contain "requestBodyCheck" -ErrorAction Stop
            $templateFileResourceProperties.policySettings.requestBodyCheck | Should -BeOfType [bool] -ErrorAction Stop
            $templateFileResourceProperties.policySettings.requestBodyCheck | Should -BeTrue
        }

        It "Should have WAF Policy 'Maximum request body inspect limit' value is set to greater than or equal to 32 KB." {
            $templateFileResourcePolicySettingsPropertyNames | Should -Contain "requestBodyInspectLimitInKB" -ErrorAction Stop
            $templateFileResourceProperties.policySettings.PSObject.Properties.Name | Should -Contain "requestBodyInspectLimitInKB"
        }

        It "Should have WAF Policy OWASP 3.2 rule set configured" {
            $templateFileResourceProperties.managedRules.managedRuleSets.ruleSetType | Should -Contain "OWASP" -ErrorAction Stop
            ($templateFileResourceProperties.managedRules.managedRuleSets | Where-Object -Property ruleSetType -EQ "OWASP").ruleSetVersion | Should -BeExactly "3.2"
        }

        It "Should not have any WAF Policy OWASP 3.2 rule disabled" {
            $templateFileResourceProperties.managedRules.managedRuleSets.ruleSetType | Should -Contain "OWASP" -ErrorAction Stop
            ($templateFileResourceProperties.managedRules.managedRuleSets | Where-Object -Property ruleSetType -EQ "OWASP").ruleSetVersion | Should -BeExactly "3.2"
            $managedRuleSet = $templateFileResourceProperties.managedRules.managedRuleSets | Where-Object -FilterScript { $_.ruleSetType -eq "OWASP" -and $_.ruleSetVersion -eq "3.2" }
            if ($managedRuleSet.PSObject.Properties.Name -contains "ruleGroupOverrides" -and ($managedRuleSet.ruleGroupOverrides | Get-Member -MemberType NoteProperty).Name -contains "rules") {
                $managedRuleSet.ruleGroupOverrides.rules.state | Should -Not -Contain "Disabled"
            }
        }

        It "Should not have more than 2 WAF Policy exclusions" {
            if ($templateFileResourceProperties.managedRules.exclusions) {
                $templateFileResourceProperties.managedRules.exclusions.exclusionManagedRuleSets.ruleGroups.rules.ruleId.Count | Should -BeLessOrEqual 2
            }
        }
    }
}
