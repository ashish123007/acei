# Description

This ARM template is intended to create a compliant **(Critical)** Application Gateway WAF Policy.

It complies with the following Azure Policies:

- AAB Application Gateway - WAF Policy enforce minimum for the 'Maximum request body inspection limit' value v1
- AAB Application Gateway - WAF Policy managed rule set should not be disabled v1
- AAB Application Gateway - WAF Policy restrict the exclusion at global or ruleset level v1
- AAB Application Gateway - WAF Policy restrict the exclusions at group level without a ruleId v1
- AAB Application Gateway - WAF Policy should allow limited exclusions at managed rule sets v1
- AAB Application Gateway - WAF Policy should use the latest OWASP rule set v1
- AAB Application Gateway - WAF Policy state enabled v1
- Azure Web Application Firewall on Azure Application Gateway should have request body inspection enabled
- Web Application Firewall (WAF) should use the specified mode for Application Gateway

# Prerequisites

- Resource Group

# Documentation

- [AAB Application Gateway v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/65788/AAB-Application-Gateway-v1)
- [Azure PowerShell cmdlets for Application Gateway](https://docs.microsoft.com/en-us/powershell/module/az.network#application-gateway)
