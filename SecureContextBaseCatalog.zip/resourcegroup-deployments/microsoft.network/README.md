# Secure Context Application Gateway

[[_TOC_]]

## Application Gateway High-Level Description

[Azure Application Gateway](https://docs.microsoft.com/en-us/azure/application-gateway) is a web traffic load balancer that enables you to manage HTTP(S) traffic to your web applications and also serves as a WAF (Web Application Firewall) for inbound traffic.

## Network Topology

Azure Application Gateway resides within both the Azure Public and Private environment. The Azure Application Gateway Management Plane and the Gateway's Public IP live in Azure Public, while the Gateway resource itself lives in Azure Private. The back-end pools that then can be configured behind the Azure Application Gateway reside either in Azure Private or Public. Azure Private resources have private IP addresses, for example IaaS resources such as VMs or vNet Integrated PaaS services. Azure Public resources are reached via a public IP address.

The Azure Application Gateway Management Plane is fully managed by Microsoft as the CSP. It needs from connectivity Azure Public to any Azure Application Gateway instance to manage and configure those instances from the cloud. This is why even in the private scenario this connectivity is drawn from Azure Public to the Azure Application Gateway.

We distinguish two network solutions for this resource type: a public-facing and a private-facing scenario. They are described below.

### Public Scenario

![Azure Application Gateway Connectivity Public](images/AzureApplicationGateway-connectivity-public.png)

The allowed traffic flows for the public scenario are the following:

- HTTPS traffic from WORKSQUARE over the Internet to Azure Application Gateway (via Akamai) on port 443.
- HTTPS traffic from the Internet to Azure Application Gateway (via Akamai) on port 443.
- HTTPS traffic from Akamai Kona Site Defender to Application Gateway on port 443.
- HTTPS traffic from Azure Application Gateway to Web Apps / Websites hosted on VMs in Azure Private on any port.
- HTTPS traffic from Azure Application Gateway to Web Apps / Websites hosted on any vNet Integrated PaaS service in Azure Private or PaaS service in Azure Public on port 443.
- HTTPS traffic from Azure Application Gateway to Web Apps / Websites hosted on-premises on CCA Back-end servers on port 443.
- TCP traffic over ports 65200-65535 from Azure Public (service tag GatewayManagement) to Azure Application Gateway. Only for management traffic between the Azure Application Gateway Management Plane and Azure Application Gateway. This is necessary for the Gateway to function correctly.

>**Note:** Unencrypted HTTP listeners are only allowed to be used in the same virtual network by the same workload. So it is not allowed for customers to use HTTP listeners for clients outside the workload.

>**Note:** Traffic to backend pools using Azure Storage Account Static Websites will go over a `Microsoft.Storage` service endpoint. Traffic to Azure App Service backend pools will go out directly to the Azure App Service by adding the gateway's public IP address to the Access Restrictions Allow list on the Azure App Service.

### Private Scenario

![Azure Application Gateway Connectivity Private](images/AzureApplicationGateway-connectivity-private.png)

The allowed traffic flows for the private scenario are the following:

- HTTPS traffic from WORKSQUARE to Azure Application Gateway on port 443 via the ExpressRoute.
- HTTPS traffic from Azure Private to Azure Application Gateway on port 443.
- HTTP or HTTPS traffic from Azure Application Gateway to Web Apps / Websites hosted on VMs in Azure Private on any port.
- HTTPS traffic from Azure Application Gateway to Web Apps / Websites hosted on any vNet Integrated PaaS service in Azure Private or PaaS service in Azure Public on port 443.
- HTTPS traffic from Azure Application Gateway to Web Apps / Websites hosted on-premises on CCA Back-end servers on port 443.
- TCP traffic over ports 65200-65535 from Azure Public (service tag GatewayManagement) to Azure Application Gateway. Only for management traffic between the Azure Application Gateway Management Plane and Azure Application Gateway. This is necessary for the Gateway to function correctly.

>**Note:** For the private scenario the only traffic flow allowed on the gateway's public IP is management traffic necessary for the gateway to function correctly. All other traffic is blocked on this public IP in this scenario by the NSG configured on the Azure Application Gateway's subnet.

>**Note:** Traffic to Static Websites hosted in Azure Storage Accounts as backend targets must go over a `Microsoft.Storage` service endpoint. It must be allowed by adding the subnet in which the Azure Application Gateway is located to the allowed Virtual Network subnets list on the Azure Storage Account. Whitelisting the public IP address of the Azure Application Gateway will not work.

>**Note:** Traffic to Azure App Service backend targets will go directly to the Azure App Service. This traffic must be allowed by adding the gateway's public IP address to the Access Restrictions Allow list on the Azure App Service.

### Virtual Network Prerequisites

The Azure Application Gateway must always be deployed in a dedicated subnet within a Virtual Network. Dedicated means that this subnet can only contain Azure Application Gateway instances. There are two different subnet types that can be requested. One for the public scenario **(appgwpublicXX)** and one for the private scenario **(appgwprivateXX)**. Please make sure that you request the correct subnet that matches your intent. Our resource type will prohibit you to deploy a public intent Azure Application Gateway to a private subnet and vice versa.

Network Security Groups are in place on both Azure Application Gateway subnets with the following default rules:

- Inbound traffic from the _GatewayManager_ service tag to the subnet must be allowed on TCP ports 65200-65535 for back-end health probe status to work correctly.
- Outbound traffic to the _Internet_ service tag must not be blocked.
- Traffic from the _AzureLoadBalancer_ service tag to the subnet must be allowed.
- Inbound traffic from the _ABN-AMRO Akamai Kona Site Defender_ instance to the subnet must be allowed on port 443 (Public Scenario only).

### Setup Virtual Network & Subnet

The creation of the Virtual Network and subnet can be done through the Self Service Network Solution (SSNS) Task Extension.
![Self Service Network Solution Task Extension](images/SelfServiceNetworkSolutionTaskExtension.png)

#### Classic Pipeline Approach

With below settings you can deploy the Virtual Network in the classic pipeline approach. Update the Azure service connection to the Resource Group value of your Secure Context environment.

![Classic Pipeline Virtual Network Settings](images/SSNSDeployVirtualNetworkClassic.png)

With below settings you can deploy a subnet dedicated for Azure Application Gateway in the created Virtual Network. Update the Azure service connection to the Resource Group value of your Secure Context environment and select your created Virtual Network resource from the previous step as your Virtual Network for the to be created subnet.

![Classic Pipeline Subnet Settings](images/SSNSDeploySubnetClassic.png)

#### YAML Pipeline Approach

With below settings you can deploy the Virtual Network in the YAML pipeline approach. Update the value ('securecontext-d-rg') of the "azureSubscription" input to the Resource Group value of your Secure Context environment.

![YAML Pipeline Virtual Network Settings](images/SSNSDeployVirtualNetworkYAML.png)

With below settings you can deploy a subnet dedicated for Azure Application Gateway in the created Virtual Network. Update the value ('securecontext-d-rg') of the "azureSubscription" input to the Resource Group value of your Secure Context environment and update the value ('securecontext-1-d-vnet') of the "vnetName" input to value of your created Virtual Network.

![Classic Pipeline Subnet Settings](images/SSNSDeploySubnetYAML.png)

## Supported Usage Scenarios

- **[Public Scenario](#public-scenario)**
This scenario allows traffic from the Internet through Akamai KONA Site defender to the Application Gateway. This scenario is intended for external facing applications.

- **[Private Scenario](#private-scenario)**
This scenario only allows traffic from on-premises or Azure Private to Application Gateway. This scenario is intended for internal facing applications.

![Usage Guidance Flow Azure Application Gateway](images/UsageGuidance-AzureApplicationGateway-scenario-decision.png)

# PowerShell Commands

Refer to the [Microsoft Documentation](https://docs.microsoft.com/en-us/powershell/module/az.network) for all available Azure PowerShell cmdlets for Azure Application Gateway.

# Deploying in Secure Context

For more information on how to consume and deploy this template please visit the [Secure Context](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64636/Secure-Context) wiki page.
