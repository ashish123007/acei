﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileResourceProperties = ($templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.Network/applicationGateways" }).properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
}

Describe "Critical Pre-Prod Application Gateway Private" {
    Context "ARM template" {
        It "Should specify Key Vault Secret ID for SSL certificates" {
            $templateFileResourcePropertyNames | Should -Contain "sslCertificates" -ErrorAction Stop

            foreach ($sslCertificate in $templateFileResourceProperties.sslCertificates) {
                $sslCertificate.PSObject.Properties.Name | Should -Contain "properties" -ErrorAction Stop
                $sslCertificate.properties.PSObject.Properties.Name | Should -Contain "keyVaultSecretId"
            }
        }

        It "Should have set the SSL policy type to Predefined and policy name to AppGwSslPolicy20170401S" {
            $templateFileResourcePropertyNames | Should -Contain "sslPolicy" -ErrorAction Stop

            $templateFileResourceProperties.sslPolicy.PSObject.Properties.Name | Should -Contain "policyType" -ErrorAction Stop
            $templateFileResourceProperties.sslPolicy.policyType | Should -BeExactly "Predefined"

            $templateFileResourceProperties.sslPolicy.PSObject.Properties.Name | Should -Contain "policyName" -ErrorAction Stop
            $templateFileResourceProperties.sslPolicy.policyName | Should -BeExactly "AppGwSslPolicy20170401S"
        }
    }
}
