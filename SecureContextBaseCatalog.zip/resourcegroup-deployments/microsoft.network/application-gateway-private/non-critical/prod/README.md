# Description

This ARM template is intended to create a compliant **(Non-Critical)** Application Gateway private with Standard_v2 SKU.

It complies with the following Azure Policies:

- AAB Application Gateway - Certificate Origin DENY v1
- AAB Application Gateway - Diagnostic Settings FSCP DINE v1
- AAB Application Gateway - Diagnostic Settings Sentinel DINE v1
- AAB Application Gateway - HTTP DENY v1
- AAB Application Gateway - Listeners Protocol DENY v1
- AAB Application Gateway - Listener Specific SSL Policy v1
- AAB Application Gateway - Public Networking DENY v1
- AAB Application Gateway - SSL Policy DENY v1
- AAB Application Gateway - Tier Setting DENY v1
- AAB Application Gateway - Web Application Firewall Mode DENY v1
- AAB Application Gateway - Web Application Firewall Status DENY v1

# Prerequisites

- Resource Group
- Key Vault
- User-Assigned Managed Identity with 'Get', 'WrapKey' and 'UnwrapKey' permissions on the Key Vault key

# Documentation

- [AAB Application Gateway v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/65788/AAB-Application-Gateway-v1)
- [Azure PowerShell cmdlets for Application Gateway](https://docs.microsoft.com/en-us/powershell/module/az.network#application-gateway)
