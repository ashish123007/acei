﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileParameters = $templateFileObject.parameters
    $templateFileResourceProperties = ($templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.Network/applicationGateways" }).properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
}

Describe "Critical Application Gateway" {
    Context "ARM template" {
        It "Should have SKU set to WAF_v2" {
            $templateFileResourcePropertyNames | Should -Contain "sku" -ErrorAction Stop
            $templateFileObject.variables.PSObject.Properties.Name | Should -Contain "skuName" -ErrorAction Stop
            $templateFileObject.variables.skuName | Should -BeExactly "WAF_v2"
        }

        It "Should specify Key Vault Secret ID for SSL certificates" {
            $templateFileResourcePropertyNames | Should -Contain "sslCertificates" -ErrorAction Stop

            foreach ($sslCertificate in $templateFileResourceProperties.sslCertificates) {
                $sslCertificate.PSObject.Properties.Name | Should -Contain "properties" -ErrorAction Stop
                $sslCertificate.properties.PSObject.Properties.Name | Should -Contain "keyVaultSecretId"
            }
        }

        It "Should only allow the specific SSL Policy names" {
            $allowedSSLPolicyNames = @(
                "AppGwSslPolicy20170401S",
                "AppGwSslPolicy20220101",
                "AppGwSslPolicy20220101S"
            )

            $templateFileParameters.PSObject.Properties.Name | Should -Contain "policyName" -ErrorAction Stop
            $templateFileParameters.policyName.PSObject.Properties.Name | Should -Contain "allowedValues" -ErrorAction Stop

            foreach ($sslPolicyName in $templateFileParameters.policyName.allowedValues) {
                $allowedSSLPolicyNames | Should -Contain $sslPolicyName
            }
        }
    }
}
