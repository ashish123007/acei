# Description

This ARM template is intended to create a compliant **(Critical)** Application Gateway with WAF_v2 SKU.

It complies with the following Azure Policies:

- AAB Application Gateway - Enforce Key Vault Based Certificate v1
- AAB Application Gateway - Diagnostic Settings FSCP DINE v1
- AAB Application Gateway - Diagnostic Settings Sentinel DINE v1
- AAB Application Gateway - Enforce HTTPS Protocol at Backend Settings v1
- AAB Application Gateway - Enforce HTTPS Protocol at Listeners v1
- AAB Application Gateway - Listener Specific SSL Policy v1
- AAB Application Gateway - SSL Policy v1
- AAB Application Gateway - Tier Setting v1

# Prerequisites

- Resource Group
- Application Gateway

# Documentation

- [AAB Application Gateway v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/65788/AAB-Application-Gateway-v1)
- [Azure PowerShell cmdlets for Application Gateway](https://docs.microsoft.com/en-us/powershell/module/az.network#application-gateway)
