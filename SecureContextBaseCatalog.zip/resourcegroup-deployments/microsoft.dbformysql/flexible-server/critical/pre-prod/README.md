# Description

This ARM template is intended to create a compliant **(Critical)** MySQL Flexible Server.

It complies with the following Azure Policies:

- AAB MySQL Database for Flexible Server - Audit Log Enabled DINE v1
- AAB MySQL Database for Flexible Server - Audit Log Events DINE v1
- AAB MySQL Database for Flexible Server - Audit Log Exclude Users DINE v1
- AAB MySQL Database for Flexible Server - Diagnostic Settings Sentinel DINE v1
- AAB MySQL Database for Flexible Server - Microsoft Managed Keys DENY v1
- AAB MySQL Database for Flexible Server - SSL Settings DINE v1
- AAB MySQL Database for Flexible Server - TLS Settings DINE v1
- Public network access should be disabled for MySQL flexible servers
- Azure MySQL flexible server should have Azure Active Directory Only Authentication enabled

# Prerequisites

- Resource Group
- Azure AD Group or Service Principal to be configured as Azure AD administrator of the MySQL Flexible Server
- Virtual Network and [Subnet with Flexible Server Network pattern (via SSNS)](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/89653/Product-Description)
- Key Vault with Customer-Managed Key to be used for data encryption, with soft-delete enabled and the retention period set to 90 days
- User-Assigned Identity with "get", "list", "unwrapKey", "wrapKey" Key permissions on the Key Vault
- When enabling geo-redundant storage for backup, an additional Key Vault, Customer-Managed Key and User-Assigned Identity are required in another region

# Notes

- [AAB MySQL Database v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/75439/AAB-MySQL-Database-v1)
- [MySQL Flexible Server ARM template resource definition](https://learn.microsoft.com/en-us/azure/templates/microsoft.dbformysql/flexibleservers?pivots=deployment-language-arm-template)
- [Azure PowerShell cmdlets for MySQL](https://learn.microsoft.com/en-us/powershell/module/az.mysql)
