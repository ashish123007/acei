﻿Describe "Non-Critical Pre-Prod MySQL Flexible Server" {
    BeforeAll {
        $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
        $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
        $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
        $templateFileResource = $templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.DBforMySQL/flexibleServers" }
        $templateFileResourceProperties = $templateFileResource.properties
        $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
    }

    Context "ARM template" {
        It "Should have User-Assigned Identity" {
            $templateFileResource.PSObject.Properties.Name | Should -Contain "identity" -ErrorAction Stop
            $templateFileResource.identity.PSObject.Properties.Name | Should -Contain "type" -ErrorAction Stop
            $templateFileResource.identity.type | Should -BeExactly "UserAssigned"
        }

        It "Should use Azure AD authentication" {
            $templateFileAadConfiguration = $templateFileResource.resources | Where-Object -FilterScript { $_.type -eq "configurations" -and $_.name -eq "aad_auth_only" }
            $templateFileAadConfiguration | Should -Not -BeNullOrEmpty -ErrorAction Stop
            $templateFileAadConfiguration.PSObject.Properties.Name | Should -Contain "properties" -ErrorAction Stop
            $templateFileAadConfigurationProperties = $templateFileAadConfiguration.properties
            $templateFileAadConfigurationProperties.PSObject.Properties.Name | Should -Contain "value" -ErrorAction Stop
            $templateFileAadConfigurationProperties.PSObject.Properties.Name | Should -Contain "source" -ErrorAction Stop
            $templateFileAadConfigurationProperties.value | Should -BeExactly "ON"
            $templateFileAadConfigurationProperties.source | Should -BeExactly "user-override"
        }

        It "Should use customer-managed keys to encrypt data at rest" {
            $templateFileResourcePropertyNames | Should -Contain "dataEncryption" -ErrorAction Stop
            $templateFileResourceProperties.dataEncryption.PSObject.Properties.Name | Should -Contain "type" -ErrorAction Stop
            $templateFileResourceProperties.dataEncryption.type | Should -BeExactly "AzureKeyVault"
            $templateFileResourceProperties.dataEncryption.PSObject.Properties.Name | Should -Contain "primaryUserAssignedIdentityId"
            $templateFileResourceProperties.dataEncryption.PSObject.Properties.Name | Should -Contain "primaryKeyURI"

            If ($templateFileResourcePropertyNames -contains "backup" -and $templateFileResourceProperties.backup.PSObject.Properties.Name -contains "geoRedundantBackup") {
                $templateFileResourceProperties.dataEncryption.PSObject.Properties.Name | Should -Contain "geoBackupUserAssignedIdentityId"
                $templateFileResourceProperties.dataEncryption.PSObject.Properties.Name | Should -Contain "geoBackupKeyURI"
            }
        }

        It "Should use VNet Integration" {
            $templateFileResourcePropertyNames | Should -Contain "network" -ErrorAction Stop
            $templateFileResourceProperties.network.PSObject.Properties.Name | Should -Contain "delegatedSubnetResourceId" -ErrorAction Stop
            $templateFileResourceProperties.network.delegatedSubnetResourceId | Should -Not -BeNullOrEmpty
            $templateFileResourceProperties.network.delegatedSubnetResourceId | Should -Not -BeLike "*null*"
        }

        It "Should use Private DNS integration" {
            $templateFileResourcePropertyNames | Should -Contain "network" -ErrorAction Stop
            $templateFileResourceProperties.network.PSObject.Properties.Name | Should -Contain "privateDnsZoneResourceId" -ErrorAction Stop
            $templateFileResourceProperties.network.privateDnsZoneResourceId | Should -Not -BeNullOrEmpty
            $templateFileResourceProperties.network.privateDnsZoneResourceId | Should -Not -BeLike "*null*"
        }
    }
}
