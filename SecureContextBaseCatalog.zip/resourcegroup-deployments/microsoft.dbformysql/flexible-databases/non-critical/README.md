# Description

This ARM template is intended to create a compliant **(Non-Critical)** MySQL Database.

It complies with the following Azure Policies:

- AAB MySQL Database for Flexible Server - AAD Auth Only DINE v1
- AAB MySQL Database for Flexible Server - Audit Log Enabled DINE v1
- AAB MySQL Database for Flexible Server - Audit Log Events DINE v1
- AAB MySQL Database for Flexible Server - Audit Log Exclude Users DINE v1
- AAB MySQL Database for Flexible Server - Diagnostic Settings Sentinel DINE v1
- AAB MySQL Database for Flexible Server - Microsoft Managed Keys DENY v1
- AAB MySQL Database for Flexible Server - SSL Settings DINE v1
- AAB MySQL Database for Flexible Server - TLS Settings DINE v1
- Public network access should be disabled for MySQL flexible servers
- Azure MySQL flexible server should have Azure Active Directory Only Authentication enabled

## Prerequisites

- Resource Group
- MySQL Database for Flexible Server

## Documentation

- [AAB MySQL Database v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/75439/AAB-MySQL-Database-v1)
- [Azure Database for MySQL documentation](https://learn.microsoft.com/en-us/azure/mysql)
- [MySQL Database ARM template resource definition](https://learn.microsoft.com/en-us/azure/templates/microsoft.dbformysql/flexibleservers/databases?pivots=deployment-language-arm-template)
- [Azure PowerShell cmdlets for MySQL](https://learn.microsoft.com/en-us/powershell/module/az.mysql)
