﻿#Requires -Modules @{ ModuleName = "Az.Accounts"; ModuleVersion = "2.17.0" }

<#
.SYNOPSIS
    Add the Service Principal of the Service Connection to MySQL Private DNS Zone Azure AD Group.

.DESCRIPTION
    Add the Service Principal of the Service Connection to MySQL Private DNS Zone Azure AD Group.

.EXAMPLE
    Invoke-MySql-Eng
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ssPtr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR((Get-AzAccessToken -AsSecureString -ErrorAction Stop).Token)

Try {
    $accessToken = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ssPtr)
}
Finally {
    [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ssPtr)
}

$headers = @{
    Authorization = "Bearer $accessToken"
}

Write-Host "Add the Service Principal of the Service Connection to MySql Private DNS Zone Azure AD Group."

Try {
    Invoke-RestMethod `
        -Uri "https://mysql-p-fa.azurewebsites.net/api/AddSpnToMySqlContributorGroup" `
        -ContentType "application/json" `
        -Headers $headers `
        -Method Post `
        -UseBasicParsing
}
Catch {
    Write-Host "Status Code: $($_.Exception.Response.StatusCode.Value__)"

    $errorResponse = $_.Exception.Response.GetResponseStream()

    If ($errorResponse) {
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $responseBody = $reader.ReadToEnd()
        Write-Host "Error Message: $responseBody"
    }
    Else {
        Write-Host "No response body available"
    }
}
