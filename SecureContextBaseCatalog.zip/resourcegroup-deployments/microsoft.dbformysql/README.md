# Secure Context Azure Database for MySQL Flexible Server

[[_TOC_]]

## Azure Database for MySQL Flexible High-Level Description

[Azure Database for MySQL Flexible Server](https://learn.microsoft.com/en-us/azure/mysql/) is a relational database service powered by the MySQL community edition. It's a fully managed database as a service  offering that can handle mission-critical workloads with predictable performance and dynamic scalability. You can secure product sentitive data at-rest and in-motion.

Some key features of Azure Database for MySQL Flexible Server include:

- Zone redundant and same zone high availability.
- Maximum control with the ability to select your scheduled maintenance window.
- Data protection using automatic backups and point-in-time restore for up to 35 days.
- Elastic scaling within seconds.
- Cost optimization controls with low-cost burstable SKU and the ability to stop/start the server.
- Enterprise-grade security, industry-leading compliance, and privacy to protect sensitive data at rest and in motion.
- Monitoring and automation to simplify management and monitoring for large-scale deployments.

## Network topology

Azure Database for MySQL Flexible Server requires to have a dedicated subnet. The database service is meant to be used internally so the preferred way to access the database is using 'Private access'.

## PowerShell Commands

Refer to the [Microsoft Documentation](https://learn.microsoft.com/en-us/powershell/module/az.mysql) for all available Azure PowerShell cmdlets for Azure MySQL Flexible Server.

## Deploying in Secure Context

For more information on how to consume and deploy this template, please visit the [Secure Context](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64636/Secure-Context) wiki page.
