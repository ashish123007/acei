# Secure Context Cosmos DB

[[_TOC_]]

## Cosmos DB High-Level Description

[Azure Cosmos DB](https://docs.microsoft.com/en-us/azure/cosmos-db) is a Microsoft managed multi-model, non-relational Database-as-a-Service (DaaS). The database allows interaction with SQL, MongoDB, Cassandra, Tables and Gremlin API. Azure Cosmos DB is a high-performance, reliable, and secure key-value database you can use to build data-driven applications and websites in the programming language of your choice, without needing to manage infrastructure.

## Network topology

Azure Cosmos DB resides within the Azure Public environment. This environment consists of Azure services with public endpoints.

Following are the allowed traffic flows:

![Connectivity](images/Connectivity.png)

1. From Azure Private to Azure Cosmos DB through Azure Firewall Network Secure Perimeter (NSP).
1. From Azure Private to Azure Cosmos DB through Azure Private Endpoint.
1. From Azure Public to Azure Cosmos DB over the public internet.
1. From on-premises (WORKSQUARE) to Azure Cosmos DB in Azure Public through the on-premises Secure Perimeter (Palo Alto NGFW). Only applies to SQL, Gremlin and Table API traffic using HTTPS or WebSocket Secure over port 443.

# PowerShell Commands

Refer to the [Microsoft Documentation](https://docs.microsoft.com/en-us/powershell/module/az.cosmosdb) for all available Azure PowerShell cmdlets for Azure Cosmos DB.

# Deploying in Secure Context

For more information on how to consume and deploy this template please visit the [Secure Context](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64636/Secure-Context) wiki page.
