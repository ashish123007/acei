# Description

This ARM template will deploy a **(Critical)** MongoDB Database in a Cosmos DB Account for Mongo API.

It applies to the following policies:

- None

## Prerequisites

- Resource Group
- Cosmos DB Account for Mongo API

## Documentation

[AAB Cosmos DB v1 RCF Controls](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64205/AAB-Cosmos-Database-v1)
