# Description

This ARM template will deploy a **(Critical)** Cassandra Keyspace in a Cosmos DB Account for Cassandra API.

It applies to the following policies:

- None

## Prerequisites

- Resource Group
- Cosmos DB Account for Cassandra API

## Documentation

[AAB Cosmos DB v1 RCF Controls](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64205/AAB-Cosmos-Database-v1)
