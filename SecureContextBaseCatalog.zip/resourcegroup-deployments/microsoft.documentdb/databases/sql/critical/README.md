# Description

This ARM template will deploy a **(Critical)** SQL Database in a Cosmos DB Account for Core (SQL) API.

It applies to the following policies:

- None

## Prerequisites

- Resource Group
- Cosmos DB Account for Core (SQL) API

## Documentation

[AAB Cosmos DB v1 RCF Controls](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64205/AAB-Cosmos-Database-v1)
