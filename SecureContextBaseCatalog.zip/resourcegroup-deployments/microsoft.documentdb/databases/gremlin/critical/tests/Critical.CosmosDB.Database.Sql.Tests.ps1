﻿BeforeAll {
    $parentFolder = Split-Path -Path $PSScriptRoot -Parent
    $armFileLocation = Get-ChildItem -Path $parentFolder -Include "azuredeploy.json" -File -Recurse
    $armParametersFileLocation = Get-ChildItem -Path $parentFolder -Include "azuredeploy.parameters.json" -File -Recurse
    $armContent = Get-Content -Path $armFileLocation | ConvertFrom-Json
}

Describe "Non-Critical Cosmos DB Gremlin Database Secure Context" {
    Context "Non-Critical Cosmos DB Gremlin Database Secure Context tests" {
        
    }
}
