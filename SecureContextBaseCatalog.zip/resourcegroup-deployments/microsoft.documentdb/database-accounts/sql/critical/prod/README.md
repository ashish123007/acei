# Description

This ARM template is intended to create a compliant **(Critical)** Cosmos DB Account for Core (SQL) API.

It complies with the following Azure Policies:

- AAB Cosmos DB - Advanced Threat Protection DINE v1
- AAB Cosmos DB - Cross-Origin Resource Sharing DENY v1
- AAB Cosmos DB - Diagnostic Settings FSCP DINE v1
- AAB Cosmos DB - Diagnostic Settings Sentinel DINE v1
- AAB Cosmos DB - Firewall Settings DENY v1
- AAB Cosmos DB - Locations Allowed v1
- AAB Cosmos DB - TLS Settings v1
- Azure Cosmos DB accounts should have firewall rules
- Azure Cosmos DB accounts should use customer-managed keys to encrypt data at rest
- Cosmos DB database accounts should have local authentication methods disabled
- CosmosDB accounts should use private link (Audit)

# Prerequisites

- Resource Group
- Key Vault
- Customer-managed key in Key Vault

# Notes

- [AAB Cosmos Database v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64205/AAB-Cosmos-Database-v1)
- [How to retrieve and set firewall IP ranges for Cosmos DB](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/93970/Firewall-Rules-Retrieve-and-set-firewall-IP-ranges)
- [Azure PowerShell cmdlets for Cosmos DB](https://docs.microsoft.com/en-us/powershell/module/az.cosmosdb)
