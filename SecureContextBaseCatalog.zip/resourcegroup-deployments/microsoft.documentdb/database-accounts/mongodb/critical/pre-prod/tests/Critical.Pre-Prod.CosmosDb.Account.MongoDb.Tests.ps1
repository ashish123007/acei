﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileParameters = $templateFileObject.parameters
    $templateFileResource = $templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.DocumentDB/databaseAccounts" }
    $templateFileResourceProperties = $templateFileResource.properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
}

Describe "Critical Pre-Prod Cosmos DB Account MongoDB" {
    Context "ARM template" {
        It "Should be of type MongoDB" {
            $templateFileResource.PSObject.Properties.Name | Should -Contain "kind" -ErrorAction Stop

            $variableRegex = [regex]::new("(?<=^\[variables\(')(.*)(?='\)\]$)")
            $variableMatch = $variableRegex.Match($templateFileResource.kind)

            if ($variableMatch.Success) {
                $variableName = $variableMatch.Value
                $templateFileObject.variables.PSObject.Properties.Name | Should -Contain $variableName -ErrorAction Stop
                $templateFileObject.variables.$variableName | Should -BeExactly "MongoDB"
            }
            else {
                $templateFileResource.kind | Should -BeExactly "MongoDB"
            }
        }

        It "Should not have default IP rules configured" {
            $templateFileParameters.PSObject.Properties.Name | Should -Contain "ipRules" -ErrorAction Stop
            $templateFileParameters.ipRules.PSObject.Properties.Name | Should -Not -Contain "defaultValue"
        }

        It "Should have server version element" {
            $templateFileResourcePropertyNames | Should -Contain "apiProperties" -ErrorAction Stop

            if ($templateFileResourceProperties.apiProperties.PSObject.Properties.Name.Contains("serverVersion")) {
                $serverVersion = $templateFileResourceProperties.apiProperties.serverVersion
            }
            else {
                $variableRegex = [regex]::new("(?<=^\[variables\(')(.*)(?='\)\]$)")
                $variableMatch = $variableRegex.Match($templateFileResourceProperties.apiProperties)
                $variableMatch.Success | Should -BeTrue -ErrorAction Stop

                $variableName = $variableMatch.Value
                $templateFileObject.variables.PSObject.Properties.Name | Should -Contain $variableName -ErrorAction Stop
                $templateFileObject.variables.$variableName.PSObject.Properties.Name | Should -BeExactly "serverVersion" -ErrorAction Stop
                $serverVersion = $templateFileObject.variables.$variableName.serverVersion
            }

            $parameterRegex = [regex]::new("(?<=^\[parameters\(')(.*)(?='\)\]$)")
            $parameterMatch = $parameterRegex.Match($serverVersion)
            $parameterMatch.Success | Should -BeTrue -ErrorAction Stop

            $parameterName = $parameterMatch.Value
            $templateFileParameters.PSObject.Properties.Name | Should -Contain $parameterName
        }

        It "Should have multiple write locations enabled" {
            $templateFileResourcePropertyNames | Should -Contain "enableMultipleWriteLocations" -ErrorAction Stop
            $templateFileResourceProperties.enableMultipleWriteLocations | Should -BeOfType [bool] -ErrorAction Stop
            $templateFileResourceProperties.enableMultipleWriteLocations | Should -BeTrue
        }

        It "Should have key based metadata write access disabled" {
            $templateFileResourcePropertyNames | Should -Contain "disableKeyBasedMetadataWriteAccess" -ErrorAction Stop
            $templateFileResourceProperties.disableKeyBasedMetadataWriteAccess | Should -BeOfType [bool] -ErrorAction Stop
            $templateFileResourceProperties.disableKeyBasedMetadataWriteAccess | Should -BeTrue
        }

        It "Should use customer managed keys" {
            $templateFileResourcePropertyNames | Should -Contain "keyVaultKeyUri" -ErrorAction Stop
            $templateFileResourceProperties.keyVaultKeyUri | Should -Not -BeNullOrEmpty
        }

        It "Should not use a wildcard for CORS allowed origins" {
            if ($templateFileResourcePropertyNames.Contains("cors")) {
                foreach ($corsPolicy in $templateFileResourceProperties.cors) {
                    $corsPolicy.allowedOrigins | Should -Not -BeExactly "*"
                }
            }
        }
    }
}
