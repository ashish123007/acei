﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileParameters = $templateFileObject.parameters
    $templateFileResource = $templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.DocumentDB/databaseAccounts" }
    $templateFileResourceProperties = $templateFileResource.properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
}

Describe "Critical Prod Cosmos DB Account Gremlin" {
    Context "ARM template" {
        It "Should be of type GlobalDocumentDB" {
            $templateFileResource.PSObject.Properties.Name | Should -Contain "kind" -ErrorAction Stop

            $variableRegex = [regex]::new("(?<=^\[variables\(')(.*)(?='\)\]$)")
            $variableMatch = $variableRegex.Match($templateFileResource.kind)

            if ($variableMatch.Success) {
                $variableName = $variableMatch.Value
                $templateFileObject.variables.PSObject.Properties.Name | Should -Contain $variableName -ErrorAction Stop
                $templateFileObject.variables.$variableName | Should -BeExactly "GlobalDocumentDB"
            }
            else {
                $templateFileResource.kind | Should -BeExactly "GlobalDocumentDB"
            }
        }

        It "Should not have default IP rules configured" {
            $templateFileParameters.PSObject.Properties.Name | Should -Contain "ipRules" -ErrorAction Stop
            $templateFileParameters.ipRules.PSObject.Properties.Name | Should -Not -Contain "defaultValue"
        }

        It "Should be enabled for Gremlin" {
            $templateFileResourcePropertyNames | Should -Not -Contain "apiProperties"
            $templateFileResourcePropertyNames | Should -Contain "capabilities" -ErrorAction Stop

            $variableRegex = [regex]::new("(?<=^\[variables\(')(.*)(?='\)\]$)")
            $variableMatch = $variableRegex.Match($templateFileResourceProperties.capabilities)

            if ($variableMatch.Success) {
                $variableName = $variableMatch.Value
                $templateFileObject.variables.PSObject.Properties.Name | Should -Contain $variableName -ErrorAction Stop
                ($templateFileObject.variables.$variableName | Get-Member -MemberType NoteProperty).Name | Should -Contain "name" -ErrorAction Stop
                $templateFileObject.variables.$variableName.name | Should -BeExactly "EnableGremlin"
            }
            else {
                ($templateFileResourceProperties.capabilities | Get-Member -MemberType NoteProperty).Name | Should -Contain "name" -ErrorAction Stop
                $templateFileResourceProperties.capabilities.name | Should -BeExactly "EnableGremlin"
            }
        }

        It "Should have multiple write locations enabled" {
            $templateFileResourcePropertyNames | Should -Contain "enableMultipleWriteLocations" -ErrorAction Stop
            $templateFileResourceProperties.enableMultipleWriteLocations | Should -BeOfType [bool] -ErrorAction Stop
            $templateFileResourceProperties.enableMultipleWriteLocations | Should -BeTrue
        }

        It "Should have key based metadata write access disabled" {
            $templateFileResourcePropertyNames | Should -Contain "disableKeyBasedMetadataWriteAccess" -ErrorAction Stop
            $templateFileResourceProperties.disableKeyBasedMetadataWriteAccess | Should -BeOfType [bool] -ErrorAction Stop
            $templateFileResourceProperties.disableKeyBasedMetadataWriteAccess | Should -BeTrue
        }

        It "Should use customer managed keys" {
            $templateFileResourcePropertyNames | Should -Contain "keyVaultKeyUri" -ErrorAction Stop
            $templateFileResourceProperties.keyVaultKeyUri | Should -Not -BeNullOrEmpty
        }

        It "Should not use a wildcard for CORS allowed origins" {
            if ($templateFileResourcePropertyNames.Contains("cors")) {
                foreach ($corsPolicy in $templateFileResourceProperties.cors) {
                    $corsPolicy.allowedOrigins | Should -Not -BeExactly "*"
                }
            }
        }
    }
}
