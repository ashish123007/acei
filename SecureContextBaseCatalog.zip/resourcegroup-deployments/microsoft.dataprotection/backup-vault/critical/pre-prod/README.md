# Description

This ARM template is intended to create a compliant **(Critical)** Azure Backup Vault.

It complies with the following Azure Policies:

- AAB Backup Vault - Diagnostic Settings FSCP DINE v1
- [Preview]: Azure Backup Vaults should use customer-managed keys for encrypting backup data. Also an option to enforce Infra Encryption.

# Prerequisites

- Resource Group
- Key Vault
- Customer-managed key in Key Vault
- User-Assigned Managed Identity (only for the initial deployment of the Azure Backup Vault and subresources)
- Storage Account with an empty blob container

# Notes

- [AAB Azure Backup Vault v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/110090/AAB-Azure-Backup-Vault-v1)
