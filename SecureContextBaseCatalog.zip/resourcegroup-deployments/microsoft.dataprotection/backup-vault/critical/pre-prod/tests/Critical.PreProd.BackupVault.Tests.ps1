BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileParameters = $templateFileObject.parameters
    $templateFileResource = $templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.DataProtection/backupVaults" }
    $templateFileResourceProperties = $templateFileResource.properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
}

Describe "Critical Pre-Prod Azure Backup Vault" {
    Context "ARM template" {
        It "Should use Customer-Managed Keys" {
            $templateFileResourcePropertyNames | Should -Contain "securitySettings" -ErrorAction Stop
            $templateFileResourceProperties.securitySettings.PSObject.Properties.Name | Should -Contain "encryptionSettings" -ErrorAction Stop
            $encryptionSettings = $templateFileResourceProperties.securitySettings.encryptionSettings
            $encryptionSettings.PSObject.Properties.Name | Should -Contain "state" -ErrorAction Stop
            $encryptionSettings.state | Should -BeExactly "Enabled"
            $encryptionSettings.PSObject.Properties.Name | Should -Contain "keyVaultProperties" -ErrorAction Stop
            $encryptionSettings.keyVaultProperties.PSObject.Properties.Name | Should -Contain "keyUri" -ErrorAction Stop
            $encryptionSettings.keyVaultProperties.keyUri | Should -Not -BeNullOrEmpty
        }
    }
}
