﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileParameters = $templateFileObject.parameters
    $templateFileResources = $templateFileObject.resources
    $diskEncryptionSetResource = $templateFileResources | Where-Object -FilterScript { $_.type -eq "Microsoft.Compute/diskEncryptionSets" }
    $diskEncryptionSetResourceProperties = $diskEncryptionSetResource.properties
    $keyVaultResourceProperties = ($templateFileResources | Where-Object -FilterScript { $_.type -eq "Microsoft.KeyVault/vaults/accessPolicies" }).properties
}

Describe "Non-Critical Pre-Prod Disk Encryption Set" {
    Context "ARM template" {
        It "Should configure encryption type" {
            $diskEncryptionSetResourceProperties.PSObject.Properties.Name | Should -Contain "encryptionType" -ErrorAction Stop

            $parameterRegex = [regex]::new("(?<=^\[parameters\(')(.*)(?='\)\]$)")
            $parameterMatch = $parameterRegex.Match($diskEncryptionSetResourceProperties.encryptionType)
            $parameterMatch.Success | Should -BeTrue -ErrorAction Stop
            $parameterName = $parameterMatch.Value
            $templateFileParameters.PSObject.Properties.Name | Should -Contain $parameterName -ErrorAction Stop

            $templateFileParameters.$parameterName.PSObject.Properties.Name | Should -Contain "defaultValue" -ErrorAction Stop
            $templateFileParameters.$parameterName.defaultValue | Should -BeExactly "EncryptionAtRestWithCustomerKey" -ErrorAction Stop

            $allowedEncryptionTypes = "EncryptionAtRestWithCustomerKey", "EncryptionAtRestWithPlatformAndCustomerKeys"
            $templateFileParameters.$parameterName.PSObject.Properties.Name | Should -Contain "allowedValues" -ErrorAction Stop
            foreach ($encryptionType in $templateFileParameters.$parameterName.allowedValues) {
                $allowedEncryptionTypes | Should -Contain $encryptionType
            }
        }

        It "Should have System-Assigned Managed Identity" {
            $diskEncryptionSetResource.PSObject.Properties.Name | Should -Contain "identity" -ErrorAction Stop
            $diskEncryptionSetResource.identity.PSObject.Properties.Name | Should -Contain "type" -ErrorAction Stop
            $diskEncryptionSetResource.identity.type | Should -BeExactly "SystemAssigned"
        }

        It "Should have Key Vault access policy for System-Assigned Managed Identity" {
            $keyVaultResourceProperties.PSObject.Properties.Name | Should -Contain "accessPolicies" -ErrorAction Stop
            ($keyVaultResourceProperties.accessPolicies | Get-Member -MemberType NoteProperty).Name | Sort-Object | Should -BeExactly "objectId", "permissions", "tenantId" -ErrorAction Stop

            $variableRegex = [regex]::new("(?<=\[.*variables\(')(.*)(?='\),.*\).identity.principalId\])")
            $variableMatch = $variableRegex.Match($keyVaultResourceProperties.accessPolicies.objectId)

            if ($variableMatch.Success) {
                $variableName = $variableMatch.Value
                $templateFileObject.variables.PSObject.Properties.Name | Should -Contain $variableName -ErrorAction Stop
                $templateFileObject.variables.$variableName | Should -MatchExactly "^\[resourceId\('Microsoft.Compute/diskEncryptionSets', parameters\('diskEncryptionSetName'\)\)\]"
            }
            else {
                $keyVaultResourceProperties.accessPolicies.objectId | Should -MatchExactly "^\[reference\(resourceId\('Microsoft.Compute/diskEncryptionSets', parameters\('diskEncryptionSetName'\)\),.*\)\.identity\.principalId\]"
            }

            $keyVaultResourceProperties.accessPolicies.permissions.PSObject.Properties.Name | Should -Contain "keys" -ErrorAction Stop
            $keyVaultResourceProperties.accessPolicies.permissions.keys | Sort-Object | Should -BeExactly "get", "unwrapKey", "wrapKey"

            $keyVaultResourceProperties.accessPolicies.tenantId | Should -BeExactly "[subscription().tenantId]"
        }
    }
}
