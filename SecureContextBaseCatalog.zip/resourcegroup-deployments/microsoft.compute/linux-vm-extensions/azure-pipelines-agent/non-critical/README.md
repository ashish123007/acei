# Description

This ARM template is intended to create a compliant **(Non-Critical)** Azure Pipelines Agent.

It complies with the following Azure Policies:

- AAB Linux Virtual Machine - Extensions AINE v1
- AAB Linux Virtual Machine - Public Endpoint AUDIT v1

# Prerequisites

- Resource Group
- Linux VM
- Azure DevOps project, with PAT token with Deployment Groups (Read & manage) access scope

# Notes

- [AAB Linux VM v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/65349/AAB-Linux-VM-v1)
- [Azure PowerShell cmdlets for Virtual Machines](https://docs.microsoft.com/en-us/powershell/module/az.compute)
