# Secure Context Windows Virtual Machine

[[_TOC_]]

## Windows Virtual Machine High-Level Description

[Windows Virtual Machines](https://docs.microsoft.com/en-us/azure/virtual-machines/) (VM) is one of several types of on-demand, scalable computing resources that Azure offers. Typically, you choose a VM when you need more control over the computing environment than the other choices offer.

## Virtual Machine Integrations

To deploy a Virtual Machine in a FSCP 3.0 environment you have to configure a couple of things. You need to setup the following:

- Join the Virtual Machine to a Domain
- Add a PIM role to your Resource Group
- Enable JIT on your Virtual Machine
- To do this you can make use of a set of API's.

[Using Virtual Machine Integrations](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/71577/Using-virtual-machine-integrations)

# PowerShell Commands

Refer to the [Microsoft Documentation](https://docs.microsoft.com/en-us/powershell/module/az.compute) for all available Azure PowerShell cmdlets for Windows Virtual Machine.

# Deploying in Secure Context

For more information on how to consume and deploy this template please visit the [Secure Context](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64636/Secure-Context) wiki page.

# Domain join error handling

More information about possible errors during the join domain process and solutions of how to handle them visit the [Resolving-domain-join-errors](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/74000/Resolving-domain-join-errors) wiki page.

# Prerequisites to domain join

Information regarding prerequisites that has to be arranged to successfully join to the domain and some important requirements are mentioned here: [Linux VM](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/74884/Virtual-Machine-Linux?anchor=domain-join) / [Windows VM](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/74458/Virtual-Machine-Windows?anchor=deploy-a-virtual-machine).

# Process of Domain Object creation

Process of creation of new Domain Object ( Computer Object ) used by the Function App is described on wiki page [VirtualMachine-DomainObject-Creation-FSCP3.0](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/68004/VirtualMachine-DomainObject-Creation-FSCP3.0)
