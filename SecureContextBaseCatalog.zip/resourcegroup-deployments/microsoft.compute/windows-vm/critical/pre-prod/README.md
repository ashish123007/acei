# Description

This ARM template is intended to create a compliant **(Critical)** Windows VM.

It complies with the following Azure Policies:

- AAB Windows Virtual Machine - Extensions AINE v1
- AAB Windows Virtual Machine - Public Endpoint AUDIT v1

# Prerequisites

- Resource Group
- Disk Encryption Set
- Virtual Network, with subnet with IaaS pattern (via SSNS)

# Notes

- [AAB Windows VM v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/65349/AAB-Windows-VM-v1)
- [Azure PowerShell cmdlets for Virtual Machines](https://docs.microsoft.com/en-us/powershell/module/az.compute)
