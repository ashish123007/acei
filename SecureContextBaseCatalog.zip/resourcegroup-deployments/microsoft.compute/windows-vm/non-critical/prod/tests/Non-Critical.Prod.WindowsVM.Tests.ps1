﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileParameters = $templateFileObject.parameters
    $templateFileResources = $templateFileObject.resources
    $virtualMachineResource = $templateFileResources | Where-Object -FilterScript { $_.type -eq "Microsoft.Compute/virtualMachines" }
    $virtualMachineResourceProperties = $virtualMachineResource.properties
    $networkInterfaceResourceProperties = ($templateFileResources | Where-Object -FilterScript { $_.type -eq "Microsoft.Network/networkInterfaces" }).properties
}

Describe "Non-Critical Prod Windows VM" {
    Context "ARM template" {
        It "Should have System-Assigned Managed Identity" {
            $virtualMachineResource.PSObject.Properties.Name | Should -Contain "identity" -ErrorAction Stop
            $virtualMachineResource.identity.PSObject.Properties.Name | Should -Contain "type" -ErrorAction Stop
            $virtualMachineResource.identity.type | Should -BeExactly "SystemAssigned"
        }

        It "Should provision VM agent" {
            $virtualMachineResourceProperties.PSObject.Properties.Name | Should -Contain "osProfile" -ErrorAction Stop
            $virtualMachineResourceProperties.osProfile.PSObject.Properties.Name | Should -Contain "windowsConfiguration" -ErrorAction Stop
            $virtualMachineResourceProperties.osProfile.windowsConfiguration.PSObject.Properties.Name | Should -Contain "provisionVMAgent" -ErrorAction Stop
            $virtualMachineResourceProperties.osProfile.windowsConfiguration.provisionVMAgent | Should -BeOfType [bool] -ErrorAction Stop
            $virtualMachineResourceProperties.osProfile.windowsConfiguration.provisionVMAgent | Should -BeTrue
        }

        It "Should configure automatic Virtual Machine guest patching and reporting" {
            $virtualMachineResourceProperties.PSObject.Properties.Name | Should -Contain "osProfile" -ErrorAction Stop
            $virtualMachineResourceProperties.osProfile.PSObject.Properties.Name | Should -Contain "windowsConfiguration" -ErrorAction Stop
            $virtualMachineResourceProperties.osProfile.windowsConfiguration.PSObject.Properties.Name | Should -Contain "patchSettings" -ErrorAction Stop
            $virtualMachineResourceProperties.osProfile.windowsConfiguration.patchSettings.PSObject.Properties.Name | Should -Contain "patchMode" -ErrorAction Stop
            $virtualMachineResourceProperties.osProfile.windowsConfiguration.patchSettings.PSObject.Properties.Name | Should -Contain "assessmentMode" -ErrorAction Stop

            $parameterRegex = [regex]::new("(?<=^\[parameters\(')(.*)(?='\)\]$)")
            $parameterMatch = $parameterRegex.Match($virtualMachineResourceProperties.osProfile.windowsConfiguration.patchSettings.patchMode)
            $parameterMatch.Success | Should -BeTrue -ErrorAction Stop
            $parameterName = $parameterMatch.Value
            $templateFileParameters.PSObject.Properties.Name | Should -Contain $parameterName -ErrorAction Stop

            $templateFileParameters.$parameterName.PSObject.Properties.Name | Should -Contain "defaultValue" -ErrorAction Stop
            $templateFileParameters.$parameterName.defaultValue | Should -BeExactly "AutomaticByPlatform" -ErrorAction Stop

            $allowedPatchModes = "AutomaticByOS", "Manual", "AutomaticByPlatform"
            $templateFileParameters.$parameterName.PSObject.Properties.Name | Should -Contain "allowedValues" -ErrorAction Stop
            foreach ($patchMode in $templateFileParameters.$parameterName.allowedValues) {
                $allowedPatchModes | Should -Contain $patchMode
            }

            $virtualMachineResourceProperties.osProfile.windowsConfiguration.patchSettings.assessmentMode | Should -BeExactly "AutomaticByPlatform" -ErrorAction Stop
        }

        It "Should have Managed Disk encrypted by Disk Encryption Set" {
            $virtualMachineResourceProperties.PSObject.Properties.Name | Should -Contain "storageProfile" -ErrorAction Stop
            $virtualMachineResourceProperties.storageProfile.PSObject.Properties.Name | Should -Contain "osDisk" -ErrorAction Stop
            $virtualMachineResourceProperties.storageProfile.osDisk.PSObject.Properties.Name | Should -Contain "managedDisk" -ErrorAction Stop
            $virtualMachineResourceProperties.storageProfile.osDisk.managedDisk.PSObject.Properties.Name | Should -Contain "diskEncryptionSet" -ErrorAction Stop
            $virtualMachineResourceProperties.storageProfile.osDisk.managedDisk.diskEncryptionSet.PSObject.Properties.Name | Should -Contain "id" -ErrorAction Stop
            $virtualMachineResourceProperties.storageProfile.osDisk.managedDisk.diskEncryptionSet.id | Should -Not -BeNullOrEmpty
        }

        It "Should not have public IP address" {
            $networkInterfaceResourceProperties.PSObject.Properties.Name | Should -Contain "ipConfigurations" -ErrorAction Stop
            ($networkInterfaceResourceProperties.ipConfigurations | Get-Member -MemberType NoteProperty).Name | Should -Contain "properties" -ErrorAction Stop
            $networkInterfaceResourceProperties.ipConfigurations.properties.PSObject.Properties.Name | Should -Not -Contain "publicIPAddress"
        }
    }
}
