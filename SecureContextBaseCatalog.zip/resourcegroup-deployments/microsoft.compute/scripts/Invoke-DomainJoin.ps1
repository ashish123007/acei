#Requires -Modules @{ ModuleName = "Az.Accounts"; ModuleVersion = "2.17.0" }

<#
.SYNOPSIS
    Joins a Virtual Machine to the Launcher Active Directory domain.

.DESCRIPTION
    Joins a Virtual Machine to the Launcher Active Directory domain.

.PARAMETER SubscriptionId
    The optional ID of the Subscription.

.PARAMETER ResourceGroupName
    The name of the Resource Group.

.PARAMETER VirtualMachineName
    The name of the Virtual Machine.

.PARAMETER LocalAdminGroupName
    The name of the Launcher Active Directory security group to configure as local admin group on the Virtual Machine.

.PARAMETER TimeoutInMinutes
    The optional time in minutes to wait for domain join completion.

.EXAMPLE
    Invoke-DomainJoin -ResourceGroupName <ResourceGroupName> -VirtualMachineName <VirtualMachineName> -LocalAdminGroupName <LocalAdminGroupName>

.EXAMPLE
    Invoke-DomainJoin -SubscriptionId <SubscriptionId> -ResourceGroupName <ResourceGroupName> -VirtualMachineName <VirtualMachineName> -LocalAdminGroupName <LocalAdminGroupName>

.EXAMPLE
    Get-AzVM -Name <VirtualMachineName> -ResourceGroupName <ResourceGroupName> | Invoke-DomainJoin -LocalAdminGroupName <LocalAdminGroupName>
#>

[CmdletBinding(SupportsShouldProcess = $true)]
Param (
    [Parameter(Mandatory = $false)]
    [String] $SubscriptionId,

    [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
    [String] $ResourceGroupName,

    [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
    [Alias("Name")]
    [String] $VirtualMachineName,

    [Parameter(Mandatory = $true)]
    [String] $LocalAdminGroupName,

    [Parameter(Mandatory = $false)]
    [ValidateRange(1, [Int]::MaxValue)]
    [Int] $TimeoutInMinutes = 15
)

Process {
    If (-not $SubscriptionId) {
        $SubscriptionId = (Get-AzContext).Subscription.Id
    }
    ElseIf ((Get-AzContext).Subscription.Id -ne $SubscriptionId) {
        Write-Verbose "Setting the current context to Subscription ID '$SubscriptionId'."
        Set-AzContext -Subscription $SubscriptionId -WhatIf:$false | Out-Null
    }

    Write-Verbose "Retrieving Virtual Machine '$VirtualMachineName' in Resource Group '$ResourceGroupName'."
    $vm = Get-AzVM -Name $VirtualMachineName -ResourceGroupName $ResourceGroupName

    Write-Verbose "Retrieving status of Virtual Machine '$VirtualMachineName' in Resource Group '$ResourceGroupName'."
    $vmStatus = Get-AzVM -Name $VirtualMachineName -ResourceGroupName $ResourceGroupName -Status
    If ($vmStatus.Statuses[1].DisplayStatus -ne "VM running") {
        Throw "Virtual Machine '$VirtualMachineName' in Resource Group '$ResourceGroupName' must be running to join it to the domain."
    }

    $body = ConvertTo-Json -InputObject @{
        SubscriptionId      = $SubscriptionId
        ResourceGroupName   = $ResourceGroupName
        VirtualMachineName  = $VirtualMachineName
        LocalAdminGroupName = $LocalAdminGroupName
    }

    $uri = "https://virtualmachinedomainjoin-p-func.azurewebsites.net/api/TriggerDomainJoin"

    $ssPtr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR((Get-AzAccessToken -AsSecureString -ErrorAction Stop).Token)

    Try {
        $accessToken = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ssPtr)
    }
    Finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ssPtr)
    }

    $headers = @{
        Authorization = "Bearer $accessToken"
    }

    Write-Host "Joining Virtual Machine '$VirtualMachineName' in Resource Group '$ResourceGroupName' to the domain."
    If ($PSCmdlet.ShouldProcess($uri, "Invoke-RestMethod")) {
        $result = Invoke-RestMethod -Method POST -Uri $uri -ContentType "application/json" -Headers $headers -Body $body

        Write-Host "Waiting for domain join of Virtual Machine '$VirtualMachineName' in Resource Group '$ResourceGroupName' to complete."

        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

        Do {
            Start-Sleep -Seconds 5

            $statusResult = Invoke-RestMethod -Method Get -Uri $result.statusQueryGetUri
        }
        While ($statusResult.runtimeStatus -match "Pending|Running" -and $stopwatch.Elapsed.TotalMinutes -lt $TimeoutInMinutes)

        $stopwatch.Stop()

        $totalSeconds = [Int][Math]::Round($stopwatch.Elapsed.TotalSeconds, [MidpointRounding]::AwayFromZero)

        Switch -Regex ($statusResult.runtimeStatus) {
            "Completed" {
                Write-Host "Domain join of Virtual Machine '$VirtualMachineName' in Resource Group '$ResourceGroupName' completed in $totalSeconds seconds."
            }
            "Failed" {
                Throw "Domain join of Virtual Machine '$VirtualMachineName' in Resource Group '$ResourceGroupName' failed after $totalSeconds seconds. Output: $($statusResult.output)."
            }
            "Pending|Running" {
                Throw "Domain join of Virtual Machine '$VirtualMachineName' in Resource Group '$ResourceGroupName' did not complete before timeout period of $TimeoutInMinutes minutes was reached. Runtime status: '$($statusResult.runtimeStatus)'."
            }
            Default {
                Throw "Domain join of Virtual Machine '$VirtualMachineName' in Resource Group '$ResourceGroupName' returned an unknown status after $totalSeconds seconds. Runtime status: '$($statusResult.runtimeStatus)'. Output: $($statusResult.output)."
            }
        }
    }
}
