# Description

This ARM template is intended to create a compliant **(Non-Critical)** Linux VM.

All the allowed versions of Red Hat Enterprise Linux (RHEL) are supported by Automatic VM Guest Patching.

It complies with the following Azure Policies:

- AAB Linux Virtual Machine - Extensions AINE v1
- AAB Linux Virtual Machine - Public Endpoint AUDIT v1

# Prerequisites

- Resource Group
- Disk Encryption Set
- Key Vault with a Key
- Virtual Network, with subnet with IaaS pattern (via SSNS)

# Notes

- [AAB Linux VM v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/65349/AAB-Linux-VM-v1)
- [Azure PowerShell cmdlets for Virtual Machines](https://docs.microsoft.com/en-us/powershell/module/az.compute)
- [Automatic VM guest patching supported OS images](https://learn.microsoft.com/en-us/azure/virtual-machines/automatic-vm-guest-patching#supported-os-images)
