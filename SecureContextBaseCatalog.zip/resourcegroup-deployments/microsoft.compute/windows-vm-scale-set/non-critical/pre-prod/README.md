# Description

This ARM template is intended to create a compliant **(Non-Critical)** Windows Virtual Machine Scale Set.

It complies with the following Azure Policies:

- AAB Platform - Network Interface Public IP Association DENY v1
- AAB Virtual Machine Scale Set - ImageReference DENY v1
- AAB Virtual Machine Scale Set - OS Upgrade DENY v1
- Audit VMs that do not use managed disks
- Configure Windows virtual machine scale sets to run Azure Monitor Agent using system-assigned managed identity

# Prerequisites

- Compute Gallery (Owned by FSCP)
- Windows Image Definition (Owned by FSCP)
- Disk Encryption Set
- Virtual Network
- Subnet

# Notes

- [AAB Virtual Machine Scale Sets v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/83786/AAB-Virtual-Machine-Scale-Sets-v1)
- [Azure PowerShell cmdlets for Virtual Machine Scale Sets](https://learn.microsoft.com/en-us/powershell/module/az.compute/?view=azps-9.4.0#vm-scale-sets)
