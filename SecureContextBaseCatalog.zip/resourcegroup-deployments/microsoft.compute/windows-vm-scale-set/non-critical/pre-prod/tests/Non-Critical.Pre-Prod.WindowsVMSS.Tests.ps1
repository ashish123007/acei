BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $vmssResource = $templateFileObject.resources
    $vmssResourceProperties = $vmssResource.properties
}

Describe "Non-Critical Pre-Prod Windows VMSS" {
    Context "ARM template" {
        It "Should apply OS upgrades automatically" {
            $vmssResourceProperties.PSObject.Properties.Name | Should -Contain "upgradePolicy" -ErrorAction Stop
            $vmssResourceProperties.upgradePolicy.PSObject.Properties.Name | Should -Contain "automaticOSUpgradePolicy" -ErrorAction Stop
            $vmssResourceProperties.upgradePolicy.automaticOSUpgradePolicy.PSObject.Properties.Name | Should -Contain "enableAutomaticOSUpgrade" -ErrorAction Stop
            $vmssResourceProperties.upgradePolicy.automaticOSUpgradePolicy.enableAutomaticOSUpgrade | Should -BeOfType [bool] -ErrorAction Stop
            $vmssResourceProperties.upgradePolicy.automaticOSUpgradePolicy.enableAutomaticOSUpgrade | Should -BeTrue

            $vmssResourceProperties.PSObject.Properties.Name | Should -Contain "virtualMachineProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.PSObject.Properties.Name | Should -Contain "osProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.osProfile.PSObject.Properties.Name | Should -Contain "windowsConfiguration" -ErrorAction Stop

            If ($vmssResourceProperties.virtualMachineProfile.osProfile.windowsConfiguration.PSObject.Properties.Name -contains "enableAutomaticUpdates") {
                $vmssResourceProperties.virtualMachineProfile.osProfile.windowsConfiguration.enableAutomaticUpdates | Should -BeOfType [bool] -ErrorAction Stop
                $vmssResourceProperties.virtualMachineProfile.osProfile.windowsConfiguration.enableAutomaticUpdates | Should -BeFalse
            }
        }

        It "Should have Application Health extension to determine upgrade operation eligibility" {
            $vmssResourceProperties.PSObject.Properties.Name | Should -Contain "virtualMachineProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.PSObject.Properties.Name | Should -Contain "extensionProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.extensionProfile.PSObject.Properties.Name | Should -Contain "extensions" -ErrorAction Stop
            ($vmssResourceProperties.virtualMachineProfile.extensionProfile.extensions | Get-Member -MemberType NoteProperty).Name | Should -Contain "type" -ErrorAction Stop
            ($vmssResourceProperties.virtualMachineProfile.extensionProfile.extensions | Get-Member -MemberType NoteProperty).Name | Should -Contain "name" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.extensionProfile.extensions.name | Should -Contain "HealthExtension" -ErrorAction Stop

            $healthExtension = $vmssResourceProperties.virtualMachineProfile.extensionProfile.extensions | Where-Object -FilterScript { $_.name -eq "HealthExtension" }
            $healthExtension.PSObject.Properties.Name | Should -Contain "properties" -ErrorAction Stop
            $healthExtension.properties.PSObject.Properties.Name | Should -Contain "publisher" -ErrorAction Stop
            $healthExtension.properties.PSObject.Properties.Name | Should -Contain "type" -ErrorAction Stop
            $healthExtension.properties.publisher | Should -BeExactly "Microsoft.ManagedServices"
            $healthExtension.properties.type | Should -BeExactly "ApplicationHealthWindows"
        }

        It "Should have Azure Monitor Agent extension" {
            $vmssResourceProperties.PSObject.Properties.Name | Should -Contain "virtualMachineProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.PSObject.Properties.Name | Should -Contain "extensionProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.extensionProfile.PSObject.Properties.Name | Should -Contain "extensions" -ErrorAction Stop
            ($vmssResourceProperties.virtualMachineProfile.extensionProfile.extensions | Get-Member -MemberType NoteProperty).Name | Should -Contain "type" -ErrorAction Stop
            ($vmssResourceProperties.virtualMachineProfile.extensionProfile.extensions | Get-Member -MemberType NoteProperty).Name | Should -Contain "name" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.extensionProfile.extensions.name | Should -Contain "AzureMonitorWindowsAgent" -ErrorAction Stop

            $azureMonitorAgent = $vmssResourceProperties.virtualMachineProfile.extensionProfile.extensions | Where-Object -FilterScript { $_.name -eq "AzureMonitorWindowsAgent" }
            $azureMonitorAgent.PSObject.Properties.Name | Should -Contain "properties" -ErrorAction Stop
            $azureMonitorAgent.properties.PSObject.Properties.Name | Should -Contain "publisher" -ErrorAction Stop
            $azureMonitorAgent.properties.PSObject.Properties.Name | Should -Contain "type" -ErrorAction Stop
            $azureMonitorAgent.properties.publisher | Should -BeExactly "Microsoft.Azure.Monitor"
            $azureMonitorAgent.properties.type | Should -BeExactly "AzureMonitorWindowsAgent"
        }

        It "Should use FSCP owned Gallery Image" {
            $vmssResourceProperties.PSObject.Properties.Name | Should -Contain "virtualMachineProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.PSObject.Properties.Name | Should -Contain "storageProfile" -ErrorAction Stop

            $vmssResourceProperties.virtualMachineProfile.storageProfile.PSObject.Properties.Name | Should -Contain "osDisk" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.storageProfile.osDisk.PSObject.Properties.Name | Should -Not -Contain "image"
            $vmssResourceProperties.virtualMachineProfile.storageProfile.osDisk.PSObject.Properties.Name | Should -Not -Contain "osType"
            $vmssResourceProperties.virtualMachineProfile.storageProfile.osDisk.PSObject.Properties.Name | Should -Not -Contain "vhdContainers"
            $vmssResourceProperties.virtualMachineProfile.storageProfile.osDisk.PSObject.Properties.Name | Should -Contain "createOption" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.storageProfile.osDisk.createOption | Should -BeExactly "FromImage"

            $vmssResourceProperties.virtualMachineProfile.storageProfile.PSObject.Properties.Name | Should -Contain "imageReference" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.storageProfile.imageReference.PSObject.Properties.Name | Should -Not -Contain "communityGalleryImageId"
            $vmssResourceProperties.virtualMachineProfile.storageProfile.imageReference.PSObject.Properties.Name | Should -Not -Contain "offer"
            $vmssResourceProperties.virtualMachineProfile.storageProfile.imageReference.PSObject.Properties.Name | Should -Not -Contain "publisher"
            $vmssResourceProperties.virtualMachineProfile.storageProfile.imageReference.PSObject.Properties.Name | Should -Not -Contain "sharedGalleryImageId"
            $vmssResourceProperties.virtualMachineProfile.storageProfile.imageReference.PSObject.Properties.Name | Should -Not -Contain "sku"
            $vmssResourceProperties.virtualMachineProfile.storageProfile.imageReference.PSObject.Properties.Name | Should -Not -Contain "version"
            $vmssResourceProperties.virtualMachineProfile.storageProfile.imageReference.PSObject.Properties.Name | Should -Contain "id" -ErrorAction Stop

            $variableRegex = [regex]::new("(?<=^\[variables\(')(.*)(?='\)\]$)")
            $variableMatch = $variableRegex.Match($vmssResourceProperties.virtualMachineProfile.storageProfile.imageReference.id)

            $imageResourceId = "[resourceId(variables('gallerySubscriptionId'), variables('galleryResourceGroup'), 'Microsoft.Compute/galleries/images', variables('galleryName'), parameters('imageName'))]"

            If ($variableMatch.Success) {
                $variableName = $variableMatch.Value
                $templateFileObject.variables.PSObject.Properties.Name | Should -Contain $variableName -ErrorAction Stop
                $templateFileObject.variables.$variableName | Should -BeExactly $imageResourceId
            }
            Else {
                $vmssResourceProperties.virtualMachineProfile.storageProfile.imageReference.id | Should -BeExactly $imageResourceId
            }

            ForEach ($variableName In "gallerySubscriptionId", "galleryResourceGroup", "galleryName") {
                $templateFileObject.variables.PSObject.Properties.Name | Should -Contain $variableName
            }
        }

        It "Should have Managed Disk encrypted by Disk Encryption Set" {
            $vmssResourceProperties.PSObject.Properties.Name | Should -Contain "virtualMachineProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.PSObject.Properties.Name | Should -Contain "storageProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.storageProfile.PSObject.Properties.Name | Should -Contain "osDisk" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.storageProfile.osDisk.PSObject.Properties.Name | Should -Contain "managedDisk" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.storageProfile.osDisk.managedDisk.PSObject.Properties.Name | Should -Contain "diskEncryptionSet" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.storageProfile.osDisk.managedDisk.diskEncryptionSet.PSObject.Properties.Name | Should -Contain "id" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.storageProfile.osDisk.managedDisk.diskEncryptionSet.id | Should -Not -BeNullOrEmpty
        }

        It "Should not have Network Interface with public IP address configuration" {
            $vmssResourceProperties.PSObject.Properties.Name | Should -Contain "virtualMachineProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.PSObject.Properties.Name | Should -Contain "networkProfile" -ErrorAction Stop
            $vmssResourceProperties.virtualMachineProfile.networkProfile.PSObject.Properties.Name | Should -Contain "networkInterfaceConfigurations" -ErrorAction Stop

            ForEach ($networkInterfaceConfiguration In $vmssResourceProperties.virtualMachineProfile.networkProfile.networkInterfaceConfigurations) {
                $networkInterfaceConfiguration.PSObject.Properties.Name | Should -Contain "properties" -ErrorAction Stop
                $networkInterfaceConfiguration.properties.PSObject.Properties.Name | Should -Contain "ipConfigurations" -ErrorAction Stop

                ForEach ($ipConfiguration In $networkInterfaceConfiguration.properties.ipConfigurations) {
                    $ipConfiguration.PSObject.Properties.Name | Should -Contain "properties" -ErrorAction Stop
                    $ipConfiguration.properties.PSObject.Properties.Name | Should -Not -Contain "publicIPAddressConfiguration"
                }
            }
        }
    }
}
