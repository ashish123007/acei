BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileParameters = $templateFileObject.parameters
    $templateFileResources = $templateFileObject.resources
    $virtualMachineExtensionResource = $templateFileResources | Where-Object -FilterScript { $_.type -eq "Microsoft.Compute/virtualMachines/extensions" }
    $virtualMachineExtensionResourceProperties = $virtualMachineExtensionResource.properties
}

Describe "Critical Azure Pipelines Agent" {
    Context "ARM template" {
        It "Should not show PAT token in logging" {
            $virtualMachineExtensionResourceProperties.PSObject.Properties.Name | Should -Contain "protectedSettings" -ErrorAction Stop
            $virtualMachineExtensionResourceProperties.protectedSettings.PSObject.Properties.Name | Should -Contain "patToken" -ErrorAction Stop

            $parameterRegex = [regex]::new("(?<=^\[parameters\(')(.*)(?='\)\]$)")
            $parameterMatch = $parameterRegex.Match($virtualMachineExtensionResourceProperties.protectedSettings.patToken)
            $parameterMatch.Success | Should -BeTrue -ErrorAction Stop
            $parameterName = $parameterMatch.Value
            $templateFileParameters.PSObject.Properties.Name | Should -Contain $parameterName -ErrorAction Stop
            $templateFileParameters.$parameterName.type | Should -BeExactly "securestring" -ErrorAction Stop
        }
    }
}
