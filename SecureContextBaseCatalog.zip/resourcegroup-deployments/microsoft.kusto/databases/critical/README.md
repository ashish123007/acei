# Description

This ARM template is intended to create a compliant **(Critical)** Azure Data Explorer Database.

# Prerequisites

- Resource Group
- Azure Data Explorer Cluster

# Notes

- [AAB Data Explorer v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/102354/AAB-Data-Explorer-v1)
- [Azure PowerShell cmdlets for Data Explorer](https://learn.microsoft.com/en-us/powershell/module/az.kusto/?view=azps-12.0.0)
