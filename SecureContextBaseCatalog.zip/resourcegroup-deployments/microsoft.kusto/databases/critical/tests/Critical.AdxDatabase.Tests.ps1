﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileResource = $templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.Kusto/clusters/databases" }
    $templateFileResourcePropertyNames = $templateFileResource.properties.PSObject.Properties.Name
}

Describe "Critical Azure Data Explorer Database" {
    Context "ARM template" {
        It "Should have kind set to ReadWrite" {
            $templateFileResource.PSObject.Properties.Name | Should -Contain "kind" -ErrorAction Stop
            $templateFileResource.kind | Should -BeExactly "ReadWrite"
        }

        It "Should have hot cache period defined" {
            $templateFileResourcePropertyNames | Should -Contain "hotCachePeriod"
        }

        It "Should have soft delete period defined" {
            $templateFileResourcePropertyNames | Should -Contain "softDeletePeriod"
        }
    }
}
