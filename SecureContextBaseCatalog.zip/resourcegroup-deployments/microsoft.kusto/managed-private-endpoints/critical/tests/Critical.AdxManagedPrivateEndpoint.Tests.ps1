﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileResourceProperties = ($templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.Kusto/clusters/managedPrivateEndpoints" }).properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
}

Describe "Critical Azure Data Explorer Cluster Managed Private Endpoint" {
    Context "ARM template" {

    }
}
