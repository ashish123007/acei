# Description

This ARM template is intended to create a compliant **(Critical)** Azure Data Explorer Managed Private Endpoint.

# Prerequisites

- Azure Data Explorer Cluster
- Cosmos DB Account

# Notes

- [AAB Data Explorer v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/102354/AAB-Data-Explorer-v1)
- [Azure PowerShell cmdlets for Data Explorer](https://learn.microsoft.com/en-us/powershell/module/az.kusto/?view=azps-12.0.0)
