# Secure Context Azure Data Explorer

[[_TOC_]]

## Azure Data Explorer High-Level Description

[Azure Data Explorer](https://learn.microsoft.com/en-us/azure/data-explorer/data-explorer-overview) is a fast and highly scalable data exploration service provided by Microsoft Azure. It is designed for analyzing large volumes of data in real-time. Some key features of Azure Data Explorer include:

- Fast Data Ingestion: It can ingest and analyze large volumes of data in real-time, making it suitable for handling streaming data.
- Advanced Analytics: Azure Data Explorer supports complex queries, time-series analysis, and machine learning algorithms to derive insights from data.
- Scalability: It can scale horizontally to handle petabytes of data and thousands of queries per second.
- Integration: It integrates well with other Azure services like Azure Data Factory, Azure Databricks, and Power BI for seamless data processing and visualization.
- Cost-Effective: Azure Data Explorer offers a pay-as-you-go pricing model, allowing users to scale resources based on their needs.

Overall, Azure Data Explorer is a powerful tool for real-time data analysis and exploration, particularly suited for scenarios where large volumes of data need to be processed quickly and efficiently..

## PowerShell Commands

Refer to the [Microsoft Documentation](https://learn.microsoft.com/en-us/powershell/module/az.kusto/?view=azps-12.0.0) for all available Azure PowerShell cmdlets for Azure Data Explorer.

## Deploying in Secure Context

For more information on how to consume and deploy this template please visit the [Secure Context](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64636/Secure-Context) wiki page.
