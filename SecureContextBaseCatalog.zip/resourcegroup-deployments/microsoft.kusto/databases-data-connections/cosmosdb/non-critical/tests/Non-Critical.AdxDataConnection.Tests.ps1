﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileResourceProperties = ($templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.Kusto/clusters/databases/dataConnections" }).properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
}

Describe "Non Critical Azure Data Explorer Data Connection CosmosDB" {
    Context "ARM template" {

    }
}
