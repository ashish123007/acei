﻿BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileResourceProperties = ($templateFileObject.resources | Where-Object -FilterScript { $_.type -eq "Microsoft.Kusto/clusters" }).properties
    $templateFileResourcePropertyNames = $templateFileResourceProperties.PSObject.Properties.Name
}

Describe "Non Critical Prod Azure Data Explorer Cluster" {
    Context "ARM template" {

        It "Should have public network access set to Disabled" {
            $templateFileResourcePropertyNames | Should -Contain "publicNetworkAccess" -ErrorAction Stop
            $templateFileResourceProperties.publicNetworkAccess | Should -BeExactly "Disabled"
        }

        It "Should have trusted external tenants list set to empty" {
            $templateFileResourcePropertyNames | Should -Contain "trustedExternalTenants" -ErrorAction Stop
            $templateFileResourceProperties.trustedExternalTenants | Should -BeNullOrEmpty
        }

        It "Should have allowed FQDN list set to empty if defined" {
            If ($templateFileResourcePropertyNames -contains "allowedFqdnList") {
                $templateFileResourceProperties.allowedFqdnList | Should -BeNullOrEmpty
            }
        }

        It "Should have KeyVault properties for the cluster encryption set" {
            $templateFileResourcePropertyNames | Should -Contain "keyVaultProperties" -ErrorAction Stop
            $templateFileResourceProperties.keyVaultProperties.PSObject.Properties.Name | Should -Contain "keyVaultUri"
            $templateFileResourceProperties.keyVaultProperties.PSObject.Properties.Name | Should -Contain "keyName"
            $templateFileResourceProperties.keyVaultProperties.PSObject.Properties.Name | Should -Contain "keyVersion"
            $templateFileResourceProperties.keyVaultProperties.PSObject.Properties.Name | Should -Contain "userIdentity"
        }
    }
}
