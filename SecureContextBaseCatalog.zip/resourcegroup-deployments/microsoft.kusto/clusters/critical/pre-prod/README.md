# Description

This ARM template is intended to create a compliant **(Critical)** Azure Data Explorer Cluster.

It complies with the following Azure Policies:

- AAB Data Explorer - Allowed FQDN List v1
- AAB Data Explorer - Diagnostic Settings FSCP DINE v1
- AAB Data Explorer - Diagnostic Settings Sentinel DINE v1
- AAB Data Explorer - Disable Outbound Network Access v1
- AAB Data Explorer - External Tenant DENY v1
- Azure Data Explorer cluster should use private link
- Azure Data Explorer encryption at rest should use a customer-managed key
- Azure Data Explorer should use a SKU that supports private link
- Public network access on Azure Data Explorer should be disabled

# Prerequisites

- Resource Group
- Key Vault
- Customer-managed key in Key Vault
- User-Assigned Managed Identity with 'Get', 'WrapKey' and 'UnwrapKey' permissions on the Key Vault key

# Notes

- [AAB Data Explorer v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/102354/AAB-Data-Explorer-v1)
- [Azure PowerShell cmdlets for Data Explorer](https://learn.microsoft.com/en-us/powershell/module/az.kusto/?view=azps-12.0.0)
