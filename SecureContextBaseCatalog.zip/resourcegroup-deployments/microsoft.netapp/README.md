# Secure Context Azure NetApp Files

[[_TOC_]]

## Azure NetApp Files High-Level Description

[Azure NetApp Files](https://azure.microsoft.com/en-us/products/netapp) is an Azure native, first-party, enterprise-class, high-performance file storage service. It provides NAS volumes as a service for which you can create NetApp accounts, capacity pools, select service and performance levels, create volumes, and manage data protection. It allows you to create and manage high-performance, highly available, and scalable file shares, using the same protocols and tools that you're familiar with and enterprise applications rely on on-premises. Azure NetApp Files supports SMB and NFS protocols and can be used for various use cases such as file sharing, home directories, databases, high-performance computing and more. Additionally, it also provides built-in availability, data protection and disaster recovery capabilities.

# PowerShell Commands

Refer to the [Microsoft Documentation](https://learn.microsoft.com/en-us/powershell/module/az.netappfiles) for all available Azure PowerShell cmdlets for Azure NetApp Files.

# Deploying in Secure Context

For more information on how to consume and deploy this template please visit the [Secure Context](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64636/Secure-Context) wiki page.
