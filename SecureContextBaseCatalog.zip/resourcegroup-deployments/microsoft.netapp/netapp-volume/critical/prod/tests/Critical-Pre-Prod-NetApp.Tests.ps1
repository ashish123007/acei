BeforeAll {
    $templateFolderPath = Split-Path -Path $PSScriptRoot -Parent
    $templateFile = Join-Path -ChildPath "azuredeploy.json" -Path $templateFolderPath
    $templateFileObject = Get-Content -Path $templateFile -Raw | ConvertFrom-Json
    $templateFileParameters = $templateFileObject.parameters
    $anfResource = $templateFileObject.resources
    $anfResourceProperties = $anfResource.properties
}

Describe "Critical Prod Netapp Volume" {
    Context "ARM template" {
        It "Should not have Basic Networking enabled" {
            $templateFileParameters.PSObject.Properties.Name | Should -Contain "networkFeatures" -ErrorAction Stop
            $templateFileParameters.networkFeatures.PSObject.Properties.Name| Should -Contain "defaultValue" -ErrorAction Stop
            $templateFileParameters.networkFeatures.defaultValue | Should -BeExactly "Standard"
        }

        It "Should not have Microsoft Managed Keys encryption enabled" {
            $anfResourceProperties.PSObject.Properties.Name | Should -Contain "encryptionKeySource" -ErrorAction Stop
            $anfResourceProperties.encryptionKeySource | Should -BeExactly "Microsoft.KeyVault"
        }
      }
  }
