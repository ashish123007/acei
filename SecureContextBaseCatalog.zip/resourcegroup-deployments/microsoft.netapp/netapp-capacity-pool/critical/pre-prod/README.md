# Description

This ARM template is intended to create a compliant **(Critical)** NetApp Capacity Pool.

It complies with the following Azure Policies:

- AAB Azure NetApp Files - Basic Networking DENY v1
- AAB Azure NetApp Files - Block Microsoft Managed Keys DENY v1
- AAB Azure NetApp Files - Export Rules DENY v1
- AAB Azure NetApp Files - NSG Association DENY v1
- AAB Azure NetApp Files - Subnet Integration DENY v1
- Azure NetApp Files SMB Volumes should use SMB3 encryption
- Azure NetApp Files Volumes of type NFSv4.1 should use Kerberos data integrity or data privacy
- Azure NetApp Files Volumes should not use NFSv3 protocol type

# Prerequisites

- Resource Group
- Key Vault
- NetApp Account

# Documentation

- [AAB NetApp Files v1](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/84083/AAB-NetApp-Files-v1)
- [Azure PowerShell cmdlets for NetApp Files](https://learn.microsoft.com/en-us/powershell/module/az.netappfiles)
