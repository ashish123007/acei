# Description

The SecureContextBaseCatalog-PolicyCompliance.yaml file is meant for validating the templates within the resourcegroup-deployments folder for policy compliancy when changes have been made through a pull request on the develop branch. This file is not of any use for anyone except for the owners of the SecureContextBaseCatalog repository.
