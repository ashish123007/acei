jest.mock('winston', () => {
    const actualWinston = jest.requireActual('winston');
    return {
      ...actualWinston,
      createLogger: jest.fn(() => ({
        info: jest.fn(),
        error: jest.fn(),
        warn: jest.fn(),
        debug: jest.fn(),
        verbose: jest.fn()
      })),
    };
  });