-- CreateTable
CREATE TABLE "InsightFeedback" (
    "insight_feedback_id" TEXT NOT NULL,
    "insight_id" TEXT NOT NULL,
    "participant_id" TEXT NOT NULL,
    "score" INTEGER NOT NULL,
    "message" TEXT,
    "additional_feedback" JSONB,

    CONSTRAINT "InsightFeedback_pkey" PRIMARY KEY ("insight_feedback_id")
);

-- AddForeignKey
ALTER TABLE "InsightFeedback" ADD CONSTRAINT "InsightFeedback_insight_id_fkey" FOREIGN KEY ("insight_id") REFERENCES "Insight"("insight_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InsightFeedback" ADD CONSTRAINT "InsightFeedback_participant_id_fkey" FOREIGN KEY ("participant_id") REFERENCES "Participant"("participant_id") ON DELETE RESTRICT ON UPDATE CASCADE;
