-- AlterTable
ALTER TABLE "ParticipantsOnInteraction" ADD COLUMN     "participantsContext" JSONB;
