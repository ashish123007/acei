/*
  Warnings:

  - You are about to alter the column `created_at` on the `ApiConsumer` table. The data in that column could be lost. The data in that column will be cast from `BigInt` to `Integer`.
  - You are about to alter the column `created_at` on the `Conversation` table. The data in that column could be lost. The data in that column will be cast from `BigInt` to `Integer`.
  - You are about to alter the column `created_at` on the `Insight` table. The data in that column could be lost. The data in that column will be cast from `BigInt` to `Integer`.
  - You are about to alter the column `created_at` on the `Interaction` table. The data in that column could be lost. The data in that column will be cast from `BigInt` to `Integer`.
  - You are about to alter the column `created_at` on the `ParticipantsOnInteraction` table. The data in that column could be lost. The data in that column will be cast from `BigInt` to `Integer`.
  - You are about to alter the column `created_at` on the `Tenant` table. The data in that column could be lost. The data in that column will be cast from `BigInt` to `Integer`.
  - You are about to alter the column `created_at` on the `Transcription` table. The data in that column could be lost. The data in that column will be cast from `BigInt` to `Integer`.

*/
-- AlterTable
ALTER TABLE "ApiConsumer" ALTER COLUMN "created_at" SET DATA TYPE INTEGER;

-- AlterTable
ALTER TABLE "Conversation" ALTER COLUMN "created_at" SET DATA TYPE INTEGER;

-- AlterTable
ALTER TABLE "Insight" ALTER COLUMN "created_at" SET DATA TYPE INTEGER;

-- AlterTable
ALTER TABLE "Interaction" ALTER COLUMN "created_at" SET DATA TYPE INTEGER;

-- AlterTable
ALTER TABLE "ParticipantsOnInteraction" ALTER COLUMN "created_at" SET DATA TYPE INTEGER;

-- AlterTable
ALTER TABLE "Tenant" ALTER COLUMN "created_at" SET DATA TYPE INTEGER;

-- AlterTable
ALTER TABLE "Transcription" ALTER COLUMN "created_at" SET DATA TYPE INTEGER;
