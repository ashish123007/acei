-- DropForeignKey
ALTER TABLE "Insight" DROP CONSTRAINT "Insight_conversation_id_fkey";

-- DropForeignKey
ALTER TABLE "InsightDocuments" DROP CONSTRAINT "InsightDocuments_insight_id_fkey";

-- DropForeignKey
ALTER TABLE "InsightKnowledgeSearchResult" DROP CONSTRAINT "InsightKnowledgeSearchResult_insight_id_fkey";

-- DropForeignKey
ALTER TABLE "InsightSummaryResult" DROP CONSTRAINT "InsightSummaryResult_insight_id_fkey";

-- DropForeignKey
ALTER TABLE "Interaction" DROP CONSTRAINT "Interaction_conversation_id_fkey";

-- DropForeignKey
ALTER TABLE "ParticipantsOnInteraction" DROP CONSTRAINT "ParticipantsOnInteraction_interaction_id_fkey";

-- DropForeignKey
ALTER TABLE "Transcription" DROP CONSTRAINT "Transcription_interaction_id_fkey";

-- AddForeignKey
ALTER TABLE "Interaction" ADD CONSTRAINT "Interaction_conversation_id_fkey" FOREIGN KEY ("conversation_id") REFERENCES "Conversation"("conversation_id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ParticipantsOnInteraction" ADD CONSTRAINT "ParticipantsOnInteraction_interaction_id_fkey" FOREIGN KEY ("interaction_id") REFERENCES "Interaction"("interaction_id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Transcription" ADD CONSTRAINT "Transcription_interaction_id_fkey" FOREIGN KEY ("interaction_id") REFERENCES "Interaction"("interaction_id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Insight" ADD CONSTRAINT "Insight_conversation_id_fkey" FOREIGN KEY ("conversation_id") REFERENCES "Conversation"("conversation_id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InsightSummaryResult" ADD CONSTRAINT "InsightSummaryResult_insight_id_fkey" FOREIGN KEY ("insight_id") REFERENCES "Insight"("insight_id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InsightKnowledgeSearchResult" ADD CONSTRAINT "InsightKnowledgeSearchResult_insight_id_fkey" FOREIGN KEY ("insight_id") REFERENCES "Insight"("insight_id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InsightDocuments" ADD CONSTRAINT "InsightDocuments_insight_id_fkey" FOREIGN KEY ("insight_id") REFERENCES "Insight"("insight_id") ON DELETE CASCADE ON UPDATE CASCADE;
