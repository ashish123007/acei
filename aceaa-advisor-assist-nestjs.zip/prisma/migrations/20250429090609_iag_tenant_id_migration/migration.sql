
   INSERT INTO "Tenant" (id, name, created_at)
   VALUES
     ('e5d98453-19ed-447e-ac05-d9338eeeaf30', 'MSD', EXTRACT(EPOCH FROM NOW())::int),
     ('aab-sys-021582', 'IAG', EXTRACT(EPOCH FROM NOW())::int);
-- Insert tenantId for MSD and IAG API consumers into the existing ApiConsumer table
INSERT INTO "ApiConsumer" (id, type, "tenant_id")
VALUES 
  ('MSD', 'system', 'e5d98453-19ed-447e-ac05-d9338eeeaf30'),
  ('IAG', 'system', 'aab-sys-021582');
 
