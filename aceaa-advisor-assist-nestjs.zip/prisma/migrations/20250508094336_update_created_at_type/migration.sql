-- AlterTable
ALTER TABLE "ApiConsumer" ALTER COLUMN "created_at" SET DATA TYPE BIGINT;

-- AlterTable
ALTER TABLE "Conversation" ALTER COLUMN "created_at" SET DATA TYPE BIGINT;

-- AlterTable
ALTER TABLE "Insight" ALTER COLUMN "created_at" SET DATA TYPE BIGINT;

-- AlterTable
ALTER TABLE "Interaction" ALTER COLUMN "created_at" SET DATA TYPE BIGINT;

-- AlterTable
ALTER TABLE "ParticipantsOnInteraction" ALTER COLUMN "created_at" SET DATA TYPE BIGINT;

-- AlterTable
ALTER TABLE "Tenant" ALTER COLUMN "created_at" SET DATA TYPE BIGINT;

-- AlterTable
ALTER TABLE "Transcription" ALTER COLUMN "created_at" SET DATA TYPE BIGINT;
