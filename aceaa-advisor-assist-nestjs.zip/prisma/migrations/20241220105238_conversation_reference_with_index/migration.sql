-- CreateIndex
CREATE INDEX "Interaction_conversation_reference_idx" ON "Interaction"("conversation_reference");
