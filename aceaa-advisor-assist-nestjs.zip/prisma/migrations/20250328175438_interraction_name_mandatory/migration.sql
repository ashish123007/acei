/*
  Warnings:

  - Made the column `name` on table `Interaction` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "Interaction" ALTER COLUMN "name" SET NOT NULL;
