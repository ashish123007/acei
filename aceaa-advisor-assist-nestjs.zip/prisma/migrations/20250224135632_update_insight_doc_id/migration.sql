/*
  Warnings:

  - The primary key for the `InsightDocuments` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `insight_document` on the `InsightDocuments` table. All the data in the column will be lost.
  - The required column `insight_document_id` was added to the `InsightDocuments` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.

*/
-- AlterTable
ALTER TABLE "InsightDocuments" DROP CONSTRAINT "InsightDocuments_pkey",
DROP COLUMN "insight_document",
ADD COLUMN     "insight_document_id" TEXT NOT NULL,
ADD CONSTRAINT "InsightDocuments_pkey" PRIMARY KEY ("insight_document_id");
