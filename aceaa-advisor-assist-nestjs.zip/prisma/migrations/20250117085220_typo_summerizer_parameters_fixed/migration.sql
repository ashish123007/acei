/*
  Warnings:

  - You are about to drop the column `summarizer_parameters` on the `Interaction` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Interaction" DROP COLUMN "summarizer_parameters",
ADD COLUMN     "summerizer_parameters" JSONB;
