-- AlterTable
ALTER TABLE "Tenant" ADD COLUMN     "conversation_ttl_hours" INTEGER NOT NULL DEFAULT 24;
