/*
  Warnings:

  - Added the required column `created_by` to the `Interaction` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Interaction" ADD COLUMN     "created_by" TEXT NOT NULL,
ADD COLUMN     "name" TEXT;
