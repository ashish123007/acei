/*
  Warnings:

  - Added the required column `template` to the `ApiConsumer` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "ApiConsumer" ADD COLUMN     "template" JSONB NOT NULL;
