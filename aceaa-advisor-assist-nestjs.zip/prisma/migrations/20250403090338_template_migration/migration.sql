
   INSERT INTO "Tenant" (id, name, created_at)
   VALUES
     ('voicebot', 'voicebot', EXTRACT(EPOCH FROM NOW())::int),
     ('nice', 'nice', EXTRACT(EPOCH FROM NOW())::int);
-- Insert templates for Nice and Voice API consumers into the existing ApiConsumer table
INSERT INTO "ApiConsumer" (id, type, template, "tenant_id")
VALUES 
  ('voicebot', 'system', '{"type": "object", "properties": { "account_number": {
    "type": "integer"
  },
  "customer_name": {
    "type": "string"
  },
  "BC_number": {
    "type": "integer"
  },
  "language_pref": {
    "type": "string"
  },
  "party_type": {
    "type": "string",
    "enum": ["Individual", "Organization"]
  },
  "bo_number": {
    "type": "integer"
  },
  "cgc_code": {
    "type": "integer"
  },
  "is_cj_customer": {
    "type": "boolean"
  },
  "ANI_recognition_status": {
    "type": "string",
    "enum": [
      "RecogANI_Success",
      "RecogANI_Success_MultiBC",
      "RecogANI_Success_NoMatch",
      "RecogANI_Failed_TechnicalError",
      "RecogANI_Failed_Unknown"
    ]
  },
  "account_recognition_status": {
    "type": "string",
    "enum": [
      "RecogAcc_Success",
      "RecogAcc_OptOut",
      "RecogAcc_Failed_NoAccountFound",
      "RecogAcc_Failed_Timeout",
      "RecogAcc_Failed_NoBCFound",
      "RecogAcc_Failed_TechnicalError",
      "RecogAcc_Failed_NoRecordsForBC",
      "RecogAcc_Failed_WrongInput"
    ]
  },
  "authentication_status": {
    "type": "string",
    "enum": [
      "CardNotValid",
      "CardNotAvailable",
      "RecognitionFailed",
      "MBSuccess",
      "MBTimeout",
      "MBFailed",
      "MBTechError"
    ]
  },
  "authentication_failure_reason": {
    "type": "string"
  },
  "endpoint_code": {
    "type": "string"
  },
  "intent": {
    "type": "string"
  },
  "intent_summary": {
    "type": "string"
  }}, "additionalProperties": false}', 'voicebot'), 
  ('nice', 'system', '{"type": "object", "properties": { "pre_intent": {
    "type": "string",
    "enum": ["DFLT", "HYPL", "BBCB"]
  },
  "phone_number": {
    "type": "integer"
  },
  "language_pref": {
    "type": "string"
  }
}, "additionalProperties": false}', 'nice');
 
