/*
  Warnings:

  - The `created_at` column on the `ApiConsumer` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `created_at` column on the `Conversation` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `created_at` column on the `Insight` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `created_at` column on the `Interaction` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `created_at` column on the `ParticipantsOnInteraction` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `created_at` column on the `Tenant` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `created_at` column on the `Transcription` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- AlterTable
ALTER TABLE "ApiConsumer" DROP COLUMN "created_at",
ADD COLUMN     "created_at" BIGINT NOT NULL DEFAULT extract(epoch from now());

-- AlterTable
ALTER TABLE "Conversation" DROP COLUMN "created_at",
ADD COLUMN     "created_at" BIGINT NOT NULL DEFAULT extract(epoch from now());

-- AlterTable
ALTER TABLE "Insight" DROP COLUMN "created_at",
ADD COLUMN     "created_at" BIGINT NOT NULL DEFAULT extract(epoch from now());

-- AlterTable
ALTER TABLE "Interaction" DROP COLUMN "created_at",
ADD COLUMN     "created_at" BIGINT NOT NULL DEFAULT extract(epoch from now());

-- AlterTable
ALTER TABLE "ParticipantsOnInteraction" DROP COLUMN "created_at",
ADD COLUMN     "created_at" BIGINT NOT NULL DEFAULT extract(epoch from now());

-- AlterTable
ALTER TABLE "Tenant" DROP COLUMN "created_at",
ADD COLUMN     "created_at" BIGINT NOT NULL DEFAULT extract(epoch from now());

-- AlterTable
ALTER TABLE "Transcription" DROP COLUMN "created_at",
ADD COLUMN     "created_at" BIGINT NOT NULL DEFAULT extract(epoch from now());
