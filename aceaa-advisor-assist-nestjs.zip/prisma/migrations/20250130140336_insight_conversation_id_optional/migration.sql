-- DropForeignKey
ALTER TABLE "Insight" DROP CONSTRAINT "Insight_conversation_id_fkey";

-- AlterTable
ALTER TABLE "Insight" ALTER COLUMN "conversation_id" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "Insight" ADD CONSTRAINT "Insight_conversation_id_fkey" FOREIGN KEY ("conversation_id") REFERENCES "Conversation"("conversation_id") ON DELETE SET NULL ON UPDATE CASCADE;
