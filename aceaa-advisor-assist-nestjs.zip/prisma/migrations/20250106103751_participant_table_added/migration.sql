-- CreateTable
CREATE TABLE "Participant" (
    "participant_id" TEXT NOT NULL,
    "type" TEXT NOT NULL,

    CONSTRAINT "Participant_pkey" PRIMARY KEY ("participant_id")
);

-- CreateTable
CREATE TABLE "ParticipantsOnInteraction" (
    "interaction_id" TEXT NOT NULL,
    "participant_id" TEXT NOT NULL,

    CONSTRAINT "ParticipantsOnInteraction_pkey" PRIMARY KEY ("interaction_id","participant_id")
);

-- AddForeignKey
ALTER TABLE "ParticipantsOnInteraction" ADD CONSTRAINT "ParticipantsOnInteraction_interaction_id_fkey" FOREIGN KEY ("interaction_id") REFERENCES "Interaction"("interaction_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ParticipantsOnInteraction" ADD CONSTRAINT "ParticipantsOnInteraction_participant_id_fkey" FOREIGN KEY ("participant_id") REFERENCES "Participant"("participant_id") ON DELETE RESTRICT ON UPDATE CASCADE;
