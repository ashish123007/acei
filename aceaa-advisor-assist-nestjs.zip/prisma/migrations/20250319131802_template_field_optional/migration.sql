-- AlterTable
ALTER TABLE "ApiConsumer" ALTER COLUMN "template" DROP NOT NULL;

