-- CreateTable
CREATE TABLE "Insight" (
    "insight_id" TEXT NOT NULL,
    "conversation_id" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "participant_id" TEXT,
    "parentInsight" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Insight_pkey" PRIMARY KEY ("insight_id")
);

-- CreateTable
CREATE TABLE "InsightSummaryResult" (
    "insight_id" TEXT NOT NULL,
    "transcript" TEXT NOT NULL,
    "summerizerParameters" JSONB,
    "summary" TEXT NOT NULL,
    "special_char_score" INTEGER NOT NULL,

    CONSTRAINT "InsightSummaryResult_pkey" PRIMARY KEY ("insight_id")
);

-- AddForeignKey
ALTER TABLE "Insight" ADD CONSTRAINT "Insight_conversation_id_fkey" FOREIGN KEY ("conversation_id") REFERENCES "Conversation"("conversation_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Insight" ADD CONSTRAINT "Insight_participant_id_fkey" FOREIGN KEY ("participant_id") REFERENCES "Participant"("participant_id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InsightSummaryResult" ADD CONSTRAINT "InsightSummaryResult_insight_id_fkey" FOREIGN KEY ("insight_id") REFERENCES "Insight"("insight_id") ON DELETE RESTRICT ON UPDATE CASCADE;
