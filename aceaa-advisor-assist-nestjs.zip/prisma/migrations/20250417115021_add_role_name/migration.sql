-- AlterTable
ALTER TABLE "ApiConsumer" ADD COLUMN     "roleName" TEXT NOT NULL DEFAULT 'AdvisorAssist-CCO';
