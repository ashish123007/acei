/*
  Warnings:

  - Changed the type of `type` on the `Insight` table. No cast exists, the column would be dropped and recreated, which cannot be done if there is data, since the column is required.

*/
-- AlterTable
ALTER TABLE "Insight" DROP COLUMN "type",
ADD COLUMN     "type" "InsightType" NOT NULL;
