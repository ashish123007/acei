-- CreateEnum
CREATE TYPE "SummaryGeneratedBy" AS ENUM ('LLM', 'Manual');

-- AlterTable
ALTER TABLE "InsightSummaryResult" ADD COLUMN     "generated_by" "SummaryGeneratedBy" NOT NULL DEFAULT 'LLM';
