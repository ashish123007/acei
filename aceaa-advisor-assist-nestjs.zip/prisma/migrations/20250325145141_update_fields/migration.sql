/*
  Warnings:

  - You are about to drop the column `tenantId` on the `ApiConsumer` table. All the data in the column will be lost.
  - You are about to drop the column `tenantId` on the `Conversation` table. All the data in the column will be lost.
  - You are about to drop the column `tenantId` on the `Insight` table. All the data in the column will be lost.
  - You are about to drop the column `tenantId` on the `InsightDocuments` table. All the data in the column will be lost.
  - You are about to drop the column `tenantId` on the `InsightFeedback` table. All the data in the column will be lost.
  - You are about to drop the column `summerizer_parameters` on the `InsightSummaryResult` table. All the data in the column will be lost.
  - You are about to drop the column `conversation_reference` on the `Interaction` table. All the data in the column will be lost.
  - You are about to drop the column `createdBy` on the `Interaction` table. All the data in the column will be lost.
  - You are about to drop the column `summerizer_parameters` on the `Interaction` table. All the data in the column will be lost.
  - You are about to drop the column `tenantId` on the `Interaction` table. All the data in the column will be lost.
  - You are about to drop the column `tenantId` on the `Participant` table. All the data in the column will be lost.
  - You are about to drop the column `participantsContext` on the `ParticipantsOnInteraction` table. All the data in the column will be lost.
  - You are about to drop the column `tenantId` on the `ParticipantsOnInteraction` table. All the data in the column will be lost.
  - You are about to drop the column `tenantId` on the `Transcription` table. All the data in the column will be lost.
  - Added the required column `tenant_id` to the `ApiConsumer` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tenant_id` to the `Conversation` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tenant_id` to the `Insight` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tenant_id` to the `InsightDocuments` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tenant_id` to the `InsightFeedback` table without a default value. This is not possible if the table is not empty.
  - Added the required column `created_by` to the `Interaction` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tenant_id` to the `Interaction` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tenant_id` to the `Participant` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tenant_id` to the `ParticipantsOnInteraction` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tenant_id` to the `Transcription` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "ApiConsumer" DROP CONSTRAINT "ApiConsumer_tenantId_fkey";

-- DropForeignKey
ALTER TABLE "Conversation" DROP CONSTRAINT "Conversation_tenantId_fkey";

-- DropForeignKey
ALTER TABLE "Insight" DROP CONSTRAINT "Insight_tenantId_fkey";

-- DropForeignKey
ALTER TABLE "InsightDocuments" DROP CONSTRAINT "InsightDocuments_tenantId_fkey";

-- DropForeignKey
ALTER TABLE "InsightFeedback" DROP CONSTRAINT "InsightFeedback_tenantId_fkey";

-- DropForeignKey
ALTER TABLE "Interaction" DROP CONSTRAINT "Interaction_tenantId_fkey";

-- DropForeignKey
ALTER TABLE "Participant" DROP CONSTRAINT "Participant_tenantId_fkey";

-- DropForeignKey
ALTER TABLE "ParticipantsOnInteraction" DROP CONSTRAINT "ParticipantsOnInteraction_tenantId_fkey";

-- DropForeignKey
ALTER TABLE "Transcription" DROP CONSTRAINT "Transcription_tenantId_fkey";

-- DropIndex
DROP INDEX "Interaction_conversation_reference_idx";

-- AlterTable
ALTER TABLE "ApiConsumer" DROP COLUMN "tenantId",
ADD COLUMN     "tenant_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "Conversation" DROP COLUMN "tenantId",
ADD COLUMN     "tenant_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "Insight" DROP COLUMN "tenantId",
ADD COLUMN     "tenant_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "InsightDocuments" DROP COLUMN "tenantId",
ADD COLUMN     "tenant_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "InsightFeedback" DROP COLUMN "tenantId",
ADD COLUMN     "tenant_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "InsightSummaryResult" DROP COLUMN "summerizer_parameters";

-- AlterTable
ALTER TABLE "Interaction" DROP COLUMN "conversation_reference",
DROP COLUMN "createdBy",
DROP COLUMN "summerizer_parameters",
DROP COLUMN "tenantId",
ADD COLUMN     "context" JSONB,
ADD COLUMN     "created_by" TEXT NOT NULL,
ADD COLUMN     "reference" TEXT,
ADD COLUMN     "tenant_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "Participant" DROP COLUMN "tenantId",
ADD COLUMN     "tenant_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "ParticipantsOnInteraction" DROP COLUMN "participantsContext",
DROP COLUMN "tenantId",
ADD COLUMN     "tenant_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "Transcription" DROP COLUMN "tenantId",
ADD COLUMN     "tenant_id" TEXT NOT NULL;

-- CreateIndex
CREATE INDEX "Interaction_reference_idx" ON "Interaction"("reference");

-- AddForeignKey
ALTER TABLE "ApiConsumer" ADD CONSTRAINT "ApiConsumer_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Conversation" ADD CONSTRAINT "Conversation_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Interaction" ADD CONSTRAINT "Interaction_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Participant" ADD CONSTRAINT "Participant_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ParticipantsOnInteraction" ADD CONSTRAINT "ParticipantsOnInteraction_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Transcription" ADD CONSTRAINT "Transcription_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Insight" ADD CONSTRAINT "Insight_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InsightDocuments" ADD CONSTRAINT "InsightDocuments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InsightFeedback" ADD CONSTRAINT "InsightFeedback_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
