-- CreateTable
CREATE TABLE "InsightKnowledgeSearchResult" (
    "insight_id" TEXT NOT NULL,
    "search" TEXT NOT NULL,

    CONSTRAINT "InsightKnowledgeSearchResult_pkey" PRIMARY KEY ("insight_id")
);

-- CreateTable
CREATE TABLE "InsightDocuments" (
    "insight_document" TEXT NOT NULL,
    "insight_id" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,

    CONSTRAINT "InsightDocuments_pkey" PRIMARY KEY ("insight_document")
);

-- AddForeignKey
ALTER TABLE "InsightKnowledgeSearchResult" ADD CONSTRAINT "InsightKnowledgeSearchResult_insight_id_fkey" FOREIGN KEY ("insight_id") REFERENCES "Insight"("insight_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InsightDocuments" ADD CONSTRAINT "InsightDocuments_insight_id_fkey" FOREIGN KEY ("insight_id") REFERENCES "Insight"("insight_id") ON DELETE RESTRICT ON UPDATE CASCADE;
