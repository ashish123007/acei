-- AlterTable
ALTER TABLE "Conversation" ADD COLUMN     "active" BOOLEAN NOT NULL DEFAULT true;

-- AlterTable
ALTER TABLE "Interaction" ADD COLUMN     "active" BOOLEAN NOT NULL DEFAULT true;
