/*
  Warnings:

  - The `summarizer_parameters` column on the `Interaction` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- AlterTable
ALTER TABLE "Interaction" DROP COLUMN "summarizer_parameters",
ADD COLUMN     "summarizer_parameters" JSONB;
