-- CreateEnum
CREATE TYPE "InsightType" AS ENUM ('Summary', 'KnowledgeSearch', 'KnowledgeSuggestion');
