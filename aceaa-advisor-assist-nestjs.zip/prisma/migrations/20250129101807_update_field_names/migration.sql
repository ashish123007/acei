/*
  Warnings:

  - You are about to drop the column `parentInsight` on the `Insight` table. All the data in the column will be lost.
  - You are about to drop the column `summerizerParameters` on the `InsightSummaryResult` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Insight" DROP COLUMN "parentInsight";

-- AlterTable
ALTER TABLE "InsightSummaryResult" DROP COLUMN "summerizerParameters",
ADD COLUMN     "parent_insight_id" TEXT,
ADD COLUMN     "summerizer_parameters" JSONB;
