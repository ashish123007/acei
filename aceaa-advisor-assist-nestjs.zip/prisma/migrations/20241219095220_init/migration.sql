-- CreateTable
CREATE TABLE "Conversation" (
    "conversation_id" TEXT NOT NULL,

    CONSTRAINT "Conversation_pkey" PRIMARY KEY ("conversation_id")
);

-- CreateTable
CREATE TABLE "Interaction" (
    "interaction_id" TEXT NOT NULL,
    "conversation_id" TEXT NOT NULL,
    "conversation_reference" TEXT,
    "topic" TEXT,

    CONSTRAINT "Interaction_pkey" PRIMARY KEY ("interaction_id")
);

-- AddForeignKey
ALTER TABLE "Interaction" ADD CONSTRAINT "Interaction_conversation_id_fkey" FOREIGN KEY ("conversation_id") REFERENCES "Conversation"("conversation_id") ON DELETE RESTRICT ON UPDATE CASCADE;
