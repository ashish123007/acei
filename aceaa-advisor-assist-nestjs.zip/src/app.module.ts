import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { TerminusModule } from '@nestjs/terminus';
import { HealthController } from './controllers/health.controller';
import { AuthModule } from './auth/auth.module';
import { ConfigModule } from '@nestjs/config';
import { TranscriptionController } from './controllers/transcription.controller';
import { SpeechToTextService } from './services/speech-to-text.service';
import { InteractionService } from './services/interaction.service';
import { ConversationController } from './controllers/conversation.controller';
import { TranscriptionService } from './services/transcription.service';
import { SummarizationService } from './services/summarization.service';
import { InsightService } from './services/insight.service';
import { ConversationService } from './services/conversation.service';
import { InsightController } from './controllers/insight.controller';
import { AiHttpClientService } from './services/http-client.service';
import { PrismaService } from './prisma.service';
import { SearchService } from './services/search.service';
import { FeedbackService } from './services/feedback.service';
import { ApiConsumerService } from './services/apiConsumer.service';
import { AnalyticsService } from './services/analytics.service';
import { AnalyticsController } from './controllers/analytics.controller';
import { ValidationService } from './services/validation.service';
import { CallAutomationService } from './services/callAutomation.service';
import { VoiceHubController } from './controllers/voicehub.controller';

@Module({
  imports: [ConfigModule.forRoot(), TerminusModule, HttpModule, AuthModule],
  controllers: [
    HealthController,
    TranscriptionController,
    ConversationController,
    InsightController,
    AnalyticsController,
    VoiceHubController,
  ],
  providers: [
    SpeechToTextService,
    InteractionService,
    ApiConsumerService,
    PrismaService,
    TranscriptionService,
    SummarizationService,
    InsightService,
    ConversationService,
    AiHttpClientService,
    SearchService,
    FeedbackService,
    AnalyticsService,
    ValidationService,
    CallAutomationService,
  ],
})
export class AppModule {}
