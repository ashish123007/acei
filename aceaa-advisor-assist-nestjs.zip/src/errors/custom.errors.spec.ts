import { HttpException, HttpStatus } from '@nestjs/common';
import type { ArgumentsHost } from '@nestjs/common';
import type { Response } from 'express';
import { BadRequestIagException, CustomExceptionFilter, NotFoundIagException } from './custom-errors';
import { logger } from '../utils/logger';

const mockArgumentsHost = (response: Response): ArgumentsHost => {
  return {
    switchToHttp: jest.fn().mockReturnValue({
      getResponse: jest.fn().mockReturnValue(response),
      getRequest: jest.fn().mockReturnValue({
        routeContext: 'some-request',
      }),
    }),
  } as unknown as ArgumentsHost;
};

describe('CustomExceptionFilter', () => {
  let filter: CustomExceptionFilter;

  beforeEach(() => {
    filter = new CustomExceptionFilter();
  });

  const mockResponse = () => {
    const res: Partial<Response> = {};
    res.status = jest.fn().mockReturnValue(res);
    res.json = jest.fn().mockReturnValue(res);
    return res as Response;
  };

  const response = mockResponse();
  const host = mockArgumentsHost(response);

  it('should format error response for HttpException', () => {
    const exception = new HttpException('Not found', HttpStatus.NOT_FOUND);

    filter.catch(exception, host);

    expect(response.status).toHaveBeenCalledWith(HttpStatus.NOT_FOUND);
    expect(response.json).toHaveBeenCalledWith({
      errors: [{ status: HttpStatus.NOT_FOUND, code: 'NOT_FOUND', message: 'Not found' }],
    });
  });

  it('should handle custom cause in NotFoundIagException', () => {
    const exception = new NotFoundIagException('CONVERSATION_NOT_FOUND');

    filter.catch(exception, host);

    expect(response.status).toHaveBeenCalledWith(HttpStatus.NOT_FOUND);
    expect(response.json).toHaveBeenCalledWith({
      errors: [
        {
          status: HttpStatus.NOT_FOUND,
          code: 'CONVERSATION_NOT_FOUND',
          message: 'Conversation with the specified conversationId not found.',
        },
      ],
    });
  });

  it('should handle custom cause in BadRequestIagException', () => {
    const exception = new BadRequestIagException('INSIGHT_TYPE_INVALID');

    filter.catch(exception, host);

    expect(response.status).toHaveBeenCalledWith(HttpStatus.BAD_REQUEST);
    expect(response.json).toHaveBeenCalledWith({
      errors: [{ status: HttpStatus.BAD_REQUEST, code: 'INSIGHT_TYPE_INVALID', message: 'Invalid Insight type.' }],
    });
  });

  it('should log unhandled exceptions', () => {
    const errorLogger = jest.spyOn(logger, 'error');

    const exception = new Error('Unhandled exception');

    filter.catch(exception, host);

    expect(errorLogger).toHaveBeenCalledWith('Unable to some-request: ', {
      exception: String(exception),
      params: {},
    });

    errorLogger.mockRestore();
  });
});
