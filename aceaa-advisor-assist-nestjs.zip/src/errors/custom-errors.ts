import type { ExceptionFilter, ArgumentsHost } from '@nestjs/common';
import { NotFoundException, BadRequestException, HttpStatus } from '@nestjs/common';
import { Catch, HttpException } from '@nestjs/common';
import type { Response, Request as ExpressRequest } from 'express';
import { logger } from '../utils/logger';
import type { HttpArgumentsHost } from '@nestjs/common/interfaces';
import type { ObjectType } from '../types';

interface Request extends ExpressRequest {
  routeContext?: string;
}

export const BadRequestAvailableCode = {
  CONVERSATION_ID_INVALID: 'Conversation id is invalid.',
  INTERACTION_ID_INVALID: 'Interaction id is invalid.',
  SEARCH_PARAMETER_MISSING: 'you must provide either participantId or interactionReference.',
  INSIGHT_TYPE_INVALID: 'Invalid Insight type.',
  SUMMARY_ACTION_INVALID: 'Summary action invalid',
  INSIGHT_ID_INVALID: 'Insight id is invalid.',
  PARTICIPANT_ID_MISSING: 'Participant ID is missing in headers.',
};

export const NotFoundAvailableCode = {
  CONVERSATION_NOT_FOUND: 'Conversation with the specified conversationId not found.',
  INTERACTION_ID_NOT_FOUND: 'Interaction id is missing.',
  INSIGHT_ID_NOT_FOUND: 'Insight with the specified insightId not found',
  TRANSCRIPTIONS_NOT_FOUND: 'Transcriptions not found with the specified conversationId/',
};

export class NotFoundIagException extends NotFoundException {
  constructor(cause: keyof typeof NotFoundAvailableCode, customMessage?: string) {
    const message = customMessage ?? NotFoundAvailableCode[cause];
    super(message, {
      cause,
    });
  }
}

export class BadRequestIagException extends BadRequestException {
  constructor(cause: keyof typeof BadRequestAvailableCode, customMessage?: string) {
    const message = customMessage ?? BadRequestAvailableCode[cause];
    super(message, {
      cause,
    });
  }
}

export const ERROR_CODES: Record<number, string> = {
  400: 'INVALID',
  401: 'NOT_AUTHENTICATED',
  403: 'FORBIDDEN',
  404: 'NOT_FOUND',
  500: 'INTERNAL_SERVER_ERROR',
  503: 'SERVICE_UNAVAILABLE',
};

@Catch()
export class CustomExceptionFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();

    const status = exception instanceof HttpException ? exception.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;

    const { message: contextMessage, params } = getRequestContextParams(ctx);
    const message = exception instanceof HttpException ? exception.message : contextMessage;
    const cause = exception instanceof HttpException ? exception.cause : '';

    if (!(exception instanceof HttpException)) {
      logger.error(`${message}: `, { exception: String(exception), params });
    }

    response.status(status).json({
      errors: [{ status, code: cause || ERROR_CODES[status], message }],
    });
  }
}

function getRequestContextParams(ctx: HttpArgumentsHost): { message: string; params: ObjectType } {
  const request = ctx.getRequest<Request>();

  const { routeContext, params } = request;

  // For insight APIs
  const body = request.body as { parameters?: { conversationId?: string } };
  const conversationId = body?.parameters?.conversationId;

  return {
    message: `Unable to ${routeContext}`,
    params: {
      ...params,
      ...(conversationId && { conversationId }),
    },
  };
}
