import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class Error {
  @ApiProperty({
    description: 'A unique and meaningful code for the error',
  })
  code: string;

  @ApiProperty({
    description: 'This contains a human readable description for the code and is specifically meant for debug purposes',
  })
  message: string;

  @ApiPropertyOptional({
    description:
      'The unique id sent in the request header for end to end traceability of an API call especially in case of errors',
  })
  traceId?: string;

  @ApiProperty({
    description: 'The HTTP response status code under which the code has been categorized',
    type: 'integer',
    format: 'int32',
  })
  status: number;
}

export class Errors {
  @ApiProperty({
    description: 'Error response',
    required: true,
    minItems: 1,
    maxItems: 2,
    type: [Error],
  })
  errors: Error[];
}
