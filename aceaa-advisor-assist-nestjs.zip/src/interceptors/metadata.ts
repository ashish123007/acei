import type { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';

import { Injectable } from '@nestjs/common';

import { Reflector } from '@nestjs/core';

import type { Observable } from 'rxjs';

@Injectable()
export class MetadataInterceptor implements NestInterceptor {
  constructor(private reflector: Reflector) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest<{ routeContext?: string }>();

    const handler = context.getHandler();

    const routeContext = this.reflector.get<string>('routeContext', handler);

    request.routeContext = routeContext;

    return next.handle();
  }
}
