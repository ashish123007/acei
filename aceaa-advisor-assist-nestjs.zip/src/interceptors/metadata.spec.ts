import { CallHandler, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { MetadataInterceptor } from './metadata';
import { of } from 'rxjs';

describe('MetadataInterceptor', () => {
  let interceptor: MetadataInterceptor;
  let reflector: Reflector;

  beforeEach(() => {
    reflector = new Reflector();
    interceptor = new MetadataInterceptor(reflector);
  });

  const mockExecutionContext = (routeContextValue: string | undefined) => {
    return {
      switchToHttp: jest.fn().mockReturnValue({
        getRequest: jest.fn().mockReturnValue({}),
      }),
      getHandler: jest.fn().mockReturnValue('mockHandler'),
    } as unknown as ExecutionContext;
  };

  it('should attach routeContext metadata to the request', () => {
    const routeContextValue = 'test-route-context';
    const context = mockExecutionContext(routeContextValue);

    jest.spyOn(reflector, 'get').mockReturnValue(routeContextValue);

    const next: CallHandler = {
      handle: jest.fn().mockReturnValue(of(null)),
    };

    const request = context.switchToHttp().getRequest();
    interceptor.intercept(context, next).subscribe();

    expect(reflector.get).toHaveBeenCalledWith('routeContext', 'mockHandler');
    expect(request.routeContext).toBe(routeContextValue);
  });

  it('should set routeContext to undefined if no metadata is found', () => {
    const context = mockExecutionContext(undefined);

    jest.spyOn(reflector, 'get').mockReturnValue(undefined);

    const next: CallHandler = {
      handle: jest.fn().mockReturnValue(of(null)),
    };

    const request = context.switchToHttp().getRequest();
    interceptor.intercept(context, next).subscribe();

    expect(reflector.get).toHaveBeenCalledWith('routeContext', 'mockHandler');
    expect(request.routeContext).toBeUndefined();
  });

  it('should call next.handle()', () => {
    const context = mockExecutionContext('test-route-context');

    jest.spyOn(reflector, 'get').mockReturnValue('test-route-context');

    const next: CallHandler = {
      handle: jest.fn().mockReturnValue(of(null)),
    };

    interceptor.intercept(context, next).subscribe();

    expect(next.handle).toHaveBeenCalled();
  });
});
