import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from '../app.module';
import { NestFactory } from '@nestjs/core';
import { writeFileSync } from 'fs';
import * as yaml from 'js-yaml';
import { logger } from '../utils/logger';

(async function generateApiDocs() {
  const app = await NestFactory.create(AppModule);

  const config = new DocumentBuilder()
    .setTitle('Conversation Insights API')
    .setDescription(
      'Conversation Insights API provides tools for retrieving and managing conversation information. It includes endpoints for fetching conversation details, insights, transcriptions, and summaries, as well as submitting feedback and searching the knowledge base.'
    )
    .setVersion('1.0.0')
    .addGlobalParameters({
      name: 'Trace-Id',
      in: 'header',
      required: false,
      description: 'Unique end-2-end trace id received from the consumer',
      schema: {
        type: 'string',
        example: '8b5e8b1e-375e-450e-9563-8d6f9cba091b',
      },
    })
    .setOpenAPIVersion('3.0.0')
    .addServer('https://host/conversation-insights/v1', 'Platform agnostic URL')

    .build();
  const document = SwaggerModule.createDocument(app, config, {
    autoTagControllers: false,
    extraModels: [],
  });

  // @ts-expect-error  x-apiType does not exists in document.info but the info is required @see https://developer-pr-iag.nl.eu.abnamro.com/rest-standards-and-guidelines/yaml-guidelines/#104
  document.info['x-apiType'] = 'enterprise';
  document.info.contact!['email'] = 'team-ace-advisor-assist@nl.abnamro.com';

  const orderedSwaggerDocument = {
    openapi: document.openapi,
    info: document.info,
    servers: document.servers,
    security: document.security,
    paths: document.paths,
    components: document.components,
  };

  const yamlStr = yaml.dump(orderedSwaggerDocument);

  writeFileSync('./generated-docs/swagger.yaml', yamlStr);

  await app.close();
})().catch((e) => logger.error(e));
