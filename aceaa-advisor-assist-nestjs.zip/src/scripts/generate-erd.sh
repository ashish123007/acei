#!/bin/bash

DOCS_DIR="generated-docs"
INPUT_FILE="schema.dbml"
OUTPUT_SVG="erd.svg"
OUTPUT_JPG="erd.jpg"
BACKGROUND_COLOR="silver"

# Generate DBML file
npx prisma generate

# Navigate to the docs directory
cd $DOCS_DIR || exit

# Generate the ERD as an SVG
npx @softwaretechnik/dbml-renderer -i $INPUT_FILE -o $OUTPUT_SVG

# Convert the SVG to a JPG with a background color
npx svgexport $OUTPUT_SVG $OUTPUT_JPG 100% "*{background:$BACKGROUND_COLOR;}" pad

# Cleanup files
rm schema.dbml erd.svg

echo "JPG file generated successfully: $DOCS_DIR/$OUTPUT_JPG"
