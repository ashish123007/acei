import type { Type } from '@nestjs/common';
import { applyDecorators } from '@nestjs/common';
import { ApiQuery, ApiBody, ApiExtraModels, ApiParam } from '@nestjs/swagger';
import type { ObjectType } from '../types';
import 'reflect-metadata';

interface ApiModelProperty {
  type?: string;
  description?: string;
  required?: boolean;
  example?: unknown;
}

type ApiModelProperties = Record<string, ApiModelProperty>;

interface ApiRequestBodyOptions {
  examples?: ObjectType;
  isArray?: boolean;
  description?: string;
}

export function ApiRequestBody<T extends Type<any>>(dto: T, { description, examples, isArray }: ApiRequestBodyOptions) {
  return applyDecorators(
    ApiBody({
      description: description ?? 'Request Body',
      type: dto,
      examples,
      isArray,
    })
  );
}

export function ApiRequestQuery<T extends Type<any>>(dto: T) {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
  const queryProps = Reflect.getMetadata('swagger/apiModelProperties', dto.prototype) as ApiModelProperties;

  const decorators = Object.keys(queryProps || {}).map((key) => {
    return ApiQuery({
      name: key,
      required: queryProps[key].required || false,
      type: queryProps[key].type,
      description: queryProps[key].description,
      example: queryProps[key].example,
    });
  });
  return applyDecorators(ApiExtraModels(dto), ...decorators);
}

export function ApiRequestParam<T extends Type<any>>(dto: T) {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
  const paramProps = Reflect.getMetadata('swagger/apiModelProperties', dto.prototype) as ApiModelProperties;

  const decorators = Object.keys(paramProps || {}).map((key) => {
    return ApiParam({
      name: key,
      required: paramProps[key].required || false,
      type: paramProps[key]?.type,
      description: paramProps[key].description,
    });
  });
  return applyDecorators(ApiExtraModels(dto), ...decorators);
}
