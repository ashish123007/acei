import { applyDecorators } from '@nestjs/common';
import { ApiExtraModels, ApiHeader, ApiOperation, ApiQuery, ApiTags } from '@nestjs/swagger';
import { ApiErrorResponseSchema, CreatedResponse, OkResponse } from './response';
import { ApiRequestBody } from './request';
import {
  InsightFeedbackInput,
  InsightCreateInput,
  Insight,
  InsightSummaryData,
  InsightSearchData,
  InsightDocument,
} from '../dto/insight.dto';
import {
  ConversationInteractionInput,
  ConversationInteraction,
  Conversation,
  InteractionContext,
  InteractionTranscript,
  ConversationBase,
} from '../dto/conversation.dto';
import { mockFullConversationResponse } from '../services/__mocks__/conversation.mock';

const ApiHeaderParticipantId = (required = false) =>
  ApiHeader({
    name: 'PII-Participant-Id',
    description: 'ID of the participant (ADVISOR or CUSTOMER or SYSTEM)',
    required,
    schema: {
      type: 'string',
      example: 'advisor.1@nl.abnamro.com',
    },
  });

const ApiQueryForConversations = () => [
  ApiHeader({
    name: 'PII-Participant-Id',
    description: 'ID of the participant (ADVISOR or CUSTOMER or SYSTEM)',
    required: false,
    schema: {
      type: 'string',
      example: 'advisor.1@nl.abnamro.com',
    },
  }),
  ApiQuery({
    name: 'interactionReference',
    type: 'string',
    required: false,
    example: 'conversation-reference',
    description: 'Ref of conversation',
  }),
];

export const CreateConversationDocs = () => {
  return applyDecorators(
    ApiTags('Real-Time Conversation'),
    ApiOperation({
      summary: 'Create a new conversation',
      description: 'Create a new conversation',
      operationId: 'createConversation',
    }),
    CreatedResponse(Conversation, {
      examples: {
        conversationId: '49b24451-74d7-49ed-9120-4a263a06d2ba',
        createdAt: 1736850840283,
        createdBy: 'aab-sys-021582',
      },
    }),
    ApiErrorResponseSchema({
      badRequests: [],
      notFounds: [],
    })
  );
};

export const GetConversationByIdDocs = () => {
  return applyDecorators(
    ApiTags('Real-Time Conversation'),
    ApiOperation({
      summary: 'Get conversation by Id',
      description: 'Get conversation by Id',
      operationId: 'getConversation',
    }),
    OkResponse(Conversation, {
      examples: mockFullConversationResponse(),
    }),
    ApiErrorResponseSchema({
      badRequests: ['CONVERSATION_ID_INVALID'],
      notFounds: ['CONVERSATION_NOT_FOUND'],
    })
  );
};

export const DeleteConversationDocs = () => {
  return applyDecorators(
    ApiTags('Real-Time Conversation'),
    ApiOperation({
      summary: 'Delete a conversation',
      description: 'Delete a conversation',
      operationId: 'deleteConversation',
    }),
    OkResponse(),
    ApiErrorResponseSchema({
      badRequests: ['CONVERSATION_ID_INVALID'],
      notFounds: [],
    })
  );
};

export const SearchConversationDocs = () => {
  return applyDecorators(
    ApiTags('Real-Time Conversation'),
    ApiOperation({
      summary: 'Search for a conversation',
      description:
        'Search for conversations using filters. list is ordered by latest conversations. max 10 conversations returned',
      operationId: 'getConversationList',
    }),
    ...ApiQueryForConversations(),
    OkResponse(ConversationBase, {
      isArray: true,
    }),
    ApiErrorResponseSchema({
      badRequests: ['SEARCH_PARAMETER_MISSING'],
      notFounds: [],
    })
  );
};

export const CreateInteractionDocs = () => {
  return applyDecorators(
    ApiTags('Real-Time Conversation'),
    ApiOperation({
      summary: 'Create a new interaction',
      description: 'Create a new interaction from a conversation',
      operationId: 'createConversationInteraction',
    }),
    ApiRequestBody(ConversationInteractionInput, {}),
    CreatedResponse(ConversationInteraction),
    ApiErrorResponseSchema({
      badRequests: ['CONVERSATION_ID_INVALID'],
      notFounds: ['CONVERSATION_NOT_FOUND'],
    })
  );
};

export const CreateTranscriptDocs = () => {
  return applyDecorators(
    ApiTags('Real-Time Conversation'),
    ApiOperation({
      summary: 'Insert transcriptions chunks for an interaction',
      description: 'Add some transcriptions to an interaction',
      operationId: 'createConversationInteractionTranscription',
    }),
    ApiRequestBody(InteractionTranscript, {
      examples: {
        example: {
          summary: 'Example',
          value: [
            {
              participantId: 'advisor.1@nl.abnamro.com',
              text: 'Ik wil een nieuwe hypotheek.',
              timestamp: 1736850840283,
            },
          ],
        },
      },
      isArray: true,
    }),
    CreatedResponse(),
    ApiErrorResponseSchema({
      badRequests: ['CONVERSATION_ID_INVALID', 'INTERACTION_ID_INVALID'],
      notFounds: ['CONVERSATION_NOT_FOUND', 'INTERACTION_ID_NOT_FOUND'],
    })
  );
};

export const GetTranscriptDocs = () => {
  return applyDecorators(
    ApiTags('Real-Time Conversation'),
    ApiOperation({
      summary: 'Get all transcript for that interaction',
      description: 'Get all transcript for that interaction',
      operationId: 'getConversationInteractionTranscription',
    }),
    OkResponse(InteractionTranscript, {
      isArray: true,
    }),
    ApiErrorResponseSchema({
      badRequests: ['CONVERSATION_ID_INVALID', 'INTERACTION_ID_INVALID'],
      notFounds: ['INTERACTION_ID_NOT_FOUND', 'CONVERSATION_NOT_FOUND'],
    })
  );
};

export const UpdateContextDocs = () => {
  return applyDecorators(
    ApiTags('Real-Time Conversation'),
    ApiOperation({
      summary: 'Update context with additional values',
      description: 'Update context with additional values',
      operationId: 'updateConversationInteractionContext',
    }),
    ApiRequestBody(InteractionContext, {
      examples: {
        example: {
          value: { pronoun: 'hij', topic: 'HYPL', language: 'EN' },
        },
      },
      description: 'Context of the interaction',
    }),
    OkResponse(InteractionContext, {
      examples: {
        pronoun: 'hij',
        topic: 'HYPL',
        language: 'EN',
      },
    }),
    ApiErrorResponseSchema({
      badRequests: ['CONVERSATION_ID_INVALID', 'INTERACTION_ID_INVALID'],
      notFounds: ['CONVERSATION_NOT_FOUND', 'INTERACTION_ID_NOT_FOUND'],
    })
  );
};
export const CreateInsightDocs = () => {
  return applyDecorators(
    ApiTags('Insight'),
    ApiOperation({
      summary: 'Create an insight as part for the conversation',
      description: `Create an insight as part for the conversation.`,
      operationId: 'createConversationInsight',
    }),
    ApiHeaderParticipantId(true),
    ApiRequestBody(InsightCreateInput, {
      examples: {
        summaryExample: {
          value: {
            type: 'summarize',
            parameters: {
              conversationId: '49b24451-74d7-49ed-9120-4a263a06d2ba',
              includeAllInteractions: true,
            },
          },
        },
        ReSummarizeExample: {
          value: {
            type: 'RE_SUMMARIZE',
            parameters: {
              insightId: 'some-insight-id',
              manual: {
                editedSummary: 'edited summary',
              },
            },
          },
        },
        KbSearchExample: {
          value: {
            type: 'KB_SEARCH',
            parameters: {
              conversationId: '49b24451-74d7-49ed-9120-4a263a06d2ba',
              message: 'search message',
            },
          },
        },
      },
    }),
    ApiExtraModels(InsightSummaryData),
    ApiExtraModels(InsightSearchData),
    ApiExtraModels(InsightDocument),
    CreatedResponse(Insight),
    ApiErrorResponseSchema({
      badRequests: ['INSIGHT_TYPE_INVALID', 'SUMMARY_ACTION_INVALID', 'INSIGHT_ID_INVALID', 'CONVERSATION_ID_INVALID'],
      notFounds: ['CONVERSATION_NOT_FOUND', 'INSIGHT_ID_NOT_FOUND', 'TRANSCRIPTIONS_NOT_FOUND'],
    })
  );
};

export const CreateInsightFeedbackDocs = () => {
  return applyDecorators(
    ApiTags('Insight'),
    ApiOperation({
      summary: 'Submit feedback for an insight',
      description: 'Submit feedback from an advisor for a specific insight.',
      operationId: 'createConversationInsightFeedback',
    }),
    ApiHeaderParticipantId(true),
    ApiRequestBody(InsightFeedbackInput, {}),
    CreatedResponse(),
    ApiErrorResponseSchema({
      badRequests: ['INSIGHT_ID_INVALID'],
      notFounds: ['INSIGHT_ID_NOT_FOUND'],
    })
  );
};
