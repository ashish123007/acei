import type { Type } from '@nestjs/common';
import { applyDecorators } from '@nestjs/common';
import {
  ApiOkResponse,
  ApiBadRequestResponse,
  ApiNotFoundResponse,
  ApiInternalServerErrorResponse,
  ApiCreatedResponse,
} from '@nestjs/swagger';
import type { ObjectType } from '../types';
import { Errors } from '../errors/response-errors';
import { BadRequestAvailableCode, NotFoundAvailableCode } from '../errors/custom-errors';

interface ApiDataResponseOptions {
  description?: string;
  isArray?: boolean;
  examples?: ObjectType;
}

interface ApiErrorOptions {
  badRequests: Array<keyof typeof BadRequestAvailableCode>;
  notFounds: Array<keyof typeof NotFoundAvailableCode>;
}

export const OkResponse = <T extends Type<any>>(dto?: T, options?: ApiDataResponseOptions) => {
  return ApiOkResponse(SuccessResponse(dto, options));
};

export const CreatedResponse = <T extends Type<any>>(dto?: T, options?: ApiDataResponseOptions) => {
  return ApiCreatedResponse(SuccessResponse(dto, options));
};

export function ApiErrorResponseSchema(options: ApiErrorOptions) {
  const serverErrorResponse = ServerErrorResponseWithExample();

  const responses: Array<MethodDecorator & ClassDecorator> = [serverErrorResponse];

  if (options.badRequests.length > 0) {
    responses.push(BadRequestResponseWithExample(options.badRequests));
  }

  if (options.notFounds.length) {
    responses.push(NotFoundResponseWithExample(options.notFounds));
  }

  return applyDecorators(...responses);
}

const SuccessResponse = <T extends Type<any>>(dto?: T, options?: ApiDataResponseOptions) => {
  return {
    description: 'Success',
    ...(dto !== undefined && { type: dto, example: options?.examples }),
    isArray: options?.isArray,
  };
};

function BadRequestResponseWithExample(badRequests: Array<keyof typeof BadRequestAvailableCode>) {
  return ApiBadRequestResponse({
    description: `Bad Request.One or more input parameters are invalid. Possible Error List:
Detailed Error List:
  ---
${badRequests.map((e) => `- ${e}\n  > ${BadRequestAvailableCode[e]}`).join('\n')}
`,
    type: Errors,
    example: {
      errors: [{ status: 400, code: badRequests[0], message: BadRequestAvailableCode[badRequests[0]] }],
    },
  });
}

function NotFoundResponseWithExample(notFounds: Array<keyof typeof NotFoundAvailableCode>) {
  return ApiNotFoundResponse({
    description: `Entity not found:
Detailed Error List:
  ---
${notFounds.map((e) => `- ${e}\n  > ${NotFoundAvailableCode[e]}`).join('\n')}
`,
    type: Errors,
    example: {
      errors: [{ status: 404, code: notFounds[0], message: NotFoundAvailableCode[notFounds[0]] }],
    },
  });
}

function ServerErrorResponseWithExample() {
  return ApiInternalServerErrorResponse({
    description: `"Internal Service Error"
Detailed Error List: 
---
- INTERNAL_SERVER_ERROR
  > Internal error occurred`,
    type: Errors,
    example: {
      errors: [{ status: 500, code: 'INTERNAL_SERVER_ERROR', message: 'Internal server error' }],
    },
  });
}
