import { generateActionId } from './generateActionId';

jest.mock('crypto', () => ({
  randomInt: jest.fn().mockReturnValue(5000),
}));

describe('Generate Action ID tests', () => {
  beforeEach(() => {
    jest.useFakeTimers();
    jest.setSystemTime(new Date(2024, 10, 2));
  });

  afterEach(() => {
    jest.resetAllMocks();
  });
  it('should generate action id based on action type', () => {
    const TASK_TYPE = 'transcribe';
    const actionId = generateActionId(TASK_TYPE);
    expect(actionId).toEqual('transcribe_1730502000000_5000');
  });
});
