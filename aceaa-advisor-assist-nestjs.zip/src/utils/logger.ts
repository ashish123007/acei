/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { createLogger, format, transports } from 'winston';
import config from '../config';
import { MESSAGE } from 'triple-beam';
import { logTelemetry } from './telemetry';
import type { RequestBodyType } from '../types/loggerTypes';

export const logIncomingRequest = (endpoint: string, requestBody?: RequestBodyType) => {
  logTelemetry(
    !requestBody
      ? {
          event_type: 'router_request_received',
          endpoint: endpoint,
        }
      : {
          event_type: 'router_request_received',
          user_id: requestBody.user_id,
          endpoint: endpoint,
        }
  );
};

export class WinstonConsoleLogTransport extends transports.Console {
  log(info: any, callback: () => void) {
    setImmediate(() => this.emit('logged', info));

    // eslint-disable-next-line no-console
    console.log(info[MESSAGE]);

    if (callback) {
      callback();
    }
  }
}

export const logger = createLogger({
  level: config.LOG_LEVEL,
  format: format.combine(format.errors({ stack: true }), format.splat(), format.json()),
  silent: config.TEST,
  transports: [
    new WinstonConsoleLogTransport({
      format: format.simple(),
    }),
  ],
});
