export const countSpecialCharacters = (text: string): number => {
  const specialCharRegex = /[^a-zA-Z0-9]/g;
  const matches = text.match(specialCharRegex);
  return matches?.length ?? 0;
};
