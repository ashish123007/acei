import { logIncomingRequest, logger, WinstonConsoleLogTransport } from './logger';
import { logTelemetry } from './telemetry';
import { MESSAGE } from 'triple-beam';

jest.mock('./telemetry');

describe('WinstonConsoleLogTransport tests', () => {
  let consoleLogSpy: jest.SpyInstance;

  beforeEach(() => {
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
  });

  afterEach(() => {
    consoleLogSpy.mockRestore();
  });

  it('should call console.log with the correct message', () => {
    const info = {
      level: 'info',
      message: 'This is a test message',
      [MESSAGE]: 'This is a test message',
    };

    const transport = new WinstonConsoleLogTransport();
    const callback = jest.fn();

    transport.log(info, callback);

    expect(consoleLogSpy).toHaveBeenCalledWith(info[MESSAGE]);
    expect(callback).toHaveBeenCalled();
  });
});

describe('Logger file tests', () => {
  describe('logIncomingRequest tests', () => {
    const requestParameters = {
      endpoint: 'test',
      requestBody: {
        user_id: '1111111',
      },
    };
    it('should respond with user_id', () => {
      logIncomingRequest(requestParameters.endpoint, requestParameters.requestBody);
      expect(logTelemetry).toHaveBeenCalledWith({
        event_type: 'router_request_received',
        user_id: requestParameters.requestBody.user_id,
        endpoint: requestParameters.endpoint,
      });
    });

    it('should respond without user_id', () => {
      logIncomingRequest(requestParameters.endpoint);
      expect(logTelemetry).toHaveBeenCalledWith({
        event_type: 'router_request_received',
        endpoint: requestParameters.endpoint,
      });
    });
  });

  it('should logger logs info', () => {
    const infoLogger = jest.spyOn(logger, 'info');
    logger.info('test');
    expect(infoLogger).toHaveBeenCalled();
    expect(infoLogger).toHaveBeenCalledWith('test');
  });

  it('should logger logs error', () => {
    const errorLogger = jest.spyOn(logger, 'error');
    logger.error('error');
    expect(errorLogger).toHaveBeenCalled();
    expect(errorLogger).toHaveBeenCalledWith('error');
  });

  it('should logger logs debug', () => {
    const debugLogger = jest.spyOn(logger, 'debug');
    logger.debug('debug');
    expect(debugLogger).toHaveBeenCalled();
    expect(debugLogger).toHaveBeenCalledWith('debug');
  });
});
