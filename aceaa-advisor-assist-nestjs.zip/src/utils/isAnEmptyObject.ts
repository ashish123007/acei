import type { ObjectType } from '../types';

export const isAnEmptyObject = (obj: ObjectType): boolean => {
  return Object.keys(obj).length === 0;
};
