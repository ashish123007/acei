import { InternalServerErrorException } from '@nestjs/common';
import { logger } from './logger';

// supported telemetry events
export const ALLOWED_EVENTS = [
  'router_request_received',
  // blob store
  'blob_client_connection_attempt',
  'blob_client_connection_failure',
  'blob_client_connection_success',
  // authentication
  'role_not_authorised',
  'capability_not_authorised',
  'role_not_in_config',
];

interface LogTelemetryParams {
  event_type?: string;
  user_id?: string;
  endpoint?: string;
  error_message?: string;
  stack?: string;
}

export function logTelemetry(tags: LogTelemetryParams) {
  if (!tags.event_type) {
    throw new InternalServerErrorException('Must pass a valid event_type.');
  }

  if (!ALLOWED_EVENTS.includes(tags.event_type)) {
    throw new InternalServerErrorException('Telemetry event type not allowed.');
  }

  logger.info('json:%s', tags);
}
