import { InternalServerErrorException } from '@nestjs/common';
import { ALLOWED_EVENTS, logTelemetry } from './telemetry';
import { logger } from './logger';

jest.mock('./logger');

describe('Telemetry file tests', () => {
  it('should throw error on invalid event_type', () => {
    try {
      logTelemetry({});
    } catch (error) {
      expect(error).toEqual(new InternalServerErrorException('Must pass a valid event_type.'));
    }
  });

  it('should throw error on unknown event_type', async () => {
    try {
      logTelemetry({ event_type: 'text', endpoint: '' });
    } catch (error) {
      expect(error).toEqual(new InternalServerErrorException('Telemetry event type not allowed.'));
    }
  });

  it('should call logger with tags', () => {
    logTelemetry({ event_type: ALLOWED_EVENTS[0], endpoint: '' });
    expect(logger.info).toHaveBeenCalledWith('json:%s', { event_type: ALLOWED_EVENTS[0], endpoint: '' });
  });
});
