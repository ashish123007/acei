import { randomInt } from 'crypto';

export const generateActionId = (taskType: string): string => {
  const currentDateInMilis = Date.now();
  const randomSeed = randomInt(10000);
  return `${taskType}_${currentDateInMilis}_${randomSeed}`;
};
