import { mockDate, mockUnixTimeStamp } from '../services/__mocks__/date.mock';
import { dateToUnixTimeStamp, formatUnixTimeStampToString } from './formatDate';

describe('dateToUnixTimestamp', () => {
  test('dateToUnixTimestamp converts Date to Unix timestamp correctly', () => {
    const date = new Date('2023-10-10T12:00:00Z');
    const expectedTimestamp = Number(1696939200000);
    const actualTimestamp = dateToUnixTimeStamp(date);
    expect(Number(actualTimestamp)).toBe(expectedTimestamp);
  });
});

describe('formatUnixTimeStampToString', () => {
  test('formatUnixTimeStampToString converts Unix timestamp to string correctly', () => {
    const expectedDateString = mockDate;
    const timestamp = mockUnixTimeStamp;
    const actualDateString = formatUnixTimeStampToString(timestamp);

    expect(actualDateString).toBe(expectedDateString);
  });
});
