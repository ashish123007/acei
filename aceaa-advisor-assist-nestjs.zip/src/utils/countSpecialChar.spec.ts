import { countSpecialCharacters } from './countSpecialChar';

describe('countSpecialCharacters', () => {
  it('should count special character in a text', () => {
    const text = 'some-text-;.';
    const result = countSpecialCharacters(text);

    expect(result).toBe(4);
  });
});
