import type { ApiConsumerWithToken } from './decorators/apiConsumer.decorator';

export const getDefaultRole = (apiConsumer: ApiConsumerWithToken, role?: string): string =>
  role ?? apiConsumer.roleName ?? 'AdvisorAssist-CCO';
