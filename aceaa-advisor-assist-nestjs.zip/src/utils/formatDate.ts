import { toZonedTime } from 'date-fns-tz';

export const dateToUnixTimeStamp = (date?: Date) => {
  const newDate = date ? +date : +new Date();
  return BigInt(newDate);
};

export const formatUnixTimeStampToString = (timestamp: bigint) => {
  const date = new Date(Number(timestamp)).toISOString();
  return toZonedTime(date, 'Europe/Amsterdam').toISOString();
};
