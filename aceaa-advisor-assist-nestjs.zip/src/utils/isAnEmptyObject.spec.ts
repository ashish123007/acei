import { isAnEmptyObject } from './isAnEmptyObject';

describe('isAnEmptyObject', () => {
  it('should return true if it is an empty object', () => {
    const text = {};
    const result = isAnEmptyObject(text);

    expect(result).toBeTruthy();
  });

  it('should return false if it is not an empty object', () => {
    const text = { foo: 'bar' };
    const result = isAnEmptyObject(text);

    expect(result).toBeFalsy();
  });
});
