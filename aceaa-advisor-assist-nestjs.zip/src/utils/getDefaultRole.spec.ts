import { ApiConsumerWithToken } from './decorators/apiConsumer.decorator';
import { getDefaultRole } from './getDefaultRole';

describe('getDefaultRole', () => {
  it('should return the actual role', () => {
    const role = 'some-role';
    const result = getDefaultRole({ roleName: 'some-role-name' } as ApiConsumerWithToken, role);

    expect(result).toBe(role);
  });

  it('should return the default role', () => {
    const result = getDefaultRole({} as ApiConsumerWithToken);

    expect(result).toBe('AdvisorAssist-CCO');
  });

  it('should return the role from apiConsumer', () => {
    const role = 'api-consumer-role';
    const result = getDefaultRole({ roleName: role } as ApiConsumerWithToken);

    expect(result).toBe(role);
  });
});
