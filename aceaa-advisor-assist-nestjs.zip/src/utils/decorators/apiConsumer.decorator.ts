import { createParamDecorator, type ExecutionContext } from '@nestjs/common';
import type { ApiConsumer } from '../../../prisma-generated-client';
import type { Request } from 'express';

export type ApiConsumerWithToken = ApiConsumer & { token: string };

export const ApiConsumerDecorator = createParamDecorator((_: unknown, ctx: ExecutionContext): ApiConsumerWithToken => {
  const request = ctx.switchToHttp().getRequest<Request & { apiConsumer: ApiConsumer }>();
  return request.apiConsumer as ApiConsumerWithToken;
});
