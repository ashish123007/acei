import { ExecutionContext } from '@nestjs/common';
import { apiConsumerMock } from '../../services/__mocks__/apiConsumer.mock';
import { ApiConsumerDecorator } from './apiConsumer.decorator';

jest.mock('@nestjs/common', () => ({
  ...jest.requireActual('@nestjs/common'),
  createParamDecorator: jest.fn((fn) => fn),
}));

describe('ApiConsumerDecorator', () => {
  it('should return the ApiConsumerWithToken from the request object', () => {
    // Arrange

    const mockRequest = {
      apiConsumer: apiConsumerMock,
    };

    const mockExecutionContext = {
      switchToHttp: () => ({
        getRequest: () => mockRequest,
      }),
    };

    // Act
    const apiConsumer = ApiConsumerDecorator(null, mockExecutionContext as ExecutionContext);

    // Assert
    expect(apiConsumer).toBe(apiConsumerMock);
  });
});
