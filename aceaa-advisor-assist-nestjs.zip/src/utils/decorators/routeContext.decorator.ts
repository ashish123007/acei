import { SetMetadata } from '@nestjs/common';

export const RouteContext = (context: string) => SetMetadata('routeContext', context);
