import { Injectable, type ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import * as jwt from 'jsonwebtoken';
import type { Request } from 'express';
import type { ApiConsumerWithToken } from '../utils/decorators/apiConsumer.decorator';
import { dateToUnixTimeStamp } from '../utils/formatDate';
import { logger } from '../utils/logger';

@Injectable()
export class JwtAuthGuardNoDb extends AuthGuard('jwt') {
  async canActivate(context: ExecutionContext) {
    const request = context.switchToHttp().getRequest<Request & { apiConsumer: ApiConsumerWithToken }>();
    const token = request.headers['authorization']?.split(' ')[1];

    let tenantId: string;

    if (!token) {
      logger.warn('Token not provided');
      throw new UnauthorizedException('No token provided');
    }

    if (token === 'masterPlatformTokenDev') {
      tenantId = 'platform';
    } else {
      const user = jwt.decode(token) as { oid: string; tid: string; preferred_username: string; name: string };

      if (!user) {
        logger.verbose('Invalid token');
        throw new UnauthorizedException('Invalid token');
      }

      tenantId = `${user.oid}.${user.tid}`;
    }

    request.apiConsumer = {
      id: tenantId,
      tenant_id: tenantId,
      type: 'advisor',
      has_ai_permission: true,
      template: {},
      has_callstatus_permission: true,
      created_at: dateToUnixTimeStamp(new Date()),
      token,
      roleName: 'AdvisorAssist-CCO',
    };

    if (token === 'masterPlatformTokenDev') {
      return true;
    }

    return super.canActivate(context) as Promise<boolean>;
  }
}
