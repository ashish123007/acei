import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { passportJwtSecret } from 'jwks-rsa';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    const JWKS_URL = `https://login.microsoftonline.com/${process.env.AZURE_TENANT_ID}/discovery/v2.0/keys?appid=${process.env.AZURE_AAD_SPN_CLIENT_ID}`;
    const ISSUER = `https://login.microsoftonline.com/${process.env.AZURE_TENANT_ID}/v2.0`;
    super({
      secretOrKeyProvider: passportJwtSecret({
        jwksUri: JWKS_URL,
      }),
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      audience: process.env.AZURE_AAD_SPN_CLIENT_ID,
      issuer: ISSUER,
      algorithms: ['RS256'],
      options: {
        require_aud: true,
        require_exp: true,
        require_iss: true,
        require_iat: true,
        require_nbf: true,
        require_sub: true,
        verify_aud: true,
        verify_exp: true,
        verify_iat: true,
        verify_iss: true,
        verify_nbf: true,
        verify_sub: true,
      },
    });
  }

  validate(payload: unknown): unknown {
    return payload;
  }
}
