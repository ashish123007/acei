import { Injectable, type ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiConsumerService } from '../services/apiConsumer.service';
import * as jwt from 'jsonwebtoken';
import type { Request } from 'express';
import type { ApiConsumerWithToken } from '../utils/decorators/apiConsumer.decorator';
import { logger } from '../utils/logger';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  constructor(private apiConsumer: ApiConsumerService) {
    super();
  }

  async canActivate(context: ExecutionContext) {
    const request = context.switchToHttp().getRequest<Request & { apiConsumer: ApiConsumerWithToken }>();
    const validatedConsumerId = request.headers['validated-consumer-id'];
    const token = request.headers['authorization']?.split(' ')[1] || '';

    const consumerId =
      typeof validatedConsumerId === 'string'
        ? validatedConsumerId
        : token
          ? this.getTenantIdFromToken(token)
          : (() => {
              logger.warn('No validated-consumer-id or token provided');
              throw new UnauthorizedException('No validated-consumer-id or token provided');
            })();

    const apiConsumer = await this.apiConsumer.getOrCreateConsumer(consumerId);

    request.apiConsumer = {
      ...apiConsumer,
      token,
    };

    return !!(validatedConsumerId || this.isSpecialToken(token) || (await super.canActivate(context)));
  }

  private getTenantIdFromToken(token: string): string {
    if (token === 'masterPlatformTokenDev') {
      return 'platform';
    } else if (token === 'mockNICETokenDev') {
      return 'nice';
    } else if (token === 'mockIVRTokenDev') {
      return 'voicebot';
    } else {
      const user = jwt.decode(token) as { oid: string; tid: string; preferred_username: string; name: string };

      if (!user) {
        logger.warn('Invalid token');
        throw new UnauthorizedException('Invalid token');
      }

      return `${user.oid}.${user.tid}`;
    }
  }
  private isSpecialToken(token: string): boolean {
    return ['masterPlatformTokenDev', 'mockNICETokenDev', 'mockIVRTokenDev'].includes(token);
  }
}
