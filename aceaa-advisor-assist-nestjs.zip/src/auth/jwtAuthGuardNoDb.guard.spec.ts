import { UnauthorizedException } from '@nestjs/common';
import * as jwt from 'jsonwebtoken';
import type { ExecutionContext } from '@nestjs/common';
import { JwtAuthGuardNoDb } from './jwtAuthGuardNoDb.guard';
import { logger } from '../utils/logger';

jest.mock('jsonwebtoken');
jest.mock('@azure/identity');
jest.mock('@nestjs/passport', () => {
  return {
    AuthGuard: (strategy: string) => {
      return class {
        canActivate() {
          return true;
        }
      };
    },
  };
});

describe('JwtAuthGuardNoDb', () => {
  let guard: JwtAuthGuardNoDb;

  beforeEach(() => {
    guard = new JwtAuthGuardNoDb();
  });

  describe('canActivate', () => {
    it('should allow access for masterPlatformTokenDev', async () => {
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'Bearer masterPlatformTokenDev',
            },
          }),
        }),
      } as unknown as ExecutionContext;

      const result = await guard.canActivate(mockExecutionContext);
      expect(result).toBe(true);
    });

    it('should decode JWT and call super.canActivate', async () => {
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'Bearer someValidToken',
            },
          }),
        }),
      } as unknown as ExecutionContext;

      (jwt.decode as jest.Mock).mockReturnValue({
        oid: 'userOid',
        tid: 'userTid',
        preferred_username: 'user',
        name: 'John Doe',
      });

      const result = await guard.canActivate(mockExecutionContext);

      expect(jwt.decode).toHaveBeenCalledWith('someValidToken');
      expect(result).toBe(true);
    });

    it('should throw an error if token is not provided', async () => {
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: undefined,
            },
          }),
        }),
      } as unknown as ExecutionContext;

      await expect(guard.canActivate(mockExecutionContext)).rejects.toThrow(UnauthorizedException);
      expect(logger.warn).toHaveBeenCalledWith('Token not provided');
    });

    it('should throw an error if token is not valid', async () => {
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'Bearer invalidToken',
            },
          }),
        }),
      } as unknown as ExecutionContext;

      (jwt.decode as jest.Mock).mockReturnValue(null);

      await expect(guard.canActivate(mockExecutionContext)).rejects.toThrow(UnauthorizedException);
      expect(logger.verbose).toHaveBeenCalledWith('Invalid token');
    });
  });
});
