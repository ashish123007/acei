import { ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { JwtAuthGuard } from './jwtAuth.guard'; // Adjust the import path as necessary
import { ApiConsumerService } from '../services/apiConsumer.service';
import * as jwt from 'jsonwebtoken';

// Mock the jwt module
jest.mock('jsonwebtoken');

// Mock the AuthGuard function to return a class with a canActivate method
jest.mock('@nestjs/passport', () => {
  return {
    AuthGuard: (strategy: string) => {
      return class {
        canActivate() {
          return true; // Mock implementation always returns true
        }
      };
    },
  };
});

describe('JwtAuthGuard', () => {
  let guard: JwtAuthGuard;
  let apiConsumerService: ApiConsumerService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        JwtAuthGuard,
        {
          provide: ApiConsumerService,
          useValue: {
            getOrCreateConsumer: jest.fn().mockResolvedValue({
              id: 'consumerId',
              name: 'platform',
            }),
          },
        },
      ],
    }).compile();

    guard = module.get<JwtAuthGuard>(JwtAuthGuard);
    apiConsumerService = module.get<ApiConsumerService>(ApiConsumerService);
  });

  describe('canActivate', () => {
    it('should allow access for masterPlatformTokenDev', async () => {
      process.env.ENVIRONMENT = 'local';
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'Bearer masterPlatformTokenDev',
            },
          }),
        }),
      } as unknown as ExecutionContext;

      const result = await guard.canActivate(mockExecutionContext);
      expect(result).toBe(true);
      process.env.ENVIRONMENT = undefined;
    });

    it('should decode JWT and call super.canActivate', async () => {
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'Bearer someValidToken',
            },
          }),
        }),
      } as unknown as ExecutionContext;

      (jwt.decode as jest.Mock).mockReturnValue({
        oid: 'userOid',
        tid: 'userTid',
      });

      const result = await guard.canActivate(mockExecutionContext);

      expect(jwt.decode).toHaveBeenCalledWith('someValidToken');
      expect(apiConsumerService.getOrCreateConsumer).toHaveBeenCalledWith('userOid.userTid');
      expect(result).toBe(true);
    });

    it('should throw an error if token or consumer-id is not provided', async () => {
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {},
          }),
        }),
      } as unknown as ExecutionContext;

      await expect(guard.canActivate(mockExecutionContext)).rejects.toThrow(UnauthorizedException);
    });
    it('should throw an error if token is not valid', async () => {
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'Bearer invalidToken',
            },
          }),
        }),
      } as unknown as ExecutionContext;

      // Mock the decode function to return null for an invalid token
      (jwt.decode as jest.Mock).mockReturnValue(null);

      await expect(guard.canActivate(mockExecutionContext)).rejects.toThrow(UnauthorizedException);
    });
    it('should allow access for mockNICETokenDev', async () => {
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'Bearer mockNICETokenDev',
            },
          }),
        }),
      } as unknown as ExecutionContext;

      const result = await guard.canActivate(mockExecutionContext);
      expect(result).toBe(true);
      expect(apiConsumerService.getOrCreateConsumer).toHaveBeenCalledWith('nice');
    });

    it('should allow access for mockIVRTokenDev', async () => {
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'Bearer mockIVRTokenDev',
            },
          }),
        }),
      } as unknown as ExecutionContext;

      const result = await guard.canActivate(mockExecutionContext);
      expect(result).toBe(true);
      expect(apiConsumerService.getOrCreateConsumer).toHaveBeenCalledWith('voicebot');
    });
    it('should allow access for IAG consumer', async () => {
      const mockExecutionContext = {
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              'validated-consumer-id': 'test',
            },
          }),
        }),
      } as unknown as ExecutionContext;

      const result = await guard.canActivate(mockExecutionContext);
      expect(result).toBe(true);
    });
  });
});
