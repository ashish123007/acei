import type { CanActivate } from '@nestjs/common';
import { Injectable, type ExecutionContext, UnauthorizedException } from '@nestjs/common';
import * as jwt from 'jsonwebtoken';
import type { Request } from 'express';
import * as jwksClient from 'jwks-rsa';
import { logger } from '../utils/logger';

const CLIENT_ID = process.env.AZURE_AAD_SPN_CLIENT_ID;
const JWKS_URL = `https://login.microsoftonline.com/${process.env.AZURE_TENANT_ID}/discovery/v2.0/keys?appid=${CLIENT_ID}`;
// support both v1 and v2 tokens
const ISSUERS = [
  `https://sts.windows.net/${process.env.AZURE_TENANT_ID}/`,
  `https://login.microsoftonline.com/${process.env.AZURE_TENANT_ID}/v2.0`,
];

@Injectable()
export class AzureJwtAuthGuard implements CanActivate {
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request>();
    const token = request.headers['authorization']?.split(' ')[1];

    if (!token) {
      logger.warn('Token not provided');
      return Promise.reject(new UnauthorizedException('No token provided'));
    }

    return new Promise((resolve, reject) => {
      jwt.verify(
        token,
        this.getSigningKey,
        {
          issuer: ISSUERS,
          audience: CLIENT_ID,
          algorithms: ['RS256'],
        },
        (err) => {
          if (err) {
            logger.error('Token verification failed:', err);
            return reject(new UnauthorizedException('Invalid token'));
          } else {
            resolve(true);
          }
        }
      );
    });
  }

  private getSigningKey = (header: jwt.JwtHeader, callback: jwt.SigningKeyCallback) => {
    const client = jwksClient({
      jwksUri: JWKS_URL,
    });

    client.getSigningKey(header.kid, (err, key) => {
      if (err) {
        logger.error('Error fetching signing key:', err);
        return callback(err);
      }
      const signingKey = key?.getPublicKey();
      callback(null, signingKey);
    });
  };
}
