import { UnauthorizedException } from '@nestjs/common';
import { AzureJwtAuthGuard } from './azureJwtAuth.guard';
import * as jwt from 'jsonwebtoken';
import * as jwksClient from 'jwks-rsa';
import { logger } from '../utils/logger';
import { JwtHeader } from 'jsonwebtoken';

jest.mock('jsonwebtoken');
jest.mock('jwks-rsa');
jest.mock('../utils/logger');

describe('AzureJwtAuthGuard', () => {
  let guard: AzureJwtAuthGuard;

  beforeEach(() => {
    guard = new AzureJwtAuthGuard();
  });

  it('should throw UnauthorizedException if no token is provided', async () => {
    const mockContext = {
      switchToHttp: () => ({
        getRequest: () => ({
          headers: {},
        }),
      }),
    } as any;

    await expect(guard.canActivate(mockContext)).rejects.toThrow(UnauthorizedException);
    expect(logger.warn).toHaveBeenCalledWith('Token not provided');
  });

  it('should throw UnauthorizedException if token verification fails', async () => {
    const mockContext = {
      switchToHttp: () => ({
        getRequest: () => ({
          headers: {
            authorization: 'Bearer invalid-token',
          },
        }),
      }),
    } as any;

    (jwt.verify as jest.Mock).mockImplementation((token, getKey, options, callback) => {
      callback(new Error('Invalid token'), null);
    });

    await expect(guard.canActivate(mockContext)).rejects.toThrow(new UnauthorizedException('Invalid token'));
    expect(logger.error).toHaveBeenCalledWith('Token verification failed:', expect.any(Error));
  });

  it('should resolve true if token verification succeeds', async () => {
    const mockContext = {
      switchToHttp: () => ({
        getRequest: () => ({
          headers: {
            authorization: 'Bearer valid-token',
          },
        }),
      }),
    } as any;

    const mockDecodedToken = { sub: '12345' };
    (jwt.verify as jest.Mock).mockImplementation((token, getKey, options, callback) => {
      callback(null, mockDecodedToken);
    });

    await expect(guard.canActivate(mockContext)).resolves.toBe(true);
  });

  it('should fetch signing key successfully', (done) => {
    const mockHeader = { kid: 'test-kid' } as JwtHeader;
    const mockKey = { getPublicKey: jest.fn().mockReturnValue('public-key') };
    const mockClient = {
      getSigningKey: jest.fn((kid, callback) => callback(null, mockKey)),
    };

    (jwksClient as unknown as jest.Mock).mockReturnValue(mockClient);

    guard['getSigningKey'](mockHeader, (err, key) => {
      expect(err).toBeNull();
      expect(key).toBe('public-key');
      done();
    });
  });

  it('should log error if fetching signing key fails', (done) => {
    const mockHeader = { kid: 'test-kid' } as JwtHeader;
    const mockClient = {
      getSigningKey: jest.fn((kid, callback) => callback(new Error('Key fetch error'), null)),
    };

    (jwksClient as unknown as jest.Mock).mockReturnValue(mockClient);

    guard['getSigningKey'](mockHeader, (err, key) => {
      expect(err).toEqual(new Error('Key fetch error'));
      expect(key).toBeUndefined();
      expect(logger.error).toHaveBeenCalledWith('Error fetching signing key:', expect.any(Error));
      done();
    });
  });
});
