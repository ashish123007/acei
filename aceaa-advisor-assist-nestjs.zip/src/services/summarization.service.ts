import { Injectable } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import type { Prisma } from '../../prisma-generated-client';
import { InsightType } from '../../prisma-generated-client';
import { AiHttpClientService } from './http-client.service';
import type { ApiConsumerWithToken } from '../utils/decorators/apiConsumer.decorator';
import { getDefaultRole } from '../utils/getDefaultRole';
import type { Insight, InsightSummaryData } from '../dto/insight.dto';
import { BadRequestIagException } from '../errors/custom-errors';

type TranscriptionGetPayload = Prisma.TranscriptionGetPayload<{
  include: {
    participant: true;
  };
}>;

export type EditSummaryAction = 'shorten' | 'female' | 'male';
export interface EditSummaryRequest {
  messages: string;
  originalSummary: string;
  action: EditSummaryAction;
}

export interface SummarizationResponse {
  actionId: string;
  message: string;
  transcription: string;
  user_id: string;
  conversation_id: string;
  openai_version: string;
}

export interface EditSummarizationResponse {
  actionId: string;
  message: string;
  original_summary: string;
  transcription: string;
}

export interface GenericSummaryResponse {
  message: string;
  openaiVersion?: string;
  insight: {
    insightId: string;
    createdAt: string;
  };
}

interface CallSummary {
  apiConsumer: ApiConsumerWithToken;
  conversationId: string;
  role?: string;
}

interface FetchSummary extends CallSummary {
  transcriptions: TranscriptionGetPayload[];
}

interface EditSummary extends CallSummary {
  editSummaryRequest: EditSummaryRequest;
}

@Injectable()
export class SummarizationService {
  constructor(private aiHttpClientService: AiHttpClientService) {}

  async fetchSummary({
    apiConsumer,
    conversationId,
    transcriptions,
    role,
  }: FetchSummary): Promise<SummarizationResponse> {
    const formattedMessages = this.formatTranscriptions(transcriptions);
    const userId = randomUUID();

    return this.aiHttpClientService.post<SummarizationResponse>(
      `advisor-assist-be/v2/summarisation?role=${getDefaultRole(apiConsumer, role)}`,
      apiConsumer.token,
      {
        user_id: userId,
        message: formattedMessages,
        conversation_id: conversationId,
      }
    );
  }

  async editSummary({
    editSummaryRequest,
    apiConsumer,
    conversationId,
    role,
  }: EditSummary): Promise<EditSummarizationResponse> {
    const { action, originalSummary, messages } = editSummaryRequest;
    const endpoint = this.getActionEndpoint(action, getDefaultRole(apiConsumer, role));
    const userId = randomUUID();

    return this.aiHttpClientService.post<EditSummarizationResponse>(endpoint, apiConsumer.token, {
      conversation_id: conversationId,
      user_id: userId,
      message: originalSummary,
      original_summary: originalSummary,
      transcription: messages,
    });
  }

  getActionEndpoint(action: EditSummaryAction, role: string) {
    const editSummaryPaths: Record<EditSummaryAction, string> = {
      shorten: `advisor-assist-be/v2/shorten?role=${role}`,
      female: `advisor-assist-be/v2/gendered/female?role=${role}`,
      male: `advisor-assist-be/v2/gendered/male?role=${role}`,
    };
    const path = editSummaryPaths[action];

    if (!path) {
      throw new BadRequestIagException('INSIGHT_TYPE_INVALID', 'Invalid action');
    }
    return path;
  }

  private formatTranscriptions(transcriptions: TranscriptionGetPayload[]) {
    return transcriptions
      .map((message) => `${message.participant.type === 'customer' ? 'klant' : 'ik'}: ${message.content}`)
      .join('\n');
  }

  formatSummaryResponse(summaryResponse: GenericSummaryResponse): Insight {
    const { insight, openaiVersion, message } = summaryResponse;

    const summarydata: InsightSummaryData = {
      content: message,
      llmVersion: openaiVersion ?? 'UNKNOWN_LLM_VERSION',
    };
    return {
      insightId: insight.insightId,
      type: InsightType.Summary,
      data: summarydata,
      insightDateTime: insight.createdAt,
    };
  }
}
