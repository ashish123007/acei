import { Test, TestingModule } from '@nestjs/testing';
import { InteractionContextDto, InteractionService } from './interaction.service';
import { PrismaService } from '../prisma.service';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { ParticipantType, Prisma } from '../../prisma-generated-client';
import { mockConversationResult, mockConversationWithInteraction } from './__mocks__/conversation.mock';
import { mockConversationInteractionInput, mockInteractionResult } from './__mocks__/interaction.mock';
import { apiConsumerMock } from './__mocks__/apiConsumer.mock';
import { TranscriptionService } from './transcription.service';
import { logger } from '../utils/logger';
import { ConversationInteraction } from '../dto/conversation.dto';
import { mockDate, mockUnixTimeStamp } from './__mocks__/date.mock';

describe('InteractionService', () => {
  let service: InteractionService;
  let prismaService: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        InteractionService,
        {
          provide: TranscriptionService,
          useValue: {
            createTranscription: jest.fn(),
          },
        },
        {
          provide: PrismaService,
          useValue: {
            interaction: {
              create: jest.fn(),
              findFirst: jest.fn(),
              findUnique: jest.fn(),
              update: jest.fn(),
              updateMany: jest.fn(),
            },
            conversation: {
              findFirst: jest.fn(),
              findUnique: jest.fn(),
              create: jest.fn(),
            },
            participant: {
              upsert: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<InteractionService>(InteractionService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  describe('findConversationId', () => {
    const mockConversationId = 'some-conversation-id';
    const mockConversationReference = 'ref-456';

    const conversationMock = mockConversationResult();

    it('should return conversation_id if conversationId is provided and found', async () => {
      jest.spyOn(prismaService.conversation, 'findUnique').mockResolvedValue(conversationMock);
      const result = await service.findConversationId(apiConsumerMock, mockConversationId);
      expect(result).toBe(mockConversationId);
    });

    it('should throw NotFoundException if conversationId is provided but not found', () => {
      jest.spyOn(prismaService.conversation, 'findUnique').mockResolvedValue(null);
      expect(service.findConversationId(apiConsumerMock, mockConversationId)).rejects.toThrow(NotFoundException);
    });

    it('should return conversation_id if conversationReference is provided and found', async () => {
      jest.spyOn(prismaService.conversation, 'findFirst').mockResolvedValue(conversationMock);

      const result = await service.findConversationId(apiConsumerMock, undefined, mockConversationReference);
      expect(result).toBe(conversationMock.conversation_id);
    });

    it('should throw NotFoundException if conversationReference is provided but not found', () => {
      jest.spyOn(prismaService.conversation, 'findFirst').mockResolvedValue(null);
      expect(service.findConversationId(apiConsumerMock, undefined, mockConversationReference)).rejects.toThrow(
        NotFoundException
      );
    });

    it('should create and return new conversation_id if neither conversationId nor conversationReference is provided', async () => {
      jest.spyOn(prismaService.conversation, 'create').mockResolvedValue(conversationMock);

      const result = await service.findConversationId(apiConsumerMock);
      expect(result).toBe(conversationMock.conversation_id);
    });
  });

  describe('createInteraction', () => {
    it('should create an interaction with participants', async () => {
      const conversationId = '123';
      const conversationInteractionInputMock = mockConversationInteractionInput();
      const interactionResultMock = mockInteractionResult({
        conversation_id: conversationId,
        reference: conversationInteractionInputMock.reference,
        context: conversationInteractionInputMock.context,
        name: conversationInteractionInputMock.name,
      });

      jest.spyOn(prismaService.interaction, 'create').mockResolvedValue(interactionResultMock);
      jest.spyOn(prismaService.interaction, 'updateMany').mockResolvedValue({} as never);

      jest.spyOn(prismaService.participant, 'upsert').mockResolvedValue({
        participant_id: '1',
        tenant_id: 'tenant_id',
        type: ParticipantType.advisor,
      });

      const result = await service.createInteraction(apiConsumerMock, conversationId, conversationInteractionInputMock);

      expect(prismaService.participant.upsert).toHaveBeenCalledTimes(
        conversationInteractionInputMock.participants?.length || 0
      );
      conversationInteractionInputMock.participants?.forEach((_p, i) => {
        const upsertMock = prismaService.participant.upsert as jest.Mock;
        const upsertCall = upsertMock.mock.calls[i];

        expect(upsertCall).toMatchSnapshot();
      });

      expect(prismaService.interaction.create).toHaveBeenCalledTimes(1);

      const interactionMock = prismaService.interaction.create as jest.Mock;
      const interactionCall = interactionMock.mock.calls[0];
      interactionCall[0].data.created_at = '1736850840283';
      expect(interactionCall).toMatchSnapshot();

      expect(result).toEqual(
        expect.objectContaining({
          interactionId: interactionResultMock.interaction_id,
          reference: interactionResultMock.reference,
          context: interactionResultMock.context,
        })
      );
    });
  });

  describe('updateContext', () => {
    const context: InteractionContextDto = {
      pre_intent: 'HYPL',
      phone_number: 1234567890,
      language_pref: 'en',
    };
    it('should update interaction context', async () => {
      const createInteractionDtoMock = mockInteractionResult({ context });

      const updInteractionContext = {
        ...createInteractionDtoMock,
        ...{
          context: {
            ...((createInteractionDtoMock.context as Prisma.JsonObject) || {}),
            ...context,
          },
        },
      };
      jest.spyOn(prismaService.interaction, 'findUnique').mockResolvedValue(createInteractionDtoMock);
      jest.spyOn(prismaService.interaction, 'update').mockResolvedValue({
        ...updInteractionContext,
      });
      const result = await service.updateContext({
        context,
        conversationId: createInteractionDtoMock.conversation_id,
        apiConsumer: apiConsumerMock,
        interactionId: createInteractionDtoMock.interaction_id,
      });
      expect(result).toEqual(context);
    });
    it('should throw an error when interaction is not found', () => {
      jest.spyOn(prismaService.interaction, 'findUnique').mockResolvedValue(null);
      expect(
        service.updateContext({
          context,
          conversationId: 'some-conversation-id',
          apiConsumer: apiConsumerMock,
          interactionId: 'some-interaction-id',
        })
      ).rejects.toThrow(NotFoundException);
    });
    it('should log error and throw BadRequestException when context is empty', async () => {
      const context: any = {};
      const conversationId = '123';
      const interactionId = '456';

      await expect(
        service.updateContext({ context, conversationId, apiConsumer: apiConsumerMock, interactionId })
      ).rejects.toThrow(BadRequestException);

      expect(logger.warn).toHaveBeenCalledWith(`No context was provided for conversationId: ${conversationId}`);
    });
  });

  describe('mapInteractionResponse', () => {
    it('should map interaction payload to conversation interaction correctly', () => {
      const mockInteraction: any = {
        interaction_id: '123',
        created_at: mockUnixTimeStamp,
        created_by: 'creator',
        name: 'Test Interaction',
        reference: 'ref-123',
        context: { key: 'value' },
        participants: [
          {
            participant: {
              participant_id: 'p1',
              type: ParticipantType.advisor,
              tenant_id: 'tenant1',
            },
            created_at: mockUnixTimeStamp,
            tenant_id: 'tenant1',
            interaction_id: '123',
            participant_id: 'p1',
          },
        ],

        transcriptions: [
          {
            participant_id: 'p1',
            content: 'Hello',
            created_at: mockUnixTimeStamp,
            tenant_id: '',
            interaction_id: '',
            transcript_id: '',
          },
        ],
      };

      const expectedResult: ConversationInteraction = {
        interactionId: '123',
        createdDateTime: mockDate,
        createdBy: 'creator',
        name: 'Test Interaction',
        reference: 'ref-123',
        context: { key: 'value' },
        participants: [{ id: 'p1', type: ParticipantType.advisor }],
        transcriptions: [{ participantId: 'p1', text: 'Hello', transcriptDateTime: mockDate }],
      };

      const result = service.mapInteractionResponse(mockInteraction);
      expect(result).toEqual(expectedResult);
    });
  });
});
