export const mockFeedbackResponse = (overrides = {}) => ({
  insight_id: '123',
  participant_id: '456',
  insight_feedback_id: 'some-feedback-id',
  score: 5,
  message: 'Some feedback message',
  tenant_id: 'tenant_id',
  additional_feedback: { key: 'value' },
  ...overrides,
});
