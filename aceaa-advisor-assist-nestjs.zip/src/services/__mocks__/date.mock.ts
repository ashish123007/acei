import { dateToUnixTimeStamp } from '../../utils/formatDate';

export const mockDate = new Date('2000-01-01').toISOString();

export const mockUnixTimeStamp = dateToUnixTimeStamp(new Date('2000-01-01'));
