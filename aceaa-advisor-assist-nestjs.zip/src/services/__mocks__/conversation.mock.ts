import { Conversation, ParticipantType, Prisma } from '../../../prisma-generated-client';
import { Conversation as ConversationDto, CreateSummarizeDto } from '../../dto/conversation.dto';
import { DeepPartial, ObjectType } from '../../types';
import { mockDate, mockUnixTimeStamp } from './date.mock';
import { mockCreateInteractionResponse } from './interaction.mock';

export const mockConversationResult = (overrides?: Partial<Conversation>): Conversation =>
  ({
    conversation_id: 'some-conversation-id',
    created_at: mockUnixTimeStamp,
    tenant_id: 'some-tenant-id',
    ...overrides,
  }) as Conversation;

export const mockBaseConversation = (overrides?: Partial<ConversationDto>): ConversationDto => ({
  conversationId: 'some-conversation-id',
  conversationDateTime: mockDate,
  createdBy: 'createdBy',
  interactions: [],
  ...overrides,
});

type ConversationWithInteractions = Prisma.ConversationGetPayload<{
  include: {
    interactions: {
      include: {
        transcriptions: true;
      };
    };
  };
}>;

export const mockConversationWithInteraction = <T extends object = ConversationWithInteractions>(
  overrides?: DeepPartial<T>
): T =>
  ({
    conversation_id: 'some-conversation-id',
    interactions: [
      {
        conversation_id: 'some-conversation-id',
        interaction_id: 'some-interaction-id',
        reference: null,
        context: null,
        created_at: mockUnixTimeStamp,
        transcriptions: [
          {
            interaction_id: '1',
            created_at: mockUnixTimeStamp,
            participant_id: '1',
            transcript_id: '1',
            content: 'some-content',
          },
        ],
      },
    ],
    created_at: mockUnixTimeStamp,
    ...overrides,
  }) as T;

export const mockConversationWithInteractionBody = <T extends object = CreateSummarizeDto>(
  overrides?: DeepPartial<T>
): T => {
  return {
    conversation: {
      interactions: [
        {
          conversationReference: 'some-reference',
          participants: [{ id: 'advisor.2@nl.abnamro.com', type: ParticipantType.advisor }],
          transcriptions: [
            {
              participantId: 'advisor.1@nl.abnamro.com',
              text: 'Ik wil een nieuwe hypotheek.',
              timestamp: 1736850840283,
            },
          ],
          name: 'NICE',
        },
      ],
    },
    complete: true,
    ...overrides,
  } as T;
};

type FullConversationSchema = Prisma.ConversationGetPayload<{
  include: {
    interactions: {
      include: {
        participants: {
          include: {
            participant: true;
          };
        };
        transcriptions: true;
      };
    };
  };
}>;

export const mockFullConversation = <T extends object = FullConversationSchema>(overrides?: DeepPartial<T>) => {
  return {
    conversation_id: 'some-conversation-id',
    interactions: [
      {
        conversation_id: 'some-conversation-id',
        interaction_id: 'some-interaction-id',
        reference: 'some-reference',
        context: null,
        created_at: mockUnixTimeStamp,
        participants: [
          {
            interaction_id: 'some-interaction-id',
            participantId: 'advisor.1@nl.abnamro.com',
            created_at: mockUnixTimeStamp,
          },
        ],
        transcriptions: [
          {
            participantId: 'advisor.1@nl.abnamro.com',
            text: 'Ik wil een nieuwe hypotheek.',
            timestamp: 1736850840283,
          },
        ],
      },
    ],
    created_at: mockUnixTimeStamp,
    ...overrides,
  } as T;
};

export const mockFullConversationResponse = (overrides?: ObjectType) => {
  return {
    conversationId: '49b24451-74d7-49ed-9120-4a263a06d2ba',
    createdAt: 1736850840283,
    createdBy: 'aab-sys-021582',
    interactions: [mockCreateInteractionResponse()],
    ...overrides,
  };
};
