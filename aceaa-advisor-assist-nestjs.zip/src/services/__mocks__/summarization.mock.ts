import { DeepPartial } from '../../types';
import { GenericSummaryResponse, SummarizationResponse } from '../summarization.service';
import { mockDate } from './date.mock';
import { GenericSummaryResponseDto } from '../../dto/insight.dto';

export const mockFetchSummaryResponse = (overrides?: Partial<SummarizationResponse>): SummarizationResponse => ({
  actionId: 'some-action-id',
  message: 'some-message',
  transcription: 'some-transcription',
  user_id: 'some-user-id',
  conversation_id: 'some-conversation-id',
  openai_version: 'OPENAI_BASE_GPT4O',
  ...overrides,
});

export const mockFormatSummaryResponse = (
  overrides?: DeepPartial<GenericSummaryResponseDto>
): GenericSummaryResponseDto =>
  ({
    insightId: 'some-insight-id',
    type: 'Summary',
    data: {
      content: 'some-message',
      llmVersion: 'OPENAI_BASE_GPT4O',
    },
    createdAt: mockDate,
    ...overrides,
  }) as GenericSummaryResponseDto;

export const mockFormatSummaryResponseDto = (overrides?: Partial<GenericSummaryResponse>): GenericSummaryResponse => ({
  message: 'some-message',
  openaiVersion: 'OPENAI_BASE_GPT4O',
  insight: {
    insightId: 'some-insight-id',
    createdAt: mockDate,
  },
  ...overrides,
});
