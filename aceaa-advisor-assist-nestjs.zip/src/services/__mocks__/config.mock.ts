export const mockGetConfig = () =>
  jest.fn((key: string) => {
    const config = {
      API_BASE_URL: 'http://some-base-url/',
      ACS_PUBLIC_ENDPOINT: 'http://some-endpoint-url/',
      ACS_URL: 'http://some-acs-url',
    };
    return config[key as keyof typeof config];
  });
