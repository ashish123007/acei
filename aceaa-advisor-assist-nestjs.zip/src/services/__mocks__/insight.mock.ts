import {
  Insight,
  InsightDocuments,
  InsightKnowledgeSearchResult,
  InsightSummaryResult,
  InsightType,
  Prisma,
  SummaryGeneratedBy,
} from '../../../prisma-generated-client';
import { DeepPartial } from '../../types';
import { CreateInsight, CreateInsightSummaryResultPayload, SaveInsight } from '../insight.service';
import { mockUnixTimeStamp } from './date.mock';

export const mockCreateInsightDto = (overrides?: Partial<CreateInsight>): CreateInsight => ({
  type: InsightType.Summary,
  participantId: 'some-participant-id',
  ...overrides,
});

export const mockInsightResponse = (overrides?: Partial<Insight>): Insight => ({
  insight_id: 'some-insight-id',
  conversation_id: 'some-conversation-id',
  type: InsightType.Summary,
  participant_id: 'some-participant-id',
  tenant_id: 'tenant_id',
  created_at: Number(mockUnixTimeStamp) as unknown as bigint,
  ...overrides,
});

export const mockCreateInsightSummaryResultDto = (
  overrides?: DeepPartial<CreateInsightSummaryResultPayload>
): CreateInsightSummaryResultPayload => ({
  transcript: 'some-transcript',
  summary: 'some-summary',
  special_char_score: 100,
  parent_insight_id: 'some-parent-insight-id',
  generated_by: SummaryGeneratedBy.LLM,
  ...overrides,
});

export const mockCreateInsightSummaryResult = (
  overrides?: DeepPartial<InsightSummaryResult>
): InsightSummaryResult => ({
  insight_id: 'some-insight-id',
  transcript: 'some-transcript',
  summary: 'some-summary',
  special_char_score: 100,
  parent_insight_id: 'some-parent-insight-id',
  generated_by: 'LLM',
  ...overrides,
});

export const mockSaveInsightDto = (overrides?: SaveInsight): SaveInsight => ({
  conversationId: 'some-conversation-id',
  participantId: 'some-participant-id',
  transcript: 'some-transcript',
  summary: 'some-summary',
  generatedBy: SummaryGeneratedBy.LLM,
  ...overrides,
});

export const mockCreateKnowledgeSearchResult = (
  overrides?: DeepPartial<InsightKnowledgeSearchResult>
): InsightKnowledgeSearchResult => ({
  insight_id: 'some-insight-id',
  search: 'some-search',
  ...overrides,
});

export const mockCreateInsightDocuments = (overrides?: DeepPartial<InsightDocuments>): InsightDocuments => ({
  insight_document_id: 'some-document-id',
  insight_id: 'some-insight-id',
  url: 'some-url',
  title: 'some-title',
  tenant_id: 'tenant_id',
  content: 'some-content',
  ...overrides,
});

type InsightWithSummaryResponses = Prisma.InsightGetPayload<{
  include: {
    insightSummaryResults: true;
  };
}>;

export const mockInsightWithSummaryResponse = (
  overrides?: DeepPartial<InsightWithSummaryResponses>
): InsightWithSummaryResponses =>
  ({
    ...mockInsightResponse(),
    ...overrides,
    insightSummaryResults: [mockCreateInsightSummaryResult()],
  }) as InsightWithSummaryResponses;
