import { Prisma, Transcription } from '../../../prisma-generated-client';
import { InteractionTranscript } from '../../dto/conversation.dto';
import { mockUnixTimeStamp } from './date.mock';

export const mockTranscriptionResult = (overrides?: Partial<Transcription>): Transcription => ({
  transcript_id: 'some-transcript-id',
  participant_id: 'some-participant-id',
  content: 'some-content',
  interaction_id: 'some-interaction-id',
  tenant_id: 'tenant_id',
  created_at: mockUnixTimeStamp,
  ...overrides,
});

type TranscriptionGetPayload = Prisma.TranscriptionGetPayload<{
  include: {
    participant: true;
  };
}>;

export const mockTranscriptionResultWithParticipant = (
  overrides?: Partial<TranscriptionGetPayload>
): TranscriptionGetPayload => ({
  transcript_id: 'some-transcript-id',
  participant_id: 'some-participant-id',
  content: 'some-content',
  interaction_id: 'some-interaction-id',
  tenant_id: 'tenant_id',
  created_at: mockUnixTimeStamp,
  participant: {
    participant_id: 'some-participant-id',
    type: 'customer',
    tenant_id: 'some-tenant-id',
  },
  ...overrides,
});

export const mockCreateTranscriptionDto = (overrides?: Partial<InteractionTranscript[]>) => {
  const defaultTranscript: InteractionTranscript[] = [
    { participantId: 'some-participant-id', text: 'test', transcriptDateTime: '2025-04-01T12:07:45.976Z' },
  ];

  const overridesArr = (overrides || []) as InteractionTranscript[];

  return [...defaultTranscript, ...overridesArr];
};
