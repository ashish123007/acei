import { Interaction, ParticipantType, Prisma } from '../../../prisma-generated-client';
import { ConversationInteractionInput, ConversationInteraction } from '../../dto/conversation.dto';
import { DeepPartial } from '../../types';
import { mockDate, mockUnixTimeStamp } from './date.mock';

export const mockConversationInteractionInput = (
  overrides?: DeepPartial<ConversationInteractionInput>
): ConversationInteractionInput => ({
  name: 'some-name',
  reference: 'some-conversation-reference',
  context: { pronoun: 'hij' },
  participants: [
    { id: 'some-participant-id-01', type: ParticipantType.advisor },
    { id: 'some-participant-id-02', type: ParticipantType.customer },
  ],
  ...overrides,
});

export const mockInteractionResult = (overrides?: DeepPartial<Interaction>): Interaction => ({
  conversation_id: 'some-conversation-id',
  interaction_id: 'some-interaction-id',
  name: 'some-name',
  reference: 'some-conversation-reference',
  tenant_id: 'tenant_id',
  active: true,
  context: {
    pronoun: 'hij',
  },
  ...overrides,
  created_at: mockUnixTimeStamp,
  created_by: 'apiConsumerId',
});

type InteractionWithConversations = Prisma.InteractionGetPayload<{
  include: {
    conversation: true;
  };
}>;

export const interactionWithConversationResult = <T extends object = InteractionWithConversations>(
  overrides?: DeepPartial<T>
): T =>
  ({
    interaction_id: 'interaction-1',
    conversation_id: '123',
    reference: 'ref',
    context: null,
    name: 'some-name',
    conversation: {
      conversation_id: 'some-conversation-id',
      created_at: mockDate,
    },
    created_at: mockDate,
    createdBy: 'apiConsumerId',
    ...overrides,
  }) as T;

export const mockCreateInteractionResponse = (overrides?: DeepPartial<ConversationInteraction>) => {
  return {
    interactionId: '39975bb8-1787-4c72-a2a5-054293a50fa0',
    createdAt: 1736850840283,
    createdBy: 'aab-sys-021582',
    name: 'NICE',
    reference: 'some-reference',
    context: {
      pronoun: 'hij',
      topic: 'HYPL',
      language: 'EN',
    },
    participants: [
      {
        id: 'advisor.2@nl.abnamro.com',
        type: 'advisor',
      },
    ],
    transcriptions: [
      {
        participantId: 'advisor.1@nl.abnamro.com',
        text: 'Ik wil een nieuwe hypotheek.',
        timestamp: 1736850840283,
      },
    ],
    ...overrides,
  };
};
