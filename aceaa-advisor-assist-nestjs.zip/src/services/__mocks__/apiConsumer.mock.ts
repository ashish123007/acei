import { ApiConsumerWithToken } from '../../utils/decorators/apiConsumer.decorator';
import { mockUnixTimeStamp } from './date.mock';

export const apiConsumerMock: ApiConsumerWithToken = {
  id: 'api-consumer',
  type: 'system',
  has_ai_permission: true,
  has_callstatus_permission: true,
  template: { pre_intent: 'HYPL' },
  tenant_id: 'tenant_id',
  created_at: mockUnixTimeStamp,
  token: 'mocked_token',
  roleName: 'AdvisorAssist-CCO',
};
