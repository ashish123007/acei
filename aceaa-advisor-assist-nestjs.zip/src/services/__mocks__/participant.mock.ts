import { Participant, ParticipantType, Prisma } from '../../../prisma-generated-client';
import { DeepPartial } from '../../types';
import { mockDate, mockUnixTimeStamp } from './date.mock';
import { mockInteractionResult } from './interaction.mock';
import { mockConversationResult } from './conversation.mock';

export const mockParticipantResult = (overrides?: Partial<Participant>): Participant => ({
  participant_id: 'some-participant-id',
  type: ParticipantType.advisor,
  tenant_id: 'tenant_id',
  ...overrides,
});

type ParticipantWithInteractions = Prisma.ParticipantsOnInteractionGetPayload<{
  include: {
    interaction: {
      include: {
        conversation: true;
      };
    };
    participant: true;
  };
}>;

export const mockParticipantsOnInteraction = <T extends object = ParticipantWithInteractions>(
  overrides?: DeepPartial<T>
): T =>
  ({
    interaction_id: 'some-interaction-id',
    participant_id: 'some-participant-id',
    interaction: {
      ...mockInteractionResult(),
      conversation: mockConversationResult(),
    },
    participant: mockParticipantResult(),
    created_at: mockDate,
    ...overrides,
  }) as T;

type ParticipantWithInteractionsWithParticipants = Prisma.ParticipantsOnInteractionGetPayload<{
  include: {
    participant: true;
  };
}>;

export const mockParticipantsOnInteractionWithParticipants = (
  overrides?: ParticipantWithInteractionsWithParticipants
): ParticipantWithInteractionsWithParticipants => ({
  interaction_id: 'some-interaction-id',
  participant_id: 'some-participant-id',
  participant: mockParticipantResult(),
  tenant_id: 'tenant_id',
  created_at: mockUnixTimeStamp,
  ...overrides,
});
