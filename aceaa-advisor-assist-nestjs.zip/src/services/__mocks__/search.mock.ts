import { Insight } from '../../dto/insight.dto';
import { DeepPartial, ObjectType } from '../../types';
import { mockDate } from './date.mock';

export const mockCreateSearchResult = (overrides?: DeepPartial<Insight>): Insight =>
  ({
    insightId: 'knowledge_search_1728916169082_5728',
    type: 'KNOWLEDGE_SEARCH',
    data: {
      input: 'nieuwe hypotheek',
      content: 'Document related to hypotheek found',
    },
    documents: [
      {
        url: 'https://abnamro.sharepoint.com/sites/informatiebank-verzekerenschade/SitePages/Producten/NN-Inboedel-Maatwerk.aspx',
        title: 'NN Inboedel Maatwerk',
        content: '....',
      },
    ],
    createdDateTime: mockDate,
    ...overrides,
  }) as Insight;

export const mockInsightDocument = (overrides?: ObjectType) => ({
  url: 'some-url',
  title: 'some-title',
  content: 'some-content',
  embedding: [],
  summary: 'some-summary',
  extra: {
    theme: 'some-theme',
    business_line: 'some-business-line',
  },
  ...overrides,
});

export const mockKbResponse = (overrides?: ObjectType) => ({
  user_id: 'some-user-id',
  original_query: 'original query ',
  actionId: 'some-action-id',
  documents: [
    {
      url: 'some-url',
      title: 'some-title',
      content: 'some-content',
      embedding: [],
      summary: 'some-summary',
      extra: {
        theme: 'some-theme',
        business_line: 'some-business-line',
      },
    },
  ],
  ...overrides,
});
