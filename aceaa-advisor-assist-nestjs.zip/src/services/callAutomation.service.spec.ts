import { ConfigService } from '@nestjs/config';
import { CallAutomationService } from './callAutomation.service';
import { TestingModule, Test } from '@nestjs/testing';
import { CallAutomationClient } from '@azure/communication-call-automation';
import { DefaultAzureCredential } from '@azure/identity';

jest.mock('@azure/identity', () => {
  return {
    DefaultAzureCredential: jest.fn(),
  };
});
jest.mock('@azure/communication-call-automation', () => {
  return {
    CallAutomationClient: jest.fn().mockImplementation(() => ({
      answerCall: jest.fn(),
    })),
  };
});

describe('CallAutomationService', () => {
  let service: CallAutomationService;
  let callAutomationClientMock: jest.Mocked<CallAutomationClient>;

  beforeEach(async () => {
    jest.clearAllMocks();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CallAutomationService,
        {
          provide: ConfigService,
          useValue: {
            get: jest.fn().mockReturnValue('mock-endpoint'),
          },
        },
      ],
    }).compile();

    service = module.get<CallAutomationService>(CallAutomationService);
    callAutomationClientMock = new CallAutomationClient(
      '',
      new DefaultAzureCredential()
    ) as jest.Mocked<CallAutomationClient>;
    callAutomationClientMock.answerCall = jest.fn();
  });

  describe('answerCall', () => {
    it('should answer call', async () => {
      await expect(service.answerCall('aa/voice-hub', 'some-incoming-context')).resolves.toBeUndefined();
    });

    it('should throw an error if the env is not available', async () => {
      const module: TestingModule = await Test.createTestingModule({
        providers: [
          CallAutomationService,
          {
            provide: ConfigService,
            useValue: {
              get: jest.fn(() => undefined),
            },
          },
        ],
      }).compile();

      const service = module.get<CallAutomationService>(CallAutomationService);

      await expect(service.answerCall('aa/voice-hub', 'some-incoming-context')).rejects.toThrow(
        new Error('Please set ACS_PUBLIC_ENDPOINT & ACS_URL variables')
      );
    });
  });
});
