import { Injectable } from '@nestjs/common';
import type { ApiConsumer } from '../../prisma-generated-client';
import { PrismaService } from '../prisma.service';

@Injectable()
export class ApiConsumerService {
  constructor(private prisma: PrismaService) {}

  async getOrCreateConsumer(consumerId: string): Promise<ApiConsumer> {
    const consumer = await this.prisma.apiConsumer.findUnique({
      where: {
        id: consumerId,
      },
    });

    if (!consumer) {
      throw new Error(`Consumer with ID ${consumerId} not found`);
    }
    return consumer;
  }
}
