import { Test, TestingModule } from '@nestjs/testing';
import { PrismaService } from '../prisma.service';
import { TranscriptionService } from './transcription.service';
import { NotFoundException } from '@nestjs/common';
import { mockParticipantResult } from './__mocks__/participant.mock';
import { mockInteractionResult } from './__mocks__/interaction.mock';
import { mockCreateTranscriptionDto, mockTranscriptionResult } from './__mocks__/transcription.mock';
import { apiConsumerMock } from './__mocks__/apiConsumer.mock';
import { mockDate, mockUnixTimeStamp } from './__mocks__/date.mock';

describe('TranscriptionService', () => {
  let service: TranscriptionService;
  let prismaService: PrismaService;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TranscriptionService,
        {
          provide: PrismaService,
          useValue: {
            transcription: {
              createMany: jest.fn(),
              findMany: jest.fn(),
            },
            participant: {
              findUnique: jest.fn(),
            },
            interaction: {
              findUnique: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<TranscriptionService>(TranscriptionService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  const apiConsumer = apiConsumerMock;

  describe('createTranscriptions', () => {
    it('should throw NotFoundException if interaction with provided interaction Id is not found', () => {
      jest.spyOn(prismaService.participant, 'findUnique').mockResolvedValue(mockParticipantResult());
      jest.spyOn(prismaService.interaction, 'findUnique').mockResolvedValue(null);
      expect(
        service.createTranscription({
          apiConsumer,
          conversationId: '2',
          transcriptions: mockCreateTranscriptionDto(),
          interactionId: '2',
        })
      ).rejects.toThrow(NotFoundException);
    });

    it('should create a transcription successfully', async () => {
      const interactionId = 'some-interaction-id';
      const transcriptions = mockCreateTranscriptionDto();

      jest.spyOn(prismaService.participant, 'findUnique').mockResolvedValue(mockParticipantResult());
      jest.spyOn(prismaService.interaction, 'findUnique').mockResolvedValue(mockInteractionResult());
      jest.spyOn(prismaService.transcription, 'createMany').mockResolvedValue({ count: 1 });

      await service.createTranscription({
        apiConsumer,
        interactionId,
        transcriptions,
        conversationId: '2',
      });

      expect(prismaService.interaction.findUnique).toHaveBeenCalledWith({
        where: { interaction_id: interactionId, tenant_id: 'tenant_id', conversation_id: '2' },
      });
      expect(prismaService.transcription.createMany).toHaveBeenCalledWith({
        data: [
          {
            tenant_id: 'tenant_id',
            content: 'test',
            interaction_id: 'some-interaction-id',
            participant_id: 'some-participant-id',
            created_at: expect.anything(),
          },
        ],
      });
    });
  });

  describe('getTranscriptions', () => {
    it('should return all transcriptions', async () => {
      const interactionId = 'some-interaction-id';

      const transcriptions = mockTranscriptionResult();

      jest.spyOn(prismaService.transcription, 'findMany').mockResolvedValue([transcriptions]);

      const result = await service.getTranscriptions({
        interactionId,
        apiConsumer,
      });

      expect(result[0].participantId).toBe(transcriptions.participant_id);
      expect(result[0].text).toBe(transcriptions.content);
    });

    it('should throw an error if no transcription found', () => {
      const interactionId = 'some-interaction-id';

      jest.spyOn(prismaService.transcription, 'findMany').mockResolvedValue([]);

      expect(
        service.getTranscriptions({
          interactionId,
          apiConsumer,
        })
      ).rejects.toThrow(NotFoundException);
    });
  });
});
