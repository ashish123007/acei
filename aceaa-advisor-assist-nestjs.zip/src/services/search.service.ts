import { Injectable } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import type { ApiConsumerWithToken } from '../utils/decorators/apiConsumer.decorator';
import { AiHttpClientService } from './http-client.service';
import { getDefaultRole } from '../utils/getDefaultRole';

export interface KBResponse {
  user_id: string;
  original_query: string;
  actionId: string;
  documents: {
    url: string;
    title: string;
    content: string;
    embedding: number[];
    summary: string;
    extra: {
      theme: string;
      business_line: string;
    };
  }[];
}

interface FetchKnowledgeBase {
  apiConsumer: ApiConsumerWithToken;
  message: string;
  conversationId?: string;
  role?: string;
}

@Injectable()
export class SearchService {
  constructor(private httpClient: AiHttpClientService) {}

  async fetchKnowledgeBase({ conversationId, message, apiConsumer, role }: FetchKnowledgeBase): Promise<KBResponse> {
    const userId = randomUUID();

    return this.httpClient.post<KBResponse>(
      `advisor-assist-be/v2/kb_query?role=${getDefaultRole(apiConsumer, role)}`,
      apiConsumer.token,
      {
        conversation_id: conversationId || 'noConversationId',
        message,
        user_id: userId,
      }
    );
  }
}
