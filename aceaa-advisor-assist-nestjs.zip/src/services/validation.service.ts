import { Injectable } from '@nestjs/common';
import Ajv from 'ajv';
import type { JSONSchemaType } from 'ajv';
import { PrismaService } from '../prisma.service';

@Injectable()
export class ValidationService {
  private ajv: Ajv;

  constructor(private readonly prisma: PrismaService) {
    this.ajv = new Ajv();
  }

  async validateWithDatabaseTemplate(apiConsumerId: string, data: object): Promise<boolean> {
    const apiConsumer = await this.prisma.apiConsumer.findUnique({
      where: { id: apiConsumerId },
    });

    if (!apiConsumer || !apiConsumer.template) {
      return true;
    }

    const schema: JSONSchemaType<typeof data> = apiConsumer.template as JSONSchemaType<typeof data>;

    const validate = this.ajv.compile(schema);
    const valid = validate(data);
    return valid;
  }
}
