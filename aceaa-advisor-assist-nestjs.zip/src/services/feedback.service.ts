import { Injectable } from '@nestjs/common';
import type { ApiConsumerWithToken } from '../utils/decorators/apiConsumer.decorator';
import { AiHttpClientService } from './http-client.service';
import { getDefaultRole } from '../utils/getDefaultRole';

export interface FeedbackResponse {
  status: string;
}

export interface PostFeedback {
  apiConsumer: ApiConsumerWithToken;
  conversation_id: string;
  sentiment: string;
  summary: string;
  topic: string;
  transcription: string;
  participantId: string;
  role?: string;
}
@Injectable()
export class FeedbackService {
  constructor(private httpClient: AiHttpClientService) {}

  async postFeedback({
    apiConsumer,
    conversation_id,
    sentiment,
    summary,
    topic,
    transcription,
    participantId,
    role,
  }: PostFeedback) {
    const feedbackData = {
      conversation_id,
      sentiment,
      summary,
      topic,
      transcription,
      user_id: participantId,
    };

    const response = await this.httpClient.post<FeedbackResponse>(
      `advisor-assist-be/v2/feedback?role=${getDefaultRole(apiConsumer, role)}`,
      apiConsumer.token,
      feedbackData
    );
    return response;
  }
}
