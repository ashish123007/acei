import { Test, TestingModule } from '@nestjs/testing';
import { PrismaService } from '../prisma.service';
import { ConversationService } from './conversation.service';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import {
  mockConversationResult,
  mockConversationWithInteraction,
  mockFullConversation,
} from './__mocks__/conversation.mock';
import { apiConsumerMock } from './__mocks__/apiConsumer.mock';
import { InteractionService } from './interaction.service';
import { logger } from '../utils/logger';
import { NotFoundIagException } from '../errors/custom-errors';

describe('ConversationService', () => {
  let service: ConversationService;
  let prismaService: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ConversationService,
        {
          provide: PrismaService,
          useValue: {
            conversation: {
              findUnique: jest.fn(),
              create: jest.fn(),
              findMany: jest.fn(),
              update: jest.fn(),
            },
            interaction: {
              findFirst: jest.fn(),
              updateMany: jest.fn(),
            },
            participantsOnInteraction: {
              findFirst: jest.fn(),
              findMany: jest.fn(),
            },
            transcription: {
              findMany: jest.fn(),
            },
          },
        },
        {
          provide: InteractionService,
          useValue: {
            mapInteractionResponse: jest.fn(),
          },
        },
      ],
    }).compile();
    service = module.get<ConversationService>(ConversationService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  const conversationMock = mockConversationResult();
  const conversation = mockFullConversation();
  const conversationId = 'some-conversation-id';
  const participantId = 'some-participant-id';

  describe('searchConversations', () => {
    it('should return a list of conversations details if participantId is provided', async () => {
      jest.spyOn(prismaService.conversation, 'findMany').mockResolvedValue([conversation]);

      const result = await service.searchConversations(apiConsumerMock, {}, '123');
      expect(result[0].conversationId).toEqual(conversationId);
    });

    it('should return a list of conversations details if interactionReference is provided', async () => {
      jest.spyOn(prismaService.conversation, 'findMany').mockResolvedValue([conversation] as never);

      const result = await service.searchConversations(apiConsumerMock, { interactionReference: '123' });
      expect(result[0].conversationId).toEqual(conversationId);
    });

    it('should throw NotFoundException if no conversations are not found', async () => {
      jest.spyOn(prismaService.conversation, 'findMany').mockResolvedValue([] as never);
      const conversations = await service.searchConversations(apiConsumerMock, {}, '123');
      expect(conversations).toEqual([]);
    });

    it('should throw BadRequestException if no participantId or interactionReference is provided', async () => {
      await expect(service.searchConversations(apiConsumerMock, {})).rejects.toThrow(BadRequestException);
    });
  });

  describe('retrieveConversationDataWithRelevantTranscriptions', () => {
    it('should find a conversation with all interactions when includeAllInteractions is true with all interactions when includeAllInteractions is true', async () => {
      const conversationMock = mockConversationWithInteraction({});

      jest.spyOn(prismaService.conversation, 'findUnique').mockResolvedValue(conversationMock);
      jest.spyOn(prismaService.transcription, 'findMany').mockResolvedValue([]);
      jest.spyOn(prismaService.transcription, 'findMany').mockResolvedValue([]);

      const result = await service.retrieveRelevantTranscriptions(apiConsumerMock, conversationId, true);

      expect(prismaService.conversation.findUnique).toHaveBeenCalledWith({
        where: { conversation_id: conversationId, tenant_id: apiConsumerMock.tenant_id },
        include: {
          interactions: {
            orderBy: {
              created_at: 'desc',
            },
            include: {
              participants: true,
            },
          },
        },
      });

      expect(result).toStrictEqual([]);
    });
    it('should find a conversation with filtered interactions when includeAllInteractions is false', async () => {
      jest.spyOn(prismaService.conversation, 'findUnique').mockResolvedValue(conversation);
      jest.spyOn(prismaService.transcription, 'findMany').mockResolvedValue([]);

      await service.retrieveRelevantTranscriptions(apiConsumerMock, conversationId, false, participantId);

      expect(prismaService.conversation.findUnique).toHaveBeenCalledWith({
        where: { conversation_id: conversationId, tenant_id: apiConsumerMock.tenant_id },
        include: {
          interactions: {
            orderBy: {
              created_at: 'desc',
            },
            include: {
              participants: true,
            },
          },
        },
      });
    });

    it('should throw NotFound if conversationId is provided but not found', async () => {
      jest.spyOn(prismaService.conversation, 'findUnique').mockResolvedValue(null);
      await expect(service.retrieveRelevantTranscriptions(apiConsumerMock, conversationId)).rejects.toThrow(
        NotFoundException
      );
    });
  });

  describe('createConversation', () => {
    it('should create a new conversation', async () => {
      jest.spyOn(prismaService.conversation, 'create').mockResolvedValue(conversationMock);
      const result = await service.createConversation(apiConsumerMock);
      expect(result).toMatchSnapshot();
    });
  });

  describe('getConversationById', () => {
    it('should get conversation by id', async () => {
      jest.spyOn(prismaService.conversation, 'findUnique').mockResolvedValue(conversation as never);
      const result = await service.getConversationById(conversationId, apiConsumerMock);
      expect(result.conversationId).toBe(conversationId);
    });

    it('should throw an error if conversation not found', async () => {
      jest.spyOn(prismaService.conversation, 'findUnique').mockResolvedValue(null as never);
      expect(service.getConversationById(conversationId, apiConsumerMock)).rejects.toThrow(NotFoundException);
    });
  });

  describe('deleteConversation', () => {
    it('should delete a conversation', async () => {
      jest.spyOn(prismaService.conversation, 'update').mockResolvedValue({} as never);
      jest.spyOn(prismaService.interaction, 'updateMany').mockResolvedValue({} as never);

      const conversationId = 'some-conversation-id';
      await service.deleteConversation(conversationId, apiConsumerMock);

      expect(logger.info).toHaveBeenCalledWith(
        `Conversation and its interactions have been deleted. ${conversationId}`
      );
    });

    it('should throw not found error when conversation is not found', async () => {
      jest.spyOn(prismaService.conversation, 'update').mockRejectedValueOnce({
        code: 'P2025',
      } as never);
      const conversationId = 'some-conversation-id';

      expect(service.deleteConversation(conversationId, apiConsumerMock)).rejects.toThrow(NotFoundIagException);
    });
  });
});
