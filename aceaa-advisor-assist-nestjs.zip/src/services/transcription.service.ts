import { Injectable } from '@nestjs/common';
import type { ApiConsumer } from '../../prisma-generated-client';
import { PrismaService } from '../prisma.service';
import { logger } from '../utils/logger';
import type { InteractionTranscript } from '../dto/conversation.dto';
import { NotFoundIagException } from '../errors/custom-errors';
import { dateToUnixTimeStamp, formatUnixTimeStampToString } from '../utils/formatDate';

@Injectable()
export class TranscriptionService {
  constructor(private prisma: PrismaService) {}

  async createTranscription({
    interactionId,
    conversationId,
    apiConsumer,
    transcriptions,
  }: {
    apiConsumer: ApiConsumer;
    interactionId: string;
    conversationId: string;
    transcriptions: InteractionTranscript[];
  }) {
    const interaction = await this.prisma.interaction.findUnique({
      where: { interaction_id: interactionId, conversation_id: conversationId, tenant_id: apiConsumer.tenant_id },
    });

    if (!interaction) {
      const errorMessage = `Interaction with interactionId "${interactionId}" and conversationId ${conversationId} not found.`;
      logger.warn(errorMessage);
      throw new NotFoundIagException('INTERACTION_ID_NOT_FOUND', errorMessage);
    }

    await this.prisma.transcription.createMany({
      data: transcriptions.map((transcript) => ({
        interaction_id: interactionId,
        participant_id: transcript.participantId,
        content: transcript.text,
        tenant_id: apiConsumer.tenant_id,
        created_at: this.convertToUnix(transcript.transcriptDateTime),
      })),
    });

    return;
  }

  private convertToUnix(unixDateTime: unknown) {
    if (typeof unixDateTime === 'number') {
      return BigInt(unixDateTime);
    }

    return dateToUnixTimeStamp(new Date(unixDateTime as string));
  }

  async getTranscriptions({ interactionId, apiConsumer }: { apiConsumer: ApiConsumer; interactionId: string }) {
    const transcriptions = await this.prisma.transcription.findMany({
      where: {
        interaction_id: interactionId,
        tenant_id: apiConsumer.tenant_id,
      },
    });

    if (!transcriptions.length) {
      logger.error(`Transcriptions with interactionId: ${interactionId} not found`);
      throw new NotFoundIagException(
        'TRANSCRIPTIONS_NOT_FOUND',
        `Transcriptions with Interaction ID: ${interactionId} not found`
      );
    }

    return transcriptions.map(({ participant_id, content, created_at }) => ({
      participantId: participant_id,
      text: content,
      transcriptDateTime: formatUnixTimeStampToString(created_at),
    }));
  }
}
