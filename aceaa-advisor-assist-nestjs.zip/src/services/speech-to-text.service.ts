import { DefaultAzureCredential } from '@azure/identity';
import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { rm } from 'fs';
import type { SpeechRecognitionResult } from 'microsoft-cognitiveservices-speech-sdk';
import {
  SpeechRecognizer,
  AudioConfig,
  SpeechConfig,
  PropertyId,
  PhraseListGrammar,
} from 'microsoft-cognitiveservices-speech-sdk';
import * as ffmpeg from 'fluent-ffmpeg';
import * as path from 'path';
import { createGuid } from 'microsoft-cognitiveservices-speech-sdk/distrib/lib/src/common/Guid';
import { readFile, writeFile } from 'fs/promises';
import { path as ffmpegPath } from '@ffmpeg-installer/ffmpeg';
import { logger } from '../utils/logger';

const PREDEFINED_WORDS = [
  'IDme',
  'spaarrekening',
  'betaalrekening',
  'priverekening',
  'beleggingsrekening',
  'hypotheek',
  'Tikkie',
  'overboeking',
  'IBAN',
  'Apple Pay',
  'E.dentifier',
  'jaaroverzicht',
  'rekeningafschrift',
  'depositogarantiestelsel',
  'beleggersrekening',
  'spaargeldslot',
  'jongerengroeirekening',
  'spaargeldslot',
  'NAW',
  'OVpay',
  'Kifid',
  'BC nummer',
  'UBO',
  'gegoedheid verklaring',
  'ABN AMRO',
  'SEPA',
  'Batch',
  'Incasso ID',
  'Batchbetaling',
  'Access',
];

const STOP_PERIODS: string = '-1';
const STOP_DURATION: string = '0.5';
const STOP_THRESHOLD: string = '-40dB';

@Injectable()
export class SpeechToTextService {
  constructor() {}

  async transcribe(audioString: string, language: string): Promise<SpeechRecognitionResult | undefined> {
    const wavFilePath = await this.createWavFileFromAudioString(audioString);
    if (wavFilePath) {
      try {
        const waveFile = await readFile(wavFilePath);
        const audioConfig = AudioConfig.fromWavFileInput(waveFile);
        const isLocalDevelopment = !process.env.ENVIRONMENT || process.env.ENVIRONMENT === 'local';

        const speechConfig = isLocalDevelopment
          ? this.getSpeechConfigApiKeys()
          : await this.getSpeechConfigAzureManagedIdentity();

        speechConfig.speechRecognitionLanguage = language;

        const speechRecognizer = new SpeechRecognizer(speechConfig, audioConfig);

        const phraseListGrammar = PhraseListGrammar.fromRecognizer(speechRecognizer);
        phraseListGrammar.addPhrases(PREDEFINED_WORDS);

        const recognitionResult = (await Promise.race([
          this.recognize(speechRecognizer),
          new Promise((resolve) => setTimeout(() => resolve('RECOGNIZER_TIMEOUT'), 20000)),
        ])) as SpeechRecognitionResult | 'RECOGNIZER_TIMEOUT';

        speechRecognizer.close();

        if (recognitionResult === 'RECOGNIZER_TIMEOUT') {
          throw new Error('SpeechToTextService transcribe hit a timeout');
        }

        return recognitionResult;
      } catch (err) {
        logger.error(err);

        const error = err as Error;
        throw new HttpException(error.message, HttpStatus.INTERNAL_SERVER_ERROR);
      } finally {
        rm(wavFilePath, () => {
          logger.info('File removed: ' + wavFilePath);
        });
      }
    }
  }

  private async createWavFileFromAudioString(audioString: string) {
    try {
      const audioBuffer = this.base64ToArrayBuffer(audioString);
      const webmFilePath = path.resolve(__dirname, createGuid());
      await writeFile(webmFilePath, audioBuffer);
      const wavFilePath = path.resolve(__dirname, createGuid()) + '.wav';
      const ffmpegConvertSucceded = await this.runffmpegConvert(webmFilePath, wavFilePath);

      rm(webmFilePath, () => {
        logger.debug('File removed: ' + webmFilePath);
      });
      if (ffmpegConvertSucceded) {
        return wavFilePath;
      }
    } catch (error) {
      logger.error(error);
    }
  }

  private runffmpegConvert(tmpFilepath: string, outputFilePath: string): Promise<boolean> {
    ffmpeg.setFfmpegPath(ffmpegPath);
    return new Promise<boolean>((resolve, reject) => {
      ffmpeg(tmpFilepath)
        .format('wav')
        .audioFilter(
          `silenceremove=stop_periods=${STOP_PERIODS}:stop_duration=${STOP_DURATION}:stop_threshold=${STOP_THRESHOLD}`
        )
        .save(outputFilePath)
        .on('end', () => {
          logger.info('process ended');
          resolve(true);
        })
        .on('error', (error) => {
          logger.warn(`Error: ${error.message}`);
          reject(error);
        });
    }).catch((error) => {
      logger.error(error);
      return false;
    });
  }

  private recognize(speechRecognizer: SpeechRecognizer): Promise<SpeechRecognitionResult> {
    return new Promise((resolve, reject) => {
      speechRecognizer.recognizeOnceAsync(
        (recognitionResult) => {
          resolve(recognitionResult);
        },
        (err) => {
          logger.error(err);
          reject(err);
        }
      );
    });
  }

  private async getSpeechConfigAzureManagedIdentity() {
    const authorizationToken = await this.getToken();
    const region = 'westeurope';
    const speechConfig = SpeechConfig.fromAuthorizationToken(authorizationToken, region);
    if (!process.env.SPEECH_ENDPOINT) {
      throw new Error('No SPEECH_ENDPOINT environment variable set!');
    }
    speechConfig.setProperty(PropertyId.SpeechServiceConnection_Endpoint, process.env.SPEECH_ENDPOINT);
    return speechConfig;
  }

  private async getToken() {
    const maapSubscriptionId = process.env.MAAP_SUBSCRIPTION_ID;
    const maapResourceGroup = process.env.MAAP_RESOURCE_GROUP;
    const maapAccountName = process.env.MAAP_ACCOUNT_NAME;
    const resourceId =
      '/subscriptions/' +
      maapSubscriptionId +
      '/resourceGroups/' +
      maapResourceGroup +
      '/providers/Microsoft.CognitiveServices/accounts/' +
      maapAccountName;
    const credential = new DefaultAzureCredential();
    const token = await credential.getToken('https://cognitiveservices.azure.com/.default');
    const authorizationToken = `aad#${resourceId}#${token.token}`;
    return authorizationToken;
  }

  private getSpeechConfigApiKeys() {
    if (!(process.env.SPEECH_KEY && process.env.SPEECH_REGION)) {
      throw new Error('Please set SPEECH_KEY and SPEECH_REGION variables');
    }

    const speechConfig = SpeechConfig.fromSubscription(process.env.SPEECH_KEY, process.env.SPEECH_REGION);
    speechConfig.speechRecognitionLanguage = 'en-US';
    return speechConfig;
  }

  private base64ToArrayBuffer(base64String: string) {
    return Buffer.from(base64String, 'base64');
  }
}
