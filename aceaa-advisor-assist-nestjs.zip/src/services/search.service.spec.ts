import { SearchService } from './search.service';
import { Test, TestingModule } from '@nestjs/testing';
import { AiHttpClientService } from './http-client.service';
import { apiConsumerMock } from './__mocks__/apiConsumer.mock';

describe('SearchService', () => {
  let service: SearchService;
  let aiHttpClientService: AiHttpClientService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SearchService,
        {
          provide: AiHttpClientService,
          useValue: {
            post: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<SearchService>(SearchService);
    aiHttpClientService = module.get<AiHttpClientService>(AiHttpClientService);
  });

  describe('fetch knowledge base result', () => {
    const message = 'some-message';
    const conversationId = 'some-conversation-id';
    const mockKbResponse = {
      user_id: 'some-user-id',
      original_query: 'original query ',
      actionId: 'some-action-id',
      documents: [
        {
          url: 'some-url',
          title: 'some-title',
          content: 'some-content',
          embedding: [],
          summary: 'some-summary',
          extra: {
            theme: 'some-theme',
            business_line: 'some-business-line',
          },
        },
      ],
    };

    it('should fetch KB search', async () => {
      aiHttpClientService.post = jest.fn().mockResolvedValue(mockKbResponse);
      const result = await service.fetchKnowledgeBase({ apiConsumer: apiConsumerMock, conversationId, message });

      expect(aiHttpClientService.post).toHaveBeenCalledWith(
        'advisor-assist-be/v2/kb_query?role=AdvisorAssist-CCO',
        apiConsumerMock.token,
        expect.any(Object)
      );

      expect(result).toBe(mockKbResponse);
    });

    it('should fetch KB search with default conversationId', async () => {
      aiHttpClientService.post = jest.fn().mockResolvedValue(mockKbResponse);
      const result = await service.fetchKnowledgeBase({ apiConsumer: apiConsumerMock, message });

      expect(aiHttpClientService.post).toHaveBeenCalledWith(
        'advisor-assist-be/v2/kb_query?role=AdvisorAssist-CCO',
        apiConsumerMock.token,
        expect.objectContaining({
          conversation_id: 'noConversationId',
          message: message,
        })
      );

      expect(result).toBe(mockKbResponse);
    });
  });
});
