import { CallAutomationClient } from '@azure/communication-call-automation';
import { DefaultAzureCredential } from '@azure/identity';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { logger } from '../utils/logger';

@Injectable()
export class CallAutomationService {
  private readonly acsPublicEndpoint: string | undefined;
  private readonly acsUrl: string | undefined;
  constructor(private configService: ConfigService) {
    this.acsPublicEndpoint = this.configService.get<string>('ACS_PUBLIC_ENDPOINT');
    this.acsUrl = this.configService.get<string>('ACS_URL');
  }

  async answerCall(voicePrefix: string, incomingCallContext: string) {
    if (!this.acsPublicEndpoint || !this.acsUrl) {
      logger.error('ACS_PUBLIC_ENDPOINT or ACS_URL not set.');
      throw new Error('Please set ACS_PUBLIC_ENDPOINT & ACS_URL variables');
    }

    const callbackUrl = `${this.acsPublicEndpoint}/${voicePrefix}callbacks`;
    const credential = new DefaultAzureCredential();
    const callAutomationClient = new CallAutomationClient(this.acsUrl, credential);
    await callAutomationClient.answerCall(incomingCallContext, callbackUrl);
  }
}
