import { Test, TestingModule } from '@nestjs/testing';
import { AnalyticsService } from './analytics.service';
import { BlobServiceClient, BlockBlobClient, ContainerClient } from '@azure/storage-blob';
import { logTelemetry } from '../utils/telemetry';

jest.mock('@azure/storage-blob');
jest.mock('../utils/telemetry', () => ({
  logTelemetry: jest.fn(),
}));

describe('AnalyticsService', () => {
  let service: AnalyticsService;
  let mockContainerClient: ContainerClient;
  let mockBlockBlobClient: BlockBlobClient;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [AnalyticsService],
    }).compile();

    service = module.get<AnalyticsService>(AnalyticsService);
    mockBlockBlobClient = {
      upload: jest.fn().mockResolvedValue(undefined),
    } as unknown as BlockBlobClient;

    mockContainerClient = {
      createIfNotExists: jest.fn().mockResolvedValue(undefined),
      getBlockBlobClient: jest.fn().mockReturnValue(mockBlockBlobClient),
    } as unknown as ContainerClient;

    jest.spyOn(BlobServiceClient.prototype, 'getContainerClient').mockReturnValue(mockContainerClient);
  });

  describe('computeBlobFilename', () => {
    it('should generate a filename with the correct format', () => {
      const eventName = 'some-event';
      const conversationId = 'conv123';
      const filename = service.computeBlobFilename(eventName, conversationId);

      expect(filename).toMatch(/^\d{4}-\d{2}-\d{2}\/conv123\/some-event_\d+_\d{4}\.json$/);
    });

    it('should handle null conversationId', () => {
      const eventName = 'some-event';
      const conversationId = null;
      const filename = service.computeBlobFilename(eventName, conversationId);

      expect(filename).toMatch(/^\d{4}-\d{2}-\d{2}\/noConversationId\/some-event_\d+_\d{4}\.json$/);
    });
  });

  describe('getOrInitStorageConnection', () => {
    it('should initialize BlobServiceClient successfully', () => {
      process.env.BLOB_ACCOUNT = 'testAccount';

      const blobServiceClient = service.getOrInitStorageConnection();
      expect(blobServiceClient).toBeInstanceOf(BlobServiceClient);

      expect(logTelemetry).toHaveBeenCalledWith({ event_type: 'blob_client_connection_attempt' });
      expect(logTelemetry).toHaveBeenCalledWith({ event_type: 'blob_client_connection_success' });
    });
  });

  describe('storeEvent', () => {
    it('should generate the correct filename and upload the event data', async () => {
      const mockContainerClient = {
        createIfNotExists: jest.fn(),
        getBlockBlobClient: jest.fn(),
      } as unknown as ContainerClient;

      const mockBlockBlobClient = {
        upload: jest.fn(),
      } as unknown as BlockBlobClient;

      (mockContainerClient.getBlockBlobClient as jest.Mock).mockReturnValue(mockBlockBlobClient);

      const mockBlobServiceClient = {
        getContainerClient: jest.fn().mockReturnValue(mockContainerClient),
      } as unknown as BlobServiceClient;

      jest.spyOn(service, 'getOrInitStorageConnection').mockReturnValue(mockBlobServiceClient);

      const eventName = 'testEvent';
      const conversationId = '12345';
      const userId = 'user1';
      const data = { key: 'value' };

      const computeBlobFilenameSpy = jest.spyOn(service, 'computeBlobFilename');
      const filename = '2025-04-30/12345/testEvent_1234567890_0001.json';
      computeBlobFilenameSpy.mockReturnValue(filename);

      await service.storeEvent(eventName, conversationId, userId, data);

      expect(computeBlobFilenameSpy).toHaveBeenCalledWith(eventName, conversationId);
      expect(service.getOrInitStorageConnection).toHaveBeenCalled();
      expect(mockContainerClient.createIfNotExists).toHaveBeenCalled();
      expect(mockContainerClient.getBlockBlobClient).toHaveBeenCalledWith(filename);
      expect(mockBlockBlobClient.upload).toHaveBeenCalledWith(
        JSON.stringify({ conversationId, userId, ...data }),
        Buffer.byteLength(JSON.stringify({ conversationId, userId, ...data }))
      );
    });

    it('should log telemetry and throw an error if upload fails', async () => {
      const mockContainerClient = {
        createIfNotExists: jest.fn(),
        getBlockBlobClient: jest.fn(),
      } as unknown as ContainerClient;

      const mockBlockBlobClient = {
        upload: jest.fn().mockRejectedValue(new Error('Upload failed')),
      } as unknown as BlockBlobClient;

      (mockContainerClient.getBlockBlobClient as jest.Mock).mockReturnValue(mockBlockBlobClient);

      const mockBlobServiceClient = {
        getContainerClient: jest.fn().mockReturnValue(mockContainerClient),
      } as unknown as BlobServiceClient;

      jest.spyOn(service, 'getOrInitStorageConnection').mockReturnValue(mockBlobServiceClient);

      const eventName = 'testEvent';
      const conversationId = '12345';
      const userId = 'user1';
      const data = { key: 'value' };

      await expect(service.storeEvent(eventName, conversationId, userId, data)).rejects.toThrow('Upload failed');

      expect(logTelemetry).toHaveBeenCalledWith({
        event_type: 'blob_client_connection_attempt',
      });
      expect(logTelemetry).toHaveBeenCalledWith({
        event_type: 'blob_client_connection_success',
      });
    });
  });
});
