import { ConfigService } from '@nestjs/config';
import { AiHttpClientService } from './http-client.service';
import { Test, TestingModule } from '@nestjs/testing';
import { mockGetConfig } from './__mocks__/config.mock';
import { HttpException } from '@nestjs/common';

describe('AiHttpClientService', () => {
  let service: AiHttpClientService;
  let configService: ConfigService;

  let originalFetch;

  beforeAll(() => {
    originalFetch = fetch;
  });

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AiHttpClientService,
        {
          provide: ConfigService,
          useValue: {
            get: mockGetConfig(),
          },
        },
      ],
    }).compile();
    service = module.get<AiHttpClientService>(AiHttpClientService);
    configService = module.get<ConfigService>(ConfigService);
    global.fetch = jest.fn();
  });

  describe('request', () => {
    it('should throw HttpException on HTTP error', async () => {
      (fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
      });

      await expect(
        service.request({
          method: 'GET',
          endpoint: 'some-endpoint',
          token: 'token',
        })
      ).rejects.toThrow(HttpException);
    });

    it('should throw an error if API_BASE_URL is not set', async () => {
      jest.spyOn(configService, 'get').mockReturnValue(undefined); // Mock de API_BASE_URL als undefined
      service = new AiHttpClientService(configService);
      const requestParams = {
        method: 'GET',
        endpoint: 'some-endpoint',
        token: 'token',
      };

      await expect(service.request(requestParams)).rejects.toThrow(Error);
      await expect(service.request(requestParams)).rejects.toThrow('Please set API_BASE_URL variables');
    });
  });

  describe('get', () => {
    it('should send a get request', async () => {
      (fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: async () => ({
          data: 'Success',
        }),
      });
      const response = await service.get('some-endpoint', 'token');
      expect(response).toEqual({ data: 'Success' });
    });
  });

  describe('post', () => {
    it('should send a post request', async () => {
      (fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: async () => ({
          data: 'Success',
        }),
      });
      const response = await service.post('some-endpoint', 'token', {});
      expect(response).toEqual({ data: 'Success' });
    });
  });
});
