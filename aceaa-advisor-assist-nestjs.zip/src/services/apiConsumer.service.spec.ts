import { Test, TestingModule } from '@nestjs/testing';
import { ApiConsumerService } from './apiConsumer.service';
import { PrismaService } from '../prisma.service';
import { ApiConsumer } from '../../prisma-generated-client';

describe('ApiConsumerService', () => {
  let service: ApiConsumerService;
  let prismaService: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ApiConsumerService,
        {
          provide: PrismaService,
          useValue: {
            apiConsumer: {
              findUnique: jest.fn(),
              create: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<ApiConsumerService>(ApiConsumerService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  const consumerId = 'existing-consumer-id';
  it('should return an existing consumer if found', async () => {
    const existingConsumer = { id: consumerId, type: 'system' } as ApiConsumer;

    jest.spyOn(prismaService.apiConsumer, 'findUnique').mockResolvedValue(existingConsumer);

    const result = await service.getOrCreateConsumer(consumerId);
    expect(result).toEqual(existingConsumer);
    expect(prismaService.apiConsumer.findUnique).toHaveBeenCalledWith({
      where: { id: consumerId },
    });
    expect(prismaService.apiConsumer.create).not.toHaveBeenCalled();
  });
});
