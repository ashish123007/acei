import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { generateActionId } from '../utils/generateActionId';
import { type ApiConsumer, SummaryGeneratedBy } from '../../prisma-generated-client';
import { InsightType } from '../../prisma-generated-client';
import { countSpecialCharacters } from '../utils/countSpecialChar';
import type {
  Insight,
  InsightCreateSearchInput,
  InsightCreateSummary,
  InsightReSummarizeInput,
} from '../dto/insight.dto';
import { ConversationService } from './conversation.service';
import { SummarizationService } from './summarization.service';
import { SearchService } from './search.service';
import type { ApiConsumerWithToken } from '../utils/decorators/apiConsumer.decorator';
import { BadRequestIagException, NotFoundIagException } from '../errors/custom-errors';
import { logger } from '../utils/logger';
import { dateToUnixTimeStamp, formatUnixTimeStampToString } from '../utils/formatDate';

export interface CreateInsight {
  type: InsightType;
  participantId?: string;
}

export interface CreateInsightSummaryResultPayload {
  transcript: string;
  summary: string;
  special_char_score: number;
  generated_by: SummaryGeneratedBy;
  parent_insight_id?: string;
}

export interface SaveInsight {
  conversationId: string | null;
  participantId?: string;
  transcript: string;
  summary: string;
  generatedBy: SummaryGeneratedBy;
  parentInsightId?: string;
}

@Injectable()
export class InsightService {
  constructor(
    private prisma: PrismaService,
    private readonly summarizationService: SummarizationService,
    private readonly conversationService: ConversationService,
    private readonly searchService: SearchService
  ) {}

  async handleSummarize(
    { conversationId, includeAllInteractions }: InsightCreateSummary,
    apiConsumer: ApiConsumerWithToken,
    participantId?: string,
    roleName?: string
  ): Promise<Insight> {
    // if includeAllInteractions is false, then participantId must be provided
    if (!includeAllInteractions && !participantId) {
      logger.error(`ParticipantId is missing when handling summary for conversationId: ${conversationId}`);
      throw new BadRequestIagException('PARTICIPANT_ID_MISSING');
    }

    if (!conversationId) {
      logger.error(`ConversationId is invalid. ConversationId: ${conversationId}`);
      throw new BadRequestIagException('CONVERSATION_ID_INVALID');
    }

    const _participantId = !includeAllInteractions ? participantId : undefined;

    const transcriptions = await this.conversationService.retrieveRelevantTranscriptions(
      apiConsumer,
      conversationId,
      includeAllInteractions,
      _participantId
    );

    if (!transcriptions.length) {
      logger.error('Transcriptions not found for conversationId: ', conversationId);
      throw new NotFoundIagException('TRANSCRIPTIONS_NOT_FOUND');
    }

    const summary = await this.summarizationService.fetchSummary({
      apiConsumer,
      conversationId,
      transcriptions,
      role: roleName,
    });

    if (!summary) {
      throw new Error('Summary was not returned by LLM');
    }

    const { transcription, message, openai_version } = summary;

    const insight = await this.saveSummaryInsight(apiConsumer, {
      conversationId,
      participantId,
      transcript: transcription,
      summary: message,
      generatedBy: SummaryGeneratedBy.LLM,
    });
    logger.info(`Summary created for conversationId: ${conversationId}, insightId: ${insight.insightId}`);
    return this.summarizationService.formatSummaryResponse({
      insight,
      message,
      openaiVersion: openai_version,
    });
  }

  async handleKbSearch(
    { message, conversationId }: InsightCreateSearchInput,
    apiConsumer: ApiConsumerWithToken,
    participantId?: string,
    roleName?: string
  ): Promise<Insight> {
    const insight = await this.createInsight(apiConsumer, conversationId ?? null, {
      type: InsightType.KnowledgeSearch,
      participantId,
    });

    const { insight_id, type, created_at } = insight;

    const KB_SEARCH = await this.searchService.fetchKnowledgeBase({
      apiConsumer,
      message,
      conversationId,
      role: roleName,
    });
    const { documents, original_query } = KB_SEARCH;

    await this.createInsightKnowledgeSearchResult(insight_id, message);
    const insightDocuments = await this.createInsightDocuments(apiConsumer, insight_id, documents);
    logger.info(
      `Knowledge search insight created with conversationId: ${conversationId}, insightId: ${insight.insight_id}`
    );
    return {
      insightId: insight_id,
      type: type,
      data: {
        input: original_query,
      },
      documents: insightDocuments?.map((document) => ({
        url: document.url,
        title: document.title,
        content: document.content,
      })),
      insightDateTime: formatUnixTimeStampToString(created_at),
    };
  }

  async handleReSummarize(
    { manual, llm, insightId }: InsightReSummarizeInput,
    apiConsumer: ApiConsumerWithToken,
    participantId?: string,
    roleName?: string
  ): Promise<Insight> {
    if (!participantId) {
      logger.error('Participant ID is missing in headers.');
      throw new BadRequestIagException('PARTICIPANT_ID_MISSING', 'Participant ID is missing in headers');
    }

    if (!manual?.editedSummary && !llm?.action) {
      logger.error(`Body not provided for insightId: ${insightId}`);
      throw new BadRequestException('Body not provided');
    }

    const insight = await this.getInsight(insightId, participantId);

    if (insight.conversation_id === null) {
      logger.error('ConversationId is required but was null.');
      throw new BadRequestIagException('CONVERSATION_ID_INVALID', 'Conversation ID is required but was null');
    }

    const insightSummaryResult = insight.insightSummaryResults[0];

    if (manual) {
      const { editedSummary } = manual;
      const newInsight = await this.saveSummaryInsight(apiConsumer, {
        conversationId: insight.conversation_id,
        participantId,
        transcript: insightSummaryResult.transcript,
        summary: editedSummary,
        generatedBy: SummaryGeneratedBy.Manual,
        parentInsightId: insight.insight_id,
      });

      return this.summarizationService.formatSummaryResponse({
        insight: newInsight,
        message: editedSummary,
      });
    } else if (llm) {
      const summary = await this.summarizationService.editSummary({
        apiConsumer,
        conversationId: insight.conversation_id,
        editSummaryRequest: {
          messages: insightSummaryResult.transcript,
          originalSummary: insightSummaryResult.summary,
          action: llm?.action,
        },
        role: roleName,
      });

      if (!summary) {
        throw new Error('No summary returned from LLM');
      }

      const { transcription, message } = summary;

      const newInsight = await this.saveSummaryInsight(apiConsumer, {
        conversationId: insight.conversation_id,
        participantId,
        transcript: transcription,
        summary: message,
        generatedBy: SummaryGeneratedBy.LLM,
        parentInsightId: insight.insight_id,
      });
      logger.info(`Edited summary created for conversationId: ${insight.conversation_id}, insightId: ${insightId}`);
      return this.summarizationService.formatSummaryResponse({
        insight: newInsight,
        message,
      });
    } else {
      logger.error(`Summary action should be manual or llm for conversationId: ${insight.conversation_id}`);
      throw new BadRequestIagException('SUMMARY_ACTION_INVALID', 'Summary action should be manual or llm');
    }
  }

  async saveSummaryInsight(
    apiConsumer: ApiConsumer,
    { conversationId, participantId, transcript, summary, generatedBy, parentInsightId }: SaveInsight
  ) {
    const insight = await this.createInsight(apiConsumer, conversationId, {
      type: InsightType.Summary,
      participantId,
    });

    await this.createInsightSummaryResult(insight.insight_id, {
      transcript,
      summary,
      special_char_score: countSpecialCharacters(summary),
      generated_by: generatedBy,
      parent_insight_id: parentInsightId,
    });
    return {
      insightId: insight.insight_id,
      createdAt: formatUnixTimeStampToString(insight.created_at),
    };
  }

  async createInsight(apiConsumer: ApiConsumer, conversationId: string | null, { type, participantId }: CreateInsight) {
    const insightId = generateActionId(type);
    const id = await this.getParticipantId(participantId);

    return this.prisma.insight.create({
      data: {
        insight_id: insightId,
        conversation_id: conversationId,
        tenant_id: apiConsumer.tenant_id,
        type,
        participant_id: id,
        created_at: dateToUnixTimeStamp(),
      },
    });
  }

  async createInsightSummaryResult(
    insightId: string,
    createInsightSummaryResultPayload: CreateInsightSummaryResultPayload
  ) {
    try {
      return this.prisma.insightSummaryResult.create({
        data: {
          insight_id: insightId,
          ...createInsightSummaryResultPayload,
        },
      });
    } catch (error) {
      logger.error(`Failed to create insight summary for insightId: ${insightId} %o`, error);
    }
  }

  async getInsight(insightId: string, participantId: string) {
    const insight = await this.prisma.insight.findUnique({
      where: {
        insight_id: insightId,
        participant_id: participantId,
      },
      include: {
        insightSummaryResults: true,
      },
    });

    if (!insight) {
      logger.warn(`Insight with insightId: ${insightId} not found`);
      throw new NotFoundIagException('INSIGHT_ID_NOT_FOUND', `Insight with ID: ${insightId} not found`);
    }
    return insight;
  }

  async createInsightKnowledgeSearchResult(insightId: string, search: string) {
    try {
      return this.prisma.insightKnowledgeSearchResult.create({
        data: {
          insight_id: insightId,
          search: search,
        },
      });
    } catch (error) {
      logger.error(`Failed to create insight knowledgeSearch for insightId: ${insightId} %o`, error);
    }
  }

  async createInsightDocuments(
    apiConsumer: ApiConsumer,
    insightId: string,
    documents: Array<{ url: string; title: string; content: string }>
  ) {
    try {
      const insightDocuments = documents.map((document) => ({
        insight_id: insightId,
        url: document.url,
        title: document.title,
        tenant_id: apiConsumer.tenant_id,
        content: document.content,
      }));

      await this.prisma.insightDocuments.createMany({
        data: insightDocuments,
      });
      return documents;
    } catch (error) {
      logger.error(`Failed to create insight documents for insightId: ${insightId}`, error);
    }
  }

  async createInsightFeedback(
    apiConsumer: ApiConsumer,
    insightId: string,
    participantId: string,
    message: string,
    score: number
  ) {
    return this.prisma.insightFeedback.create({
      data: {
        insight_id: insightId,
        participant_id: participantId,
        tenant_id: apiConsumer.tenant_id,
        score: score,
        message: message,
      },
    });
  }

  private async getParticipantId(participantId?: string) {
    if (!participantId) {
      return null;
    }

    const participant = await this.prisma.participant.findUnique({
      where: {
        participant_id: participantId,
      },
    });
    return participant?.participant_id;
  }
}
