import { Injectable } from '@nestjs/common';
import { BlobServiceClient } from '@azure/storage-blob';
import { DefaultAzureCredential } from '@azure/identity';
import { logTelemetry } from '../utils/telemetry';
import type { ObjectType } from '../types';

@Injectable()
export class AnalyticsService {
  computeBlobFilename(eventName: string, conversationId: string | null): string {
    const date = new Date().toISOString().split('T')[0];
    const conversationPart = conversationId || 'noConversationId';
    const timestamp = Date.now();
    const randomFileSeed = Math.floor(Math.random() * 10000)
      .toString()
      .padStart(4, '0');

    return `${date}/${conversationPart}/${eventName}_${timestamp}_${randomFileSeed}.json`;
  }

  getOrInitStorageConnection() {
    logTelemetry({ event_type: 'blob_client_connection_attempt' });
    try {
      const service = new BlobServiceClient(
        `https://${process.env.BLOB_ACCOUNT}.blob.core.windows.net`,
        new DefaultAzureCredential()
      );
      logTelemetry({ event_type: 'blob_client_connection_success' });
      return service;
    } catch (error) {
      const err = error as Error;
      logTelemetry({
        event_type: 'blob_client_connection_failure',
        error_message: err.message,
        stack: err.stack,
      });
      throw new Error(err.message);
    }
  }

  async storeEvent(eventName: string, conversationId: string | null, userId: string, data: ObjectType): Promise<void> {
    const filename = this.computeBlobFilename(eventName, conversationId);
    const CONVERSATION_CONTAINER_NAME = 'callgpt-user-conversation';
    const blobServiceClient = this.getOrInitStorageConnection();

    const content = {
      conversationId,
      userId,
      ...data,
    };

    const containerClient = blobServiceClient.getContainerClient(CONVERSATION_CONTAINER_NAME);
    await containerClient.createIfNotExists();
    const blockBlobClient = containerClient.getBlockBlobClient(filename);
    const jsonStringContent = JSON.stringify(content);
    await blockBlobClient.upload(jsonStringContent, Buffer.byteLength(jsonStringContent));
  }
}
