import { Test, TestingModule } from '@nestjs/testing';
import { EditSummaryAction, GenericSummaryResponse, SummarizationService } from './summarization.service';
import { ConfigService } from '@nestjs/config';
import { mockFetchSummaryResponse, mockFormatSummaryResponseDto } from './__mocks__/summarization.mock';
import { mockTranscriptionResultWithParticipant } from './__mocks__/transcription.mock';
import { mockGetConfig } from './__mocks__/config.mock';
import { AiHttpClientService } from './http-client.service';
import { apiConsumerMock } from './__mocks__/apiConsumer.mock';
import { getDefaultRole } from '../utils/getDefaultRole';
import { BadRequestIagException } from '../errors/custom-errors';
import { InsightType } from '../../prisma-generated-client';
import { ApiConsumerWithToken } from '../utils/decorators/apiConsumer.decorator';
import { mockDate } from './__mocks__/date.mock';

describe('SummarizationService', () => {
  let service: SummarizationService;
  let aiHttpClientService: AiHttpClientService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SummarizationService,
        {
          provide: ConfigService,
          useValue: {
            get: mockGetConfig(),
          },
        },
        {
          provide: AiHttpClientService,
          useValue: {
            post: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<SummarizationService>(SummarizationService);
    aiHttpClientService = module.get<AiHttpClientService>(AiHttpClientService);
  });

  describe('fetchSummary', () => {
    const mockConversationId = 'some-conversation-id';
    const mockMessages = [mockTranscriptionResultWithParticipant()];

    it('should fetch summary', async () => {
      const summaryResponseMock = mockFetchSummaryResponse();

      aiHttpClientService.post = jest.fn().mockResolvedValue(summaryResponseMock);

      const result = await service.fetchSummary({
        apiConsumer: apiConsumerMock,
        conversationId: mockConversationId,
        transcriptions: mockMessages,
      });

      expect(aiHttpClientService.post).toHaveBeenCalledWith(
        'advisor-assist-be/v2/summarisation?role=AdvisorAssist-CCO',
        apiConsumerMock.token,
        expect.any(Object)
      );

      expect(result).toBe(summaryResponseMock);
    });
  });

  describe('formatSummaryResponse', () => {
    it('should format summary response', () => {
      const summaryResponseDtoMock = mockFormatSummaryResponseDto();
      const result = service.formatSummaryResponse(summaryResponseDtoMock);
      expect(result).toMatchSnapshot();
    });
    it('should format summary response with default llmVersion when openaiVersion is undefined', () => {
      const summaryResponse: GenericSummaryResponse = {
        insight: {
          insightId: '123',
          createdAt: mockDate,
        },
        openaiVersion: undefined,
        message: 'This is a summary message',
      };
      const result = service.formatSummaryResponse(summaryResponse);

      expect(result).toEqual({
        insightId: '123',
        type: InsightType.Summary,
        data: {
          content: 'This is a summary message',
          llmVersion: 'UNKNOWN_LLM_VERSION',
        },
        insightDateTime: summaryResponse.insight.createdAt,
      });
    });
  });

  describe('getActionEndpoint', () => {
    const role = getDefaultRole({} as ApiConsumerWithToken);
    it.each([
      ['shorten', 'advisor-assist-be/v2/shorten?role=AdvisorAssist-CCO'],
      ['female', 'advisor-assist-be/v2/gendered/female?role=AdvisorAssist-CCO'],
      ['male', 'advisor-assist-be/v2/gendered/male?role=AdvisorAssist-CCO'],
    ])('should return correct path for %s', (input, expected) => {
      const result = service.getActionEndpoint(input as EditSummaryAction, role);

      expect(result).toBe(expected);
    });
    it('should throw BadRequestIagException for invalid action', () => {
      const action: any = 'invalidAction';

      expect(() => service.getActionEndpoint(action, role)).toThrow(BadRequestIagException);
    });
  });

  describe('editSummary', () => {
    const mockConversationId = '123';

    it('should edit summary', async () => {
      const summaryResponseMock = mockFetchSummaryResponse();

      aiHttpClientService.post = jest.fn().mockResolvedValue(summaryResponseMock);

      const result = await service.editSummary({
        apiConsumer: apiConsumerMock,
        conversationId: mockConversationId,
        editSummaryRequest: {
          messages: 'some-messages',
          originalSummary: 'some-original-summary',
          action: 'female',
        },
      });

      expect(aiHttpClientService.post).toHaveBeenCalledWith(
        'advisor-assist-be/v2/gendered/female?role=AdvisorAssist-CCO',
        apiConsumerMock.token,
        expect.any(Object)
      );

      expect(result).toBe(summaryResponseMock);
    });
  });
});
