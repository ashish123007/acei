import { Test, TestingModule } from '@nestjs/testing';
import { ValidationService } from './validation.service';
import { PrismaService } from '../prisma.service';
import { apiConsumerMock } from './__mocks__/apiConsumer.mock';

describe('ValidationService', () => {
  let validationService: ValidationService;
  let prismaService: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ValidationService,
        {
          provide: PrismaService,
          useValue: {
            apiConsumer: {
              findUnique: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    validationService = module.get<ValidationService>(ValidationService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  it('should validate data successfully with a valid template', async () => {
    const mockData = { pre_intent: 'HYPL' };

    const validApiConsumer = {
      ...apiConsumerMock,
      template: {
        type: 'object',
        properties: {
          pre_intent: { type: 'string', enum: ['HYPL'] },
        },
        required: ['pre_intent'],
        additionalProperties: false,
      },
    };

    jest.spyOn(prismaService.apiConsumer, 'findUnique').mockResolvedValue(validApiConsumer);

    const result = await validationService.validateWithDatabaseTemplate(validApiConsumer.id, mockData);
    expect(result).toBe(true);
  });

  it('should return false for invalid data against the template', async () => {
    const invalidData = { pre_intent: 'BBCB' };

    const invalidApiConsumer = {
      ...apiConsumerMock,
      template: {
        type: 'object',
        properties: {
          pre_intent: { type: 'string', enum: ['HYPL'] },
        },
        required: ['pre_intent'],
        additionalProperties: false,
      },
    };

    jest.spyOn(prismaService.apiConsumer, 'findUnique').mockResolvedValue(invalidApiConsumer);

    const result = await validationService.validateWithDatabaseTemplate(invalidApiConsumer.id, invalidData);
    expect(result).toBe(false);
  });
  it('should return true when no apiConsumer is found', async () => {
    const mockData = { pre_intent: 'HYPL' };

    jest.spyOn(prismaService.apiConsumer, 'findUnique').mockResolvedValue(null);

    const result = await validationService.validateWithDatabaseTemplate('non-existent-id', mockData);
    expect(result).toBe(true);
  });
});
