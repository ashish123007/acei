import { Injectable } from '@nestjs/common';
import type { ApiConsumer } from '../../prisma-generated-client';
import type {
  Conversation as ConversationDto,
  ConversationBase,
  ConversationSearchParams,
} from '../dto/conversation.dto';
import { BadRequestIagException, NotFoundIagException } from '../errors/custom-errors';
import { PrismaService } from '../prisma.service';
import { InteractionService } from './interaction.service';
import { logger } from '../utils/logger';
import { dateToUnixTimeStamp, formatUnixTimeStampToString } from '../utils/formatDate';

@Injectable()
export class ConversationService {
  constructor(
    private prisma: PrismaService,
    private interactionService: InteractionService
  ) {}

  async searchConversations(
    apiConsumer: ApiConsumer,
    { interactionReference }: ConversationSearchParams,
    participantId?: string
  ): Promise<ConversationBase[]> {
    if (!participantId && !interactionReference) {
      logger.warn('Search parameter missing');
      throw new BadRequestIagException('SEARCH_PARAMETER_MISSING');
    }

    const conversations = participantId
      ? await this.findConversationWithParticipantId(participantId)
      : await this.findConversationWithInteractionReference(interactionReference!);

    return conversations.map((conversation) => ({
      conversationId: conversation.conversation_id,
      conversationDateTime: formatUnixTimeStampToString(conversation.created_at),
      createdBy: apiConsumer.tenant_id,
    }));
  }

  async retrieveRelevantTranscriptions(
    apiConsumer: ApiConsumer,
    conversationId: string,
    includeAllInteractions?: boolean,
    requestingParticipantId?: string
  ) {
    logger.info(`Fetching conversation with ID: ${conversationId} for tenant: ${apiConsumer.tenant_id}`);

    const conversation = await this.prisma.conversation.findUnique({
      where: { conversation_id: conversationId, tenant_id: apiConsumer.tenant_id },
      include: {
        interactions: {
          orderBy: {
            created_at: 'desc',
          },
          include: {
            participants: true,
          },
        },
      },
    });

    if (!conversation) {
      logger.warn(`Conversation not found with conversationId: ${conversationId}`);
      throw new NotFoundIagException(
        'CONVERSATION_NOT_FOUND',
        `Conversation with conversationId: ${conversationId} not found`
      );
    }

    let filteredInteractionsIds = [];
    if (includeAllInteractions) {
      // fetch all interactionIds without filtering on relevancy
      filteredInteractionsIds = conversation.interactions.map((interaction) => interaction.interaction_id);
    } else {
      // fetching interactions with filtering on relevancy from newest to oldest with match on participantId
      let startCollecting = false;
      for (const interaction of conversation.interactions) {
        if (!startCollecting && interaction.participants.some((p) => p.participant_id === requestingParticipantId)) {
          startCollecting = true;
        }
        if (startCollecting) {
          filteredInteractionsIds.push(interaction.interaction_id);
        }
      }
    }

    const transcriptions = await this.prisma.transcription.findMany({
      where: {
        interaction_id: { in: filteredInteractionsIds },
      },
      include: {
        participant: true,
      },
    });

    logger.info(`Transcriptions retrieved for conversationId: ${conversation.conversation_id}`);
    return transcriptions;
  }
  async createConversation(apiConsumer: ApiConsumer): Promise<ConversationDto> {
    const conversation = await this.prisma.conversation.create({
      data: {
        tenant_id: apiConsumer.tenant_id,
        created_at: dateToUnixTimeStamp(),
      },
    });

    logger.info(`New conversation has been created: ${conversation.conversation_id}`);

    return {
      conversationId: conversation.conversation_id,
      conversationDateTime: formatUnixTimeStampToString(conversation.created_at),
      createdBy: apiConsumer.tenant_id,
      interactions: [],
    };
  }

  async getConversationById(conversationId: string, apiConsumer: ApiConsumer): Promise<ConversationDto> {
    const conversation = await this.prisma.conversation.findUnique({
      where: { conversation_id: conversationId, tenant_id: apiConsumer.tenant_id, active: true },
      include: {
        interactions: {
          include: {
            participants: {
              include: {
                participant: true,
              },
            },
            transcriptions: true,
          },
        },
      },
    });

    if (!conversation) {
      logger.warn(`Conversation not found with conversationId: ${conversationId}`);
      throw new NotFoundIagException('CONVERSATION_NOT_FOUND');
    }

    return {
      conversationId: conversation.conversation_id,
      conversationDateTime: formatUnixTimeStampToString(conversation.created_at),
      createdBy: apiConsumer.tenant_id,
      interactions: conversation.interactions?.map((interaction) =>
        this.interactionService.mapInteractionResponse(interaction)
      ),
    };
  }

  async deleteConversation(conversationId: string, apiConsumer: ApiConsumer) {
    try {
      await this.prisma.conversation.update({
        where: {
          conversation_id: conversationId,
          tenant_id: apiConsumer.tenant_id,
        },
        data: {
          active: false,
        },
      });

      await this.prisma.interaction.updateMany({
        where: {
          conversation_id: conversationId,
        },
        data: {
          active: false,
        },
      });

      logger.info(`Conversation and its interactions have been deleted. ${conversationId}`);
    } catch (error) {
      if ((error as { code: string }).code === 'P2025') {
        logger.warn(`Conversation does not exist with ${conversationId}`);
        throw new NotFoundIagException('CONVERSATION_NOT_FOUND');
      } else {
        throw error;
      }
    }
  }

  private async findConversationWithInteractionReference(reference: string) {
    const conversations = await this.prisma.conversation.findMany({
      where: {
        interactions: {
          some: {
            reference,
          },
        },
      },
      include: {
        interactions: {
          include: {
            participants: {
              include: {
                participant: true,
              },
            },
            transcriptions: true,
          },
          where: {
            reference,
          },
        },
      },
      // return only ten conversations
      take: 10,
    });

    return conversations;
  }

  private async findConversationWithParticipantId(participantId: string) {
    const conversations = await this.prisma.conversation.findMany({
      where: {
        interactions: {
          some: {
            participants: {
              some: {
                participant_id: participantId,
              },
            },
          },
        },
      },
      include: {
        interactions: {
          include: {
            participants: {
              include: {
                participant: true,
              },
            },
            transcriptions: true,
          },
          where: {
            participants: {
              some: {
                participant_id: participantId,
              },
            },
          },
        },
      },
      // return only ten conversations
      take: 10,
    });

    return conversations;
  }
}
