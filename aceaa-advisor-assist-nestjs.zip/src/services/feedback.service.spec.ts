import { Test, TestingModule } from '@nestjs/testing';
import { FeedbackService } from './feedback.service';
import { AiHttpClientService } from './http-client.service';
import { apiConsumerMock } from './__mocks__/apiConsumer.mock';

describe('FeedbackService', () => {
  let service: FeedbackService;
  let aiHttpClientService: AiHttpClientService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        FeedbackService,
        {
          provide: AiHttpClientService,
          useValue: {
            post: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<FeedbackService>(FeedbackService);
    aiHttpClientService = module.get<AiHttpClientService>(AiHttpClientService);
  });

  describe('fetch feedback results', () => {
    const conversationId = 'some-conversation-id';
    const sentiment = 'positive';
    const summary = 'some-summary';
    const transcription = 'some-transcription';
    const topic = 'summary';
    const participantId = 'some-participant-id';

    it('should fetch the feedback', async () => {
      const mockResponse = {
        status: 'complete',
      };

      aiHttpClientService.post = jest.fn().mockResolvedValue(mockResponse);

      const result = await service.postFeedback({
        apiConsumer: apiConsumerMock,
        conversation_id: conversationId,
        sentiment,
        summary,
        topic,
        transcription,
        participantId,
      });

      expect(aiHttpClientService.post).toHaveBeenCalledWith(
        'advisor-assist-be/v2/feedback?role=AdvisorAssist-CCO',
        apiConsumerMock.token,
        expect.any(Object)
      );

      expect(result).toBe(mockResponse);
    });
  });
});
