import { Test, TestingModule } from '@nestjs/testing';
import { PrismaService } from '../prisma.service';
import { InsightService } from './insight.service';
import { InsightSummaryResult, InsightType } from '../../prisma-generated-client';
import {
  mockCreateInsightDto,
  mockCreateInsightSummaryResultDto,
  mockCreateKnowledgeSearchResult,
  mockInsightResponse,
  mockInsightWithSummaryResponse,
  mockSaveInsightDto,
} from './__mocks__/insight.mock';
import { mockDate } from './__mocks__/date.mock';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { mockFeedbackResponse } from './__mocks__/feedback.mock';
import { apiConsumerMock } from './__mocks__/apiConsumer.mock';
import { ConversationService } from './conversation.service';
import { SearchService } from './search.service';
import { EditSummaryAction, SummarizationService } from './summarization.service';
import { MockProxy } from 'jest-mock-extended';
import { mockFetchSummaryResponse, mockFormatSummaryResponse } from './__mocks__/summarization.mock';
import { mockKbResponse, mockInsightDocument } from './__mocks__/search.mock';
import { logger } from '../utils/logger';
import { BadRequestIagException, NotFoundIagException } from '../errors/custom-errors';
import { mockTranscriptionResultWithParticipant } from './__mocks__/transcription.mock';
import { formatUnixTimeStampToString } from '../utils/formatDate';

describe('InsightService', () => {
  let service: InsightService;
  let prismaService: PrismaService;
  let summarizationService: MockProxy<SummarizationService>;
  let conversationService: MockProxy<ConversationService>;
  let searchService: MockProxy<SearchService>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        InsightService,
        {
          provide: PrismaService,
          useValue: {
            insight: {
              create: jest.fn(),
              findUnique: jest.fn(),
            },
            insightSummaryResult: {
              create: jest.fn(),
            },
            insightKnowledgeSearchResult: {
              create: jest.fn(),
            },
            insightDocuments: {
              createMany: jest.fn().mockImplementation(() => {
                throw new Error('Simulated error');
              }),
            },
            insightFeedback: {
              create: jest.fn().mockImplementation(() => {
                throw new Error('Simulated error');
              }),
            },
            participant: {
              findUnique: jest.fn().mockImplementation(() => {
                throw new Error('Simulated error');
              }),
            },
          },
        },
        {
          provide: ConversationService,
          useValue: {
            retrieveRelevantTranscriptions: jest.fn(),
          },
        },
        {
          provide: SummarizationService,
          useValue: {
            fetchSummary: jest.fn(),
            formatSummaryResponse: jest.fn(),
            editSummary: jest.fn(),
          },
        },
        {
          provide: SearchService,
          useValue: {
            fetchKnowledgeBase: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<InsightService>(InsightService);
    prismaService = module.get<PrismaService>(PrismaService);
    conversationService = module.get(ConversationService);
    summarizationService = module.get(SummarizationService);
    searchService = module.get(SearchService);

    jest.clearAllMocks();
  });
  const mockInsightId = 'some-insight-id';
  const mockConversationId = 'some-conversation-id';
  const mockParticipantId = 'some-participant-id';
  const message = 'feedback message';
  const score = 5;
  const insightResponseMock = mockInsightResponse();

  describe('handleSummarize', () => {
    const summaryResponseMock = mockFetchSummaryResponse();
    const transcriptions = [mockTranscriptionResultWithParticipant()];

    it('should throw an error if participantId is not provided while includeAllInteractions is set to false', () => {
      expect(
        service.handleSummarize({ conversationId: mockConversationId, includeAllInteractions: false }, apiConsumerMock)
      ).rejects.toThrow(BadRequestException);
    });

    it('should handle summary correctly with all interactions', async () => {
      jest.spyOn(conversationService, 'retrieveRelevantTranscriptions').mockResolvedValue(transcriptions);
      jest.spyOn(summarizationService, 'fetchSummary').mockResolvedValue(summaryResponseMock);
      jest
        .spyOn(service, 'saveSummaryInsight')
        .mockResolvedValue({ insightId: 'mock-insight-id', createdAt: mockDate });

      await service.handleSummarize(
        { conversationId: mockConversationId, includeAllInteractions: true },
        apiConsumerMock
      );

      expect(conversationService.retrieveRelevantTranscriptions).toHaveBeenCalled();
      expect(summarizationService.fetchSummary).toHaveBeenCalled();
      expect(service.saveSummaryInsight).toHaveBeenCalled();
    });

    it('should log error and throw BadRequestIagException when conversationId is invalid', async () => {
      const conversationId: any = null;
      await expect(
        service.handleSummarize({ conversationId: conversationId, includeAllInteractions: true }, apiConsumerMock)
      ).rejects.toThrow(BadRequestIagException);

      expect(logger.error).toHaveBeenCalledWith('ConversationId is invalid. ConversationId: null');
    });
    it('should throw NotFoundException if interactions are not found', async () => {
      jest.spyOn(conversationService, 'retrieveRelevantTranscriptions').mockResolvedValue([]);

      await expect(
        service.handleSummarize({ conversationId: mockConversationId, includeAllInteractions: true }, apiConsumerMock)
      ).rejects.toThrow(NotFoundIagException);
    });
    it('should throw Error if summary cannot be fetched', async () => {
      jest.spyOn(conversationService, 'retrieveRelevantTranscriptions').mockResolvedValue(transcriptions);
      jest.spyOn(summarizationService, 'fetchSummary').mockResolvedValue(null as never);

      await expect(
        service.handleSummarize(
          { conversationId: mockConversationId, includeAllInteractions: false },
          apiConsumerMock,
          mockParticipantId
        )
      ).rejects.toThrow(Error);
    });
  });

  describe('handleKbSearch', () => {
    it('should create an insight search', async () => {
      const mockInsight = mockInsightResponse({
        type: InsightType.KnowledgeSearch,
      });

      const kbResponse = mockKbResponse();
      const insightDocMock = [mockInsightDocument()];
      const mockSearchResult = mockCreateKnowledgeSearchResult();

      service.createInsight = jest.fn().mockResolvedValue(mockInsight);
      searchService.fetchKnowledgeBase.mockResolvedValue(kbResponse);
      service.createInsightKnowledgeSearchResult = jest.fn().mockResolvedValue(mockSearchResult);
      service.createInsightDocuments = jest.fn().mockResolvedValue(insightDocMock);

      const result = await service.handleKbSearch(
        { message: 'some-message', conversationId: 'some-conversation-id' },
        apiConsumerMock
      );

      expect(result).toMatchSnapshot();
    });
  });

  describe('handleReSummarize', () => {
    const insightWithSummaryResponseMock = mockInsightWithSummaryResponse();
    const formatSummaryResponseMock = mockFormatSummaryResponse();
    const summaryResponseMock = mockFetchSummaryResponse();

    it.each([
      ['llm', { llm: { action: 'male' as EditSummaryAction } }],
      ['manual', { manual: { editedSummary: 'some-edited-summary' } }],
    ])('should edit %s summary', async (_, body) => {
      summarizationService.editSummary.mockResolvedValue(summaryResponseMock as never);
      service.getInsight = jest.fn().mockResolvedValue(insightWithSummaryResponseMock);
      service.createInsight = jest.fn().mockResolvedValue(insightResponseMock);
      service.saveSummaryInsight = jest.fn().mockResolvedValue({
        insightId: mockInsightId,
        createdAt: mockDate,
      });
      summarizationService.formatSummaryResponse.mockResolvedValue(formatSummaryResponseMock as never);

      const result = await service.handleReSummarize(
        { ...body, insightId: 'some-insight-id' },
        apiConsumerMock,
        mockParticipantId
      );

      expect(result).toEqual(formatSummaryResponseMock);
    });

    it('should throw BadRequestException if body is not provided', () => {
      expect(
        service.handleReSummarize({ insightId: 'some-insight-id' }, apiConsumerMock, mockParticipantId)
      ).rejects.toThrow(BadRequestException);
    });

    it('should throw BadRequestException if conversation_id is null', async () => {
      const mockInsightWithNullConversation = {
        ...insightWithSummaryResponseMock,
        conversation_id: null,
      };

      service.getInsight = jest.fn().mockResolvedValue(mockInsightWithNullConversation);

      await expect(
        service.handleReSummarize(
          { manual: { editedSummary: 'some-summary' }, insightId: mockInsightId },
          apiConsumerMock,
          mockParticipantId
        )
      ).rejects.toThrow(BadRequestException);
    });

    it('should throw an error if unable to edit summary', async () => {
      summarizationService.editSummary.mockResolvedValue('' as never);
      service.getInsight = jest.fn().mockResolvedValue(insightWithSummaryResponseMock);

      await expect(
        service.handleReSummarize(
          { llm: { action: 'male' as EditSummaryAction }, insightId: mockInsightId },
          apiConsumerMock,
          mockParticipantId
        )
      ).rejects.toThrow(Error);
    });

    it('should throw an error if participantId is missing', async () => {
      await expect(
        service.handleReSummarize(
          { llm: { action: 'male' as EditSummaryAction }, insightId: mockInsightId },
          apiConsumerMock
        )
      ).rejects.toThrow(BadRequestException);
    });
  });
  describe('saveSummaryInsight', () => {
    const saveInsightParams = mockSaveInsightDto();
    it('should successfully save summary insight', async () => {
      jest.spyOn(service, 'createInsight').mockResolvedValue(insightResponseMock);
      jest.spyOn(service, 'createInsightSummaryResult').mockResolvedValue(undefined);

      const result = await service.saveSummaryInsight(apiConsumerMock, saveInsightParams);

      expect(result).toEqual({
        insightId: insightResponseMock.insight_id,
        createdAt: formatUnixTimeStampToString(insightResponseMock.created_at),
      });
    });
  });

  describe('createInsight', () => {
    const createInsightDtoMock = mockCreateInsightDto();

    it('should create an insight', async () => {
      jest.spyOn(prismaService.insight, 'create').mockResolvedValue(insightResponseMock);
      jest.spyOn(prismaService.participant, 'findUnique').mockResolvedValue({} as never);

      const result = await service.createInsight(apiConsumerMock, mockConversationId, createInsightDtoMock);

      expect(prismaService.insight.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          conversation_id: mockConversationId,
          type: 'Summary',
        }),
      });
      expect(result).toEqual(insightResponseMock);
    });
  });

  describe('createInsightSummaryResult', () => {
    const createInsightSummaryResultDtoMock = mockCreateInsightSummaryResultDto();
    const createInsightSummaryResultMock = mockCreateInsightSummaryResultDto();

    it('should create insight summary result', async () => {
      jest
        .spyOn(prismaService.insightSummaryResult, 'create')
        .mockResolvedValue(createInsightSummaryResultMock as unknown as InsightSummaryResult);
      const result = await service.createInsightSummaryResult(mockInsightId, createInsightSummaryResultDtoMock);
      expect(prismaService.insightSummaryResult.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          insight_id: mockInsightId,
          special_char_score: createInsightSummaryResultDtoMock.special_char_score,
        }),
      });
      expect(result).toEqual(createInsightSummaryResultMock);
    });
    it('should log error when create fails for insight summary result', async () => {
      jest.spyOn(prismaService.insightSummaryResult, 'create').mockImplementation(() => {
        throw new Error('Simulated error');
      });

      await service.createInsightSummaryResult(mockInsightId, createInsightSummaryResultDtoMock);

      expect(logger.error).toHaveBeenCalled();
    });
  });

  describe('getInsight', () => {
    it('should get insight', async () => {
      jest.spyOn(prismaService.insight, 'findUnique').mockResolvedValue(insightResponseMock);

      const result = await service.getInsight(mockInsightId, mockParticipantId);
      expect(result).toBe(insightResponseMock);
    });

    it('should throw NotFoundException if insightId is provided but not found', () => {
      expect(service.getInsight(mockInsightId, mockParticipantId)).rejects.toThrow(NotFoundException);
    });
  });

  describe('createInsightKnowledgeSearchResult', () => {
    const createInsightKnowledgeSearchResultMock = mockCreateKnowledgeSearchResult();

    it('should create an insight knowledge search result', async () => {
      jest
        .spyOn(prismaService.insightKnowledgeSearchResult, 'create')
        .mockResolvedValue(createInsightKnowledgeSearchResultMock);
      const result = await service.createInsightKnowledgeSearchResult(
        mockInsightId,
        createInsightKnowledgeSearchResultMock.search
      );
      expect(result).toEqual(createInsightKnowledgeSearchResultMock);
    });
    it('should log error when create fails for insight knowledge search result', async () => {
      jest.spyOn(prismaService.insightKnowledgeSearchResult, 'create').mockImplementation(() => {
        throw new Error('Simulated error');
      });

      await service.createInsightKnowledgeSearchResult(mockInsightId, createInsightKnowledgeSearchResultMock.search);

      expect(logger.error).toHaveBeenCalled();
    });
  });

  describe('createInsightDocuments', () => {
    const createInsightDocumentsDtoMock = {
      documents: [{ url: 'some-url', title: 'some-title', content: 'some-content' }],
    };

    it('should create insight documents', async () => {
      prismaService.insightDocuments.createMany = jest.fn().mockResolvedValue({});
      const result = await service.createInsightDocuments(
        apiConsumerMock,
        mockInsightId,
        createInsightDocumentsDtoMock.documents
      );
      expect(result).toEqual(createInsightDocumentsDtoMock.documents);
    });
    it('should log error when failing to create insight documents', async () => {
      await service.createInsightDocuments(apiConsumerMock, mockInsightId, createInsightDocumentsDtoMock.documents);
      expect(logger.error).toHaveBeenCalled();
    });
  });

  describe('createInsightFeedback', () => {
    it('should create insight feedback', async () => {
      const feedbackResponse = mockFeedbackResponse();
      jest.spyOn(prismaService.insightFeedback, 'create').mockResolvedValue(feedbackResponse);
      await service.createInsightFeedback(apiConsumerMock, mockInsightId, mockParticipantId, message, score);

      expect(prismaService.insightFeedback.create).toHaveBeenCalledWith({
        data: {
          insight_id: mockInsightId,
          participant_id: mockParticipantId,
          score: score,
          message: message,
          tenant_id: 'tenant_id',
        },
      });
    });
  });

  describe('getParticipantId', () => {
    it('should return null if participantId is not provided', async () => {
      const result = await service['getParticipantId'](undefined);
      expect(result).toBeNull();
      expect(prismaService.participant.findUnique).not.toHaveBeenCalled();
    });
  });
});
