import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import type { ObjectType } from '../types';
import { logger } from '../utils/logger';

export interface HttpClientRequest {
  method: RequestInit['method'];
  endpoint: string;
  body?: ObjectType;
  headers?: ObjectType;
  token: string;
}

@Injectable()
export class AiHttpClientService {
  private readonly apiBaseUrl: string | undefined;
  constructor(private configService: ConfigService) {
    this.apiBaseUrl = this.configService.get<string>('API_BASE_URL');
  }

  async request<T>({ endpoint, method, token, body, headers = {} }: HttpClientRequest): Promise<T> {
    if (!this.apiBaseUrl) {
      throw new Error('Please set API_BASE_URL variables');
    }
    const url = `${this.apiBaseUrl}${endpoint}`;

    logger.verbose(`Sending ${method} ${url}: %j`, body);
    const response = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        ...headers,
      },
      ...(body && { body: JSON.stringify(body) }),
    });

    if (!response.ok) {
      logger.warn(`HTTP Error: ${response.status} - ${response.statusText}`);
      throw new HttpException('Unable to complete request', HttpStatus.INTERNAL_SERVER_ERROR);
    }
    return (await response.json()) as T;
  }

  async get<T>(endpoint: string, token: string, headers?: ObjectType): Promise<T> {
    return this.request<T>({
      method: 'GET',
      endpoint,
      token,
      headers,
    });
  }

  async post<T>(endpoint: string, token: string, body: ObjectType, headers?: ObjectType): Promise<T> {
    return this.request<T>({
      method: 'POST',
      endpoint,
      token,
      headers,
      body,
    });
  }
}
