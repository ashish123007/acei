import { Test } from '@nestjs/testing';
import { SpeechToTextService } from './speech-to-text.service';
import { readFile, writeFile } from 'fs/promises';
import { HttpException } from '@nestjs/common';
import { logger } from '../utils/logger';

jest.mock('fs/promises');

const mockGetToken = jest.fn();
jest.mock('@azure/identity', () => {
  return jest.fn().mockImplementation(() => {
    return {
      DefaultAzureCredential: jest.fn().mockImplementation(() => {
        return { getToken: mockGetToken };
      }),
    };
  });
});

jest.mock('@azure/identity', () => {
  function defaultAzureCredential() {
    return {
      getToken: () => ({}),
    };
  }

  return { DefaultAzureCredential: defaultAzureCredential };
});

jest.mock('microsoft-cognitiveservices-speech-sdk', () => ({
  AudioConfig: { fromWavFileInput: jest.fn() },
  SpeechConfig: {
    fromAuthorizationToken: function () {
      return { setProperty: jest.fn() };
    },
  },
  SpeechRecognizer: function () {
    return { close: jest.fn(), recognizeOnceAsync: (cb: Function) => cb('VALUE!') };
  },
  PropertyId: { SpeechServiceConnection_Endpoint: '' },
  PhraseListGrammar: {
    fromRecognizer: function () {
      return { addPhrases: jest.fn() };
    },
  },
}));

jest.mock('fluent-ffmpeg', () => {
  const mockFn = () => ({
    format: () => ({
      audioFilter: () => ({
        save: () => ({
          on: (_: string, cb: Function) => {
            cb();
            return {
              on: () => ({
                on: () => ({
                  pipe: () => {},
                }),
              }),
            };
          },
        }),
      }),
    }),
  });
  mockFn.setFfmpegPath = jest.fn();
  return mockFn;
});

describe('SpeechToTextService', () => {
  let service: SpeechToTextService;
  let envCopy: NodeJS.ProcessEnv;
  const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
  const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();

  beforeEach(async () => {
    envCopy = { ...process.env };
    const module = await Test.createTestingModule({
      providers: [SpeechToTextService],
    }).compile();

    service = module.get<SpeechToTextService>(SpeechToTextService);
    jest.resetAllMocks();
  });

  afterEach(() => {
    process.env = envCopy;
    consoleLogSpy.mockClear();
    consoleErrorSpy.mockClear();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should transcribe wav file', async () => {
    process.env.ENVIRONMENT = 'test';
    process.env.SPEECH_ENDPOINT = 'test';

    const result = await service.transcribe('SOME BASE64 AUDIO STRING', 'en-us');
    expect(writeFile).toHaveBeenCalled();
    expect(result).toEqual('VALUE!');
  });

  it('should read files', async () => {
    process.env.ENVIRONMENT = 'test';
    process.env.SPEECH_ENDPOINT = 'test';

    await service.transcribe('SOME BASE64 AUDIO STRING', 'en-us');
    expect(readFile).toHaveBeenCalled();
    expect(logger.info).toHaveBeenCalled();
  });

  it('should handle error', async () => {
    await expect(service.transcribe('SOME BASE64 AUDIO STRING', 'en-us')).rejects.toThrow(HttpException);
    expect(logger.error).toHaveBeenCalled();
  });
});
