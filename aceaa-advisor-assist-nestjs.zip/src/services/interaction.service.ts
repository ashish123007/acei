import { BadRequestException, Injectable } from '@nestjs/common';
import type { ApiConsumer, ParticipantType, Prisma } from '../../prisma-generated-client';
import { PrismaService } from '../prisma.service';
import { logger } from '../utils/logger';
import type {
  ConversationInteractionInput,
  ConversationInteraction,
  InteractionContext,
} from '../dto/conversation.dto';
import { TranscriptionService } from './transcription.service';
import { isAnEmptyObject } from '../utils/isAnEmptyObject';
import { NotFoundIagException } from '../errors/custom-errors';

export type InteractionGetPayload = Prisma.InteractionGetPayload<{
  include: {
    participants: {
      include: {
        participant: true;
      };
    };
    transcriptions: true;
  };
}>;
import type { NiceParametersDto } from '../dto/Nice.dto';
import type { IVRParametersDto } from '../dto/IVR.dto';
import { dateToUnixTimeStamp, formatUnixTimeStampToString } from '../utils/formatDate';

export type InteractionContextDto = NiceParametersDto | IVRParametersDto;

@Injectable()
export class InteractionService {
  constructor(
    private prisma: PrismaService,
    private readonly transcriptionService: TranscriptionService
  ) {}

  async findConversationId(
    apiConsumer: ApiConsumer,
    conversationId?: string,
    conversationReference?: string
  ): Promise<string> {
    if (conversationId) {
      const existingConversation = await this.prisma.conversation.findUnique({
        where: { conversation_id: conversationId, tenant_id: apiConsumer.tenant_id },
      });
      if (!existingConversation) {
        logger.warn(`Conversation with conversationId ${conversationId} not found`);
        throw new NotFoundIagException('CONVERSATION_NOT_FOUND', `Conversation with ID "${conversationId}" not found.`);
      }

      return existingConversation.conversation_id;
    } else if (conversationReference) {
      const existingConversation = await this.prisma.conversation.findFirst({
        where: {
          interactions: { some: { reference: conversationReference, tenant_id: apiConsumer.tenant_id } },
        },
      });
      if (!existingConversation) {
        logger.error(`Conversation with reference ${conversationReference} not found`);
        throw new NotFoundIagException(
          'INTERACTION_ID_NOT_FOUND',
          `Interaction with Reference "${conversationReference}" not found.`
        );
      }
      return existingConversation.conversation_id;
    } else {
      const newConversation = await this.prisma.conversation.create({
        data: {
          tenant_id: apiConsumer.tenant_id,
          created_at: dateToUnixTimeStamp(),
        },
      });
      return newConversation.conversation_id;
    }
  }

  async createInteraction(
    apiConsumer: ApiConsumer,
    conversationId: string,
    ConversationInteractionInput: ConversationInteractionInput
  ) {
    await this.setIInteractionsActiveToFalse(conversationId);

    if (ConversationInteractionInput.participants?.length) {
      await this.upsertParticipants(apiConsumer, ConversationInteractionInput.participants);
    }

    const interaction = await this.prisma.interaction.create({
      data: {
        conversation_id: conversationId,
        name: ConversationInteractionInput.name,
        reference: ConversationInteractionInput.reference,
        context: ConversationInteractionInput.context ?? {},
        tenant_id: apiConsumer.tenant_id,
        created_by: apiConsumer.id,
        created_at: dateToUnixTimeStamp(),
        participants: {
          create: ConversationInteractionInput.participants?.map((participant) => ({
            participant: {
              connectOrCreate: {
                where: { tenant_id: apiConsumer.tenant_id, participant_id: participant.id },
                create: {
                  tenant_id: apiConsumer.tenant_id,
                  participant_id: participant.id,
                  type: participant.type,
                },
              },
            },
            tenant: { connect: { id: apiConsumer.tenant_id } },
          })),
        },
      },
      include: {
        participants: {
          include: {
            participant: true,
          },
        },
        transcriptions: true,
      },
    });

    if (ConversationInteractionInput.transcriptions?.length) {
      await this.transcriptionService.createTranscription({
        apiConsumer,
        interactionId: interaction.interaction_id,
        transcriptions: ConversationInteractionInput.transcriptions,
        conversationId,
      });
    }

    return this.mapInteractionResponse(interaction);
  }

  async updateContext({
    context,
    interactionId,
    conversationId,
    apiConsumer,
  }: {
    context: InteractionContextDto;
    interactionId: string;
    conversationId: string;
    apiConsumer: ApiConsumer;
  }): Promise<InteractionContext> {
    if (isAnEmptyObject(context)) {
      logger.warn(`No context was provided for conversationId: ${conversationId}`);
      throw new BadRequestException('No context was provided');
    }
    const options = {
      where: {
        interaction_id: interactionId,
        conversation_id: conversationId,
        tenant_id: apiConsumer.tenant_id,
      },
      select: {
        context: true,
      },
    };

    const existingInteraction = await this.prisma.interaction.findUnique({
      ...options,
    });

    if (!existingInteraction) {
      logger.warn('Interaction not found with interactionId: ', interactionId, ' and conversationId: ', conversationId);
      throw new NotFoundIagException(
        'INTERACTION_ID_NOT_FOUND',
        `Interaction not found with interaction_id: ${interactionId} `
      );
    }

    const updatedInteraction = await this.prisma.interaction.update({
      ...options,
      data: {
        context: {
          ...((existingInteraction.context as Prisma.JsonObject) || {}),
          ...context,
        },
      },
    });
    logger.info(
      `Interaction context updated successfully with conversationId: ${conversationId}, interactionId: ${interactionId}`
    );
    return updatedInteraction.context ?? {};
  }

  private async upsertParticipants(apiConsumer: ApiConsumer, participants: { id: string; type: ParticipantType }[]) {
    const upsertParticipants = participants.map((participant) =>
      this.prisma.participant.upsert({
        where: { participant_id: participant.id },
        update: { type: participant.type },
        create: { tenant_id: apiConsumer.tenant_id, participant_id: participant.id, type: participant.type },
      })
    );

    await Promise.all(upsertParticipants);
  }

  private async setIInteractionsActiveToFalse(conversationId: string) {
    await this.prisma.interaction.updateMany({
      where: {
        conversation_id: conversationId,
      },
      data: {
        active: false,
      },
    });
  }

  mapInteractionResponse(interaction: InteractionGetPayload): ConversationInteraction {
    return {
      interactionId: interaction.interaction_id,
      createdDateTime: formatUnixTimeStampToString(interaction.created_at),
      createdBy: interaction.created_by,
      name: interaction.name,
      reference: interaction.reference ?? undefined,
      context: interaction.context ?? {},
      participants: (interaction?.participants || []).map(({ participant }) => ({
        id: participant.participant_id,
        type: participant.type,
      })),
      transcriptions: (interaction?.transcriptions || []).map((transcription) => ({
        participantId: transcription.participant_id,
        text: transcription.content,
        transcriptDateTime: formatUnixTimeStampToString(transcription.created_at),
      })),
    };
  }
}
