import 'reflect-metadata';
import { NestFactory, Reflector } from '@nestjs/core';
import { AppModule } from './app.module';
import { RequestMethod } from '@nestjs/common';
import config from './config';
import * as appInsights from 'applicationinsights';
import { logger } from './utils/logger';
import { CustomExceptionFilter } from './errors/custom-errors';
import { MetadataInterceptor } from './interceptors/metadata';
import { DefaultAzureCredential } from '@azure/identity';

const { PORT } = config;
const APPINSIGHTS_CONNECTION_STRING = process.env.APPINSIGHTS_CONNECTION_STRING;

function startAppInsight() {
  if (APPINSIGHTS_CONNECTION_STRING) {
    const credential = new DefaultAzureCredential();
    const appInsightInstance = appInsights.setup(APPINSIGHTS_CONNECTION_STRING).setAutoCollectConsole(true, true);

    appInsights.defaultClient.context.tags[appInsights.defaultClient.context.keys.cloudRole] = 'advisor-assist-nestjs';
    appInsights.defaultClient.config.aadTokenCredential = credential;
    appInsightInstance.start();
    logger.info('appinsight started');
  }
}

async function bootstrap() {
  try {
    startAppInsight();
    const app = await NestFactory.create(AppModule);

    const reflector = app.get(Reflector);
    app.useGlobalInterceptors(new MetadataInterceptor(reflector));
    app.useGlobalFilters(new CustomExceptionFilter());
    app.setGlobalPrefix('conversation-insights/v1/', {
      exclude: [
        { path: 'health', method: RequestMethod.GET },
        // exclude aa/voice-hub routes, they are public routes for ACS
        {
          path: 'aa/voice-hub/events',
          method: RequestMethod.POST,
        },
        {
          path: 'aa/voice-hub/callbacks',
          method: RequestMethod.POST,
        },
      ],
    });
    app.enableCors({ origin: process.env.ALLOWED_ORIGINS && process.env.ALLOWED_ORIGINS.split(',') });

    await app.listen(PORT);
  } catch (err) {
    logger.error('unable to start nest %o', err);
  }
}

// eslint-disable-next-line @typescript-eslint/no-floating-promises
bootstrap();
