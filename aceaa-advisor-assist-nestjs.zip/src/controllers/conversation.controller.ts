import {
  Controller,
  Post,
  Headers,
  Get,
  Body,
  Param,
  UseGuards,
  Query,
  Patch,
  BadRequestException,
  Delete,
} from '@nestjs/common';
import { InteractionService } from '../services/interaction.service';
import { TranscriptionService } from '../services/transcription.service';
import { ConversationService } from '../services/conversation.service';
import { logger } from '../utils/logger';
import { ApiConsumerDecorator, ApiConsumerWithToken } from '../utils/decorators/apiConsumer.decorator';
import { JwtAuthGuard } from '../auth/jwtAuth.guard';
import type {
  Conversation,
  ConversationBase,
  ConversationInteraction,
  InteractionContext,
  InteractionTranscript,
} from '../dto/conversation.dto';

import {
  CreateConversationDocs,
  CreateInteractionDocs,
  CreateTranscriptDocs,
  DeleteConversationDocs,
  GetConversationByIdDocs,
  GetTranscriptDocs,
  SearchConversationDocs,
  UpdateContextDocs,
} from '../swagger';

import { ValidationService } from '../services/validation.service';
import type { NiceParametersDto } from '../dto/Nice.dto';
import type { IVRParametersDto } from '../dto/IVR.dto';

import {
  ConversationIdDto,
  ConversationParamDto,
  ConversationSearchParams,
  ConversationInteractionInput,
} from '../dto/conversation.dto';
import { RouteContext } from '../utils/decorators/routeContext.decorator';

type InteractionContextDto = NiceParametersDto | IVRParametersDto;

@Controller('conversations')
export class ConversationController {
  constructor(
    private readonly interactionService: InteractionService,
    private readonly transcriptionService: TranscriptionService,
    private readonly conversationService: ConversationService,
    private readonly validationService: ValidationService
  ) {}

  @Post()
  @UseGuards(JwtAuthGuard)
  @RouteContext('create new conversation')
  @CreateConversationDocs()
  async createConversation(@ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken): Promise<Conversation> {
    return this.conversationService.createConversation(apiConsumer);
  }

  @Get('/:conversationId')
  @UseGuards(JwtAuthGuard)
  @RouteContext('retrieve conversation')
  @GetConversationByIdDocs()
  async getConversationById(
    @Param() { conversationId }: ConversationIdDto,
    @ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken
  ): Promise<Conversation> {
    return this.conversationService.getConversationById(conversationId, apiConsumer);
  }

  @Delete('/:conversationId')
  @UseGuards(JwtAuthGuard)
  @RouteContext('delete conversation')
  @DeleteConversationDocs()
  async deleteConversation(
    @Param() { conversationId }: ConversationIdDto,
    @ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken
  ) {
    await this.conversationService.deleteConversation(conversationId, apiConsumer);
    return;
  }

  @Post('/:conversationId/interactions')
  @UseGuards(JwtAuthGuard)
  @RouteContext('create interaction')
  @CreateInteractionDocs()
  async createInteraction(
    @Param() { conversationId }: ConversationIdDto,
    @Body() createInteractionDto: ConversationInteractionInput,
    @ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken
  ): Promise<ConversationInteraction> {
    if (apiConsumer.template && createInteractionDto.context && typeof createInteractionDto.context === 'object') {
      const isValid = await this.validationService.validateWithDatabaseTemplate(
        apiConsumer.id,
        createInteractionDto.context
      );

      if (!isValid) {
        logger.warn(`Invalid payload for interaction context, conversationId: ${conversationId}.`);
        throw new BadRequestException('Invalid payload');
      }
    }
    const convId = await this.interactionService.findConversationId(apiConsumer, conversationId);

    logger.debug('Creating interaction with params', {
      reqConversationId: conversationId,
      actualConversationId: convId,
      createInteractionDto,
    });
    return this.interactionService.createInteraction(apiConsumer, convId, createInteractionDto);
  }

  @Post('/:conversationId/interactions/:interactionId/transcriptions')
  @UseGuards(JwtAuthGuard)
  @RouteContext('create transcriptions')
  @CreateTranscriptDocs()
  async createTranscript(
    @Param() { interactionId, conversationId }: ConversationParamDto,
    @Body() body: InteractionTranscript[],
    @ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken
  ): Promise<void> {
    await this.transcriptionService.createTranscription({
      apiConsumer,
      interactionId,
      conversationId,
      transcriptions: body,
    });
    logger.info(`Transcriptions created successfully with conversationId: ${conversationId}`);
    return;
  }

  @Get('/:conversationId/interactions/:interactionId/transcriptions')
  @UseGuards(JwtAuthGuard)
  @RouteContext('retrieve transcriptions')
  @GetTranscriptDocs()
  async getTranscripts(
    @Param() { interactionId }: ConversationParamDto,
    @ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken
  ): Promise<InteractionTranscript[]> {
    return this.transcriptionService.getTranscriptions({
      apiConsumer,
      interactionId,
    });
  }

  @Patch('/:conversationId/interactions/:interactionId/context')
  @UpdateContextDocs()
  @RouteContext('update contexts')
  @UseGuards(JwtAuthGuard)
  async updateInteractionContext(
    @Param() { interactionId, conversationId }: ConversationParamDto,
    @Body() context: InteractionContextDto,
    @ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken
  ): Promise<InteractionContext> {
    if (apiConsumer.template) {
      const isValid = await this.validationService.validateWithDatabaseTemplate(apiConsumer.id, context);

      if (!isValid) {
        logger.warn(
          `Invalid payload for interaction context, conversationId: ${conversationId}, interactionId: ${interactionId}`
        );
        throw new BadRequestException('Invalid payload');
      }
    }

    return this.interactionService.updateContext({
      apiConsumer,
      interactionId,
      conversationId,
      context,
    });
  }

  @Get()
  @UseGuards(JwtAuthGuard)
  @SearchConversationDocs()
  @RouteContext('search conversations')
  async searchConversations(
    @ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken,
    @Query() conversationSearchParams: ConversationSearchParams,
    @Headers('PII-Participant-Id') participantId?: string
  ): Promise<ConversationBase[]> {
    return this.conversationService.searchConversations(apiConsumer, conversationSearchParams, participantId);
  }
}
