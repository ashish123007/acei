import { Controller, Headers, Param, Body, Post, UseGuards } from '@nestjs/common';
import { InsightService } from '../services/insight.service';
import { FeedbackService } from '../services/feedback.service';
import { JwtAuthGuard } from '../auth/jwtAuth.guard';
import { ApiConsumerDecorator, ApiConsumerWithToken } from '../utils/decorators/apiConsumer.decorator';
import { InsightFeedbackInput, InsightCreateInput, SummaryParamDto } from '../dto/insight.dto';
import { CreateInsightDocs, CreateInsightFeedbackDocs } from '../swagger';
import type {
  InsightCreateSearchInput,
  InsightCreateSummary,
  InsightReSummarizeInput,
  Insight,
} from '../dto/insight.dto';
import { BadRequestIagException } from '../errors/custom-errors';
import { logger } from '../utils/logger';
import { RouteContext } from '../utils/decorators/routeContext.decorator';

@Controller('insights')
export class InsightController {
  constructor(
    private readonly insightService: InsightService,
    private readonly feedbackService: FeedbackService
  ) {}

  @Post()
  @UseGuards(JwtAuthGuard)
  @RouteContext('create insight')
  @CreateInsightDocs()
  async createInsight(
    @Body() body: InsightCreateInput,
    @ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken,
    @Headers('PII-Participant-Id') participantId?: string
  ): Promise<Insight> {
    const { roleName, type, parameters } = body;
    switch (type) {
      case 'SUMMARIZE':
        return this.insightService.handleSummarize(
          parameters as InsightCreateSummary,
          apiConsumer,
          participantId,
          roleName
        );

      case 'KB_SEARCH':
        return this.insightService.handleKbSearch(
          parameters as InsightCreateSearchInput,
          apiConsumer,
          participantId,
          roleName
        );

      case 'RE_SUMMARIZE':
        return this.insightService.handleReSummarize(
          parameters as InsightReSummarizeInput,
          apiConsumer,
          participantId,
          roleName
        );

      default:
        logger.error(`Invalid insight type for participantId: ${participantId}`);
        throw new BadRequestIagException(
          'INSIGHT_TYPE_INVALID',
          'Valid Insight types: SUMMARIZE, KB_SEARCH, RE_SUMMARIZE'
        );
    }
  }

  @Post('/:insightId/feedback')
  @UseGuards(JwtAuthGuard)
  @RouteContext('add feedback')
  @CreateInsightFeedbackDocs()
  async createInsightFeedback(
    @Param() { insightId }: SummaryParamDto,
    @Body() body: InsightFeedbackInput,
    @ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken,
    @Headers('PII-Participant-Id') participantId: string
  ): Promise<void> {
    if (!participantId) {
      logger.error(`Failed to create insight feedback, participantId is missing. InsightId: ${insightId} `);
      throw new BadRequestIagException('PARTICIPANT_ID_MISSING');
    }

    const { message, score } = body;

    const sentiment = score > 0 ? 'positive' : 'negative';

    const insight = await this.insightService.getInsight(insightId, participantId);

    let { conversation_id } = insight;
    if (conversation_id === null) {
      conversation_id = 'noConversationId';
    }

    if (!insight.insightSummaryResults || !insight.insightSummaryResults.length) {
      logger.error(`INSIGHT_TYPE_VALID for insight with conversationId: ${conversation_id}`);
      throw new BadRequestIagException('INSIGHT_TYPE_INVALID', 'Feedback is only supported for summarize');
    }

    const { summary, transcript } = insight.insightSummaryResults[0];

    await this.feedbackService.postFeedback({
      apiConsumer,
      conversation_id,
      sentiment,
      summary,
      topic: 'summary',
      transcription: transcript,
      participantId,
      role: '',
    });

    await this.insightService.createInsightFeedback(apiConsumer, insightId, participantId, message, score);
    logger.info(`Feedback created for conversationId: ${conversation_id}, insightId: ${insightId}`);

    return;
  }
}
