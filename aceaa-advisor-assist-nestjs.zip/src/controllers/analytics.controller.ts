import { Controller, Post, Body, UseGuards } from '@nestjs/common';
import { AnalyticsService } from '../services/analytics.service';
import { ApiConsumerDecorator, ApiConsumerWithToken } from '../utils/decorators/apiConsumer.decorator';
import type { ObjectType } from '../types';
import { ApiExcludeEndpoint } from '@nestjs/swagger';
import { JwtAuthGuardNoDb } from '../auth/jwtAuthGuardNoDb.guard';
import { logger } from '../utils/logger';
import { RouteContext } from '../utils/decorators/routeContext.decorator';

interface TrackEventBody {
  eventName: string;
  conversationId: string | null;
  data: ObjectType;
}

@Controller('analytics')
export class AnalyticsController {
  constructor(private readonly analyticsService: AnalyticsService) {}

  @Post()
  @ApiExcludeEndpoint()
  @RouteContext('track event')
  @UseGuards(JwtAuthGuardNoDb)
  async trackEvent(@Body() body: TrackEventBody, @ApiConsumerDecorator() apiConsumer: ApiConsumerWithToken) {
    const { eventName, conversationId, data } = body;
    const userId = apiConsumer.id;

    await this.analyticsService.storeEvent(eventName, conversationId, userId, data);
    logger.info(`Event tracked for conversationId: ${conversationId}`);
    return { message: 'Event tracked successfully' };
  }
}
