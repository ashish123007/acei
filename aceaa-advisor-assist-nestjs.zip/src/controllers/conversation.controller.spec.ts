import { Test, TestingModule } from '@nestjs/testing';
import { ConversationController } from './conversation.controller';
import { InteractionService } from '../services/interaction.service';
import { TranscriptionService } from '../services/transcription.service';
import { ConversationService } from '../services/conversation.service';
import { mockBaseConversation, mockFullConversationResponse } from '../services/__mocks__/conversation.mock';
import {
  mockConversationInteractionInput,
  mockCreateInteractionResponse,
} from '../services/__mocks__/interaction.mock';
import { apiConsumerMock } from '../services/__mocks__/apiConsumer.mock';
import type { MockProxy } from 'jest-mock-extended';
import { mockCreateTranscriptionDto } from '../services/__mocks__/transcription.mock';
import { ValidationService } from '../services/validation.service';
import { NiceParametersDto } from '../dto/Nice.dto';
import { IVRParametersDto } from '../dto/IVR.dto';
import { BadRequestException } from '@nestjs/common';

describe('ConversationController', () => {
  let conversationController: MockProxy<ConversationController>;
  let interactionService: MockProxy<InteractionService>;
  let transcriptionService: MockProxy<TranscriptionService>;
  let conversationService: MockProxy<ConversationService>;
  let validationService: ValidationService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ConversationController],
      providers: [
        {
          provide: InteractionService,
          useValue: {
            findConversationId: jest.fn(),
            createInteraction: jest.fn(),
            updateContext: jest.fn(),
          },
        },
        {
          provide: TranscriptionService,
          useValue: {
            createTranscription: jest.fn(),
            getTranscriptions: jest.fn(),
          },
        },
        {
          provide: ConversationService,
          useValue: {
            searchConversations: jest.fn(),
            findConversation: jest.fn(),
            createConversation: jest.fn(),
            getConversationById: jest.fn(),
            deleteConversation: jest.fn(),
          },
        },
        {
          provide: ValidationService,
          useValue: {
            validateWithDatabaseTemplate: jest.fn(),
          },
        },
      ],
    }).compile();

    conversationController = module.get(ConversationController);
    interactionService = module.get(InteractionService);
    transcriptionService = module.get(TranscriptionService);
    conversationService = module.get(ConversationService);
    validationService = module.get<ValidationService>(ValidationService);
  });

  const interactionId = 'interaction-id';
  const conversationId = 'some-conversation-id';
  const participantId = 'advisor.2@nl.abnamro.com';

  describe('createConversation', () => {
    it('should create a new conversation successfully', async () => {
      const conversation = mockBaseConversation();
      conversationService.createConversation.mockResolvedValue(conversation);

      const result = await conversationController.createConversation(apiConsumerMock);
      expect(result).toEqual(conversation);
    });
  });
  describe('getConversationById', () => {
    it('should get conversation by id', async () => {
      const conversation = mockFullConversationResponse({
        conversationId,
      });
      conversationService.getConversationById.mockResolvedValue(conversation as never);
      const result = await conversationController.getConversationById({ conversationId }, apiConsumerMock);

      expect(result.conversationId).toEqual(conversationId);
      expect(result.interactions.length).toBe(1);
    });
  });

  describe('createInteraction', () => {
    const createInteractionDto = mockConversationInteractionInput({});
    const interactionResponse = mockCreateInteractionResponse({
      interactionId,
    });
    it('should find or create a conversation and then create an interaction', async () => {
      interactionService.findConversationId.mockResolvedValue(conversationId);
      interactionService.createInteraction.mockResolvedValue(interactionResponse as never);
      (validationService.validateWithDatabaseTemplate as jest.Mock).mockResolvedValue(true);

      const apiConsumerWithTemplate = { ...apiConsumerMock, template: 'api-consumer' };

      const result = await conversationController.createInteraction(
        { conversationId },
        createInteractionDto,
        apiConsumerWithTemplate
      );

      expect(validationService.validateWithDatabaseTemplate).toHaveBeenCalledWith(
        'api-consumer',
        createInteractionDto.context
      );
      expect(interactionService.findConversationId).toHaveBeenCalledWith(apiConsumerWithTemplate, conversationId);
      expect(interactionService.createInteraction).toHaveBeenCalledWith(
        apiConsumerWithTemplate,
        conversationId,
        createInteractionDto
      );
      expect(result).toEqual(
        expect.objectContaining({
          interactionId: interactionResponse.interactionId,
          context: interactionResponse.context,
        })
      );
    });
    it('should skip validation and create interaction when no template exists', async () => {
      interactionService.findConversationId.mockResolvedValue(conversationId);
      interactionService.createInteraction.mockResolvedValue(interactionResponse as never);

      const result = await conversationController.createInteraction({ conversationId }, createInteractionDto, {
        ...apiConsumerMock,
        template: null,
      });

      expect(validationService.validateWithDatabaseTemplate).not.toHaveBeenCalled();
      expect(interactionService.findConversationId).toHaveBeenCalledWith(
        expect.objectContaining({
          id: apiConsumerMock.id,
          tenant_id: apiConsumerMock.tenant_id,
        }),
        conversationId
      );
      expect(interactionService.createInteraction).toHaveBeenCalledWith(
        expect.objectContaining({
          id: apiConsumerMock.id,
          tenant_id: apiConsumerMock.tenant_id,
        }),
        conversationId,
        createInteractionDto
      );
      expect(result).toEqual(
        expect.objectContaining({
          interactionId: interactionResponse.interactionId,
          context: interactionResponse.context,
        })
      );
    });

    it('should throw BadRequestException when validation fails', async () => {
      interactionService.findConversationId.mockResolvedValue(conversationId);
      (validationService.validateWithDatabaseTemplate as jest.Mock).mockResolvedValue(false);

      await expect(
        conversationController.createInteraction({ conversationId }, createInteractionDto, {
          ...apiConsumerMock,
          template: 'api-consumer',
        })
      ).rejects.toThrow(BadRequestException);
    });
  });
  describe('createTranscript', () => {
    const body = [{ participantId: participantId, text: 'test', transcriptDateTime: '2025-04-01T12:07:45.976Z' }];

    it('should create a transcription', async () => {
      transcriptionService.createTranscription.mockResolvedValue('Transcriptions submitted successfully.' as never);
      await conversationController.createTranscript({ interactionId, conversationId }, body, apiConsumerMock);

      expect(transcriptionService.createTranscription).toHaveBeenCalledWith(
        expect.objectContaining({ apiConsumer: apiConsumerMock, interactionId, transcriptions: body })
      );
    });
  });
  describe('getTranscriptions', () => {
    it('should get transcriptions', async () => {
      const transcriptions = mockCreateTranscriptionDto();
      transcriptionService.getTranscriptions.mockResolvedValue(transcriptions as never);

      const result = await conversationController.getTranscripts({ interactionId, conversationId }, apiConsumerMock);

      expect(result).toBe(transcriptions);
    });
  });

  describe('Update conversation Context', () => {
    type InteractionContextDto = NiceParametersDto | IVRParametersDto;

    const payload: InteractionContextDto = {
      pre_intent: 'DFLT',
      phone_number: 1234567890,
      language_pref: 'en',
    };

    it('should update context successfully', async () => {
      apiConsumerMock.id = 'nice';
      apiConsumerMock.tenant_id = 'nice';
      jest.spyOn(validationService, 'validateWithDatabaseTemplate').mockResolvedValue(true);
      jest.spyOn(interactionService, 'updateContext').mockResolvedValue(payload);

      await expect(
        conversationController.updateInteractionContext(
          { interactionId: 'some-interaction-id', conversationId: 'some-conversation-id' },
          payload,
          apiConsumerMock
        )
      ).resolves.toEqual(payload);
    });
  });

  describe('searchConversations', () => {
    it('should find the conversation by conversationId', async () => {
      const conversations = mockFullConversationResponse({
        conversationId,
        interactionId,
      });

      conversationService.searchConversations.mockResolvedValue([conversations] as never);

      const result = await conversationController.searchConversations(apiConsumerMock, {}, participantId);

      expect(result[0]).toEqual(
        expect.objectContaining({
          conversationId: conversationId,
        })
      );
    });
  });

  describe('deleteConversation', () => {
    it('should delete a conversation', async () => {
      conversationService.deleteConversation.mockResolvedValueOnce({} as never);
      conversationController.deleteConversation({ conversationId }, apiConsumerMock);

      expect(conversationService.deleteConversation).toHaveBeenCalledWith(conversationId, apiConsumerMock);
    });
  });
});
