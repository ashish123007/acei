import { Controller, UseGuards, Post, Body, InternalServerErrorException } from '@nestjs/common';
import { generateActionId } from '../utils/generateActionId';
import { SpeechRecognitionResult } from 'microsoft-cognitiveservices-speech-sdk';
import { SpeechToTextService } from '../services/speech-to-text.service';
import type { CreateSpeechToTextResponseDto } from '../dto/transcription.dto';
import { CreateSpeechToTextDto } from '../dto/transcription.dto';
import { ApiExcludeEndpoint, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuardNoDb } from '../auth/jwtAuthGuardNoDb.guard';
import { logger } from '../utils/logger';

ApiTags('AdvisorAssist');
@Controller('transcription')
export class TranscriptionController {
  constructor(private speechToTextService: SpeechToTextService) {}

  @Post()
  @UseGuards(JwtAuthGuardNoDb)
  @ApiExcludeEndpoint()
  async transcribe(
    @Body()
    { message, language }: CreateSpeechToTextDto
  ): Promise<CreateSpeechToTextResponseDto> {
    const actionId = generateActionId('transcription');
    const transcriptionResult = await this.speechToTextService.transcribe(message, language);
    if (transcriptionResult instanceof SpeechRecognitionResult) {
      return {
        actionId,
        transcriptions: [
          {
            text: transcriptionResult.text ?? '',
            offset: 0,
            language: language,
          },
        ],
      };
    }
    logger.error(`Failed to transcribe speech to text for actionId: ${actionId}`);
    throw new InternalServerErrorException('Timeout while processing request');
  }
}
