import { Test, TestingModule } from '@nestjs/testing';
import { CallAutomationService } from '../services/callAutomation.service';
import { VoiceHubController } from './voicehub.controller';
import type { MockProxy } from 'jest-mock-extended';
import { logger } from '../utils/logger';
import { AcsEventType, MicrosoftAcsEventType } from '../dto/voicehub.dto';

describe('VoiceHubController', () => {
  let voiceHubController: VoiceHubController;
  let callAutomationService: MockProxy<CallAutomationService>;

  beforeEach(async () => {
    jest.clearAllMocks();

    const module: TestingModule = await Test.createTestingModule({
      controllers: [VoiceHubController],
      providers: [
        {
          provide: CallAutomationService,
          useValue: {
            answerCall: jest.fn(),
          },
        },
      ],
    }).compile();

    voiceHubController = module.get(VoiceHubController);
    callAutomationService = module.get(CallAutomationService);
  });

  describe('events', () => {
    it('should validate subscription event', async () => {
      const body = [
        {
          eventType: MicrosoftAcsEventType.SubscriptionValidationEvent,
          data: {
            validationCode: '200',
          },
        },
      ];
      const result = await voiceHubController.events(body as AcsEventType);

      expect(result?.validationResponse).toEqual(body[0].data.validationCode);
    });

    it('should answer incoming call event', async () => {
      callAutomationService.answerCall.mockResolvedValue({} as never);

      const body = [
        {
          eventType: MicrosoftAcsEventType.IncomingCall,
          data: {
            incomingCallContext: 'some-incoming-call',
          },
        },
      ];

      await expect(voiceHubController.events(body as AcsEventType)).resolves.toBeUndefined();
    });
  });

  describe('callbacks', () => {
    it('should log events', async () => {
      const result = await voiceHubController.callbacks({});
      expect(result.statusCode).toBe(200);
      expect(logger.verbose).toHaveBeenCalledTimes(2);
    });
  });
});
