import { Test, TestingModule } from '@nestjs/testing';
import { InsightService } from '../services/insight.service';
import { mockInsightResponse } from '../services/__mocks__/insight.mock';
import { mockFormatSummaryResponse } from '../services/__mocks__/summarization.mock';
import { InsightController } from './insight.controller';
import { BadRequestException } from '@nestjs/common';
import { FeedbackService } from '../services/feedback.service';
import { apiConsumerMock } from '../services/__mocks__/apiConsumer.mock';
import { mockCreateSearchResult } from '../services/__mocks__/search.mock';
import { InsightCreateInput } from '../dto/insight.dto';

describe('InsightController', () => {
  let insightController: InsightController;
  let insightService: InsightService;
  let feedbackService: FeedbackService;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [InsightController],
      providers: [
        {
          provide: InsightService,
          useValue: {
            handleSummarize: jest.fn(),
            handleKbSearch: jest.fn(),
            handleReSummarize: jest.fn(),
            getInsight: jest.fn(),
            createInsightFeedback: jest.fn(),
          },
        },
        {
          provide: FeedbackService,
          useValue: {
            postFeedback: jest.fn(),
          },
        },
      ],
    }).compile();

    insightController = module.get<InsightController>(InsightController);
    insightService = module.get<InsightService>(InsightService);
    feedbackService = module.get<FeedbackService>(FeedbackService);
  });

  const mockInsightId = '456';
  const insightResponseMock = mockInsightResponse({
    insight_id: mockInsightId,
  });

  describe('createInsight', () => {
    it('should handle handleSummarize', async () => {
      const formatSummaryResponseMock = mockFormatSummaryResponse({
        insightId: mockInsightId,
      });
      insightService.handleSummarize = jest.fn().mockResolvedValue(formatSummaryResponseMock);

      const result = await insightController.createInsight(
        {
          type: 'SUMMARIZE',
          parameters: {
            conversationId: 'some-conversation-id',
            includeAllInteractions: false,
          },
        },
        apiConsumerMock,
        '123'
      );
      expect(result).toBe(formatSummaryResponseMock);
    });
    it('should handle handleKbSearch', async () => {
      const formatSummaryResponseMock = mockCreateSearchResult({
        insightId: mockInsightId,
      });
      insightService.handleKbSearch = jest.fn().mockResolvedValue(formatSummaryResponseMock);

      const result = await insightController.createInsight(
        {
          type: 'KB_SEARCH',
          parameters: {
            message: 'some-message',
          },
        },
        apiConsumerMock,
        '123'
      );
      expect(result).toBe(formatSummaryResponseMock);
    });
    it('should handle RE_SUMMARIZE', async () => {
      const formatSummaryResponseMock = mockFormatSummaryResponse({
        insightId: mockInsightId,
      });
      insightService.handleReSummarize = jest.fn().mockResolvedValue(formatSummaryResponseMock);

      const result = await insightController.createInsight(
        {
          type: 'RE_SUMMARIZE',
          parameters: {
            insightId: 'some-insight-id',
            manual: {
              editedSummary: 'some-edited-summary',
            },
          },
        },
        apiConsumerMock,
        '123'
      );
      expect(result).toBe(formatSummaryResponseMock);
    });
    it('should throw an error if the type is invalid', () => {
      expect(
        insightController.createInsight(
          {
            type: 'invalidType',
          } as unknown as InsightCreateInput,
          apiConsumerMock
        )
      ).rejects.toThrow(BadRequestException);
    });
  });

  describe('createInsightFeedback', () => {
    it('should set sentiment to positive', async () => {
      const mockInsight = {
        ...insightResponseMock,
        conversation_id: 'some-conversation-id',
        insightSummaryResults: [{ summary: 'summary', transcript: 'transcript' }],
        type: 'Summary',
      };

      insightService.getInsight = jest.fn().mockResolvedValue(mockInsight);

      await insightController.createInsightFeedback(
        { insightId: 'someId' },
        { message: 'Test', score: 5 },
        apiConsumerMock,
        'participantId'
      );

      expect(feedbackService.postFeedback).toHaveBeenCalledWith(
        expect.objectContaining({
          apiConsumer: apiConsumerMock,
          conversation_id: 'some-conversation-id',
          sentiment: 'positive',
          participantId: 'participantId',
        })
      );
    });

    it('should set conversation_id to "noConversationId" if it is null or undefined', async () => {
      const mockInsightWithNullConversation = {
        ...insightResponseMock,
        conversation_id: null,
        insightSummaryResults: [{ summary: 'summary', transcript: 'transcript' }],
        type: 'Summary',
      };

      insightService.getInsight = jest.fn().mockResolvedValue(mockInsightWithNullConversation);

      await insightController.createInsightFeedback(
        { insightId: 'someId' },
        { message: 'Test', score: 5 },
        apiConsumerMock,
        'participantId'
      );

      expect(feedbackService.postFeedback).toHaveBeenCalledWith(
        expect.objectContaining({
          apiConsumer: apiConsumerMock,
          conversation_id: 'noConversationId',
          sentiment: 'positive',
          participantId: 'participantId',
        })
      );
    });

    it('should set sentiment to negative', async () => {
      const mockInsight = {
        ...insightResponseMock,
        conversation_id: 'some-conversation-id',
        insightSummaryResults: [{ summary: 'summary', transcript: 'transcript' }],
        type: 'Summary',
      };

      insightService.getInsight = jest.fn().mockResolvedValue(mockInsight);

      await insightController.createInsightFeedback(
        { insightId: 'someId' },
        { message: 'Test', score: 0 },
        apiConsumerMock,
        'participantId'
      );

      expect(feedbackService.postFeedback).toHaveBeenCalledWith(
        expect.objectContaining({
          apiConsumer: apiConsumerMock,
          conversation_id: 'some-conversation-id',
          sentiment: 'negative',
          participantId: 'participantId',
        })
      );
    });

    it('should throw error for non-summary insight ', async () => {
      const mockInsightWithUnknownType = {
        ...insightResponseMock,
        conversation_id: 'some-conversation-id',
        type: 'Summary',
      };

      insightService.getInsight = jest.fn().mockResolvedValue(mockInsightWithUnknownType);

      await expect(
        insightController.createInsightFeedback(
          { insightId: 'someId' },
          { message: 'Test', score: 5 },
          apiConsumerMock,
          'participantId'
        )
      ).rejects.toThrow(BadRequestException);
    });

    it('should throw BadRequestException if participantId is missing', async () => {
      await expect(
        insightController.createInsightFeedback(
          { insightId: 'someId' },
          { message: 'Test', score: 5 },
          apiConsumerMock,
          ''
        )
      ).rejects.toThrow(BadRequestException);
    });
  });
});
