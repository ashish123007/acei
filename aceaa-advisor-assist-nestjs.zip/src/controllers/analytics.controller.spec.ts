import { Test, TestingModule } from '@nestjs/testing';
import { AnalyticsController } from './analytics.controller';
import { AnalyticsService } from '../services/analytics.service';
import { apiConsumerMock } from '../services/__mocks__/apiConsumer.mock';

describe('AnalyticsController', () => {
  let analyticsController: AnalyticsController;
  let analyticsService: AnalyticsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AnalyticsController],
      providers: [
        {
          provide: AnalyticsService,
          useValue: {
            storeEvent: jest.fn(),
          },
        },
      ],
    }).compile();

    analyticsController = module.get<AnalyticsController>(AnalyticsController);
    analyticsService = module.get<AnalyticsService>(AnalyticsService);
  });

  const mockBody = {
    eventName: 'some-event-name',
    conversationId: 'some-conversation-id',
    data: { key: 'value' },
  };
  it('should track an event successfully', async () => {
    await expect(analyticsController.trackEvent(mockBody, apiConsumerMock)).resolves.toEqual({
      message: 'Event tracked successfully',
    });

    expect(analyticsService.storeEvent).toHaveBeenCalledWith(
      mockBody.eventName,
      mockBody.conversationId,
      apiConsumerMock.id,
      mockBody.data
    );
  });
});
