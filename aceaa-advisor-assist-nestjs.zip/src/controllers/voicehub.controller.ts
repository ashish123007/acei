import { Body, Controller, Post, Headers, UseGuards } from '@nestjs/common';
import { ObjectType } from '../types';
import { logger } from '../utils/logger';

import { CallAutomationService } from '../services/callAutomation.service';
import { ApiExcludeEndpoint } from '@nestjs/swagger';
import { AcsEvenDto, MicrosoftAcsEventType } from '../dto/voicehub.dto';
import { RouteContext } from '../utils/decorators/routeContext.decorator';
import { AzureJwtAuthGuard } from '../auth/azureJwtAuth.guard';

const AA_VOICE_PREFIX = 'aa/voice-hub/';

@Controller(AA_VOICE_PREFIX)
@UseGuards(AzureJwtAuthGuard)
export class VoiceHubController {
  constructor(private readonly callAutomationService: CallAutomationService) {}

  @Post('events')
  @RouteContext('listen to events')
  @ApiExcludeEndpoint()
  async events(@Body() body: AcsEvenDto, @Headers() headers?: ObjectType) {
    logger.verbose(`[ACS] Received acs events %j`, body);
    logger.verbose(`[ACS], Received acs events header %j`, headers);

    for (const event of body) {
      if (event?.data && event?.eventType == MicrosoftAcsEventType.SubscriptionValidationEvent) {
        const code = event.data.validationCode;
        return {
          validationResponse: code,
        };
      } else if (event?.data && event?.eventType == MicrosoftAcsEventType.IncomingCall) {
        await this.callAutomationService.answerCall(AA_VOICE_PREFIX, event.data.incomingCallContext);
      }
    }
  }

  // eslint-disable-next-line @typescript-eslint/require-await
  @Post('callbacks')
  @ApiExcludeEndpoint()
  async callbacks(@Body() body: ObjectType, @Headers() headers?: ObjectType) {
    logger.verbose(`[ACS], Received acs callbacks headers %j`, headers);
    logger.verbose(`[ACS], Received acs callbacks body %j`, body);
    return {
      statusCode: 200,
    };
  }
}
