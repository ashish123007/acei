import { Test, TestingModule } from '@nestjs/testing';
import { TranscriptionController } from './transcription.controller';
import { SpeechToTextService } from '../services/speech-to-text.service';
import { SpeechRecognitionResult } from 'microsoft-cognitiveservices-speech-sdk';
import { HttpException, HttpStatus } from '@nestjs/common';

jest.mock('../utils/generateActionId', () => ({ generateActionId: jest.fn().mockReturnValue('actionId') }));

describe('Transcription Controller tests', () => {
  let transcriptionController: TranscriptionController;
  const SAMPLE_TEXT = 'sampleText';
  const speechRecognitionResult = new SpeechRecognitionResult(undefined, undefined, SAMPLE_TEXT);

  let transcribeMock = jest.fn().mockResolvedValue(speechRecognitionResult as SpeechRecognitionResult);
  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      controllers: [TranscriptionController],
      providers: [{ provide: SpeechToTextService, useValue: { transcribe: transcribeMock } }],
    }).compile();

    transcriptionController = app.get<TranscriptionController>(TranscriptionController);
  });

  describe('Transcription tests', () => {
    it('should transcribe base64 string', async () => {
      const transcription = await transcriptionController.transcribe({
        language: 'en-us',
        message: 'BASE64STRING',
      });
      expect(transcription.actionId).toEqual('actionId');
      expect(transcription.transcriptions.length).toEqual(1);
      expect(transcription.transcriptions[0].language).toEqual('en-us');
      expect(transcription.transcriptions[0].offset).toEqual(0);
      expect(transcription.transcriptions[0].text).toEqual(SAMPLE_TEXT);
    });
  });

  it('should throw HttpException if transcription fails', async () => {
    transcribeMock = jest.fn().mockResolvedValue(null);
    const app: TestingModule = await Test.createTestingModule({
      controllers: [TranscriptionController],
      providers: [{ provide: SpeechToTextService, useValue: { transcribe: transcribeMock } }],
    }).compile();

    transcriptionController = app.get<TranscriptionController>(TranscriptionController);

    await expect(
      transcriptionController.transcribe({
        language: 'en-us',
        message: 'BASE64STRING',
      })
    ).rejects.toThrow(new HttpException('Timeout while processing request', HttpStatus.INTERNAL_SERVER_ERROR));
  });
});
