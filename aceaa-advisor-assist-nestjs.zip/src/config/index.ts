export default {
  PORT: process.env.PORT || 3000,
  TEST: process.env.TEST === 'true',
  LOG_LEVEL: process.env.LOG_LEVEL || 'info',
  ENVIRONMENT: process.env.ENVIRONMENT || 'local',
};
