import type { OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaClient } from '../prisma-generated-client';
import { logger } from './utils/logger';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  constructor(private configService: ConfigService) {
    super();
  }

  async onModuleInit() {
    if (this.configService.get('DATABASE_URL')) {
      await this.$connect();
    } else {
      logger.warn('No database url found, AA endpoint will fails');
    }
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }
}
