export type RequestBodyType =
  | EditedSummarisationBody
  | GenderedInputBody
  | KBInputBody
  | ShortenInputBody
  | SummaryInputBody
  | TranscriptionInputBody
  | FeedbackInputBody
  | ChatCompletionRequest
  | NPSInputBody
  | NPSScoresInputBody
  | WriteGroundTruthRequest
  | ReadAudioRequest
  | LanguageDetectionInputBody;

export interface EditedSummarisationBody {
  user_id: string;
  conversation_id: string;
  message: string;
  original_summary: string;
  transcription: string;
}

export enum FeedbackTopicChoices {
  SUMMARY = 'summary',
  KB_RESULT = 'kb_result',
  KB_MISSING = 'kb_missing',
}

export enum FeedbackSentimentChoices {
  POSITIVE = 'positive',
  NEGATIVE = 'negative',
}

export enum TranscriptionLanguageChoice {
  DUTCH = 'nl-NL',
  ENGLISH = 'en-US',
}

export enum TopicDomain {
  DFC = 'DFC',
  SIM = 'SIM',
  BANK_POLICY = 'Policy Framework',
}
export interface GenderedInputBody {
  user_id: string;
  conversation_id: string;
  message: string;
  original_summary: string;
  transcription: string;
}

export interface ShortenInputBody {
  user_id: string;
  conversation_id: string;
  message: string;
  original_summary: string;
  transcription: string;
}

export interface KBFeedbackField {
  query: string; // Field(min_length=3)
  position: number;
  url: string; // Field(min_length=50)
}

export interface FeedbackInputBody {
  user_id: string;
  conversation_id: string;
  topic: FeedbackTopicChoices;
  sentiment?: FeedbackSentimentChoices;
  message?: string; // Field(None, max_length=2000)
  extra?: KBFeedbackField;
  summary: string;
  transcription: string;
}

export interface NPSInputBody {
  user_id: string;
  nps_score: number;
  message: string[]; // Field(None, max_length=2000)
}

export interface NPSScoresInputBody {
  user_id: string;
}

export interface KBInputBody {
  user_id: string;
  conversation_id: string;
  message: string; // Field(..., min_length=1)
  selected_document: string[];
  only_business_client?: boolean[];
  topic_domains?: TopicDomain[];
}

export interface TranscriptionInputBody {
  user_id: string;
  conversation_id: string;
  chunk_id: string;
  message: string;
  language: TranscriptionLanguageChoice | TranscriptionLanguageChoice[]; // TranscriptionLanguageChoice.DUTCH
}

export interface LanguageDetectionInputBody {
  user_id: string;
  conversation_id: string;
  message: string; // Field(..., min_length=1)
}

export enum DFCTopic {
  GENERAL_INFORMATION = 'General Information',
  BUSINESS_ACTIVITY = 'Business Activity',
  PAYMENT_TRANSACTION = 'Payment Transaction',
  NEGATIVE_PUBLICITY = 'Negative Publicity',
  SUSTAINABILITY_RISK = 'Sustainability Risk',
  SANCTIONS = 'Sanctions',
}

export interface SummaryInputBody {
  user_id: string;
  conversation_id: string;
  message: string;
  topics?: DFCTopic[];
  custom_questions?: string;
}

export interface WriteGroundTruthRequest {
  user_id: string;
  audio_filename: string;
  ground_truth: string;
}

export interface ReadAudioRequest {
  user_id: string;
  audio_filename?: string;
}

export interface ChatCompletionRequest {
  user_id: string;
  messages: OpenAIMessage[];
}

export interface OpenAIMessage {
  role: 'system' | 'assistant' | 'user';
  content: string;
}
