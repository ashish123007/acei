import { ApiProperty } from '@nestjs/swagger';

export class CreateSpeechToTextDto {
  @ApiProperty({
    example: 'audio message',
    description: 'Audio message of the transcription',
  })
  message: string;

  @ApiProperty({
    example: 'nl-NL',
    description: 'Language of the transcription',
  })
  language: string;
}

export class CreateSpeechToTextResponseDto {
  @ApiProperty({ example: 'transcript-001', description: 'Id of the transcriptions' })
  actionId: string;

  @ApiProperty({
    example: [
      {
        text: 'some-text',
        offset: 0,
        language: 'nl-NL',
      },
    ],
    description: 'Details of the newly created transcriptions',
    minItems: 0,
    maxItems: 20,
  })
  transcriptions: CreateSpeechToTextTranscriptResponseDto[];
}

export class CreateSpeechToTextTranscriptResponseDto {
  @ApiProperty({ example: 'some-text' })
  text: string;

  @ApiProperty({ example: 0 })
  offset: number;

  @ApiProperty({ example: 'nl-NL' })
  language: string;
}
