import { ApiExtraModels, ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { getSchemaPath } from '@nestjs/swagger';
import { InsightType } from '../../prisma-generated-client';

export type EditSummaryAction = 'shorten' | 'female' | 'male';

export class SummaryParamDto {
  @ApiProperty({ example: 'some-insight-id', description: 'ID of an Insight' })
  insightId: string;
}

export class GenericSummaryResponseDto extends SummaryParamDto {
  @ApiProperty({
    description: 'type of insight',
    example: 'Summary',
  })
  type: string;
  @ApiProperty({
    description: 'result from the summerizer',
    example: {
      content: '...',
      openaiVersion: 'OPENAI_BASE_GPT4O',
    },
  })
  data: {
    content: string;
    openaiVersion: string;
  };
  @ApiProperty({
    example: '2025-01-14T10:34:00.283Z',
    description: 'Summary creation date',
    type: 'string',
    format: 'date-time',
  })
  summaryDateTime: string;
}

export class InsightFeedbackInput {
  @ApiProperty({ example: 'some-message', description: 'optional message' })
  message: string;

  @ApiProperty({
    example: 1,
    description: 'Feedback score. (0 -5)',
    minimum: 0,
    maximum: 5,
    format: 'float',
  })
  score: number;
}

export class InsightCreateSummary {
  @ApiProperty({
    example: '49b24451-74d7-49ed-9120-4a263a06d2ba',
    description: 'ID of the conversation',
  })
  conversationId: string;

  @ApiPropertyOptional({
    example: true,
    description:
      'A boolean indicating whether to return the full conversation or exclude details after the participant left. Defaults to false if not provided.',
  })
  includeAllInteractions?: boolean;
}

export class InsightReSummarizeManual {
  @ApiProperty({
    description: 'text of the edited summary',
    example: 'edited summary',
  })
  editedSummary: string;
}

export class InsightReSummarizeLlm {
  @ApiProperty({
    description: 'type of re-summary requested by the user',
    example: 'shorten',
    enum: ['SHORTEN', 'FEMALE', 'MALE'],
  })
  action: EditSummaryAction;
}

export class InsightReSummarizeInput extends SummaryParamDto {
  @ApiPropertyOptional({
    description: 'text of the edited summary',
  })
  manual?: InsightReSummarizeManual;

  @ApiPropertyOptional({
    description: 'type of action for the re-summerizer',
  })
  llm?: InsightReSummarizeLlm;
}

export class InsightCreateSearchInput {
  @ApiPropertyOptional({
    example: '49b24451-74d7-49ed-9120-4a263a06d2ba',
    description: 'ID of the conversation',
  })
  conversationId?: string;

  @ApiProperty({ example: 'some-message', description: 'optional message' })
  message: string;
}
@ApiExtraModels(InsightCreateSummary, InsightReSummarizeInput, InsightCreateSearchInput)
export class InsightCreateInput {
  @ApiProperty({
    description: 'the type of insight to be created',
    enum: ['SUMMARIZE', 'KB_SEARCH', 'RE_SUMMARIZE'],
  })
  type: 'SUMMARIZE' | 'KB_SEARCH' | 'RE_SUMMARIZE';

  @ApiPropertyOptional({
    description: 'optional role name used for the insight, roles are used to get more specific insight.',
    example: 'NabestaandenDesk',
  })
  roleName?: string;

  @ApiProperty({
    anyOf: [
      {
        $ref: getSchemaPath(InsightCreateSummary),
      },
      {
        $ref: getSchemaPath(InsightReSummarizeInput),
      },
      {
        $ref: getSchemaPath(InsightCreateSearchInput),
      },
    ],
  })
  parameters: InsightCreateSummary | InsightReSummarizeInput | InsightCreateSearchInput;
}

export class InsightSearchData {
  @ApiProperty({
    example: 'search input',
    description: 'knowledge search input',
    required: true,
  })
  input: string;

  @ApiProperty({
    example: 'search result',
    description: 'search result',
    required: false,
  })
  content?: string;
}

export class InsightSummaryData {
  @ApiProperty({
    example: 'conversation about mortgage',
    description: 'summary of the conversation',
    required: true,
  })
  content: string;

  @ApiProperty({
    example: 'OPENAI_BASE_GPT4O',
    description: 'llm version used with summary',
    required: true,
  })
  llmVersion: string;
}

export class InsightDocument {
  @ApiProperty({
    example:
      'https://abnamro.sharepoint.com/sites/informatiebank-verzekerenschade/SitePages/Producten/NN-Inboedel-Maatwerk.aspx',
    description: 'url of the document',
    required: true,
  })
  url: string;

  @ApiProperty({
    example: 'NN Inboedel Maatwerk',
    description: 'title of the document',
    required: true,
  })
  title: string;

  @ApiProperty({
    example: 'detailed information about Inboedel Maatwerk',
    description: 'content of the document',
    required: true,
  })
  content: string;
}

export class Insight {
  @ApiProperty({
    example: 'insight-001',
    description: 'ID of an insight',
    required: true,
  })
  insightId: string;

  @ApiProperty({
    example: 'KnowledgeSearch',
    description: 'Type of insight',
    enum: ['SUMMARY', 'KNOWLEDGE_SEARCH'],
    required: true,
  })
  type: InsightType;

  @ApiProperty({
    example: '2025-01-14T10:34:00.283Z',
    description: 'Insight creation date',
    type: 'string',
    format: 'date-time',
  })
  insightDateTime: string;

  @ApiProperty({
    example: {
      search: {
        value: {
          input: 'nieuwe hypotheek',
          content: 'Document related to hypotheek found',
        },
      },
      summary: {
        content: 'summary of the conversation',
        llmVersion: 'OPENAI_BASE_GPT4O',
      },
    },
    description: 'Search input and content',
    oneOf: [
      {
        $ref: getSchemaPath(InsightSearchData),
      },
      {
        $ref: getSchemaPath(InsightSummaryData),
      },
    ],
  })
  data: InsightSearchData | InsightSummaryData;

  @ApiProperty({
    minItems: 0,
    maxItems: 20,
    description: 'Documents found',
    required: false,
    type: [InsightDocument],
  })
  documents?: InsightDocument[];
}

export class InsightCreateResponse {}
