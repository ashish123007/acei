import { ApiProperty, ApiPropertyOptional, ApiSchema } from '@nestjs/swagger';
import { ParticipantType, Prisma } from '../../prisma-generated-client'; // Assuming this is an enum

@ApiSchema({ description: 'A key / value pair, holding context of the interaction' })
export class InteractionContext {}
// Participant DTO
export class InteractionParticipant {
  @ApiProperty({
    example: 'advisor.2@nl.abnamro.com',
    description: 'ID of the participant',
  })
  id: string;

  @ApiProperty({
    example: ParticipantType.advisor,
    description: 'Type of the participant',
  })
  type: ParticipantType;
}

// Transcript DTO
export class InteractionTranscript {
  @ApiProperty({
    example: 'advisor.1@nl.abnamro.com',
    description: 'ID of the participant',
  })
  participantId: string;

  @ApiProperty({
    example: 'Ik wil een nieuwe hypotheek.',
    description: 'Text of the transcription',
  })
  text: string;

  @ApiProperty({
    example: '2025-01-14T10:34:00.283Z',
    description: 'Date of the transcription',
    type: 'string',
    format: 'date-time',
  })
  transcriptDateTime: string;
}

// Interaction DTO
export class ConversationInteractionInput {
  @ApiProperty({
    description: 'Name of the interaction',
    example: 'NICE',
  })
  name: string;

  @ApiPropertyOptional({
    description: 'Reference created by a third party',
    example: 'some-reference',
  })
  reference?: string;

  @ApiPropertyOptional({
    example: { pronoun: 'hij', topic: 'HYPL', language: 'EN' },
    description: 'Context of the interaction',
    type: InteractionContext,
  })
  context?: Prisma.JsonValue;

  @ApiPropertyOptional({
    type: [InteractionParticipant],
    description: 'List of participants in the interaction',
    minItems: 0,
    maxItems: 10,
  })
  participants?: InteractionParticipant[];

  @ApiPropertyOptional({
    type: [InteractionTranscript],
    description: 'List of transcripts in the interaction',
    minItems: 0,
    maxItems: 10000,
  })
  transcriptions?: InteractionTranscript[];
}

// Conversation DTO
export class CreateConversationDto {
  @ApiProperty({
    type: [ConversationInteractionInput],
    description: 'List of interactions in the conversation',
    minItems: 0,
    maxItems: 100,
  })
  interactions: ConversationInteractionInput[];
}

// Query DTO for searching conversations
export class ConversationSearchQueryDto {
  @ApiPropertyOptional({
    example: 'some-reference',
    description: 'Reference created by a third party',
  })
  conversationReference?: string;

  @ApiPropertyOptional({
    example: true,
    description: 'Retrieve the latest conversation for the participant',
  })
  latestFromParticipant?: boolean;
}

export class ConversationIdDto {
  @ApiProperty({
    example: '49b24451-74d7-49ed-9120-4a263a06d2ba',
    description: 'ID of the conversation',
  })
  conversationId: string;
}

export class ConversationParamDto {
  @ApiProperty({
    example: '49b24451-74d7-49ed-9120-4a263a06d2ba',
    description: 'ID of the conversation',
  })
  conversationId: string;

  @ApiProperty({ example: 'b284a9e9-9664-451f-827d-b19ba0a43488', description: 'ID of the interaction' })
  interactionId: string;
}

export class CreateSummarizeDto {
  @ApiProperty({
    description: 'A full conversation object',
    required: false,
    example: {
      interactions: [
        {
          conversationReference: 'some-reference',
          summerizerParameters: { pronoun: 'hij', topic: 'HYPL' },
          participants: [{ id: 'advisor.2@nl.abnamro.com', type: ParticipantType.advisor }],
          transcriptions: [
            {
              participantId: 'advisor.1@nl.abnamro.com',
              text: 'Ik wil een nieuwe hypotheek.',
              timestamp: 1736850840283,
            },
          ],
          name: 'NICE',
        },
      ],
    },
  })
  conversation?: CreateConversationDto;

  @ApiProperty({
    example: true,
    description:
      'A boolean indicating whether to return the full conversation or exclude details after the participant left. Defaults to false if not provided.',
  })
  complete: boolean;
}

export class ConversationInteraction extends ConversationInteractionInput {
  @ApiProperty({
    example: '39975bb8-1787-4c72-a2a5-054293a50fa0',
    description: 'ID of the interaction',
  })
  interactionId: string;

  @ApiProperty({
    example: '2025-01-14T10:34:00.283Z',
    description: 'Interaction creation date',
    type: 'string',
    format: 'date-time',
  })
  createdDateTime: string;

  @ApiProperty({
    example: 'aab-sys-021582',
    description: 'Information about the consumer that created the conversation',
  })
  createdBy: string;
}

export class ConversationBase {
  @ApiProperty({
    example: '49b24451-74d7-49ed-9120-4a263a06d2ba',
    description: 'ID of the conversation',
  })
  conversationId: string;

  @ApiProperty({
    example: '2025-01-14T10:34:00.283Z',
    description: 'Conversation creation date',
    type: 'string',
    format: 'date-time',
  })
  conversationDateTime: string;

  @ApiProperty({
    example: 'aab-sys-021582',
    description: 'Information about the consumer that created the conversation',
  })
  createdBy: string;
}

export class Conversation extends ConversationBase {
  @ApiPropertyOptional({
    description: 'List of interactions',
    minItems: 0,
    maxItems: 100,
    type: [ConversationInteraction],
  })
  interactions: ConversationInteraction[];
}

export class ConversationSearchParams {
  @ApiPropertyOptional({
    example: 'some-interaction-reference',
    description: 'Ref of conversation',
  })
  interactionReference?: string;
}
