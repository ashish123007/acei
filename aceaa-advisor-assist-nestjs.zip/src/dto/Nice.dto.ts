// @see https://confluence.int.abnamro.com/pages/viewpage.action?spaceKey=CIEDC&title=Onsignal
export type NiceParametersDto = {
  pre_intent: 'DFLT' | 'HYPL' | 'BBCB';
  phone_number: number;
  language_pref: string;
};
