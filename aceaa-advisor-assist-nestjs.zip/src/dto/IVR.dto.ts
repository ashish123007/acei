// @see https://confluence.int.abnamro.com/pages/viewpage.action?spaceKey=CIEDC&title=Onsignal
export type IVRParametersDto = {
  account_number: number;
  customer_name: string;
  BC_number: number;
  language_pref: string;
  party_type: 'Individual' | 'Organization';
  bo_number: number;
  cgc_code: number;
  is_cj_customer: boolean;
  ANI_recognition_status:
    | 'RecogANI_Success'
    | 'RecogANI_Success_MultiBC'
    | 'RecogANI_Success_NoMatch'
    | 'RecogANI_Failed_TechnicalError'
    | 'RecogANI_Failed_Unknown';
  account_recognition_status:
    | 'RecogAcc_Success'
    | 'RecogAcc_OptOut'
    | 'RecogAcc_Failed_NoAccountFound'
    | 'RecogAcc_Failed_Timeout'
    | 'RecogAcc_Failed_NoBCFound'
    | 'RecogAcc_Failed_TechnicalError'
    | 'RecogAcc_Failed_NoRecordsForBC'
    | 'RecogAcc_Failed_WrongInput';
  authentication_status:
    | 'CardNotValid'
    | 'CardNotAvailable'
    | 'RecognitionFailed'
    | 'MBSuccess'
    | 'MBTimeout'
    | 'MBFailed'
    | 'MBTechError';
  authentication_failure_reason: string;
  endpoint_code: string;
  intent: string;
  intent_summary: string;
};
