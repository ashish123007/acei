import { z } from '@nest-zod/z';
import { createZodDto } from 'nestjs-zod';

export enum MicrosoftAcsEventType {
  SubscriptionValidationEvent = 'Microsoft.EventGrid.SubscriptionValidationEvent',
  IncomingCall = 'Microsoft.Communication.IncomingCall',
}

// @see https://learn.microsoft.com/en-us/javascript/api/azure-communication-services/@azure/communication-calling/incomingcall?view=azure-communication-services-js
export const AcsIncomingCallEvent = z.object({
  eventType: z.literal(MicrosoftAcsEventType.IncomingCall),
  id: z.string(),
  data: z.object({
    incomingCallContext: z.string(),
    serverCallId: z.string(),
    customContext: z
      .object({
        sipHeaders: z.any().optional(),
      })
      .optional(),
    from: z.any(),
  }),
});

// @see https://learn.microsoft.com/en-us/javascript/api/@azure/eventgrid/subscriptionvalidationeventdata?view=azure-node-latest
const AcsValidationEvent = z.object({
  eventType: z.literal(MicrosoftAcsEventType.SubscriptionValidationEvent),
  data: z.object({
    validationCode: z.string(),
    validationUrl: z.string().optional(),
  }),
});

export const AcsEventType = z.array(z.union([AcsValidationEvent, AcsIncomingCallEvent]));

export type AcsEventType = z.infer<typeof AcsEventType>;

export class AcsEvenDto extends createZodDto(AcsEventType) {}
