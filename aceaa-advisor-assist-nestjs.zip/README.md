## Running the app

One time action to download the TIA certificate locally

```bash
  security find-certificate -c "TIA ROOT CA 2022" -p > ./abn_tia_cert.pem
```

Run the application

```bash
  docker compose up
```

Generate Prisma client. This also generate a [DBML](https://dbml.dbdiagram.io/home/) file

```bash
  npx prisma generate
```

Run Database migrations

```bash
  npx prisma migrate dev --name <file-name>
```

Run Unit tests

```bash
  npm t
```

Run linting

```bash
  npm run prettier:fix
```

Generate API Docs. You can find the generated Swagger Docs [here](generated-docs/swagger.json)

```bash
  npm run generate:docs
```

Generate ERD Diagram. You can find the generated ERD [here](generated-docs/erd.png)

```bash
  npm run generate:erd
```

### Before creating a PR

- Run `npm run prettier:fix` to fix linting issues

- Run `npm run generate:docs` if you add a new API, modify request or response object

- Run `npx prisma generate` && `npm run generate:erd` if you updated the DB schema

## Docs

### API Docs: [Swagger Docs](generated-docs/swagger.yaml)

### Entity Relationship Diagram

![Image](generated-docs/erd.jpg)

### Run Prisma Studio on DTAP

- Switch the context to the correct K8s context
- Run `kubectl get pods` to get all the pods
- Run `kubectl port-forward pod/<prisma-studio-pod>  --address localhost 1024:5555` to forward a port from a Kubernetes Pod to your local machine
- Go to http://127.0.0.1:1024/ in your browser to access the UI
