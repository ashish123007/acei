import type { Config } from 'jest';

const config: Config = {
  moduleFileExtensions: ['js', 'json', 'ts'],
  rootDir: 'src',
  testMatch: ['**/*.spec.ts'],
  setupFiles: ['../jest.setup.js'],
  transform: {
    '^.+\\.(t|j)s$': 'ts-jest',
  },
  testResultsProcessor: 'jest-sonar-reporter',
  collectCoverage: true,
  collectCoverageFrom: [
    '**/*.(t|j)s',
    '!**/*.module.ts',
    '!main.ts',
    '!*/jwt.strategy.ts',
    '!**/types/*',
    '!/src/services/__mocks__/*',
    '!/src/errors/custom-errors.ts',
    '!src/swagger/*',
    '!src/prisma.service.ts',
    '!src/scripts/*',
  ],
  coverageDirectory: '../coverage',
  coverageReporters: ['lcov', 'text', 'json'],
  testEnvironment: 'node',
};

export default config;
