module.exports = {
  parser: '@typescript-eslint/parser',
  parserOptions: {
    project: './tsconfig.json',
  },
  plugins: ['@typescript-eslint', "import"],
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:@typescript-eslint/eslint-recommended',
    'plugin:@typescript-eslint/recommended-requiring-type-checking',
    'prettier',
    'plugin:prettier/recommended',
    'plugin:import/typescript'
  ],
  root: true,
  env: {
    node: true,
    jest: true,
    es2022: true
  },
  ignorePatterns: ['.eslintrc.js'],
  "settings": {
    "import/resolver": {
      "typescript": true,
      "node": {
        "extensions": [".js", ".ts"]
      }
    }
  },
  rules: {
    '@typescript-eslint/interface-name-prefix': 'off',
    '@typescript-eslint/explicit-function-return-type': 'off',
    '@typescript-eslint/explicit-module-boundary-types': 'off',
    '@typescript-eslint/no-explicit-any': 'off',
    "@typescript-eslint/no-misused-promises": [
      "error",
      {
        "checksVoidReturn": false
      }
    ],
    "no-constant-condition": ["error", { "checkLoops": false }],
    "no-multiple-empty-lines": ["error", { "max": 2 }],
    "brace-style": ["error"],
    "no-trailing-spaces": ["error"],
    "prettier/prettier": ["error", { "semi": true }],
    "no-console": ["error", { allow: ["error"] }],
    '@typescript-eslint/consistent-type-imports': [
      "error",
      {prefer: "type-imports"}
    ],
    
    '@typescript-eslint/no-unused-vars': [
      "error",
      {ignoreRestSiblings: true}
    ],

  },
};
