$dataFilePath = $env:DATA_FILE_PATH
if (Test-Path $dataFilePath) {
    $testData = Get-Content -Path $dataFilePath | ConvertFrom-Json
    $rgName = $($testData.resourceGroupName)
    $aksData = $($testData.aks)
    $keyVaultData = $($testData.keyVault)
    $BackupVaultData = $($testData.BackupVault)
    $LogWorkspaceData = $($testData.LogWorkspace)
    $StorageAccountData = $($testData.StorageAccount)
}
else {
    throw "Data file not found: $dataFilePath"
}
# Load the data file
BeforeAll {
    $dataFilePath = $env:DATA_FILE_PATH
    Write-Host "DataFilePath : $dataFilePath"
    if (Test-Path $dataFilePath) {
        $testData = Get-Content -Path $dataFilePath | ConvertFrom-Json
        $rgName = $($testData.resourceGroupName)
        Write-Host "RG Name : $rgName"
        $aksData = $($testData.aks)
        $keyVaultData = $($testData.keyVault)
        $BackupVaultData = $($testData.BackupVault)
        $LogWorkspaceData = $($testData.LogWorkspace)
        $StorageAccountData = $($testData.StorageAccount)
    }
    else {
        throw "Data file not found: $dataFilePath"
    }
}