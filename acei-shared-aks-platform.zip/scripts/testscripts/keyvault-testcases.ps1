#Load AKS Test Data
. ./scripts/testcrpits/load-testdata.ps1

Describe "keyVault.TestCase" -ForEach $keyVaultData {
    $data = $_
    #To Display in the testcase title this variable is needed
    $tdKeyVaultName = $data.name
    BeforeAll {
        $data = $_
        $tdKeyVaultName = $data.name
        $tdKeyVaultSKU = $data.sku
        $tdPublicAccess = $data.publicNetworkAccess
            
        # Fetch Backup Vault informations
        $response = (az keyvault show -g $rgName -n $tdKeyVaultName -o json)
        $responseJson = $response | ConvertFrom-Json
    }
    
    It "[$tdKeyVaultName]_exists_check" {
        $responseJson | Should -Not -BeNullOrEmpty
    }

    It "[$tdKeyVaultName]_ple_enable_check" {
        $responseJson.properties.privateEndpointConnections | Should -Not -BeNullOrEmpty
    }

    It "[$tdKeyVaultName]_sku_check" {
        $responseJson.properties.sku.name | Should -Be $tdKeyVaultSKU
    }

    It "[$tdKeyVaultName]_public_access_disable_check" -ForEach $keyVaultData {
        $responseJson.properties.publicNetworkAccess | Should -Be $tdPublicAccess
    }
}