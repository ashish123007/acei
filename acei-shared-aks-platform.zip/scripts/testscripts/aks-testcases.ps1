#Load AKS Test Data
. ./scripts/testcrpits/load-testdata.ps1

Describe "AKSCluster.TestCase" -ForEach $aksData {
    $data = $_
    #To Display in the testcase title this variable is needed
    $tdClusterName = $data.name

    BeforeAll {
        $data = $_
        $tdClusterName = $data.name
        $tdClusterVersion = $data.version
        $tdClusterRBAC = $data.enabledRBAC
        $tdPrivateCluster = $data.enablePrivateCluster
        $tdWorkloadIdentityEnable = $data.securityProfile.workloadIdentity
        $tdImageCleanerEnable = $data.securityProfile.imageCleaner
        $tdNetworkMode = $data.networkProfile.networkPluginMode
        $tdNetworkPolicy = $data.networkProfile.networkPolicy
        $tdAZPolicyEnabled = $data.addonProfiles.azurePolicy
        $tdSecretsProviderEnabled = $data.addonProfiles.azureKeyvaultSecretsProvider
        $tdOMSAgentEnabled = $data.addonProfiles.omsagent
        $tdNodepoolCount = $data.nodepoolcount

        # Fetch Cluster informations
        $response = (az aks show -n $tdClusterName -g $rgName  -o json --only-show-errors)
        $responseJson = $response | ConvertFrom-Json
    }
        

    It "[$tdClusterName]_exists_check" {
        $responseJson | Should -Not -BeNullOrEmpty
    }

    It "[$tdClusterName]_version_check" {
        $responseJson.currentKubernetesVersion | Should -Be $tdClusterVersion
    }

    It "[$tdClusterName]_rbac_enable_check" {
        [bool]::Parse($responseJson.enableRbac) | Should -Be $tdClusterRBAC
    }

    It "[$tdClusterName]_private_cluster_check" {
        [bool]::Parse($responseJson.apiServerAccessProfile.enablePrivateCluster) | Should -Be $tdPrivateCluster
    }

    It "[$tdClusterName]_workload_identity_enable_check" {
        [bool]::Parse($responseJson.securityProfile.workloadIdentity.enabled) | Should -Be $tdWorkloadIdentityEnable
    }

    It "[$tdClusterName]_image_cleaner_enable_check" {
        [bool]::Parse($responseJson.securityProfile.imageCleaner.enabled) | Should -Be $tdImageCleanerEnable
    }

    It "[$tdClusterName]_network_plugin_mode_check" {
        $responseJson.networkProfile.networkPluginMode | Should -Be $tdNetworkMode
    }

    It "[$tdClusterName]_network_policy_check" {
        $responseJson.networkProfile.networkPolicy | Should -Be $tdNetworkPolicy
    }

    It "[$tdClusterName]_keyvault_secrets_provider_class_enable_check" {
        [bool]::Parse($responseJson.addonProfiles.azureKeyvaultSecretsProvider.enabled) | Should -Be $tdSecretsProviderEnabled
    }

    It "[$tdClusterName]_azure_policy_enable_check" {
        [bool]::Parse($responseJson.addonProfiles.azurePolicy.enabled) | Should -Be $tdAZPolicyEnabled
    }

    It "[$tdClusterName]_OMS_agent_for_logs_enable_check" {
        [bool]::Parse($responseJson.addonProfiles.omsagent.enabled) | Should -Be $tdOMSAgentEnabled
    }

    It "[$tdClusterName]_node_pool_count_check" {
        $nodePools = @($responseJson.agentPoolProfiles)
        $nodePools.Length | Should -Be $tdNodepoolCount
    }

    Describe "[$tdClusterName]_nodepools" -ForEach $data.nodepool {
        $nodeData = $_
        #To Display in the testcase title this variable is needed
        $tdNodepoolName = $nodeData.name

        BeforeAll {
            $nodeData = $_
            $tdVMSize = $nodeData.vmSize
            $tdAutoScaling = $nodeData.enableAutoScaling
            $tdEncryptionAtHost = $nodeData.enableEncryptionAtHost
            $tdOSDiskType = $nodeData.osDiskType
            $tdStatus = $nodeData.status
            $tdNodepoolName = $nodeData.name
            $tdApplicationLabel = $nodeData.applicationLabel
            $tdNodeType = $nodeData.nodeType
            $tdAvailabilityZoneSize = $nodeData.availabilityZoneSize
            $tdApplicationLabel = $nodeData.applicationLabel
            $tdNodeType = $nodeData.nodeType
            $tdAvailabilityZoneSize = $nodeData.availabilityZoneSize
            $tdMinNodeCount = $nodeData.minNodeCount
            $tdMaxNodeCount = $nodeData.maxNodeCount

            # Fetch Node Pool informations
            $nodeResponse = (az aks nodepool list --cluster-name $tdClusterName -g $rgName --query "[?name=='$tdNodepoolName']" -o json --only-show-errors)
            $parseJson = $nodeResponse | ConvertFrom-Json
        }
            
        It "[$tdNodepoolName]_node_version_check" {
            $parseJson.orchestratorVersion | Should -Be $tdClusterVersion 
        }

        It "[$tdNodepoolName]_node_vm_size_check" {
            $parseJson.vmSize | Should -Be $tdVMSize 
        }

        It "[$tdNodepoolName]_node_autoscale_check" {
            $parseJson.enableAutoScaling | Should -Be $tdAutoScaling 
        }

        It "[$tdNodepoolName]_node_encryptionathost_check" {
            $parseJson.enableEncryptionAtHost | Should -Be $tdEncryptionAtHost 
        }

        It "[$tdNodepoolName]_node_osdisktype_check" {
            $parseJson.osDiskType | Should -Be $tdOSDiskType 
        }

        It "[$tdNodepoolName]_node_status_check" {
            $parseJson.powerState.code | Should -Be $tdStatus 
        }

        It "[$tdNodepoolName]_node_type_check" {
            $parseJson.mode | Should -Be $tdNodeType 
        }

        It "[$tdNodepoolName]_node_availability_zone_config_check" {
            $($parseJson.availabilityZones).Length | Should -Be $tdAvailabilityZoneSize 
        }

        It "[$tdNodepoolName]_node_min_max_check" {
            if ([bool]::Parse($parseJson.enableAutoScaling)) {
                $parseJson.maxCount | Should -Be $tdMaxNodeCount 
                $parseJson.minCount | Should -Be $tdMinNodeCount 
            }
            else {
                $parseJson[0].count | Should -Be $tdMaxNodeCount 
            }
        }
            
        It "[$tdNodepoolName]_node_application_label_check" {
            $parseJson.nodeLabels."abnamro.bank/application-name" | Should -Be $tdApplicationLabel 
        }
    }
}