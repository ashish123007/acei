#Load AKS Test Data
. ./scripts/testcrpits/load-testdata.ps1

Describe "StorageAccount.TestCase" -ForEach $StorageAccountData {
    $data = $_
    #To Display in the testcase title this variable is needed
    $tdSAName = $data.name
    BeforeAll {
        $data = $_
        $tdSAName = $data.name
        $tdSAKind = $data.kind
        $tdSAEncryption = $data.requireInfrastructureEncryption
        $tdSASKU = $data.sku
        $tdTier = $data.tier
        $tdSAPublicAccess = $data.allowBlobPublicAccess
            
        # Fetch Storage Account informations
        $response = (az storage account show -g $rgName -n $tdSAName -o json --only-show-errors)
        $responseJson = $response | ConvertFrom-Json
    }

    It "[$tdSAName]_exists_check" {
        $responseJson | Should -Not -BeNullOrEmpty
    }

    It "[$tdSAName]_kind_check" {
        $responseJson.kind | Should -Be $tdSAKind
    }

    It "[$tdSAName]_ple_enable_check" {
        $responseJson.privateEndpointConnections | Should -Not -BeNullOrEmpty
    }

    It "[$tdSAName]_encryption_enable_check" {
        $responseJson.encryption.requireInfrastructureEncryption | Should -Be $tdSAEncryption
    }

    It "[$tdSAName]_sku_check" {
        $responseJson.sku.name | Should -Be $tdSASKU
    }

    It "[$tdSAName]_tier_check" {
        $responseJson.sku.tier | Should -Be $tdTier
    }

    It "[$tdSAName]_public_access_disable_check" {
        [bool]::Parse($responseJson.allowBlobPublicAccess) | Should -Be $tdSAPublicAccess
    }
}
