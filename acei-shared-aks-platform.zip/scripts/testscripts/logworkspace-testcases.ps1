#Load AKS Test Data
. ./scripts/testcrpits/load-testdata.ps1

Describe "LogWorkspace.TestCase" -ForEach $LogWorkspaceData {
    $data = $_
    #To Display in the testcase title this variable is needed
    $tdLogWorkspaceName = $data.name

    BeforeAll {
        $data = $_
        $tdLogWorkspaceName = $data.name
        $tdRetentionDays = $data.retentionInDays
        $tdPublicAccess = $data.publicNetworkAccessForIngestion

        # Fetch Log Workspace informations
        $response = (az monitor log-analytics workspace show -g $rgName -n $tdLogWorkspaceName -o json --only-show-errors)
        $responseJson = $response | ConvertFrom-Json
    }

    It "[$tdLogWorkspaceName]_exists_check" {
        $responseJson | Should -Not -BeNullOrEmpty
    }

    It "[$tdLogWorkspaceName]_log_retention_days_check" {
        $responseJson.retentionInDays | Should -Be $tdRetentionDays
    }

    It "[$tdLogWorkspaceName]_public_access_disable_check" {
        $responseJson.publicNetworkAccessForIngestion | Should -Be $tdPublicAccess
    }
}
