#Load AKS Test Data
. ./scripts/testcrpits/load-testdata.ps1

Describe "BackupVault.TestCase" -ForEach $BackupVaultData {
    $data = $_
    #To Display in the testcase title this variable is needed
    $tdBackupVaultName = $data.name
    BeforeAll {
        $data = $_
        $tdBackupVaultName = $data.name
        $tdBackupVaultretentionDays = $data.retentionDurationInDays
        $tdBackupVaultsoftDelete = $data.softDelete
        $tdBackupVaultEncryption = $data.encryption
        $tdBackupVaultDatastoreType = $data.datastoreType
        $tdBackupVaultRedundantType = $data.redundantType

        # Fetch Backup Vault informations
        $response = (az dataprotection backup-vault show -g $rgName -v $tdBackupVaultName -o json --only-show-errors)
        $responseJson = $response | ConvertFrom-Json
    }

    It "[$tdBackupVaultName]_exists_check" {
        $responseJson | Should -Not -BeNullOrEmpty
    }

    It "[$tdBackupVaultName]_retention_days_check" {
        [int]$responseJson.properties.securitySettings.softDeleteSettings.retentionDurationInDays | Should -Be $tdBackupVaultretentionDays
    }

    It "[$tdBackupVaultName]_soft_delete_enable_check" {
        $responseJson.properties.securitySettings.softDeleteSettings.state | Should -Be $tdBackupVaultsoftDelete
    }

    It "[$tdBackupVaultName]_encryption_enable_check" {
        $responseJson.properties.securitySettings.encryptionSettings.state | Should -Be $tdBackupVaultEncryption
    }

    It "[$tdBackupVaultName]_data_store_type_check" {
        $responseJson.properties.storageSettings.datastoreType | Should -Be $tdBackupVaultDatastoreType
    }
        
    It "[$tdBackupVaultName]_data_redundant_typ_check" {
        $responseJson.properties.storageSettings.type | Should -Be $tdBackupVaultRedundantType
    }
}