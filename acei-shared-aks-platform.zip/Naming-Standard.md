# Azure Pipeline and Bicep Naming Convention
 
## General Rules
- Use **lowercase letters** and hyphens (`-`) for file and folder names.
- Avoid special characters or spaces.

## Folder Structure:
acei-shared-aks-platform
- templates
  - helm-charts
  - bicep-templates
  - yaml-templates
- modules
- pipelines
- scheduler
- scripts
- variables
  - all-env
  - acceptance
    - common
    - json
  - development
    - common
    - json
    - teamvars
      - teamA
      - teamB

 
## File Naming
- Format Example: `base-aks-pipeline.yaml`, ~~common.aks.parameters.json~~

## Folder Naming
- Format Example: `ingress-controller`

## Parameter Naming
- Add parameters with ~~description to clarify thier purpose~~ and ensure start with "p"
- Format Example: `pLogAnalyticsWorkspaceSKU`

## Variables Naming
- Add variables with ~~description to clarify thier purpose~~ and ensure start with "v"
- Format Example: `vClusterVersion`

## Helm Variables Naming
- Add variables with ~~description to clarify thier purpose~~
- Format Example: `helmVersion`

## HelmValue File Naming
- Add variables with ~~description to clarify thier purpose~~.
- Format Example: 
``` 
                    resourceQuota:
                        limits:
                            ## Provide CPU and Memory Limit
                            cpu: "6000m"
                            memory: "10Gi"
