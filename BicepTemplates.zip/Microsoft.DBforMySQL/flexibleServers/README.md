# MySQL Flexible Servers

This module creates Azure MySQL Flexible Servers .

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

As of now we dont have nightly build, check below Contributor permissions on an Azure Static DNS zone

## Usage Guidance

### Prerequisites

The pre-requisities to use this module are:

- Customer-managed keys (CMK)
- User-Assigned Managed Identity
- Key Vault for CMK
- Key for CMK
- Dedicated Subnet
- SPN with DNS contributor rights, you can achieve this via this [script](./pipelines/scripts/Invoke-MySqlApi.ps1)
[More information](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/92249/MySQL-Flexible-Server-requesting-temporary-permissions-to-deploy?anchor=process-description).

If you don't have all the Prerequisites yet, you can choose to create a pipeline step.
In the file `pipelines/jobs.pre-deployment-setup.yml` you will find how to do this.

### Available Submodules

- [Database](./databases/README.md)

### Contributor permissions on an Azure Static DNS zone

Currently there is a problem with MySQL Flexible Server deployment. It requires Contributor permissions on
an Azure Static DNS zone to start deployment.  If this permission is not there, it will simply fail even if
the required DNS-VNET association is already there. This issue has been escalated to Microsoft.
[MySQL Flexible Server - requesting temporary permissions to deploy](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/92249/MySQL-Flexible-Server-requesting-temporary-permissions-to-deploy)

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module mySqlFlexibleServerModule 'br/FSCPRegistry:bicep/modules/dip/core/mysql-flexible-servers:2.0.0' = {
  name: '<name of deployment>'
  params: {
    serverName: '<Flexible Server name>'
    subnetName: '<Name of the subnet>'
    virtualNetworkName: '<Name of the virtual Network >'
    virtualNetworkResourceGroup: '<Name of the vistual Network RG>'
    primaryKeyURI: '<Uri of Key With Version>'
    administratorLogin: '<Username of the administrator>'
    administratorLoginPassword: '<Password of the administrator, it's recommended that you use a secure variable for this>'
    principalName: '<The name of the Group or Service Principal>'
    principalObjectId: '<The object id of the Group or Service Principal>'
    aadIdentityName: '<Name of Microsoft Entra ID>'
    primaryUserAssignedIdentityId: 'user managed identity'
    intendedBackupInterval: '<Intended Backup Interval duration>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| administratorLogin | string | The administrator login name of a server. Can only be specified when the MySQL Flexible servers is being created. |
| administratorLoginPassword | string | The administrator login password. |
| intendedBackupInterval | string | The intendedBackupInterval tag must be set to one of the following allowed values: Continuous, 1h, 4h, 1d, 7d, 14d, 30d & None. |
| serverName | string | The name of the MySQL flexible servers. |
| primaryUserAssignedIdentityId | string | User-Assigned Managed Identity to be used for data encryption. |
| virtualNetworkResourceGroup | string | The name of the Virtual Network Resource Group.|
| virtualNetworkName | string | The name of the Virtual Network. |
| subnetName | string | The name of the dedicated subnet. |
| primaryKeyURI | string | The primary Key URI for data encryption. |
| aadIdentityName | string | User-Assigned Managed Identity and This identity requires the following permission: \'User.Read.All\', \'Group.Read.All\' and \'Application.Read.All\. |
| principalName | string | The name of the Group or Service Principal to be configured as Azure AD administrator |
| principalObjectId | string | The object id of the Group or Service Principal to be configured as Azure AD administrator |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| tags | object | {} | Additional MySql server properties. |
| identityType | string | UserAssigned | Type of identityType |
| additionalProperties | object|{} | Additional MySql flexible server properties. |
| backupRetentionDays | int | 7 | The backup retention period in days. |
| geoRedundantBackup | string | Disabled | Whether geo-redundant storage for backup is enabled or disabled. |
| createMode | string | Default | The mode to create a new MqSQL Flexible server. |
| mySqlVersion | string | 8.0.21 | The version of MySQL Flexible Server. |
| storageAutoGrow | string | Enabled | When enabled (default), the storage automatically grows without impacting the workload. |
| storageSizeGB | int | 128 | The amount of storage expressed in gigabytes.|
| location | string | | Location of MySql Flexible server. |
| skuName | string | 'Standard_D8ads_v5' | The name of the sku. |
| serverEdition | string | 'GeneralPurpose' |The tier of the particular SKU |
| dataEncryptionType | string | 'AzureKeyVault' |The data encryption type |
| privateDnsZoneResourceId | string | 'private01.mysql.database.azure.com' |The Private Dns Zone ResourceId |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| location | string | The location the resource was deployed into. |
| name | string | Name of the Mysql flexible Server |
| mySqlFlexibleServers | object | Mysql flexible Server |
| resourceGroupName | string | The name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

This section details which properties need to be set and what values should be used to create a compliant service.
They are already implemented in the provided template but this information can be used if you wish to create your
own template.

### Network

| Name | Description | Value |
| :-- | :-- | :--|
| delegatedSubnetResourceId | Delegated subnet resource id used to setup vnet for a server. | subnetName |
| privateDnsZoneResourceId | Private DNS zone resource id. | 'private01.mysql.database.azure.com' |
| publicNetworkAccess | Whether or not public network access is allowed for this server. Value is 'Disabled' when server has VNet integration. | 'Disabled' or 'Enabled' |

### Encryption

| Name | Description | Value |
| :-- | :-- | :-- |
| primaryKeyURI | Infrastructure encryption should be enabled for Azure Database for MySQL Flexible servers | primaryKey URI |
| primaryUserAssignedIdentityId | Primary user identity resource id of your MySQL Flexible servers. | Primary user identity resource id. |
| type | The key type, AzureKeyVault for enable cmk, SystemManaged for disable cmk. | 'AzureKeyVault'. |

## Reference

- <https://confluence.int.abnamro.com/display/VEEJH/DIP+Bicep+FAQ>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/75439/AAB-MySQL-Database-v1>
