# Release and Upgrade Notes

## Version 1.1.0

- Released: 2025 Mar 5
- Description: Updated API versions
- Story: [5077426](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5077426)
Added new parameters in pre-requisite.
- Story: [5113541](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5113541)

## Version 1.0.0

- Released: 2024 June 24
- Description: Initial version of the MySql Database server
- Story: [3456442](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3456442)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)
