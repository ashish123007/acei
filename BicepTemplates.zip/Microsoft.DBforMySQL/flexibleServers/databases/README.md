# Mysql Flexible Servers Database

This module creates Azure MySql Flexible Servers Database.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

As of now we dont have nightly build, check below Contributor permissions on an Azure Static DNS zone

## Pre-Requisities

The pre-requisities to use this module are:

- Key Vault with PE
- A MySQL Flexible Servers

## Usage Guidance

### Prerequisites

If you don't have all the Prerequisites yet, you can choose to create a pipeline step.
In the file `pipelines/jobs.pre-deployment-setup.yml` you will find how to do this.

### Consume the module

_Warning: The usage of Azure Container Regsitry (ACR) is not target state and the instance will be switched off as
soon as Nexus is available.
This will require customer teams to update their applications to consume the module from Nexus instead of ACR_

You can also create databases when creating the database server. You can read how to do this in
[the readme of the mysql flexible server](../flexibleServers/README.md).

### Contributor permissions on an Azure Static DNS zone

Currently there is a problem with MySQL Flexible Server deployment. It requires Contributor permissions on
an Azure Static DNS zone to start deployment.  If this permission is not there, it will simply fail even if
the required DNS-VNET association is already there. This issue has been escalated to Microsoft.
[MySQL Flexible Server - requesting temporary permissions to deploy](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/92249/MySQL-Flexible-Server-requesting-temporary-permissions-to-deploy)

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module mySQLDatabaseModule 'br/FSCPRegistry:bicep/modules/dip/core/mysql-flexible-servers-database:1.1.0' = {
  name: '<name of deployment>'
  params: {
    databaseName: '<The resource name>'
    flexibleServersName: 'bicep/modules/dip/core/mysql-flexible-servers:1.1.0'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| databaseName | string | name of mysql flexible server database. |
| flexibleServersName | string | flexible server name |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalProperties | object | {} | Additional mysql flexible servers database properties. |
| charset | string | 'utf8' | The character set of the database. |
| collation | string | 'utf8_general_ci' | The collation of the database. |
| tags | object | {} | User provided resource tags in the form of json |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| name | string | The name of the created resource. |
| mySqlFlexibleServersDatabase | object | Mysql flexible servers Database |
| resourceGroupName | string | the name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Reference(needs to update with MysqlFlexible server)

- <https://confluence.int.abnamro.com/display/VEEJH/DIP+Bicep+FAQ>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/75439/AAB-MySQL-Database-v1>
