# Release and Upgrade Notes

## Version 2.0.0

- Released: 2025 Mar 06
- Description: Added the IntendedBackupInterval Manadatory tag
- Story: [4993374](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4993374/)

### Upgrade steps to 2.0.0

Upgrade of the module needs parameter intendedBackupInterval enabled.
The parameters for intendedBackupInterval -`Continuous`, `1h`, `4h`, `1d`, `7d`, `14d`, `30d` & `None`

---

## Version 1.1.0

- Released: 2025 Mar 5
- Description: Updated API versions
- Story: [5077426](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5077426)

---

## Version 1.0.0

- Released: 2024 Jun 24
- Description: Initial version of the MySql Flexible servers
- Story: [3456442](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3456442)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)
