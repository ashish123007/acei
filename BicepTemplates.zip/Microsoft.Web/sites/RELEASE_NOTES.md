# Release and Upgrade Notes

## Version 2.5.6

- Released: 2025 Jun 02
- Description: updated version due to BICEP PEP upgrade
- Story: [5444323](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5444323)

---

## Version 2.5.5

- Released: 2025 Apr 29
- API Update from 2024-04-01 to 2024-11-01 for Microsoft.Web/sites.
Renamed python script names.
- Change done by auto-heal-function.
- Story: [5321420](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5321420)

---

## Version 2.5.4

- Released: 2025 Mar 17
- Description: updated version due to log analytics upgrade
- Story: [5122199](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5122199)

---

## Version 2.5.3

- Released: 2025 Mar 11
- Description: updated version due to BICEP PEP upgrade
- Story: [5101539](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5101539)

---

## Version 2.5.2

- Released: 2025 Feb 05
- Description: merge additional siteconfig
for appservice slot settings
- Story: [4956809](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4956809)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 2.5.1

- Released: 2024 Dec 09
- Description: updated version due to BICEP  PEP upgrade
- Story: [4707678](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4707678)

---

## Version 2.5.0

- Released: 2024 Oct 28
- Description: updated version due to outdated API
- Story: [4470596](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4470596)

---

## Version 2.4.1

- Released: 2024 Sep 23
- Description: updated the slot configuration to also use the additionalSteConfig.
- Story: [4246944](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4246944)

---

## Version 2.4.0

- Released: 2024 Sep 02
- Description: added one more parameter additionalSiteConfig
- Story: [3839759](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4088683)

---

## Version 2.3.3

- Released: 2024 Jul 04
- Description: updated version due to outdated API
- Story: [3839759](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3839759)

---

## Version 2.3.2

- Released: 2024 May 10
- Description: updated version due to PEP upgrade
- Story: [3616182](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3616182)

---

## Version 2.3.1

- Released: 2024 Mar 26
- Description: added two more parameters ipSecurityRestrictionsDefaultAction and scmIpSecurityRestrictionsDefaultAction.
- Story: [3566674](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3566674)

---

## Version 2.3.0

- Released: 2024 Mar 23
- Description: Added output for slot object `appServiceSlot`.

---

## Version 2.2.0

- Released: 2024 Feb 16
- Description: Added parameter for slot siteconfig `appServiceSlotSiteConfig`.
- Story: [3250596](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3250596)

---

## Version 2.1.0

- Released: 2023 Nov 03
- Description: Elabled http2.0 to be complient with policy.
- Story: [3186073](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3186073)

---

## Version 2.0.0

- Released: 2023 Nov 03
- Description: To allow setting the Runtime stack for linux and windows the
optional parameter linuxFxVersion is renamed to osFxVersion. Parameter osType
is added to support this feature.
- Story: [2879119](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2879119)

---

### Upgrade steps from 1.9.x to 2.0.0

1. Change module version to `2.0.0` in your original bicep.
1. Optional parameter `linuxFxVersion` changed to `osFxVersion`.
Rename the parameter in your original bicep when applicable.
1. Add the `osType` parameter to deploy Windows based app services
when applicable.

For example.

```code
module appServiceModule 'br/FSCPRegistry:bicep/modules/dip/core/dip-module-app-service:2.0.0' = {
  name: '<name of deployment>'
  params: {
    appServiceName: '<your app-service name>'
    appServicePlanName: '<your app-service plan name>'
    appServiceSettings: { APPINSIGHTS_INSTRUMENTATIONKEY: 'e96c7737-657b-4dfd-8b48-4adde8dffdfa' }
    appServiceSubnetName: '<your subnet for appservice>'
    appServiceSlotName: 'staging'
    appServiceSlotSettings: { APPINSIGHTS_INSTRUMENTATIONKEY: 'xxxx-92xxx35-4xxxb0b-xxx' }
    osFxVersion: '<Runtime stack of the App Service>'
    osType: '<OS type of App Service. Use linux or windows>'
    privateEndpointSubnetName: '<your subnet for appservice>'
    vnetName: '<your vnet name>'
    vnetResourceGroup: '<your vnet resourcegroup name>'
  }
}
```

---

## Version 1.9.1

- Released: 2023 Oct 13
- Description: added tag `NSF-Format` parameter to comply with the policy
aab-platform-nsf-tag-audit-v1
- Story: [2807840](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2807840)

---

## Version 1.9.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 1.8.10

- Released 2023 Sep 04
- AppService resource version out of date. update from 2022-03-01 to 2022-09-01
- Story: [2653047](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2653047)

---

## Version 1.8.9

- Released 2023 Aug 08
- Upgraded Bicep versions.
Use only local references for submodules.
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 1.8.8

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 1.8.7

- Released: 2023 July 13
- Description: updated PLE version in the template from 2.2.0 to 2.2.1.
- Story: [2475562](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 1.8.6

- Released: 2023 July 03
- Description: Private Endpoint module version used has been updated.
- Story: [2438072](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2438072)

---

## Version 1.8.5

- Released: 2023 May 23
- Description: nightly-builds-fix for version.
  Use of ASP module instead of 'in-line' module and removed creation of 'do-not-delete' app service.
- Story: [2273734](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2273734)

---

## Version 1.8.4

- Released: 2023 Apr 23
- Description: nightly-builds-fix after validation fix.
- Story: [2221485](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2221485)

---

## Version 1.8.3

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 1.8.2

- Released: 2023 Jan 30
- Description: Added name as an output parameter.
Activated retry trigger in nightly.
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1935001)
- Story: [2029891](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2029891)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 1.8.1

- Released: 2023 Nov 09
- Description: App Service module removed clientCertEnabled to revert to the default setting.
- Story: [1817957](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1817957)

---

## Version 1.8.0

- Released: 2022 Nov 03
- Description: Added Additional App service Properties and upgraded to API version of Microsoft.Web/sites
- Story: [1556580](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1556580/)
- Story: [1847324](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1847324)

---

## Version 1.7.0

- Released: 2022 Oct 18
- Description: Added Private Endpoint for App Service Slots.
- Story: [1501501](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1501501/)

---

## Version 1.6.0

- Released: 2022 Oct 13
- Description: Added Private Endpoint as consumable module & move to Catalogue.

---

## Version 1.5.3

- Released: 2022 Sep 15
- Description: Adapted for new token replacement; Introduced new stable build
- Story: [1321307](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1321307/)

---

## Version 1.5.2

- Released: 2022 Sep 14
- Description: Fixed linter issues
- Story: [1393321](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1393321/)

---

## Version 1.5.1

- Released: 2022 Sep 09
- Description: Fixed the publishing issue.
- Story: [1387775](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1387775/)

---

## Version 1.5.0

- Released: 2022 Sep 01
- Description: Added Build Badges to the README for main and nightly.

---

## Version 1.4.0

- Released: 2022 Aug 12
- Description: New repo, added publishing functionality and nightly-build PL.

---

## Version 1.3.0

- Released: 2022 Jun 28
- Description: Added slot creation capability.

---

## Version 1.2.2

- Released: 2022 Jun 06
- Description: Lock is added to the released module tag and added template for pull request checklist.

---

## Version 1.2.1

- Released: 2022 Jun 03
- Description: Updated UAMI resource id param to string.

---

## Version 1.2.0

- Released: 2022 Jun 01
- Description: Updated Identity part to support both System Assigned and User Assigned Identities.

---

## Version 1.1.2

- Released: 2022 May 02
- Description: Added missing input params ipSecurityRestrictions and scmIpSecurityRestrictions in readme file.

---

## Version 1.1.1

- Released: 2022 Apr 27
- Description: Azure pipeline update & corrected ACR information in readme file.

---

## Version 1.1.0

- Released: 2022 Apr 25
- Description: resourceTags param added & README updated with ACR information.

---

## Version 1.0.0

- Released: 2022 Mar 01
- Description: Initial release of App Service bicep.
