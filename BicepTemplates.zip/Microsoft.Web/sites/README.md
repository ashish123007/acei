# App Service

This module creates Azure App Service configured for Linux.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/app-service(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99153&branchName=main)

## Pre-Requisities

- A vnet and subnet need to be in place. This can be created using [SSNS](https://confluence.int.abnamro.com/pages/viewpage.action?pageId=395260555)
- An App Service Plan needs to be created

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module appServiceModule 'br/FSCPRegistry:bicep/modules/dip/core/dip-module-app-service:2.5.6' = {
  name: '<name of deployment>'
  params: {
    appServiceName: '<your app-service name>'
    appServicePlanName: '<your app-service plan name>'
    appServiceSettings: { APPINSIGHTS_INSTRUMENTATIONKEY: 'e96c7737-657b-4dfd-8b48-4adde8dffdfa' }
    appServiceSubnetName: '<your subnet for appservice>'
    appServiceSlotName: 'staging'
    appServiceSlotSettings: { APPINSIGHTS_INSTRUMENTATIONKEY: 'xxxx-92xxx35-4xxxb0b-xxx' }
    privateEndpointSubnetName: '<your subnet for appservice>'
    vnetName: '<your vnet name>'
    vnetResourceGroup: '<your vnet resourcegroup name>'
  }
}
```

(*) NOTE: If you need information on how to deploy Logic App in your Subscription,
 you can use FSCP AZURE Logic App
 [Cookbook](https://confluence.int.abnamro.com/pages/viewpage.action?spaceKey=GRIDAD&title=FSCP+Azure+Cookbook+-+Azure+Logic+App)
  for detailed process.

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| appServiceName | string | App Service name |
| appServicePlanName | string | App Service plan name |
| appServiceSettings | object | Application settings like app insight instrumentation key e.g. {"APPINSIGHTS_INSTRUMENTATIONKEY":"xxxx-92xxx35-4xxxb0b-xxx"}. |
| privateEndpointSubnetName  | string | SubnetName of the PLE |
| vnetName | string | Virtual network name |
| vnetResourceGroup | string | Vnet resource group name |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalAppServiceProperties | object | {} | Any additional properties of app service which the user wants to provide.|
| additionalSiteConfig | object | {} | Any additional properties of site config which the user wants to provide. e.g. { netFrameworkVersion: 'v8.0'}|
| appServiceSlotName | string | staging | Slot name of app service.|
| appServiceSlotSettings | object | {} | Application settings for slot like app insight instrumentation key e.g. {"APPINSIGHTS_INSTRUMENTATIONKEY":"xxxx-92xxx35-4xxxb0b-xxx"} |
| appServiceSlotSiteConfig | object | {} | Site configuration for slot e.g. { alwaysOn: false } |
| appServiceSubnetName | string | appservice01-subnet | App service subnet name |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| enableSlot | bool | false | Determines whether slot creation is required.|
| identityType | string | SystemAssigned | Identity type of App Service |
| ipSecurityRestrictions | array | An array of IP | An array of IP security restriction rules |
| kind | string | app,linux | Kind of resource |
| location | string | location of the resource group | App Service location |
| osFxVersion | string | JAVA 11-java11 | Runtime stack of the App Service |
| osType | string | linux | OS type of App Service. Use linux or windows |
| resourceTags | object | {} | User provided resource tags in the form of json |
| scmIpSecurityRestrictions | array | An array of IP |  An array of SCM IP security restriction |
| scmIpSecurityRestrictionsDefaultAction | string | Deny |  Default action for scm access restriction if no rules are matched. |
| ipSecurityRestrictionsDefaultAction | string | Deny |  Default action for main access restriction if no rules are matched. |
| scmIpSecurityRestrictionsUseMain | bool | false | Whether to use the main IP security restrictions for SCM. |
| userAssignedIdentityId | string | | The Resource Id of user assigned identity for the App Service e.g. /subscriptions/XXXX-XXX-XXX-XXXX-XXXXX/resourceGroups/XXXX-d-rg/providers/Microsoft.ManagedIdentity/userAssignedIdentities/XXXX-uam |

Provide the last 3 params if you want to create slot for your app service -
enableSlot with value true, appServiceSlotName and appServiceSlotSettings

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| appService | object |The created App Service object |
| appServiceSlot | object | The created App Service Slot object |
| location | string | The location the resource was deployed into. |
| name | string | Name of the App Service resource |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### SiteProperties

| Name | Description | Value |
| :-- | :-- | :--|
| httpsOnly | HttpsOnly: configures a web site to accept only https requests. Issues redirect for http requests | 'true' |

### SiteConfig

| Name | Description | Value |
| :-- | :-- | :-- |
| ftpsState | State of FTP / FTPS service | 'Disabled' |
| ipSecurityRestrictions | IP security restrictions for main. | IpSecurityRestriction[] |
| minTlsVersion | MinTlsVersion: configures the minimum version of TLS required for SSL requests | '1.2' |
| scmMinTlsVersion | ScmMinTlsVersion: configures the minimum version of TLS required for SSL requests for SCM site | '1.2' |
| scmIpSecurityRestrictions | IP security restrictions for scm. | IpSecurityRestriction[] |
| vnetRouteAllEnabled | Virtual Network Route All enabled. This causes all outbound traffic to have Virtual Network Security Groups and User Defined Routes applied. | 'true' |

### IpSecurityRestriction

| Name | Description | Value |
| :-- | :-- | :-- |
| action | Allow or Deny access for this IP range. | 'Allow' |
| name | IP restriction rule name. | {string} |
| ipAddress | IP address the security restriction is valid for. It can be in form of pure ipv4 address (required SubnetMask property) or CIDR notation  ipv4/mask (leading bit match). For CIDR, SubnetMask property must not be specified. | {string} |
| priority | Priority of IP restriction rule. | {int} |

## Network Connectivity

### Azure Public

In this usage scenario, App Service is deployed and used to serve a web application with user interface to ABN AMRO
employees (i.e., people with an Azure AD account in the ABN AMRO tenant) or to external users through the public
internet.
The application must be fronted by an Application Gateway instance and be behind the Akamai Kona Site Defender
instance of ABN AMRO if the web application needs to be accessible for external users.

### Azure Private

In this usage scenario, App Service is used to host an API, Web or Function application without a user interface for
external consumers. However it is not directly exposed to those users or external network traffic for additional
security. The application must be fronted by either an API Management or Application Gateway instance and only allows
inbound traffic from those instances.

## Reference

- <https://confluence.int.abnamro.com/display/VEEJH/DIP+Bicep+FAQ>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64623/AAB-App-Service-Public-v1>
