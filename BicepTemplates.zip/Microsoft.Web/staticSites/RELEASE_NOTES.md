# Release and Upgrade Notes

## Version 1.1.4

- Released: 2025 Jun 02
- Description: updated version due to BICEP  PEP upgrade
- Story: [5444323](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5444323)

---

## Version 1.1.3

- Released: 2025 Apr 28
- API Update from 2024-04-01 to 2024-11-01 for Microsoft.Web/staticSites.
- Change done by auto-heal-function.

---

## Version 1.1.2

- Released: 2025 Mar 11
- Description: updated version due to BICEP PEP upgrade
- Story: [5101539](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5101539)

---

## Version 1.1.1

- Released: 2024 Dec 09
- Description: updated version due to BICEP  PEP upgrade
- Story: [4707678](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4707678)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 1.1.0

- Released: 2024 Oct 28
- Description: updated version due to PEP upgrade, config and bicep upgrade
- Story: [4470596](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4470596)

---

## Version 1.0.1

- Released: 2024 May 10
- Description: updated version due to PEP upgrade
- Story: [3616182](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3616182)

---

## Version 1.0.0

- Released: 2023 Sep 29
- Description: Initial version.
Exempted one DINE policy that is know to fail.
- Story: [2438584](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2438584)
- Story: [2820673](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2820673)

---
