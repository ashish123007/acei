# Static Web App

This module creates Azure Static Web App.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

[![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/static-web-app(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99181&branchName=main)

## Pre-Requisities

- A vnet and subnet need to be in place. This can be created using [SSNS](https://confluence.int.abnamro.com/pages/viewpage.action?pageId=395260555)

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module staticWebAppModule 'br/FSCPRegistry:bicep/modules/dip/core/static-web-app:1.1.4' = {
  name: '<name of deployment>'
  params: {
    staticWebAppName: '<your app-service name>'
    projectName: '<your project name>'
    repositoryName: '<your repository name>'
    branchName: '<your branch name>'   
    privateEndpointVnetName: '<your private enpoint vnet name>'
    privateEndpointVnetResourceGroup: '<your private vnet resourcegroup name>'
    privateEndpointSubnetName: '<your private endpoint subnet name>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| branchName | string | The name of the branch within the repository. |
| privateEndpointSubnetName | string | Private endpoint subnet name. |
| privateEndpointVnetName | string | Private endpoint vnet name. |
| privateEndpointVnetResourceGroup | string | Private endpoint vnet resource group name. |
| projectName | string | The name of the project within the organization. |
| repositoryName | string | The name of the repository within the project. |
| staticWebAppName | string | Static web app name. |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| allowConfigFileUpdates | bool | true | Whether it is allowed to update the config files for the Static Web App. |
| appSettings | object | {} | The variables passed as environment variables to the application code. |
| deploymentsNameFormat | string | '${deployment().name}-{0}' | Format to use for child deployment names. |
| location | string | location of the resource group | Static web app location. |
| organizationName | string | cbsp-abnamro | The name of the organization. |
| resourceTags | object | {} | User provided resource tags in the form of json. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| location | string | The location the resource was deployed into. |
| name | string | Name of the static web app resource |
| resourceGroupName | string | The name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |
| staticWebApp | object | The created static web app object |

## Policy Details

### staticSites

| Name | Description | Value |
| :-- | :-- | :--|
| provider | The provider that submitted the last deployment to the primary environment of the static site. | 'DevOps' |
| publicNetworkAccess | State indicating whether public traffic are allowed or not for a static web app. | 'Disabled' |
| SkuName | Name of the resource SKU. | 'Standard' |

### Private endpoint

Private Endpoint Connection should have a status of 'Approved'

## Network Connectivity

### Uploading website

Uploading the website can be done via a pipeline with a special task for static webapps.
You can find an example [here](https://dev.azure.com/cbsp-abnamro/GRD0001007/_git/fscp-static-webapp).

### Browsing

Browsing the static webapp is done via the private endpoint.
_note_ Currently the DNS configuration is not properly forwardend. The networking team is working on it.

## Reference

- <https://confluence.int.abnamro.com/display/VEEJH/DIP+Bicep+FAQ>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64623/AAB-App-Service-Public-v1>
- <https://learn.microsoft.com/en-us/azure/static-web-apps/get-started-portal?tabs=vanilla-javascript&pivots=azure-devops>
