# Release and Upgrade Notes

## Version 3.1.1

- Released: 2025 Apr 28
- API Update from 2024-04-01 to 2024-11-01 for Microsoft.Web/serverfarms.
- Change done by auto-heal-function.

---

## Version 3.1.0

- Released: 2024 Oct 28
- Description: updated version due to outdated API
- Story: [4470596](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4470596)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 3.0.0

- Released: 2024 Aug 15
- Description:
    Default value of sku has been changed from P1V2 to S1 to reduce costs.
    Added missing skutiermap values. PremiumV2 has been removed as it is outdated.
- Story: [3816509](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3816509)
- Story: [4007606](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/4007606)

---

## Version 2.2.0

- Released: 2024 Jul 29
- Description: Add support for logic apps to App Service Plan module
- Story: [3947656](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3947656)

---

## Version 2.1.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 2.0.3

- Released 2023 September 4
- AppServicePlan resource version out of date. update from 2022-03-01 to 2022-09-01
- Story: [2653047](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2653047)

---

## Version 2.0.2

- Released 2023 August 10
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)
- Story: [2578986](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2578986)

---

## Version 2.0.1

- Released: 2023 May 04
- Description: Fixing the 'P'. Enabled Zone redundant in test case.
- Story: [2256493](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2256493/)
- Story: [2304877](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2304877/)

---

## Version 2.0.0

- Released: 2023 May 01
- Description: Initial release of App Service Plan bicep.
- Story: [2130578](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2130578/)

### Upgrade steps from 1.1.1 to 2.0.0

1. Change module version to `2.0.0` in your original bicep.

1. Mandatory parameter `applicationServicePlanName` changed to
`name`. Rename the parameter in your original bicep.

1. Outputs 'outputAppServicePlanName` and `outputAppServicePlanId`
changed to `name` (string) and
`appServicePlan` (complete resource).
If applicable, replace references to mentioned outputs by
`name` and `appServicePlan.id` in your original bicep.

---

## Version 1.1.1

- Released: 2022 Jun 09
- Description: Latest release of ASP module (DIP)
