# App Service Plan

This module creates Azure App Service Plan.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/app-service-plan(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99154&branchName=main)

## Pre-Requisities

None

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

**Please note from version 3.0.0, default value of sku has been changed from P1V2 to S1.**
**Redeployment of existing ASP with new version especially on higher environments may have some impact.**

```code

module appServicePlanModule 'br/FSCPRegistry:bicep/modules/dip/core/app-service-plan:3.1.1' = {
  name: '<name of deployment>'
  params: {
    name: '<your App Service Plan name>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| name | string | App Service Plan name |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalAppServicePlanProperties | object | {} | Any additional properties of App Service Plan which the user wants to provide. |
| additionalAppServicePlanSku | object | {} | Any additional properties of App Service Plan sku which the user wants to provide. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| elasticScaleEnabled | bool | false | Whether App Services in this App Service Plan will scale as if the App Service Plan had an Elastic Premium SKU. This property only applies to Premium SKUs that are not elastic by themselves. |
| location | string | location of the resource group | App Service Plan location. |
| maximumElasticWorkerCount | int | 1 | The maximum number of elastic workers for the App Service Plan. |
| minimumElasticWorkerCount | int | 1 | The minimum number of elastic workers for the App Service Plan. |
| osType | string | linux | OS type of App Service Plan. Use linux or windows. |
| resourceTags | object | {} | User provided resource tags in the form of json. |
| skuCapacity | int | 1 | The number of workers for the App Service Plan. |
| skuName | string | S1 | Name of the App Service Plan SKU (*). |
| zoneRedundant | bool | false | Whether this App Service Plan will perform availability zone balancing. |

(*) As the SKU policy tier is bound by policy not all App Service Plan SKU are available.
The policy allows only dedicated compute pricing tiers,
which include the Basic, Standard, Premium, PremiumV3, and ElasticPremium.
This currently limits the allowed SKU names to:
'B1',
'B2',
'B3',
'EP1',
'EP2',
'EP3',
'P0V3',
'P1MV3',
'P1V3',
'P2MV3',
'P2V3',
'P3MV3',
'P3V3',
'P4MV3',
'P5MV3',
'S1',
'S2',
'S3',
'WS1',
'WS2',
'WS3'.

(*) NOTE: If you need information on how to deploy Logic App in your Subscription,
 you can use FSCP AZURE Logic App
 [Cookbook](https://confluence.int.abnamro.com/pages/viewpage.action?spaceKey=GRIDAD&title=FSCP+Azure+Cookbook+-+Azure+Logic+App)
 for detailed process.

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| appServicePlan | object | The created App Service Plan object |
| location | string | The location the resource was deployed into. |
| name | string | Name of the App Service Plan resource |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### sku

| Name | Description | Value |
| :-- | :-- | :--|
| tier | MUST be a dedicate compute tier (see above)  | depends on SKU name |

## Network Connectivity

### Azure Public

Refer to App Service module for subnet integration.

### Azure Private

Refer to App Service module for subnet integration and private endpoints.

## Reference

- <https://confluence.int.abnamro.com/display/VEEJH/DIP+Bicep+FAQ>
- <https://learn.microsoft.com/en-us/azure/templates/microsoft.web/serverfarms?pivots=deployment-language-bicep>
- <https://learn.microsoft.com/en-us/azure/app-service/overview-vnet-integration>
