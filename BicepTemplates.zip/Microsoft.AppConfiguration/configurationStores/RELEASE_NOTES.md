# Release and Upgrade Notes

## Version 1.6.4

- Released: 2025 Jun 02
- Description: updated version due to BICEP PEP upgrade
- Story: [5444323](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5444323)

---

## Version 1.6.3

- Released: 2025 Apr 22
- API Update from 2024-05-01 to 2024-06-01 for Microsoft.AppConfiguration/configurationStores.
Renamed python script names.
- Change done by auto-heal-function.
- Story: [5321420](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5321420)

---

## Version 1.6.2

- Released: 2025 Mar 11
- Description: updated version due to BICEP PEP upgrade
- Story: [5101539](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5101539)

---

## Version 1.6.1

- Released: 2024 Dec 09
- Description: updated version due to BICEP PEP upgrade
- Story: [4707678](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4707678)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 1.6.0

- Released: 2024 Nov 22
- Description: updated version due to BICEP  upgrade. From MS documentation:
  - Removed:
    - ExperimentationProperties
    - TelemetryProperties
  - Updated:
    - ConfigurationStoreProperties: Removed property 'experimentation'
    - ConfigurationStoreProperties: Removed property 'telemetry'
- Story: [4618536](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4618536)

---

## Version 1.5.2

- Released: 2024 Oct 28
- Description: updated version due to PEP upgrade
- Story: [4458622](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4458622)

---

## Version 1.5.1

- Released: 2024 May 10
- Description: updated version due to PEP upgrade
- Story: [3616182](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3616182)

---

## Version 1.5.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
Key rotation.
Prevent role assignment leakage.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)
- Story: [2774709](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2774709)
- Story: [3457882](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3457882)

---

## Version 1.4.3

- Released 2023 August 8
- Upgraded Bicep versions.
Use only local references for submodules.
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 1.4.2

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

## Version 1.4.1

- Released: 2023 July 13
- Description: updated PLE version in the template from 2.2.0 to 2.2.1.
- Story: [2475562](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 1.4.0

- Released: 2023 July 04
- Description: unique deployment names for private endpoint sub resource.
- Story: [2389017](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2389017)

---

## Version 1.3.2

- Released: 2023 July 03
- Description: Private Endpoint module version used has been updated.
- Story: [2438072](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2438072)

---

## Version 1.3.1

- Released: 2023 Apr 23
- Description: nightly-builds-fix after validation fix.
- Story: [2221485](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2221485)

---

## Version 1.3.0

- Released: 2023 Apr 12
- Description: Updated version of MS bicep.
- Story: [2182344](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2182344)

---

## Version 1.2.5

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 1.2.4

- Released: 2023 Jan 30
- Description: Added name as an output parameter.
Activated retry trigger in nightly.
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1935001)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 1.2.3

- Released: 2022 Nov 28
- Description: Updated version of keyvault module and pe module.
- Story: [1581912](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1581912/)

---

## Version 1.2.2

- Released: 2022 Nov 14
- Description: Fixed deploy issue using PE
- Story: [1637060](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1637060/)

---

## Version 1.2.1

- Released: 2022 Nov 11
- Description: Fixed Violations or pre-req resources and used the fscp PE
- Story: [1637060](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1637060/)

---

## Version 1.2.0 (duplicate)

- Released: 2022 Oct 17
- Description: Bugfix for stable-build, add param and removed varGroup.
- Story: [1511045](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1511045/)

---

## Version 1.2.0

- Released: 2022 Oct 13
- Description: Migrated to Community Reopo.

---

## Version 1.1.1

- Released: 2022 Oct 04
- Description: Fixed nightly build and introduced stable pipeline.

---

## Version 1.1.0

- Released: 2022 Sep 21
- Description: Added Private endpoint resource.

---

## Version 1.0.3

- Released: 2022 Sep 19
- Description: Fixed Register module version.

---

## Version 1.0.2

- Released: 2022 Sep 14
- Description: Fixed linter issues.
- Story: [1393321](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1393321/)

---

## Version 1.0.1

- Released: 2022 Sep 09
- Description: Fixed the publishing issue.
- Story: [1387775](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1387775/)

---

## Version 1.0.0

- Released: 2022 Aug 26
- Description: Initial release of Application Configuration bicep.

---
