# App Configuration

This repository can be used to deploy an instance of App Configuration.
[Learn more](https://docs.microsoft.com/en-us/azure/azure-app-configuration/overview)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/app-config(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99151&branchName=main)

## Pre-Requisities

- Managed Identity for the App Config to reach Key vault. [Learn more](https://docs.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/overview)
- Azure Key Vault for the Customer Managed Key (CMK) requirement of the App Config policies. You need to provide
identityclientid and keyidnetifier for App config to reach Key vault.
 [Learn more](https://docs.microsoft.com/en-us/azure/azure-app-configuration/concept-customer-managed-keys)
- Private Endpoint Subnet to create private link of the resource. [Learn more](https://aka.ms/appconfig/private-endpoint)

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)

and the below code snippet shows how to consume the module

```code
module configurationStore 'br/FSCPRegistry:bicep/modules/dip/core/app-config:1.6.4' = {
  name: '<name of deployment>'
  params: {
    name: '<app config name>'
    publicNetworkAccess: 'Disabled'
    sku: 'Standard'
    softDeleteRetentionInDays: 1
    createMode: 'Default'
    disableLocalAuth: true
    enablePurgeProtection: false
    identityClientId: '<client id of user managed identity>'
    keyIdentifier: '<uri of key in Key-vault>'
    identityType: 'UserAssigned'
    userAssignedIdentities: '<uri of user managed identity>'
    vnetResourceGroup: '<Vnet RG name>'
    vnetName: '<Vnet name>'
    pleSubnetName: '<ple subnet name>'
    privateEndpointName:'<private endpoint name>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- |  :-- |
| identityClientId | string | The client id of the identity which will be used to access key vault.|
| keyIdentifier | string | The URI of the key vault key used to encrypt data.|
| name | string | App Configuration name|
| pleSubnetName | string | Private link endpoint subnet name|
| privateEndpointName | string | Private endpoint name of the resource|
| userAssignedIdentities| string | Property specifying user managed identity|
| vnetName | string | Virutal network name|
| vnetResourceGroup | string | Virtual network resource group name.|

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalAppConfigurationProperties | object | {} | Any additional properties of app configuration which the user wants to provide.|
| createMode | string | Default | Indicates whether the configuration store need to be recovered. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| disableLocalAuth | bool | true | Disables all authentication methods other than AAD authentication. |
| enablePurgeProtection | bool | false | Property specifying whether protection against purge is enabled for this configuration store. |
| identityType | string | UserAssigned |The type of managed identity used.|
| location | string | location of the resource group  | App Service location. |
| publicNetworkAccess | string | Disabled | Control permission for data plane traffic coming from public networks while private endpoint is enabled.|
| sku | string | Standard | Pricing tier of App Configuration. |
| softDeleteRetentionInDays | int | 1 | The amount of time in days that the configuration store will be retained when it is soft deleted. |
| tags | object | {} | User provided resource tags in the form of json. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| appConfig | object | App Configuration resource as a object. |
| location | string | The location the resource was deployed into. |
| name | string | Name of the App Configuration. |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### ResourceIdentity

| Name | Description | Value |
| :-- | :-- | :-- |
| type | The type of managed identity used. | 'UserAssigned' |
| userAssignedIdentities | object | The user-assigned identity dictionary keys will be ARM resource ids in the form: '/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/{identityName}'. |

### KeyVaultProperties

| Name | Description | Value |
| :-- | :-- | :-- |
| identityClientId | The client id of the identity which will be used to access key vault. | string |
| keyIdentifier | The URI of the key vault key used to encrypt data. | string |

## Network Connectivity

### Azure Public

From Azure Public PaaS services to Azure App Configuration over HTTPS using TLS1.2.

### Azure Private

From Azure Private to Azure App Configuration via the Azure Firewall Network Secure Perimeter over HTTPS using TLS 1.2.

## Reference

- <https://dev.azure.com/cbsp-abnamro/GRD0001007/_wiki/wikis/GRD0001007.wiki/71536/How-to-set-up-Visual-Studio-Code-for-accessing-Azure-Container-Registry>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://docs.microsoft.com/en-us/azure/templates/microsoft.appconfiguration/configurationstores?pivots=deployment-language-bicep>
