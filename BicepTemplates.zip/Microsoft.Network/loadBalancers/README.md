# Load Balancer

This repository can be used to deploy an instance of Load Balancer. [Learn more](https://learn.microsoft.com/en-us/azure/load-balancer/load-balancer-overview)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/loadbalancer(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99170&branchName=main)

## Pre-Requisities

- VNet and subnet without delegation. Note: We recommend using the IAAS Pattern in SSNS as it is critical the
subnet is not delegated.
  - Read more - SSNS <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/58963/Usage-Guidance>
  - Read more - Subnet delegation <https://learn.microsoft.com/en-us/azure/virtual-network/subnet-delegation-overview>

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module loadbalancer 'br/FSCPRegistry:bicep/modules/dip/core/load-balancer:2.1.3'  = {
  name: '<name of deployment>'
  params: {
      loadBalancerName: '<loadBalancerName>'
      frontEndIPConfigName: '<frontEndIPConfigName>'
      lbBackEndName: '<lbBackEndName>'
      loadBalancingRuleName: '<loadBalancingRuleName>'
      probename: '<probename>'
      privateIPAddress: '<privateIPAddress>'
      subnet: '<subnet>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- | :-- |
| frontEndIPConfigName | string | Object representing the frontend IPs to be used for the load balancer.|
| loadBalancerName | string | | Load Balancer name |
| lbBackEndName| string | Name of the backend address.|
| loadBalancingRuleName | string | Name of the load balancer rule.|
| probename| string | The name of the resource that is unique within the set of probes used by the load balancer.|
| privateIPAddress| string | The private IP address of the IP configuration. |
| subnet| string | The reference to the subnet resource.|

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalloadbalancingProperties | object | {} | Paramater to add more properties for existing load balancer|
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| intervalInSeconds| int | 5 | The interval, in seconds, for how frequently to probe the endpoint for health status |
| location| string | resourceGroup().location | Location of your load balancer |
| loadBalancerSku| string | Standard | Name of a load balancer SKU |
| probeThreshold| int | 2 | The number of probes where if no response,will result in stopping further traffic to endpoint.|
| privateIPAddressVersion| string | IPv4 | Whether the specific ipconfiguration is IPv4 or IPv6. Default is taken as IPv4. |
| privateIPAllocationMethod | string | Static | The Private IP allocation method.|
| port| int | 5 | The port for communicating the probe. Possible values range from 1 to 65535, inclusive.|
| protocol| string | tcp | The protocol of the end point.|
| resourceTags| object | {} | tags for module|

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| loadBalancer | object | load balancer resource as a object |
| location | string | The location the resource was deployed into. |
| name | string | The name of the created resource. |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### loadBalancers

| Name | Description | Default Value |
| :-- | :-- | :-- | :-- |
| location | Resource location. | string |
| name | The resource name | string |

### LoadBalancerProperties

| Name | Description | Default Value |
| :-- | :-- | :-- | :-- |
| backendAddressPools | Collection of backend address pools.| BackendAddressPool |
| frontendIPConfigurations| Object representing the frontend IPs.| frontendIPConfiguration |
| loadBalancingRules| Object collection representing the load balancing rules Gets the provisioning.|loadBalancingRule|
| probes | Collection of probe objects used in the load balancer.| Probe |

### Subnet

| Name | Description | Default Value |
| :-- | :-- | :-- | :-- |
| name | The name of the resource that is unique within a resource group.| string |

## Network Reference

- This product resides as a CBSP Azure VNet Integrated PaaS instances in the AzurePrivate environment.
- Private Peering via the Express Route makes it possible via the ABN AMRO Zone Internconnect.

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/167/Product-Description?anchor=network-topology>

## Reference

- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/templates/microsoft.network/loadbalancers?pivots=deployment-language-bicep>
