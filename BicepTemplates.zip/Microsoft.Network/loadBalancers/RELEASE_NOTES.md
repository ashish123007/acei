# Release and Upgrade Notes

## Version 2.1.3

- Released: 2025 May 25
- API Update from 2024-07-01 to 2024-10-01 for Microsoft.Network/loadBalancers.
- Change done by auto-heal-function and manual interaction.

---

## Version 2.1.2

- Released: 2025 May 25
- API Update from 2024-10-01 to 2024-05-01 for Microsoft.Network/loadBalancers.
- Story: [5420823](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5420823)

---

## Version 2.1.0

- Released: 2025 Mar 10
- Description: Upgrade Bicep version to 2024-07-01
  No properties added, updated or removed.
- Story: [5094855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5094855)

---

## Version 2.0.0

- Released: 2025 Jan 07
- Description: Update load balancer module to use probeThreshold instead of numberOfProbes, this is a breaking change.
  Replaced numberOfProbes with probeThreshold in  probes
- Story: [4796316](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4796316)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 1.8.0

- Released: 2024 Dec 04
- Description: Upgrade Bicep version to 2024-05-01
  No properties added, updated or removed.
- Story: [4693855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4693855)

---

## Version 1.7.0

- Released: 2024 Oct 25
- Latest bicep version updated
- Task: [4458622](https://dev.azure.com/cbsp-abnamro/GRD0001023/_workitems/edit/4458622/)

---

## Version 1.6.0

- Released: 2024 May 10
- Latest bicep version updated
- Task: [3616182](https://dev.azure.com/cbsp-abnamro/GRD0001023/_workitems/edit/3616182/)

---

## Version 1.5.1

- Released: 2024 Apr 18
- Added backendAddressPool and probe to loadBalancingRules
- Task: [2081197](https://dev.azure.com/cbsp-abnamro/GRD0001023/_workitems/edit/2081197/)

---

## Version 1.5.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 1.4.0

- Released 2023 August 8
- Upgraded Bicep versions
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)

---

## Version 1.3.3

- Released: 2023 July 11
- Description: Bicep version update
- Story: [2465551](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2465551)

---

## Version 1.3.2

- Released: 2023 May 16
- Description: Minor bug fixed in loadBalancingRuleName param
- Story: [2285838](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2285838)

---

## Version 1.3.1

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 1.3.0

- Released: 2022 Oct 27
- Description: Updated new API version of loadbalancer release by Microsoft.
Activated retry trigger in nightly.
- Story: [1894607](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1894607)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 1.2.0

- Released: 2022 Oct 13
- Description: fixed Parameters in readme and bicep

---

## Version 1.1.0

- Released: 2022 Oct 05
- Description: Migrated to community repo

---

## Version 1.0.1

- Released: 2022 Oct 03
- Description: Added name in output.

---

## Version 1.0.0

- Released: 2022 Nov 14
- Description: Initial release of Load balancer
