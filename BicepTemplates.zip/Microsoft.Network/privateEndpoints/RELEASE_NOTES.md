# Release and Upgrade Notes

## Version 2.8.1

- Released: 2025 May 28
- API Update from 2024-07-01 to 2024-10-01 for Microsoft.Network/privateEndpoints.
- Change done by auto-heal-function.

---

## Version 2.8.0

- Released: 2025 Mar 10
- Description: Bicep version update to 2024-07-01
- Story: [5094855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5094855)

---

## Version 2.7.0

- Released: 2024 Dec 04
- Description: Upgrade Bicep version to 2024-05-01
  - Added:
    IpamPoolPrefixAllocation
- Updated:
  SubnetPropertiesFormat: Added property 'ipamPoolPrefixAllocations'
- Story: [4693855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4693855)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 2.6.0

- Released: 2024 Oct 25
- Description: Bicep version update
- Story: [4458622](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4458622)

---

## Version 2.5.0

- Released: 2024 May 8
- Description: Bicep version update
- Story: [3611564](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3611564)

---

## Version 2.4.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 2.3.0

- Released 2023 August 8
- Because of compile changes
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)

---

## Version 2.2.2

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 2.2.1

- Released: 2023 July 11
- Description: Bicep version update
- Story: [2465551](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2465551)

---

## Version 2.2.0

- Released: 2023 Apr 29
- Description: Optional additional properties added
- Story: [2420753](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2420753)

---

## Version 2.1.3

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2167088)

---

## Version 2.1.2

- Released: 2023 Jan 09
- Description: Updated the Bicep version.
Activated retry trigger in nightly.
- Story: [1637060](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1637060)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 2.1.1

- Released: 2022 Nov 11
- Description: Fixed resource api version.
- Story: [1637060](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1637060)

---

## Version 2.1.0

- Released: 2022 Oct 18
- Description: Added an optional parameter 'resourceIDForPrivateEndpoint' to provide the ID of the resource for the new Endpoint.

---

## Version 2.0.0

- Released: 2022 Oct 10
- Description: Moved projectfiles to fscp-private-endpoint. Renamed PLE parameters to privateEndpoint.

---

## Version 1.2.0

- Released: 2022 Jul 01
- Description: Parameterized Private Link End point name.
Earlier it was getting formed using private link resource name and value of private link
resource name is same for App service and its slot resulting into conflict.

---

## Version 1.1.1

- Released: 2022 Jun 14
- Description: Lock is added to the released module tag and a template is added for pull request checklist.

---

## Version 1.1.0

- Released: 2022 Apr 27
- Description: resourceTags param added, README updated with ACR information & Azure pipeline update.

---

## Version 1.0.0

- Released: 2022 Mar 01
- Description: Initial release of Private Endpoint bicep.
