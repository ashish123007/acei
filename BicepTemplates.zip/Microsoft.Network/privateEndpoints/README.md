# Private Endpoint

This module creates an Azure Private Endpoint.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/private-endpoints(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99174&branchName=main)

## Pre-Requisities

- A vnet and subnet need to be in place.
This can be created using [SSNS](https://confluence.int.abnamro.com/pages/viewpage.action?pageId=395260555)

## Usage Guidance

### Consume the module

#### Code Snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module myPrivateEndpoint 'br/FSCPRegistry:bicep/modules/dip/core/private-endpoint:2.8.1' = {
  name: '<name of deployment>'
  params: {
    resourceNameForPrivateEndpoint: '<resourceNameForPrivateEndpoint>'
    vnetResourceGroup: '<vnetResourceGroup>'
    vnetName: '<vnetName>'
    privateEndpointSubnetName: '<privateEndpointSubnetName>'
    privateEndpointGroupId: '<privateEndpointGroupId>'
    resourceType: '<resourceType>'
    privateEndpointName: '<privateEndpointName>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| privateEndpointGroupId | string | Group id for input resourceNameForPrivateEndpoint. e.g. for App Service=sites, App Service slots=sites-slotName & cosmos=sql' |
| privateEndpointName | string | Name of the Private End point |
| privateEndpointSubnetName | string | Private Endpoint subnet name |
| resourceNameForPrivateEndpoint | string | Resource name to which Private Endpoint would be linked   |
| resourceType | string |Resouce type for for input resourceNameForPrivateEndpoint e.g. For App Service and its slot = 'Microsoft.Web/sites' |
| vnetName | string | Vnet name|
| vnetResourceGroup | string | Vnet resource group name |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalPeProperties | object | {} | Additional Private Endpoint Properties |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| resourceGroupName | string | resourceGroup().name | Private Endpoint deployment resource group |
| resourceIDForPrivateEndpoint | string | determined from the resourceNameForPrivateEndpoint | Resource ID to which Private Endpoint would be linked |
| resourceTags | object | | User provided resource tags in the form of json |
| location | string | resourceGroup().location | Location of the resource  |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| location | string | The location the resource was deployed into. |
| name | string | The name of the created resource. |
| privateEndpoint | object | The created private-endpoint as object |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

No specific policy details for Private Endpoint.

## Network Connectivity

As a Network component itself no specific details.

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/60577/Private-Link-Endpoint-v2>
- <https://dev.azure.com/cbsp-abnamro/Azure/_git/SecureContext?path=/policy-catalog/resources/privatelink>
