# Application Gateway Web Application Firewall Policies

This module creates an Application Gateway Web Application Firewall Policies resource.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

1. Nightly compliance check

## Pre-Requisities

This resource doesnot have any prerequisities.

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to
[ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module.

```code
module AppGatewayWAFPolicyModule 'br/FSCPRegistry:bicep/modules/dip/core/app-gateway-waf-policies:1.2.0' = {
  name: '<name of deployment>'
  params: {
    name: '<appgateway waf policies name>'  
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| name | string | The resource name. |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalAppGatewayWAFPolicyProperties | object | {} | Additional configuration properties in raw format. Please find sample value below. |
| customRules | array | [] | The list of custom WAF Policy rules. |
| exclusions | array | [] | The list exclusions that are applied on the WAF Policy. |
| fileUploadEnforcement | bool | true | Whether allow WAF to enforce file upload limits. |
| fileUploadLimitInMb | int | 100 | The maximum file upload size in MB for WAF. |
| location | string | location of default resourceGroup | Resource location. |
| requestBodyEnforcement | bool | true | Whether WAF to enforce the request body limits. |
| requestBodyInspectLimitInKB | int | 128 | The maximum inspection limit in KB for request body inspection for WAF. |
| resourceTags | object | {} | User provided resource tags in the form of json. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| name | string | Name of the Application Gateway |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

This section details which properties need to be set and what values should be used to create a compliant service.
They are already implemented in the provided template but this information can be used if you wish to create your
own template.

### AAB Application Gateway - WAF Policy should use the latest OWASP rule set v1

| Name | Description | Value |
| :-- | :-- | :-- |
| managedRules | Should contain a `managedRuleSet` with `ruleSetType` set to `OWASP` and `ruleSetVersion` set to `3.2` | 'OWASP/3.2' |

### Web Application Firewall (WAF) should use the specified mode for Application Gateway

| Name | Description | Value |
| :-- | :-- | :-- |
| mode | The `policySetting/mode` must be set to specific value.  | 'Prevention' |

### WAF Policy should allow limited exclusions at managed rule sets v1

| Name | Description | Value |
| :-- | :-- | :-- |
| exclusions | The number of `managedRules/exclusions` should be not greater than 2  | <= 2 |

### WAF Policy managed rule set should not be disabled v1

| Name | Description | Value |
| :-- | :-- | :-- |
| state | None of the `managedRuleSet` should have state disabled.  | not `Disabled` |

### Azure Web Application Firewall on Azure Application Gateway should have request body inspection enabled

| Name | Description | Value |
| :-- | :-- | :-- |
| requestBodyCheck | The request body inspection should be enabled. | true |

### AAB Application Gateway - WAF Policy enforce minimum for the 'Maximum request body inspection limit' value v1

| Name | Description | Value |
| :-- | :-- | :-- |
| requestBodyInspectLimitInKB | The value for `requestBodyInspectLimitInKB` should be higher then specified. | 32 |

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/65788/AAB-Application-Gateway-v1>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/templates/microsoft.network/applicationgateways?pivots=deployment-language-bicep>
- <https://learn.microsoft.com/en-us/azure/web-application-firewall/ag/application-gateway-crs-rulegroups-rules?tabs=owasp32#owasp32>
