# Release and Upgrade Notes

## Version 1.2.0

- Released: 2025 Mar 10
- Description: Upgrade Bicep version to 2024-07-01
  No properties added, updated or removed.
- Story: [5094855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5094855)
- Story: [5139185](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5139185)
- Story: [5141474](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5141474)

## Version 1.1.0

- Released: 2024 Dec 04
- Description: Upgrade Bicep version to 2024-05-01
  No properties added, updated or removed.
- Story: [4693855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4693855)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

## Version 1.0.0

- Released: 2024 Oct 14
- Policy Initiative Compliance Version: N/A
- Description: Upgrade to WAF Policies
- Story: [4368211](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4368211)
