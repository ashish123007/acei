# Release and Upgrade Notes

## Version 5.7.0

- Released: 2025 Jun 02
- Description: introduced 2 subflavors of shared intent.
- Story: [5401387](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5401387)

---

## Version 5.6.1

- Released: 2025 Mar 13
- Description: better testability for shared intent
Renamed python script names.
- Story: [4992227](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4992227)
- Story: [5321420](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5321420)

---

## Version 5.6.0

- Released: 2025 Mar 11
- Description: Support shared intent
- Story: [4992227](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4992227)

---

## Version 5.5.0

- Released: 2025 Mar 10
- Description: New API versions
- Story: [5094855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5094855)

---

## Version 5.4.0

- Released: 2025 Feb 19
- Description: New API versions
- Story: [5021476](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5021476)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 5.3.1

- Released: 2024 Dec 09
- Description: updated version due to SSL policy upgrade to AppGwSslPolicy20220101
- Story: [4707678](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4707678)

---

## Version 5.3.0

- Released: 2024 Dec 04
- Description: Upgrade Bicep version to 2024-05-01
  No properties added, updated or removed.
- Story: [4693855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4693855)

---

## Version 5.2.0

- Released: 2024 Oct 30
- Description: Added firewallPolicyName parameter
- Story: [4359925](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4359925)

---

## Version 5.1.0

- Released: 2024 Oct 25
- Description: New Bicep API version
- Story: [4458622](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4458622)

---

## Version 5.0.0

- Released: 2024 Oct 14
- Description: Upgrade to WAF Policies
- Story: [4368211](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4368211)

### Upgrade steps from 4.3.0 to 5.x.x

The configuration of the WAF of the application gateway has been externalized
in an 'Application Gateway Web Application Firewall Policies' resource since
version 5.x.x.

To migrate, first create an
'Application Gateway Web Application Firewall Policies' resource.
Follow the instructions in the accompanying [README.md](../ApplicationGatewayWebApplicationFirewallPolicies/README.md).

You remove the WAF settings from your application gateway bicep parameters.

Link the created 'Application Gateway Web Application Firewall Policies'
resource with your application gateway using the firewallPolicyName parameter.

Check also for the 'knowledge session on WAF Policies' and the
'Cookbook setting up AGW with WAF'

---

## Version 4.3.0

- Released: 2024 May 08
- Description: Bicep version update
- Story: [3611564](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3611564)

---

## Version 4.2.1

- Released: 2024 Apr 22
- Description: Updated BICEP key vault version
to 2023-07-01.
- Story: [3543675](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3543675)

---

## Version 4.2.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 4.1.0

- Released 2023 August 8
- Because of compile changes.
Use only local references for submodules.
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 4.0.3

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 4.0.2

- Released: 2023 July 11
- Description: Bicep version update
- Story: [2465551](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2465551)

---

## Version 4.0.1

- Released: 2023 July 03
- Description: Private Endpoint module used version updated
- Story: [2438072](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2438072)

---

## Version 4.0.0

- Released: 2023 May 22
- Description: introduced new parameter to disable the merger of sub resources.
This aids deployment of complex scenarios.
- Story: [2221485](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2221485)
- Story: [2329487](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2329487)

### Upgrade steps to 4.0.0

Upgrade of the module version is accepted without any changes to the parameters.
However, if you set `additionalApplicationGatewayProperties`,
you need to add the new property `mergeSubResources` and set it to `true`
to conserve the behaviour of previous versions of the module.

---

## Version 3.1.2

- Released: 2023 Apr 06
- Description: nightly-builds-fix after validation fix.
- Story: [2221485](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2221485)

---

## Version 3.1.1

- Released: 2023 Apr 23
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 3.1.0

- Released: 2023 Mar 30
- Description: Configure only public IP in public intent AGW.
- Story: [2095373](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2095373)

---

## Version 3.0.0

- Released: 2023 Feb 03
- Description: Upgrade default WAF configuration from 3.1 to 3.2.
Activated retry trigger in nightly.
- Story: [1896189](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1896189)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

### Upgrade steps from 2.1.0 to 3.0.0

Upgrade of the module version is accepted without any changes to the parameters.
However it might have side-effects if you used the default `wafConfig` parameter
(see README). The reason is that some previously disabled rules are now activated,
and these might block your legimate requests.

If you provide a `wafConfig` parameter to the module you might consider to upgrade its
OWASP rule set version.

1. Change wafConfig ruleSetVersion to `3.2` in your original bicep.

1. Remove `disabledRuleGroups`, `exclusions`, `requestBodyCheck`,`maxRequestBodySizeInKb`.
As part of OWASP_3.2 upgrade, The Max Request Body Size limit was increased from 128KB to 2MB,
and the Max File Upload Size limit was increased from 750MB to 4GB.

Please note that once you upgraded to OWASP_3.2, you can't downgrade to CRS 3.1 or earlier.
If you need to downgrade, create Azure Support Request.

---

## Version 2.1.0

- Released: 2023 Jan 30
- Description: introduced intent parameter
- Story: [2039215](https://dev.azure.com/cbsp-abnamro/GRD0001007/_sprints/taskboard/BLK0003414/GRD0001007/BLK0003414/Sprint%20158?workitem=2039215)

---

## Version 2.0.4

- Released: 2023 Jan 30
- Description: Added name as an output parameter.
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_sprints/taskboard/BLK0003414/GRD0001007/BLK0003414/Sprint%20158?workitem=1935001)

---

## Version 2.0.3

- Released: 2023 Jan 09
- Description: Updated API version for Microsoft.Network/publicIPAddresses@2022-07-01
and Microsoft.Network/applicationGateways@2022-07-01
- Story: [1891474](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1891474)

---

## Version 2.0.2

- Released: 2022 Nov 11
- Description: Removed reference to preview API version
- Story: [1637060](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1637060)
- Story: [1847324](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1847324)

---

## Version 2.0.1

- Released: 2022 Nov 03
- Description: Removed reference to preview API version
- Story: [1580848](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1580848)

---

## Version 2.0.0

- Released: 2022 Nov 01
- Description: Initial release of Application Gateway,
replaces application-gateway-private module.
- Story: [1394127](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1314927)

### Upgrade steps from 1.0.0 to 2.0.0

1. Module name changed from `application-gateway-private` to `application-gateway`.
Rename the module path in your original bicep.

1. Change module version to `2.0.0` in your original bicep.

1. Mandatory parameter `applicationGatewayName` changed to
`name`. Rename the parameter in your original bicep.

1. Mandatory parameter `inputBackendPool` changed to `inputBackendPools`.
The format of the array items changed:
member `backendAddress` is renamed to `backendFQDN`.
Rename the parameter, and the `backendAddress` array items member
in your original bicep.

1. The format of the array items of mandatory parameter `inputPathMap` changed:
member `path` is renamed to `paths`.
Rename the `path` array items member of `inputPathMap` in your original bicep.

1. Mandatory parameter `applicationGatewayUAMI` (a name) changed to
`userAssignedIdentities` (a completed Azure resource ID).
Rename the parameter and change its value to the complete resource ID
in your original bicep.

1. Outputs `outputApplicationGatewayName` and `outputApplicationGatewayId`
changed to `applicationGateway` (complete resource).
If applicable, replace references to mentioned outputs by
`applicationGateway.name` and `applicationGateway.id` in your original bicep.

---

## Version 1.0.0

- Released: 2022 Jul 14
- Description: Initial release of Application Gateway (DIP)
applicationGatewayName
