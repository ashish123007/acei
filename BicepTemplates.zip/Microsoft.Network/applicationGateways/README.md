# Application Gateway

This module creates an Application Gateway and can be used in both private and public scenarios.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

1. Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/application-gateway(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99156&branchName=main)

## Pre-Requisities

The pre-requisities to use this module are:

- VNet with Application Geteway subnet for Private or Public intent
- Service Endpoints for Microsoft.KeyVault service enabled on Appliaction Gateway subnet (*)
- Key Vault for SSL certificate
- Key Vault firewall policy that allows access from Application Gateway subnet (*)
- SSL certificate
- User managed identity for accessing Key Vault

(*) When Application Gateway retrieves key material from Key Vault it does _not_ make use of the
Private Endpoint of the KeyVault, if any configured.
It accesses the Key Vault over its service endpoint (if Service Endpoints are enabled),
or the Key Vault public IP address.
The Key Vault firewall policies must allow access from Application Gateway
subnet (if Service Endpoints are enabled), or its public IP address.
When such access is not arranged the deployment may succeed without reported
issues, and the Application Gateway may start without reported issues.
However, a TLS handshake to the Application Gateway will be aborted from
Application Gateway side with the `unrecognized_name(112)` alert.
More information on the key vault - app gateway limitation can be found
[here](https://confluence.int.abnamro.com/display/AZURE/Azure+Key+vault+and+Application+Gateway+Communication).

## Usage Guidance

### Prerequisites

If you don't have all the prerequisites yet, you can choose to create a pipeline step.
In the file `pipelines/jobs.pre-deployment-setup.yml` you will find a sample on how to do this.

### Consume the module

#### Code snippet

This module has been published to
[ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module.

```code
module applicationGatewayModule 'br/FSCPRegistry:bicep/modules/dip/core/application-gateway:5.7.0' = {
  name: '<name of deployment>'
  params: {
    name: '<ag_name>'
    userAssignedIdentities: '/subscriptions/<subscription_id>/resourceGroups/<rg_name>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/<mi_name>'
    applicationGatewayPrivateIP: '10.<b_octet>.<c_octet>.<d_octet>'
    applicationGatewayKeyVaultName: '<kv_name>'
    vnetResourceGroup: '<vnet_rg_name>'
    vnetName: '<vnet_name>'
    firewallPolicyName: '<string>'
    inputBackendPools: [
      {
        name: 'applicationBackendPool1'
        backendFQDN: '<as_name>.azurewebsites.net'
      }
    ]
    inputPathMap: [
      {
        backendAddressPoolName: 'applicationBackendPool1'
        paths: '/*'
      }
    ]
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| applicationGatewayKeyVaultName | string | Key Vault name where certificate for Application Gateway is stored. |
| firewallPolicyName | string | Name of the Application Gateway Web Application Firewall Policies resource. |
| inputPathMap | array |  Input array of mapped paths. Please find sample value below. |
| name | string | The resource name. |
| userAssignedIdentities| string | The user-assigned identitiy associated with the resource. The user-assigned identity dictionary key will be ARM resource id in the form: '/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/{identityName}'. |
| vnetName | string | Vnet name. |
| vnetResourceGroup | string | Vnet resource group name. |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalApplicationGatewayProperties | object | {} | Additional configuration properties in raw format. Please find sample value below. |
| applicationGatewayCertificate | string | name | Certificate name for Application Gateway from Key Vault. |
| applicationGatewayPrivateIP | string | '' | **Mandatory for a Private intent.** Application Gateway private IP address from application gateway private subnet. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| inputBackendPools | array | [] | Input array of backend pool config for Application Gateway. Please find sample value below. |
| inputPathMapDefaults | object | {} | Input object of pathmap defaults. Please find sample value below. |
| intent | string | 'Private' | Intent of Application Gateway, may be 'Private', 'Public', 'Shared', 'Shared,Public' or 'Shared,Private'. The 443 transport(s) will be configured according to intent. For 'Private', 'Shared' and 'Shared,Private' intent the value for 'applicationGatewayPrivateIP' is mandatory.|
| location | string | location of default resourceGroup | Resource location. |
| maxCapacity | int | 2 | Maximum auto scale instance count. |
| mergeSubResources | bool | false | Whether to merge internal subresources or not with extenally provide additional properties (see below). |
| minCapacity | int | 1 | Minimum auto scale instance count. |
| replaceParentToken | bool | true | Whether to replace `parent::` token in parameter values or not (see below). |
| resourceTags | object | {} | User provided resource tags in the form of json. |
| skuName | string | 'WAF_v2' | Application gateway Sku and Tier. Supported SKU values are Standard_v2 and WAF_v2. Consider using Standard_v2 if WAF tier is not required for your application. It saves 40 to 50% cost. |
| subnetName | string | '' | Application gateway subnet name. If left empty it will default to appgwprivate01-subnet or appgwpublic01-subnet, according to intent |
| zones | array | [] | Input array containing availability zones. Possible values for WE region are  1 , 2, 3. |

**Reserved values**

Please note that the following set of values cannot be used as they as reserved for use internally
by Azure or the Bicep module: `doNotUseThisBackendPool`, `UnusedApplicationBackendPool`,
`appGatewaySSLCertificate`, `doNotUseThisProbe`, `applicationProbe`, `UnusedApplicationProbe`,
`appgw-ip-config`, `appgw-public-frontend-ip`,
`appgw-private-frontend-ip`, `port_443`, `port_8443`,
`doNotUseTheseBackendHttpSettings`, `applicationHttpSetting`, `UnusedApplicationHttpSetting`,
`doNotUseThisHttpListener`, `applicationListener`, `UnusedApplicationListener`,
`doNotUseThisRoutingRule`.

**Sample parameter values**

The samples below may refer to _raw configuration properties_ of the resource or its subresources.
Raw properties are resource properties in json format as specified in Azure infocenter.
For more information on the configuration properties of the Application Gateway resource,
or one of its subresources webApplicationFirewallConfiguration, backendAddressPools,
urlPathMaps and urlPathMaps/pathRules, please consult the Azure documentation
[here](https://learn.microsoft.com/en-us/rest/api/application-gateway/application-gateways/get?tabs=HTTP#applicationgateway).

Wherever raw properties are applicable the special substring `parent::` refers to the resource ID
of the application gateway itself; and it will be replaced by the resource ID before deployment.
This replacement can be disabled by setting `replaceParentToken` parameter to false.

A sample value for `inputBackendPools` is as follows.

```code
[
    {
      "name": "applicationBackendPool1",
      "backendFQDN": "firstApi.azurewebsites.net"
    },
    {
      "name": "applicationBackendPool2",
      "backendFQDN": "secondApi.azurewebsites.net"
    }
    .
    .
]
```

The array item member `name` is required. All other members are optional.
Each array item may also have a member named `properties`, that holds additional backendAddressPool properties,
if required.

A sample value for `inputPathMap` is as follows.

```code
[
    {
      "name": "applicationRoutingPathRule1",
      "backendAddressPoolName": "applicationBackendPool1",
      "backendHttpSettingsName": "applicationHttpSetting",
      "paths": "/*"
    },
    {
      "name": "applicationRoutingPathRule2",
      "backendAddressPoolName"": "applicationBackendPool2",
      "backendHttpSettingsName": "applicationHttpSetting",
      "rewriteRuleSetName": "HardeningRuleSet",
      "paths": "/secondAPIPath/*"
    }
    .
    .
]
```

The member `backendAddressPoolName` is required.
All other array item members are optional.
The member `name` defaults to the urlPathMap name and a sequence number.
The member `backendHttpSettingsName` defaults to "applicationHttpSetting" (set by template).
Each array item may also have a member named `properties`,
that holds additional pathRules properties, if required.

A sample value for `inputPathMapDefaults` is as follows.

```code
{
    "name": "BasicRoutingRule",
    "defaultBackendAddressPoolName": "applicationBackendPool1",
    "defaultBackendHttpSettingsName": "applicationHttpSetting",
    "properties": {
      "defaultRewriteRuleSet": {
        "id": "parent::/rewriteRuleSets/HardeningRuleSet"
      }
    }
}
```

All members properties are optional. The default for `name` is "applicationRouting".
Each array item may also have a member named `properties`, that holds additional pathRules properties, if required.

The default (policy compliant) value for `wafConfig` is as follows.

```code
{
    "enabled": true,
    "firewallMode": "Prevention",
    "ruleSetType": "OWASP",
    "ruleSetVersion": "3.2"
}
```

Up to version 2.1.0 of the module the default WAF ruleset was based on OWASP 3.1 with 6 exclusions.
These exclusions were added because they were known to yield false positive
results in the ABN/AMRO environment.
For example the SQL Injection rule (REQUEST-942-APPLICATION-ATTACK-SQLI)
blocks requests that contain headers
with JSON elements in their value, like the Internet Banking session cookie.
Whenever your Application Gateway starts blocking traffic after an upgrade
from version 2 to 3 you might consider to disable one or more
of below ruleGroups.
These ruleGroups were disabled in Application Gateway module version 2.
Provide the `wafConfig` parameter as follows and drop ruleGroups until you identified the minimal
disabled set for your application.

```code

param wafConfig object = {
  enabled: true
  firewallMode: 'Prevention'
  ruleSetType: 'OWASP'
  ruleSetVersion: '3.2'
  disabledRuleGroups: [
      {
          ruleGroupName: 'REQUEST-942-APPLICATION-ATTACK-SQLI'
      }
      {
          ruleGroupName: 'REQUEST-944-APPLICATION-ATTACK-JAVA'
      }
      {
          ruleGroupName: 'REQUEST-933-APPLICATION-ATTACK-PHP'
      }
      {
          ruleGroupName: 'REQUEST-932-APPLICATION-ATTACK-RCE'
      }
      {
          ruleGroupName: 'REQUEST-930-APPLICATION-ATTACK-LFI'
      }
      {
          ruleGroupName: 'REQUEST-931-APPLICATION-ATTACK-RFI'
      }
  ]
}

```

A sample value for `additionalApplicationGatewayProperties` is as follows.

```code
{
    "backendHttpSettingsCollection": [
      {
        "name": "defaultsettings",
        "properties": {
          "port": 443,
          "protocol": "Https",
          "cookieBasedAffinity": "Disabled",
          "connectionDraining": {
            "enabled": false,
            "drainTimeoutInSec": 1
          },
          "pickHostNameFromBackendAddress": true,
          "path": "/",
          "requestTimeout": 60,
          "probe": {
            "id": "parent::/probes/defaultprobe"
          }
        }
      }
    ],
    "probes": [
      {
        "name": "defaultprobe",
        "properties": {
          "provisioningState": "Succeeded",
          "protocol": "Https",
          "path": "/healthcheck.html",
          "interval": 5,
          "timeout": 15,
          "unhealthyThreshold": 2,
          "pickHostNameFromBackendHttpSettings": true,
          "minServers": 0,
          "match": {
            "statusCodes": [
              "200"
            ]
          },
          "backendHttpSettings": [
            {
              "id": "parent::/backendHttpSettingsCollection/defaultsettings"
            }
          ]
        }
      }
    ],
    "rewriteRuleSets": [
      {
        "name": "HardeningRuleSet",
        "properties": {
          "rewriteRules": [
            {
              "ruleSequence": 110,
              "conditions": [
                {
                  "variable": "http_resp_Server",
                  "pattern": ".",
                  "ignoreCase": false,
                  "negate": false
                }
              ],
              "name": "RemoveServerHeader",
              "actionSet": {
                "requestHeaderConfigurations": [],
                "responseHeaderConfigurations": [
                  {
                    "headerName": "Server"
                  }
                ]
              }
            }
          ]
        }
      }
    ]
}
```

In general the members of `additionalApplicationGatewayProperties` override the properties set by the template.
This may break the policy compliancy of the template, for example
when `sku` or `sslPolicy` is overridden in this way.
The following application gateway properties members are merged
if `mergeSubResources` is set to `true`, that is,
these conserve the array items already set by the template:
  `backendAddressPools`,
  `backendHttpSettingsCollection`,
  `probes`,
  `httpListeners`,
  `frontendPorts`,
  `frontendIPConfigurations`,
  `gatewayIPConfigurations`,
  `sslCertificates`,
  `requestRoutingRules`,
  `urlPathMaps`.

**Web frontend flow**

In case you use your Application Gateway in conjuction with Web frontend flow from `pft-pipeline-templates`
you need to align it with how the flow expects it to be prepared.

- The first `requestRoutingRules` member _must_ be named `BasicRoutingRule`.
These were hardcoded in Web front end flow so it needs to be tight coupled for flow to go successful.

- The first `urlPathMaps` member _must_ be named `BasicRoutingRule`.
These were hardcoded in Web front end flow so it needs to be tight coupled for flow to go successful.

- There _must_ be a `backendHttpSettingsCollection` member named `defaultsettings`.
This _must_ utilize a `probes` member that uses `/healthcheck.html` as probe path.
See above for an example input for `defaulthttpsettings` and its probe.

- The `pathRules` member for a storage account _must_ be named `rt<storage account name>`.

- The `backendAddressPools` member for a storage account _must_ be named `be<storage account name>`.

The Web frontend flow will create or modify `rt<storage account name>` and `be<storage account name>`
upon each deployment if required.

In Acceptance and Production environments so-called blue/green deployments are enabled in Web frontend flow
if a primary or secondary gateway name is provided in the flow.
This means that actually two storage accounts are utilized.

If you want to create these in advance, that is not to use the Web frontend infra creation flow,
you are required to
create `<storage account name>gr` and `<storage account name>bl` storage accounts.
Upon each deployment the pool member of `be<storage account name>` backend pool
is updated to reflect to the latest deployment.

_Please note_: If you rerun your Bicep module for Application Gateway,
you must be sure to specify all the `pathRules` and `backendAddressPools` created
by Web frontend flow and specify the correct live storage account backend pool member,
otherwise these are overwritten, or even removed.

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| applicationGateway | object | Application Gateway |
| location | string | The location the resource was deployed into. |
| name | string | Name of the Application Gateway |
| publicIP | object | Public IP of Application Gateway |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

This section details which properties need to be set and what values should be used to create a compliant service.
They are already implemented in the provided template but this information can be used if you wish to create your
own template.

_Sometimes a so-called DINE (DeployfNotExists) policy ends up in failed state for your Application Gateway.
According to SECO team this is a known, but not yet resolved issue.
To resolve a DINE non-compliancy for your own resource,
you must navigate to the non-compliant policy in your resources group,
and select "create exemption" form its context menu._

### sku

This policy is enforced in Critical landing zones only.

| Name | Description | Value |
| :-- | :-- | :-- |
| tier | Sku tier must be WAF_v2. | 'WAF_v2' |

### sslPolicy

| Name | Description | Value |
| :-- | :-- | :-- |
| policyType | The policy type must be set to specific value.  | 'Predefined' |
| policyName | The policy name must be set to specific value. | 'AppGwSslPolicy20220101' |

### sslCertificates

| Name | Description | Value |
| :-- | :-- | :-- |
| keyVaultSecretId | The secret reference must be set to a value.  | {key_ref} |

### backendHttpSettingsCollection

| Name | Description | Value |
| :-- | :-- | :-- |
| protocol | The protocol must not be Http.  | Https |

### httpListeners

| Name | Description | Value |
| :-- | :-- | :-- |
| protocol | The protocol must not be Http.  | Https |

### webApplicationFirewallConfiguration

This policy is enforced in Critical landing zones only.

| Name | Description | Value |
| :-- | :-- | :-- |
| enabled | WAF must be enabled. | true |
| firewallMode | WAF must be in prevention mode. | 'Prevention' |

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/65788/AAB-Application-Gateway-v1>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/templates/microsoft.network/applicationgateways?pivots=deployment-language-bicep>
- <https://learn.microsoft.com/en-us/azure/web-application-firewall/ag/application-gateway-crs-rulegroups-rules?tabs=owasp32#owasp32>
