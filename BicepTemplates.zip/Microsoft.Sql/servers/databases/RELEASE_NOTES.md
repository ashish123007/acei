# Release and Upgrade Notes  

## Version 2.4.0

- Released 2025 Feb 25
- Description: Updated the SQL Bicep API
- Story: [5041861](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5041861)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 2.3.0

- Released 2024 July 25
- Description: Updated new release version.
- Story: [3816496](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3816496)

---

## Version 2.2.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)
- Story: [2794896](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2794896)

---

## Version 2.1.2

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 2.1.1

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
    Stable build failure fixed
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2167088)

---

## Version 2.1.0

- Released: 2023 Feb 08
- Description: Made skuName a free field.
Activated retry trigger in nightly.
- Story: [1986612](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1986612)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

## Version 2.0.1

- Released: 2022 Nov 15
- Description: Added the base template for SQL Database.
Added readme consumption validation.
- Story: [1314936](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1314936)
