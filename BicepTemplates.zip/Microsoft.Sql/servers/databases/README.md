# SQL Database

This repository can be used to deploy an instance of SQL Database. [Learn more](https://learn.microsoft.com/en-us/azure/azure-sql/database/sql-database-paas-overview?view=azuresql)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/sql-database(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99178&branchName=main)

## Pre-Requisities

- An Azure SQL Server to store the data of the database [Learn more](https://learn.microsoft.com/en-us/azure/templates/microsoft.sql/servers?pivots=deployment-language-bicep)

## Usage Guidance for existing SQL server

## Usage Guidance for creation of both SQL server and (one or more) databases

Use the instructions given in the SQL server repository, see [SQL server](https://dev.azure.com/cbsp-abnamro/Azure/_git/BicepTemplates?path=Microsoft.Sql/servers/README.md&_a=preview)

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module configurationStore 'br/FSCPRegistry:bicep/modules/dip/core/sql-database:2.4.0' = {
  name: '<name of deployment>'
  params: {
    name: '<database name>'
    serverName: '<name of the existing server>'
   }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| name | string | The name of the database. |
| serverName | string | The name of the existing SQL Server. |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| collation | string | SQL_Latin1_General_CP1_CI_AS | The collation of the SQL Database defines the rules that sort and compare data, and cannot be changed after SQL Database creation.|
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| location | string | resourceGroup().location | Location for all Resources. |
| maxSizeGigabytes | int | 500 |The max size of the SQL Database expressed in gigabytes. |
| numberOfReplicas | int | 0 | The number of secondary replicas associated with the SQL Database that are used to provide high availability. |
| requestedBackupStorageRedundancy | string | Geo | The storage account type to be used to store backups for this database. |
| skuName | string | S0 | The SKU name of the SQL Database. |
| zoneRedundant | bool | false | Whether this SQL Database is zone redundant, which means the replicas of this SQL Database will be spread across multiple availability zones. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| name | string | The name of the created resource. |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |
| sqlDatabase | object | SQL database resource as an object  |

## Policy Details

### SKUSetting

| Name | Description | Value |
| :-- | :-- | :-- |
| sku | This setting should be set to either "Standard"(For Develop & Test) "Business Critical" or "Premium" ( For Acceptance & Production) SKU names | S0 |

### Storage

| Name | Description | Value |
| :-- | :-- | :-- |
| requestedBackupStorageRedundancy | The 'Backup storage redundancy' setting needs to be set to 'Geo-redundant backup storage' | Geo |

## Network Connectivity

### Azure Public

From Azure SQL Database to and from Azure Public over TCP 1443 using TLS1.3 encryption.

### Azure Private

- From Azure Private to Azure SQL Database via the NSP v2 Azure Firewall over TCP 1433 using TLS1.3 encryption.
- From Azure Private to Azure SQL Database via Private Link.

More information can be found on [here](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/173/Product-Description#network-topology).

## Reference

- <https://learn.microsoft.com/en-us/azure/azure-sql/database/single-database-overview?view=azuresql>
- <https://learn.microsoft.com/en-us/azure/azure-sql/database/sql-database-paas-overview?view=azuresql>
