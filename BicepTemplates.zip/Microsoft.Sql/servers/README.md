# SQL Server

This module creates Azure Sql Database Server. [Learn more](https://learn.microsoft.com/nl-nl/azure/azure-sql/azure-sql-iaas-vs-paas-what-is-overview?view=azuresql)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/sql-server(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99179&branchName=main)

## Pre-Requisities

The pre-requisities to use this module are:

- An Azure AD administrator (group) to connect to the database [Learn more](https://learn.microsoft.com/en-us/azure/azure-sql/database/authentication-aad-overview?view=azuresql).
- Key Vault for CMK
- Key for CMK
- User managed identity for CMK [Learn more](https://learn.microsoft.com/en-us/azure/azure-sql/database/authentication-azure-ad-user-assigned-managed-identity?view=azuresql)

## Usage Guidance

### Available Submodules

- [Database](./databases/README.md)

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module sqlServerModule 'br/FSCPRegistry:bicep/modules/dip/core/sql-server:3.0.1' = {
  name: '<name of deployment>'
  params: {
    name: '<name of server>'
    aadAdminName: '<aadAdminName>'
    aadAdminType: '<aadAdminType>'
    aadAdminObjectId: '<aadAdminObjectId>'
    userAssignedIdentities: '<userAssignedIdentities>'
    keyId: '<keyId>'
    intendedBackupInterval: '<Intended Backup Interval duration>'
   }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| aadAdminName | string | The name of the Azure AD admin for the SQL Server. |
| aadAdminObjectId | string | The object ID of the Azure AD admin. |
| aadAdminType | string | The principal type of the Azure AD admin. |
| keyId | string | The CMK URI of the key to use for encryption. |
| intendedBackupInterval | string | The intendedBackupInterval tag must be set to one of the following allowed values: Continuous, 1h, 4h, 1d, 7d, 14d, 30d & None. |
| name | string | The name of the SQL Server. |
| userAssignedIdentities | string | The ID(s) to assign to the resource. |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalDatabaseProperties | object | [] | Additional SQL Server Properties. |
| databases | array | [] | The databases to create in the server. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| firewallRules | array | [] | Array of FirewallRule Objects(firewallRuleName, startIpAddress, endIpAddress) for allowing connectivity to sql server. For up to date IPs you can also integrate with the centrally provided [Firewall Automation](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/93970/Firewall-Rules-Retrieve-and-set-firewall-IP-ranges)|
| location | string | resourceGroup().location | Location for all Resources. |
| publicNetworkAccess | string | Disabled | Whether public network access is enabled or disabled.|
| tdekeyid | string | keyId | TDE KeyID . |
| autoRotationEnabled | bool | true | Enabling TDE autorotate on the server. |
| serverKeyType | string | AzureKeyVault | The encryption protector type like ServiceManaged or AzureKeyVault.|
| resourceTags | object| {} | User provided resource tags in the form of json. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| location | string | The location the resource was deployed into. |
| name | string | Returning name of the Sql Server |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |
| sqlServer | object | Returning object of the Sql Server |

## Policy Details

This section details which properties need to be set and what values should be used to create a compliant service.
They are already implemented in the provided template but this information can be used if you wish to create your
own template.

### Identity

| Name | Description | Value |
| :-- | :-- | :--|
| type | The identity type. | 'UserAssigned' |
| userAssignedIdentities | List of user assigned identities for the server | string |

### EncryptionConfiguration

| Name | Description | Default Value |
| :-- | :-- | :-- |
| keyId | The CMK URI of the key to use for encryption. | string |
| userAssignedIdentities | User assigned identity to use to authenticate to customer's key vault. | [] |

## Network Connectivity

### Azure Public

From Azure Public PaaS services to Azure Sql Server over HTTPS using TLS1.2.

### Azure Private

From Azure Private to Azure Sql Server via the Azure Firewall Network Secure Perimeter over HTTPS using TLS 1.2.

## Reference

- <https://confluence.int.abnamro.com/display/VEEJH/DIP+Bicep+FAQ>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64797/AAB-SQL-Database-v1>
