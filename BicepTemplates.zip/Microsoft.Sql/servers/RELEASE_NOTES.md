# Release and Upgrade Notes  

## Version 3.0.1

- Released: 2025 Feb 26
- Description: Added dependency
- Story: [5048205](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5048205/)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

## Version 3.0.0

- Released: 2025 Feb 25
- Description: Added the IntendedBackupInterval Manadatory tag
- Story: [4993374](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4993374/)

### Upgrade steps to 3.0.0

Upgrade of the module needs parameter intendedBackupInterval enabled.
The parameters for intendedBackupInterval -`Continuous`, `1h`, `4h`, `1d`, `7d`, `14d`, `30d` & `None`

---

## Version 2.6.0

- Released: 2025 Jan 16
- Description: Added a sub resource to enable TDE auto rotation.
- Story: [4828076](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/4828076)

---

## Version 2.5.0

- Released: 2024 Dec 06
- Description: property, restrictOutboundNetworkAccess: 'Enabled' by default now.
- Story: [4703043](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/4703043)

---

## Version 2.4.0

- Released: 2024 Jan 15
- Description: Implemented cost recommendations.
- Story: [3816496](https://dev.azure.com/cbsp-abnamro/Azure/_sprints/taskboard/FSCP%20Automation%20Team/Azure/2024/IP11/Sprint%202/IP11%20S2%20-%20Automation?workitem=3816496)

---

## Version 2.3.0

- Released: 2024 Jan 15
- Description: added `firewallRules` parameter to support firewall rules.
Prevent role assignment leakage.
- Story: [3126272](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3126272)
- Story: [3457882](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3457882)

---

## Version 2.2.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)
- Story: [2794896](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2794896)

---

## Version 2.1.4

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 2.1.3

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 2.1.2

- Released: 2023 May 16
- Description : Fixed  Use-parent-property warning.
- Story: [2214054](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2214054)

---

## Version 2.1.1

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2167088)

---

## Version 2.1.0

- Released: 2023 Feb 09
- Description: Removed sku limitation in database subresource.
Activated retry trigger in nightly.
- Story: [1986612](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1986612)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 2.0.1

- Released: 2023 Jan 30
- Description: Added name as an output parameter.
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_sprints/taskboard/BLK0003414/GRD0001007/BLK0003414/Sprint%20158?workitem=1935001)

---

## Version 2.0.0

- Released: 2022 Nov 15
- Description: Added the base template for SQL server
- Story: [1314936](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1314936)
- Story: [1847324](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1847324)
- Story: [1948087](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1948087)
