# Event Hub

This repository can be used to provision a Event Hub Namespace. [Learn more](https://learn.microsoft.com/en-us/azure/event-hubs/event-hubs-about)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/event-hub(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99165&branchName=main)

## Pre-Requisities

- Azure Key Vault as a keySource for encryption
- RSA2048 key for encryption
- User Assigned Managed Identity to access the Key Vault

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module eventHubModuleDeploy 'br/FSCPRegistry:bicep/modules/dip/core/event-hub:3.3.2' = {
  name: '<name of deployment>'
  params: {
    name: '<name of the resource>'
    keyVaultUserAssignedIdentity: '<ARM ID of Managed User Identity>'
    keyName: '<Key Name>'
    keyVaultUri: '<KeyVault URI>'
    privateEndpointVnetResourceGroup: '<Private Endpoint Vnet RG>'
    privateEndpointVnetName: '<Private Endpoint Vnet Name>'
    privateEndpointSubnetName: '<Private Endpoint Subnet Name>'
  }
}
```

**Required parameters**

| Parameter Name | Type |  Description |
| :-- | :-- | :-- |
| keyName | string  | Name of the Key from KeyVault for encryption |  
| keyVaultUserAssignedIdentity | string  | ARM ID of Managed User Identity selected to access the KeyVault  |
| keyVaultUri | string  | Uri of KeyVault for encryption |
| name | string  | The Resource Name |
| privateEndpointSubnetName | string  | Private Endpoint Subnet Name |
| privateEndpointVnetName | string  | Private Endpoint Vnet Name |
| privateEndpointVnetResourceGroup | string  | Private Endpoint Vnet RG |

**Optional parameters**

| Parameter Name | Type | Default Value |  Description |
| :-- | :-- | :-- | :-- |
| additionalEventHubProperties | object | {} | Additional Event Hub Properties |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| disableLocalAuth | bool | true | disable local authentication |
| ipRules | array | list of valid IPRule objects | Sets the IP ACL rules. Array items may be filled based on the client's need, and it must be selected from the corresponding policy to be compliant. [Firewall Settings DENY policy](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetailBlade/definitionId/%2Fproviders%2Fmicrosoft.management%2Fmanagementgroups%2Fc7c0086e-e721-4f52-bcf8-effd9a2d53f0%2Fproviders%2Fmicrosoft.authorization%2Fpolicydefinitions%2Faab-event-hubs-namespace-firewall-settings-deny-v1). For up to date IPs you can also integrate with the centrally provided [Firewall Automation](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/93970/Firewall-Rules-Retrieve-and-set-firewall-IP-ranges)|
| location | string | Resource Group Location | The Geo-location where the resource lives |
| requireInfrastructureEncryption  | bool | true | enable infrastructure encryption |
| skuTier | string | 'Premium' | The SKU name of the Event Hub |
| trustedServiceAccessEnabled | bool | false | You must enable "Allow trusted Microsoft services to bypass this firewall" setting in Event Hubs so that the Azure Monitor diagnostic settings service is granted access to your Event Hubs resources. |
| zoneRedundant | bool | true | enable zone redundant |
| keyVersion | string  | '' | Version of the Key from KeyVault for encryption |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| eventHubNamespace | object | Event Hubs Namespace |
| location | string | The location the resource was deployed into. |
| name | string | Name of the Event Hubs Namespace |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### Event Hub Namespace Resource

| Name | Description | Value |
| :-- | :-- | :-- |
| identity | The type of managed identity used. The valid value is 'UserAssigned' | UserAssignedIdentityProperties |
| properties | Properties of Event Hub | EventHUbNamespaceProperties |
| sku | Properties of SKU | SBSku |

### SBSku

| Name | Description | Value |
| :-- | :-- | :-- |
| name | Name of this SKU. | 'Premium' |
| tier | The billing tier of this particular SKU. | 'Premium' |

### UserAssignedIdentityProperties

| Name | Description | Value |
| :-- | :-- | :-- |
| type | The type of managed identity used. | 'UserAssigned' |
| userAssignedIdentities | ARM ID of user Identity selected for encryption | object |

### EventHUbNamespaceProperties

| Name | Description | Value |
| :-- | :-- | :-- |
| encryption | Properties of BYOK Encryption description | Encryption |

### Encryption

| Name | Description | Value |
| :-- | :-- | :-- |
| keySource | Enumerates the possible value of keySource for Encryption | 'Microsoft.KeyVault' |
| keyVaultProperties | Properties of KeyVault | KeyVaultProperties[]    |

### KeyVaultProperties

| Name | Description | Value |
| :-- | :-- | :-- |
| keyName | Name of the Key from KeyVault | string |
| keyVaultUri | Uri of KeyVault | string |
| keyVersion | Version of KeyVault | string |

## Network Connectivity

### Azure Public

Kafka Protocol (TCP/9093)

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/4218/Product-Description>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/templates/microsoft.eventhub/namespaces?pivots=deployment-language-bicep>
