# Release and Upgrade Notes

## Version 3.3.2

- Released: 2025 Jun 02
- Description: updated version due to BICEP PEP upgrade
- Story: [5444323](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5444323)

---

## Version 3.3.1

- Released: 2025 Mar 11
- Description: updated version due to BICEP PEP upgrade
- Story: [5101539](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5101539)

---

## Version 3.3.0

- Released: 2025 Feb 19
- Description: New API versions.
- Story: [5016990](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5016990)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 3.2.2

- Released: 2024 Dec 09
- Description: updated version due to BICEP  PEP upgrade
- Story: [4707678](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4707678)

---

## Version 3.2.1

- Released: 2024 Oct 28
- Description: updated version due to PEP upgrade
- Story: [4470596](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4470596)

---

## Version 3.2.0

- Released: 2024 July 29
- Description: Updated new API version
- Story: [3599952](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3599952)

---

## Version 3.1.1

- Released: 2024 May 10
- Description: updated version due to PEP upgrade
- Story: [3616182](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3616182)

---

## Version 3.1.0

- Released: 2024 Apr 24
- Description: added `trustedServiceAccessEnabled` parameter to grant the Azure
Monitor diagnostic settings access to your Event Hubs resources.
[Diagnostic settings in Azure Monitor | Destination limitations](https://learn.microsoft.com/en-us/azure/azure-monitor/essentials/diagnostic-settings?WT.mc_id=Portal-Microsoft_Azure_Monitoring#destination-limitations)
- Story: [3553442](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3553442)

---

## Version 3.0.0

- Released: 2024 Jan 15
- Description: Updated ipRules input types to be compatible with firewall automation.
Prevent role assignment leakage.
- Story: [3126272](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3126272)
- Story: [3457882](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3457882)

### Upgrade steps from 2.1.0 to 3.0.0

- Update the value for the parameter `ipRules` as ipRule-objects. So

```json
"ipRules": {
    "value": [
        "10.11.12.0/28",
        "10.11.13.0/28"
    ]
}
```

becomes:

```json
"ipRules": {
    "value": [ 
        {
            "action": "Allow",
            "value": "10.11.12.0/28"
        }, 
        {
            "action": "Allow",
            "10.11.13.0/28"
        }
    ]
}  
```

---

## Version 2.1.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 2.0.7

- Released 2023 August 8
- Upgraded Bicep versions.
Use only local references for submodules.
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 2.0.6

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 2.0.5

- Released: 2023 July 13
- Description: updated PLE version in the template from 2.2.0 to 2.2.1.
- Story: [2475562](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 2.0.4

- Released: 2023 July 03
- Description: Private Endpoint module version used has been updated.
- Story: [2438072](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2438072)

---

## Version 2.0.3

- Released: 2023 Apr 23
- Description: nightly-builds-fix after validation fix.
- Story: [2221485](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2221485)
- Story: [2389206](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2389206)

---

## Version 2.0.2

- Released: 2023 Apr 20
- Description: Fixed warning on location
- Story: [2195152](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2195152)

---

## Version 2.0.1

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 2.0.0

- Released: 2023 Jan 30
- Description: Added name as an output parameter and changed input parameter eventHubNamespaceName to name.
Activated retry trigger in nightly.
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1935001)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 1.0.3

- Released: 2022 Nov 28
- Description: Added consume-readme test and added default for keyVersion parameter.
- Story: [1581912](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1581912/)

---

## Version 1.0.2

- Released: 2022 Nov 11
- Description: NetworkRuleSets and EventHubs Namspace versions updated to 2021-11-01
- Story: [1643361](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1643361/)

---

## Version 1.0.1

- Released: 2022 Oct 20
- Description: New Resource Names

---

## Version 1.0.0

- Released: 2022 Oct 04
- Description: Initial release of Event Hub Namespace bicep
