# Release and Upgrade Notes

## Version 2.3.2

- Released: 2025 Jun 02
- Description: updated version due to BICEP  PEP upgrade
- Story: [5444323](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5444323)

---

## Version 2.3.1

- Released: 2025 Mar 11
- Description: updated version due to BICEP PEP upgrade
- Story: [5101539](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5101539)

---

## Version 2.3.0

- Released: 2025 Feb 19
- Description: New API versions.
- Story: [5016990](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5016990)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 2.2.4

- Released: 2024 Dec 09
- Description: updated version due to BICEP  PEP upgrade
- Story: [4707678](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4707678)

---

## Version 2.2.3

- Released: 2024 Oct 28
- Description: updated version due to PEP upgrade
- Story: [3616182](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3616182)

---

## Version 2.2.2

- Released: 2024 May 10
- Description: updated version due to PEP upgrade
- Story: [3616182](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3616182)

---

## Version 2.2.1

- Released: 2024 Apr 22
- Description: Updated BICEP key vault version
to 2023-07-01.
- Story: [3543675](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3543675)

---

## Version 2.2.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
Prevent role assignment leakage.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)
- Story: [3457882](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3457882)

---

## Version 2.1.4

- Released 2023 August 9
- Explicitely pass location parameter to all sub resources,
to prevent linter error.
Use only local references for submodules.
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 2.1.3

- Released 2023 August 8
- Upgraded Bicep versions
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)

---

## Version 2.1.2

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 2.1.1

- Released: 2023 July 13
- Description: updated PLE version in the template from 2.2.0 to 2.2.1.
- Story: [2475562](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 2.1.0

- Released: 2023 July 04
- Description: unique deployment names for private endpoint sub resource.
- Story: [2389017](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2389017)

---

## Version 2.0.6

- Released: 2023 July 03
- Description: Private Endpoint module version used has been updated.
- Story: [2438072](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2438072)

---

## Version 2.0.5

- Released: 2023 May 10
- Description: nightly-builds-fix for version
- Story: [2273734](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2273734)

---

## Version 2.0.4

- Released: 2023 May 01
- Description: DINE policy Exemption
- Story: [2238482](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2238482)

---

## Version 2.0.3

- Released: 2023 Apr 23
- Description: nightly-builds-fix after validation fix.
- Story: [2221485](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2221485)

---

## Version 2.0.2

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 2.0.1

- Released: 2023 Jan 30
- Description: Added name as an output parameter.
Activated retry trigger in nightly. Added pre-requisites resources to the pipeline
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1935001)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)
- Story: [2116283](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2116283)

---

## Version 2.0.0

- Released: 2022 Nov 28
- Description: Added readme-consume test and removed unneeded parameters.
- Story: [1581912](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1581912)

### Upgrade steps from 1.4.1 to 2.0.0

1. Remove parameter `privateEndpointGroupId`
1. Remove parameter `resourceType`

---

## Version 1.4.1

- Released: 2022 Nov 14
- Description: Fixed Resource API version.
- Story: [1637060](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1637060)

## Version 1.4.0

- Released: 2022 Oct 11
- Description: Added PLE and Tested in Acceptance

---

## Version 1.1.3

- Released: 2022 Sep 21
- Description: Fixed linter issues.
- Story: [1425245](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1425245)

---

## Version 1.1.2

- Released: 2022 Sep 14
- Description: Fixed linter issues.
- Story: [1393321](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1393321)

---

## Version 1.1.1

- Released: 2022 Sep 12
- Description:  Fixed name in nightly.

### Version 1.1.0

- Released: 2022 Sep 08
- Description: Fixed typos and name.

---

## Version 1.0.0

- Released: 2022 Sep 01
- Description: Initial release of Service Data Factory.
