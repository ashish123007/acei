# Data Factory

This repository can be used to deploy an instance of Azure Data Factory. [Learn more](https://azure.microsoft.com/en-us/services/data-factory/#overview)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/datafactory(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99162&branchName=main)

## Pre-Requisities

- Managed Identity for the Data Factory to reach Key vault.
[Learn more](https://docs.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/overview)
- Azure Key Vault for the Customer Managed Key (CMK) requirement of the Data Factory policies.
 You need to provide identityclientid and keyidentifier for Data Factory to reach Key vault.
 [Learn more](https://docs.microsoft.com/en-us/azure/data-factory/enable-customer-managed-key)

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module dataFactory 'br/FSCPRegistry:bicep/modules/dip/core/data-factory:2.3.2'  = {
  name: '<name of deployment>'
  params: {
    name: '<name of instance>'
    vnetResourceGroup: '<vnetResourceGroup>'
    vnetName: '<vnetName>'
    privateEndpointSubnetName: '<privateEndpointSubnetName>'
    privateEndpointName: '<privateEndpointName>'
    userAssignedIdentities: '<user assigned identity>'
    cMKKeyName: '<KeyName for CMK>'
    cMKKeyVaultResourceId: '<ResourceId for the CMK keyvault>'
    cMKUserAssignedIdentityResourceId: '<Identity URI of Datafactory Service.'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| name | string | Data Factory name. |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionaldatafactoryProperties | object | {} | Additional DataFactory Properties. |
| cMKKeyName | string | '' | The name of the key in Azure Key Vault to use as Customer Managed Key. |
| cMKKeyVaultResourceId |string | '' | The url of the Azure Key Vault used for CMK. |
| cMKKeyVersion | string | '' | The version of the customer managed key to reference for encryption. |
| cMKUserAssignedIdentityResourceId | string | '' | Identity URI of Datafactory Service. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| identityType | string | 'UserAssigned' | Enables system or user managed identity on the resource. |
| location| string |  resourceGroup().location | Location of your datafactory. |
| privateEndpointName | string | '' | private endpoint name of the resource. |
| privateEndpoints | array | [] | Private endpoint description. |
| privateEndpointSubnetName | string | '' | Private endpoint subnet name. |
| publicNetworkAccess| string | 'Disabled' | Whether or not public network access is allowed for the data factory. |
| resourceTags| object | {} | User provided resource tags in the form of json. |
| userAssignedIdentities | string | '' | The Resource Id of user assigned identity for the Datafactory. |
| vnetName | string | Vnet name. | '' |
| vnetResourceGroup | string | '' | Vnet resource group name. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| dataFactory | object | Data Factory resource as a object |
| location | string | The location the resource was deployed into. |
| name | string | Name of the Data Factory resource |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### Factories

| Name | Description | Default Value |
| :-- | :-- | :-- |
| name | The resource name | string |
| identity | Managed service identity of the factory. | FactoryIdentity |

### FactoryIdentity

| Name | Description | Default Value |
| :-- | :-- | :-- |
| type | The identity type. | 'UserAssigned' (required) |
| userAssignedIdentities | List of user assigned identities for the factory. | string|

### FactoryProperties

| Name | Description | Default Value |
| :-- | :-- | :-- |
| encryption | Properties to enable Customer Managed Key for the factory. | EncryptionConfiguration |
| publicNetworkAccess | Whether or not public network access is allowed for the data factory. | 'Disabled' |

### EncryptionConfiguration

| Name | Description | Default Value |
| :-- | :-- | :-- |
| identity | User assigned identity to use to authenticate to customer's key vault. If not provided Managed Service Identity will be used. | CMKIdentityDefinition |
| keyName | The name of the key in Azure Key Vault to use as Customer Managed Key.| string |
| keyVersion | The version of the key used for CMK. If not provided, latest version will be used. | string|
| vaultBaseUrl | The url of the Azure Key Vault used for CMK. | string |

### CMKIdentityDefinition

| Name | Description | Default Value |
| :-- | :-- | :-- |
|userAssignedIdentity| The resource id of the user assigned identity to authenticate to customer's key vault. | string|

## Network Connectivity

Azure Data Factory is a PaaS and does not have the option of a built-in firewall or VNet Service Endpoints so
isolation on network level is not possible.

### The allowed traffic flows are the following

## Public

From Data Factory to/from Azure Services (public).

## Private

From Azure Private to Data Factory using the ExpressRoute (private and public peering). Routing is controlled using
the Palo Alto NGFW which contains a whitelist of allowed traffic flows.

## OnPrem

From on-premises (WorkSquare and WorkSquare-Guest) to Data Factory using the on-premises forward proxy.

All other traffic flows are blocked. A firewall change is required to allow application specific traffic flows.

The Self-Hosted Integration Runtime can be deployed either on-premises or in Azure Private.

## Azure service(s) in scope

1. Azure Data Factory
1. Self-hosted Integration Runtime
1. Azure services needed (prerequisites)
1. Azure Active Directory
1. Related Azure services
1. Azure ExpressRoute if connectivity from Azure Private is required for the solution
(e.g. when leveraging a Self-hosted Integration Runtime)

## When creating a Blob storage trigger

1. Azure Storage Account
1. Azure Event Grid
1. Other Limitations
1. Azure-SSIS Integration Runtime is not part of the product CBSP Azure Data Factory v4.
1. Automated deployment of Self-hosted Integration Runtime is out of scope (see Appendix A: Self-hosted Integration
Runtime on Azure (optional) for deployment approach).
1. The credentials for the Linked Services “HDInsight” & “HDInsight primary storage” are set by CBSP and not exposed to
the solution team.

## Network Reference

<https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/1912/Product-Description?anchor=network-topology>

## Reference

- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://docs.microsoft.com/en-us/azure/templates/microsoft.datafactory/factories?pivots=deployment-language-bicep>
