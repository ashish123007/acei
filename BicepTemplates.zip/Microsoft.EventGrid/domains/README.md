# Event Grid Domain

This repository can be used to provision a Event Grid Domain. [Learn more](https://learn.microsoft.com/en-us/azure/event-grid/overview)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/eventgrid-domain(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99166&branchName=main)

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module eventGridDomainModuleDeploy 'br/FSCPRegistry:bicep/modules/dip/core/eventgrid-domains:1.3.2' = {
  name: '<name of deployment>'
  params: {
    name: '<name of the resource>'
    privateEndpointVnetResourceGroup: '<Private Endpoint Vnet RG>'
    privateEndpointVnetName: '<Private Endpoint Vnet Name>'
    privateEndpointSubnetName: '<Private Endpoint Subnet Name>'
  }
}
```

**Required parameters**

| Parameter Name | Type |  Description |
| :-- | :-- | :-- |
| name | string  | The Resource Name |
| privateEndpointSubnetName | string  | Private Endpoint Subnet Name |
| privateEndpointVnetName | string  | Private Endpoint Vnet Name |
| privateEndpointVnetResourceGroup | string  | Private Endpoint Vnet RG |

**Optional parameters**

| Parameter Name | Type | Default Value |  Description |
| :-- | :-- | :-- | :-- |
| additionalEventGridDomainProperties | object | {} | Additional Event Grid Domain Properties |
| disableLocalAuth | bool | true | This boolean is used to enable or disable local auth. When the property is set to true, only AAD token will be used to authenticate if user is allowed to publish to the domain. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| identityType | string | None |The type of managed identity used.|
| inboundIpRules | array | | This can be used to restrict traffic from specific IPs instead of all IPs. Note: These are considered only if PublicNetworkAccess is enabled. |
| location | string | Resource Group Location | The Geo-location where the resource lives |
| resourceTags | object| {} | User provided resource tags in the form of json. |
| userAssignedIdentityId | string | | The Resource Id of user assigned identity  e.g. /subscriptions/XXXX-XXX-XXX-XXXX-XXXXX/resourceGroups/XXXX-d-rg/providers/Microsoft.ManagedIdentity/userAssignedIdentities/XXXX-uam |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| eventGridDomain | object | Event Grid Domain Object |
| location | string | The location the resource was deployed into. |
| name | string | Name of the Event Grid Domain |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### Event Grid Domain Resource

| Name | Description | Value |
| :-- | :-- | :-- |
| properties | Properties of Event Grid Domain | EventGridDomainProperties |

### EventGridDomainProperties

| Name | Description | Value |
| :-- | :-- | :-- |
| inboundIpRules | This can be used to restrict traffic from specific IPs instead of all IPs. Note: These are considered only if PublicNetworkAccess is enabled. | array of allowed valid IPs |
| disableLocalAuth | This boolean is used to enable or disable local auth. Value should be set to true, only AAD token will be used to authenticate if user is allowed to publish to the domain. | true |

## Network Connectivity

<https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/83946/AAB-Event-Grid-v1>

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/83946/AAB-Event-Grid-v1>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/templates/microsoft.eventgrid/domains?pivots=deployment-language-bicep>
