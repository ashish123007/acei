# Release and Upgrade Notes

## Version 7.0.1

- Released: 2025 May 27
- API Update from 2024-01-01 to 2025-01-01 for Microsoft.Storage/storageAccounts.
- Change done by auto-heal-function.

---

## Version 7.0.0

- Released: 2025 Mar 03
- Description: Added the IntendedBackupInterval Manadatory tag
- Story: [4993374](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4993374/)

### Upgrade steps to 7.0.0

Upgrade of the module needs parameter intendedBackupInterval enabled.
The parameters for intendedBackupInterval -`Continuous`, `1h`, `4h`, `1d`, `7d`, `14d`, `30d` & `None`

---

## Version 6.2.0

- Released: 2025 Feb 19
- Description: New API versions
- Story: [5016990](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/5016990)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

## Version 6.1.0

- Released: 2024 Sep 26
- Description: Updated resource API version
- Story: [4255496](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3816496)

## Version 6.0.0

- Released: 2024 Jul 26
- Description: AccessTier has been Changed to COOL from HOT based on
FinOps Recommendation but teams can change based on there requirement to HOt for HIgher environments.
- Story: [3816496](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3816496)

## Version 5.3.0

- Released: 2024 Jul 24
- Description: Implemented Finops recommendations for cost Effectiveness
- Story: [3816496](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3816496)

---

## Version 5.2.0

- Released: 2024 Feb 16
- Description: Updated Bicep version.
Prevent role assignment leakage.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3269390)
- Story: [3457882](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3457882)

---

## Version 5.1.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 5.0.1

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 5.0.0

- Released: 2023 Jul 07
- Description: New version because of new property added for enabling Hierarchical Namespace.
upgrade steps: Remove 'isHnsEnabled' from 'additionalProperties' when applicable and set the 'standard' parameter to 'true'.
- Task: [2448277](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2448277)

---

## Version 4.0.4

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2167088)
- Story: [2389206](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2389206)

---

## Version 4.0.3

- Released: 2023 Feb 14
- Description: Updated Microsoft API version.
Activated retry trigger in nightly.
- Story: [2000837](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2000837)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 4.0.2

- Released: 2023 Jan 30
- Description: Added name as an output parameter.
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_sprints/taskboard/BLK0003414/GRD0001007/BLK0003414/Sprint%20158?workitem=1935001)

---

## Version 4.0.1

- Released: 2022 Nov 11
- Description: To make Audit policy (Customer Managed Keys Queue and Table Storage AUDIT v1
) compliant  
Fixed post-publish validator
- Story: [1640360](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1640360)
[1790302](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1790302)
.

---

## Version 4.0.0

- Released: 2022 Nov 01
- Description: Changed several parameter names in line with Microsoft.
storageAccountKind -> kind,
storgeAccountAccessTier -> accessTier,
storageAccountSku -> sku and storageAccountName -> name.
- Story: [1556243](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1556243).

### Version 3.1.0

- Released: 2022 Oct 31
- Description: Added whitelisting for subnetids.
- Story: [1521315](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1521315).

---

## Version 3.0.0

- Released: 2022 Oct 19
- Description: Initial release of Storage Account bicep.
