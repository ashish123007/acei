# Storage Account

This repository can be used to deploy an instance of Storage Account. [Learn more](https://learn.microsoft.com/en-us/azure/storage/blobs/)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/storage-account(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99182&branchName=main)

## Pre-Requisities

- Azure Key Vault as a keySource for encryption with CMK.
- RSA2048 key with the required expiry date, to enable CMK [Learn more](https://learn.microsoft.com/en-us/azure/storage/common/customer-managed-keys-overview).
- Managed Identity for the Storage Account [Learn more](https://docs.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/overview).
- Access policy that allows the Managed Identity to Unwrap Key, Get, Wrap Key from the Keyvault.

## Usage Guidance

### Prerequisites

If you don't have all the Prerequisites yet, you can also choose to create a pipeline step.
In the file `pipelines/jobs.pre-deployment-setup.yml` you will find an example on how to do this.

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module storageAccount 'br/FSCPRegistry:bicep/modules/dip/core/storage-account:7.0.1' = {
  name: '<name of deployment>'
  params: {
      name: '<storageAccountName>'
      keyName: '<keyName>'
      keyVaultUri: '<keyVaultUri>'
      userAssignedIdentities: '<userAssignedIdentities>'
      intendedBackupInterval: '<Intended Backup Interval duration>'
  }
}
```

#### Input parameters

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| intendedBackupInterval | string | The intendedBackupInterval tag must be set to one of the following allowed values: Continuous, 1h, 4h, 1d, 7d, 14d, 30d & None. |
| keyName | string | The name of Key Vault key which is used for encryption. |
| keyVaultUri | string | The key vault URI for customer-managed key. |
| name | string | Name of the Storage Account to create. |
| userAssignedIdentities | string | Property specifying an existing user managed identity. |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| accessTier | string | Cool | Storage Account Access Tier. |
| additionalProperties | object | {} | Additional Storage Account Properties. |
| allowBlobPublicAccess | bool | false |  Indicates whether public access is enabled for all blobs or containers in the storage |
| allowSharedKeyAccess | bool | false | All requests, including shared access signatures, must be authorized. |
| allowTrustedAzureServices | bool | true |  Whether to allow Azure services on the trusted services list to access this Storage Account. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| identityType | string | userAssigned | The type of managed identity used.  |
| ipRules | array | [{action: 'Allow'value: '164.140.188.224/28'}{action: 'Allow'value: '167.202.201.0/27'}{action: 'Allow'value: '164.140.203.224/28'}] | An array of IPv4 addresses or IPv4 address ranges in CIDR format. Array items may be filled based on the client's need, and it must be selected from the corresponding policy to be compliant. [Firewall Setting Deny Policy](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetailBlade/definitionId/%2Fproviders%2FMicrosoft.Management%2Fmanagementgroups%2Fc7c0086e-e721-4f52-bcf8-effd9a2d53f0%2Fproviders%2FMicrosoft.Authorization%2FpolicyDefinitions%2Faab-sa-firewall-settings-deny-v1). |
| isHnsEnabled | bool | false | Enable Hierarchical Namespace. |
| isNfsV3Enabled | bool | false | Enable network file system v3 needs to be disabled |
| kind  | string | StorageV2 | Type of Storage Account to create. |
| location | string | resourceGroup().location | Location for all Resources. |
| minimumTlsVersion | string | TLS1_2 | Set the minimum TLS version on request to storage. |
| publicNetworkAccess | string | Disabled | Whether or not public network access is allowed for this resource. |
| requireInfrastructureEncryption | bool | true | A secondary layer of encryption with platform managed keys for data at rest. |
| resourceTags | object | {} | User provided resource tags in the form of json. |
| sku | string | Standard_LRS | Storage Account Sku Name. |
| supportsHttpsTrafficOnly | bool | true | Allows HTTPS traffic only to storage service if sets to true. |
| virtualNetworkRules | array | [] | Sets the virtual network rules. |

#### Output parameters

| Output | type | Description |
| :-- | :---   | :-- |
| location | string | The location the resource was deployed into. |
| name | string | Name of the storageAccount resource |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |
| storageAccount | object | storageAccount resource as an object |

## Policy Details

### Encryption

| Name | Description | Value |
|  :-- | :-- | :-- |
| keySource | 'Microsoft.Keyvault' | string |
| keyvaultproperties | Properties of KeyVault | KeyVaultProperties[] |
| requireInfrastructureEncryption | A secondary layer of encryption with platform managed keys for data at rest. | bool |

### Keyvaultproperties

| Name | Description| Value |
|  :-- | :-- | :-- |
| keyname | Name of the Key from KeyVault. | string |
| keyvaulturi | The URI of the key vault key used to encrypt data. | string |

### Identity

| Name | Description | Value |
|  :-- | :-- | :-- |
| identityType | The type of managed identity used.  | 'UserAssigned' |
| userAssignedIdentities | ARM ID of user Identity selected for encryption.  | object |

### SKUSetting

| Name | Description | Value |
|  :-- | :-- | :-- |
| sku | Storage Account Sku Name. | string  |

### networkAcls

| Name | Description | Value |
|  :-- | :-- | :-- |
| allowTrustedAzureServices | Whether to allow Azure services on the trusted services list to access this Storage Account. | true |
| bypass | Whether to allow Azure services on the trusted services list to access this Storage Account. | true  |
| defaultAction | Only certain IP rules should be allowed, all others should be denied. | Deny |
| ipRules | An array of IPv4 addresses or IPv4 address ranges in CIDR format. | array |

## Network Connectivity

It is not possible anymore to allow default network access in the product. All the network traffic goes through the firewall.

### Azure Public

HTTPS traffic through the REST API on port 443.

### Azure Private

See [network topology](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/66465/Product-Description?anchor=network-topology).

### On Premise

Private Link is mandatory for connectivity from on premise.

## Reference

- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/storage/common/storage-account-overview>
