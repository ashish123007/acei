# Redis Cache

This repository can be used to deploy an instance of Redis Cache. [Learn more](https://learn.microsoft.com/en-us/azure/azure-cache-for-redis/cache-overview)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/redis(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99176&branchName=main)

## Pre-Requisities

- Vnet and a Subnet for creating Redis Cache service with Private Endpoint.

  Read more - SSNS <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/58963/Usage-Guidance>

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module redisCache 'br/FSCPRegistry:bicep/modules/dip/core/rediscache:1.5.1'  =  {
  name: '<name of deployment>'
  params: {
      name: '<name of redis>'
      privateEndpointName: '< privateEndpointName >'
      privateEndpointSubnetName: '< privateEndpointSubnetName >'
      vnetName: '<vnetName>'
      vnetResourceGroup: '< vnetResourceGroup >'
      userAssignedIdentities: '< userAssignedIdentities >'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| name | string | redis cache name |
| privateEndpointName | string | private endpoint name of the resource. |
| privateEndpointSubnetName | string | Private endpoint subnet name. |
| vnetName | string | Vnet name. |
| vnetResourceGroup | string | Vnet resource group name. |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalRedisProperties | object | {} | Paramater to add more properties for existing redis cache. |
| capacity | int |  | The size of the redis cache to deploy. Valid values: for C (Basic/Standard) family (0, 1, 2, 3, 4, 5, 6), for P (Premium) family (1, 2, 3, 4). |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| disableAccessKeyAuthentication | bool | true | Authentication to Redis through access keys is disabled when set as true. |
| enableNonSslPort | bool | false | Specifies whether the non-ssl redis cache server port (6379) is enabled. |
| identityType | string | managedidentities | Enables system or user managed identity on the resource. |
| location| string | resourceGroup().location | Location of your redis cache. |
| minimumTlsVersion | string | | Requires clients to use a specified TLS version (or higher) to connect. |
| publicNetworkAccess| string | disabled | Whether or not public network access is allowed for the redis cache. |
| privateEndpointGroupId | string | redisCache | Group id for input resourceNameForPrivateEndpoint. |
| privateEndpoints | array | | Private endpoint description. |
| resourceTags| object | | tags for module. |
| redisConfiguration | object | {'aad-enabled': 'true'} | All redis cache Settings. The property 'aad-enabled' specifies whether Entra ID (former AAD)-based authentication has been enabled or disabled for the cache. |
| redisVersion | string | | redis cache version. Only major version will be used in PUT/PATCH request with current valid values: (4, 6). |
| replicasPerMaster | int | 1 | The number of replicas to be created per primary. |
| replicasPerPrimary | int | 1 | The number of replicas to be created per primary. |
| resourceType | string | Microsoft.Cache/Redis | Resource type for input Private endpoint resource. |
| resourceTags| object | | User provided resource tags in the form of json. |
| shardCount | int | 1 | The number of shards to be created on a Premium Cluster Cache. Minimum value is 1 |
| skuName | string | Premium | The type of redis cache to deploy.|
| staticIP | string | | Static IP address. May be specified when deploying a redis cache inside an existing Azure Virtual Network; auto assigned by default. |
| subnetId | string | | The full resource ID of a subnet in a virtual network to deploy the redis cache in. |
| tenantSettings | object | {} | A dictionary of tenant settings. |
| userAssignedIdentities | string | | The Resource Id of user assigned identity for the redis cache. |
| zones | array | pickZones('Microsoft.Cache', 'redis', location, 1) | A list of availability zones denoting where the resource needs to come from. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| location | string | The location the resource was deployed into. |
| name | string | Name of the Redis Cache resource |
| rediscache | object | redis cache resource as a object |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### Redis

| Name | Description |
| :-- | :-- |
| location | Resource location. |
| name | The resource name |
| identity | The identity of the resource. |
| properties | redis cache properties. |

### Replicas

To ensure you have at least as many nodes as zones you are replicating, always make sure you have as many replicas
as the the number of zones. So if your array has [1,2] you need a minimum of 2 replicasPerMaster.

| Output | type | Description |
| :-- | :-- | :-- |
| replicasPerMaster | int | The number of replicas to be created per primary need to be atleast as much as the number of zones. |

## Network Reference

### On-Premise to Azure

Not Applicable

### Azure to Azure

Azure Private to Azure Public services are connected via Service end point and PLE subnet.

### Azure to On-premise

Not Applicable

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/72382/AAB-Redis-Cache>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/templates/microsoft.cache/redis?pivots=deployment-language-bicep>
