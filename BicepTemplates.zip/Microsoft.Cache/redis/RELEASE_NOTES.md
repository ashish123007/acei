# Release and Upgrade Notes

## Version 1.5.1

- Released: 2025 Jun 02
- Description: updated version due to BICEP PEP upgrade
- Story: [5444323](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5444323)

---

## Version 1.5.0

- Released: 2025 May 14
- Description: added the properties 'disableAccessKeyAuthentication' and 'aad-enabled',
  with the applicable parameters and compliant default parameter values
- Story: [5227549](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5227549)

## Version 1.4.1

- Released: 2025 Mar 11
- Description: updated version due to BICEP PEP upgrade
- Story: [5101539](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5101539)

---

## Version 1.4.0

- Released: 2024 Dec 04
- Description: Upgrade Bicep version to 2024-11-01
  No properties added, updated or removed.
- Story: [4693855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4693855)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 1.3.2

- Released: 2024 Oct 28
- Description: updated version due to PEP upgrade
- Story: [4470596](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4470596)

---

## Version 1.3.1

- Released: 2024 May 10
- Description: updated version due to PEP upgrade
- Story: [3616182](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3616182)

---

## Version 1.3.0

- Released: 2024 Jan 15
- Description: updated the bicep version
- Story: [3129428](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3129428)

---

## Version 1.2.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 1.1.8

- Released 2023 August 9
- Explicitely pass location parameter to all sub resources,
to prevent linter error.
Use only local references for submodules.
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 1.1.7

- Released 2023 August 8
- Because of compile changes
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)

---

## Version 1.1.6

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

## Version 1.1.5

- Released: 2023 July 13
- Description: updated PLE version in the template from 2.2.0 to 2.2.1.
- Story: [2475562](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 1.1.4

- Released: 2023 July 03
- Description: Private Endpoint module version used has been updated.
- Story: [2438072](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2438072)

---

## Version 1.1.3

- Released: 2023 May 10
- Description: nightly-builds-fix for version
- Story: [2273734](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2273734)

## Version 1.1.2

- Released: 2023 Apr 24
- Description: New version of private endpoint.
- Story: [2221485](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2221485)

---

## Version 1.1.1

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2167088)

---

## Version 1.1.0

- Released: 2023 Feb 14
- Description: Added support for Zone Redundancy and Multi-Zonal Resources.
Activated retry trigger in nightly.
- Story: [2001338](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2001338)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

## Version 1.0.5

- Released: 2023 Jan 30
- Description: Added name as an output parameter.
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_sprints/taskboard/BLK0003414/GRD0001007/BLK0003414/Sprint%20158?workitem=1935001)

## Version 1.0.4

- Released: 2022 Nov 24
- Description: Handle optional UAMI paramater as optional. Added readme validator.
- Story: [1765785](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1765785)
- Story: [1847324](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1847324)

---

## Version 1.0.3

- Released: 2022 Nov 18
- Description: Fixed readme parameters
- Story: [1706892](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1706892)

---

## Version 1.0.2

- Released: 2022 Oct 21
- Description: Fixed resource api version.
- Story: [1637060](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1637060)

---

## Version 1.0.1

- Released: 2022 Oct 21
- Description: Fixed lints

---

## Version 1.0.0

- Released: 2022 Oct 19
- Description: Initial release of Redis.
