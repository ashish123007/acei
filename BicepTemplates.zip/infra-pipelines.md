## Infrastructure pipelines

The following infrastructure pipeline components are (shortly) discussed below.

- Bicep parameter files, in _JSON_
- (main) Bicep modules in repository in module registry, in _Bicep_
- azure pipeline definition and pipeline templates, in _YAML_
- azure pipeline variables in pipeline library and variable templates, also in _YAML_

## Bicep parameters

### Static parameter files

The most straight forward way is to keep the parameter sets in a JSON file per environment.
This is the way suggested by the [FTT QuickStart Pipeline](https://dev.azure.com/cbsp-abnamro/FSCP%20Azure%20Community/_git/FSCPAzureCommunity?path=/FTT-Accelerator/Pipelines/quickStartPipeline).

If the set of parameters differs for each main Bicep you will require one parameter file for each stage and each environment.
The files are named after their stage and environment, for example `bicep.parameters.main.acceptance.json`.

Below is a sample parameters file that contains 3 parameters, an array, a string and a bool.

```
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "saIpRules": {
      "value": [ 
        {
          "action": "Allow",
          "value": "10.11.12.0/28"
        }, 
        {
          "action": "Allow",
          "10.11.13.0/28"
        }
      ]
    },
    "agSkuName": {
      "value": "standard"
    },
    "enableHigherPriviligeGroupRoles": {
      "value": true
    }
  }
}
```

### Generated parameter files

The static approach tends to duplicate values that are traditionally
already set as pipeline variables.
Samples of such values are the short dtap identifier used in resource names or
the AD Group object ID for the AD DevOps group that owns a resource group.

A special case form dynamic values, like latest key version for in rest encryption,
that cannot be calculated in Bicep at all.
When static parameter files are used such values cannot be passed to Bicep in that way,
and the infra creation will be populated with additional Azure CLI tasks that fire deployments in another way.

Some mechanism to populate parameter files with environment-specific values is proven to be very helpful here.

FSCP Automation team experimented with token replacement task named
[qetza.replacetokens.replacetokens-task.replacetokens](https://marketplace.visualstudio.com/items?itemName=qetza.replacetokens).
This is available for Azure Devops pipeline agents at ABN AMRO subscriptions.
The task replaces tokens.
A token consists of a prefix, a name and a suffix.
The whole group is replaced by the token value, which is the value of a pipeline variable with the same name as the token (case-insensitive).

When the standard Azure pipelines prefix `$(` and suffix `)` are used above parameter file shows as follows.
All values are replaced by tokens.

```
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "saIpRules": {
      "value": $(saIpRules)
    },
    "agSkuName": {
      "value": "$(agSkuName)"
    },
    "enableHigherPriviligeGroupRoles": {
      "value": $(enableHigherPriviligeGroupRoles)
    }
  }
}
```

Straight forward enough. Now you are ready to pass variables from the pipeline to your Bicep modules.
However, there are a few caveats here.

First, all JSON datatypes, except strings, are not in correct JSON syntax.
Editors that understand JSON will show syntax errors.
This can be circumvented by using a prefix and suffix that are accepted in JSON syntax.
For example `"$[` and `]"`. See sample below.
Another way to prevent syntax errors is to duplicate the parameters for each environment and each stage and
put any non-string value as a literal.
We advise to accept the syntax errors, or allow for 2 token types.

```
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "saIpRules": {
      "value": "$[saIpRules]"
    },
    "agSkuName": {
      "value": "$(agSkuName)"
    },
    "enableHigherPriviligeGroupRoles": {
      "value": "$[enableHigherPriviligeGroupRoles]"
    }
  }
}
```

Another inconvenience is that every parameter file must list all parameters
that are mentioned in the main Bicep modules of each pipeline stage.
You could have the ambition to create only one parameter file for _all_ stages,
probably at the cost of defining unused parameters in your main Bicep modules.
Even that warning could be worked around by specifying only _one_ object parameter `context` in your Bicep modules.
Then you can use its members as you like inside the Bicep. So instead of using a parameter named `agSkuName`
you would refer to `context.agSkuName`.
We advise to maintain as many parameter files as there are main Bicep modules.

A third thing to mention is that azure pipeline variables that are defined in variable
groups or variables section are restricted to string datatype only.
Complex values like array or object can only be assigned to a variable through tricks.
It is most straight forwarded to assign a valid JSON string directly to a pipeline variable.
Below you find another way to arrage it, at the cost of helper YAML templates.
We advise you to define complex values as string values that contain valid JSON snippets.

## Bicep modules

### Bicep use cases

Below follow three use cases of different behaviour in different environments, on the Bicep technology. The actual parameter value should passed through a (generated) parameter file.

#### AG with lower cost SKU in Development

For cost saving it is good practice to enable lower cost SKUs in lower environments,
when FSCP3 policies allow it, of course.
The FSCP Bicep modules set defaults for CIA 111 production workload policies,
but sometimes these can be relaxed in lower environments. 
For example the WAF_v2 SKU is required by policy in production workloads,
but development RGs may run Standard_v2 SKU.

Introduce a string parameter for the AG SKU in the main Bicep that creates
the AG and pass its value to the FSCP AG module. As default value you _must_ use
the same default as the module would set.
There is no simple, straight-forwarded way to
_not_ pass a module parameter at all, based on an expression.

The Bicep language requires that the _module_ object, and its _params_ member are literal objects.
When a _null_ or an _empty_ value is used, this same value is passed to the module.
Only when the module explicitely handles these values as special default cases,
the outcome will be as expected.
For example, in this case, the 
[AG module](https://dev.azure.com/cbsp-abnamro/Azure/_git/BicepTemplates?path=/Microsoft.Network/applicationGateways/README.md&version=GBfeature/movecode&_a=preview)
will not allow _null_ or _empty_ values for the `skuName` parameter.

In pseudo-Bicep this use case shows as below.

```
(..)

// SKU for AG resource. Lower environments may specify other than default. 
param agSkuName string = 'WAF_v2'
param agName string

(..)

module <symbolicName> '<AG module reference>' = {
    name: '<deployment name>'
    params: {
        name: agName
        skuName: agSkuName

(..)

```

#### SA with different Akamai IP white list in Acceptance and Production

Introduce an array parameter for the `ipRules` parameter of [SA module](https://dev.azure.com/cbsp-abnamro/Azure/_git/BicepTemplates?path=/Microsoft.Storage/storageAccounts/README.md&version=GBfeature/movecode&_a=preview).
The same principles as previous use case apply.
The case is added here to demonstrate passing a more complex datatype than a string.

```
(..)

// IP white list for SA resource. Different environments may specify different lists. 
param saIpRules array = []
param saName string

(..)

module <symbolicName> '<SA module reference>' = {
    name: '<deployment name>'
    params: {
        name: saName
        ipRules: saIpRules

(..)

```

#### Enable additional Role Assignements conditionally

Introduce a switch for the feature and use it in an `if` expression for any resource or module.

```
(..)

// Switch for high privilige feature. Lower environments may enable it.
param enableHigherPriviligeGroupRoles bool = false

(..)

resource <symbolicName> 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (enableHigherPriviligeGroupRoles) {

(..)

```

### Generated Bicep module

In principle Bicep modules can be generated directly, using token replacement. This has the advantage of by-passing the need for parameter files.
However, this beats any Bicep-aware editor.
Above that, if not carefully designed, the Bicep modules tend to evolve to code that freely mixes Bicep variables and replacement tokens,
which does not add to its maintainability.
So the advise is to generate parameter files only, if any.

## Pipeline definition

### Use extension template

If you require different pipeline triggers/schedules for different environments you can place the variables and stages section
in an extension template.
The original pipeline YAML will then hold the triggers and schedule and extend from the template
for one environmenty only.
The reference pipeline definition that extends from an extension template can be found
[here](https://dev.azure.com/cbsp-abnamro/GRD0001007/_git/fscp-automatcher?path=/pipelines/infra-pipeline.yml).

### Use dynamic values and token replacement

Below is a sample tasks template that can be used for token replacement in
your pipeline.
You can adapt the bash task body to your own needs, or even make it a CLI
task if resource interaction is required.
Of course you can also switch to powershell if that is your favourite.
You might also want to align the tokenPrefix/tokenSuffix in qetza tasks to your own preferences.

```code
steps:

  # register dynamic variables with different values in different stages
  # might be CLI task if dataplane connectivity is required
  - bash: |
      # demonstration of setting a dynamic value
      myDynamicValue=$(date)

      echo "register myDynamicValue = '$myDynamicValue'"
      echo "##vso[task.setvariable variable=myDynamicValue]$myDynamicValue"
    displayName: 'Register additional dynamic variables for current job'

  # replace all literal tokens "$[token]" in JSON, will not escape and remove quotes
  - task: qetza.replacetokens.replacetokens-task.replacetokens@4
    condition: not(or(failed(), canceled()))
    displayName: 'Replace raw tokens'
    inputs:
      rootDirectory: ${{ variables.pipelineFolderRoot }}
      verbosity: detailed
      targetFiles: |
        **/*.json
      tokenPattern: custom
      tokenPrefix: '"$['
      tokenSuffix: ']"'
      transformPrefix: '<'
      transformSuffix: '>'
      escapeType: none
      enableTransforms: true
      enableTelemetry: false

  # replace all string tokens $(token) in JSON, will do proper escaping
  - task: qetza.replacetokens.replacetokens-task.replacetokens@4
    displayName: 'Replace string tokens'
    inputs:
      rootDirectory: ${{ variables.pipelineFolderRoot }}
      verbosity: detailed
      targetFiles: |
        **/*.json
      tokenPattern: custom
      tokenPrefix: '$('
      tokenSuffix: ')'
      transformPrefix: '<'
      transformSuffix: '>'
      # escapeType: none
      enableTransforms: true
      enableTelemetry: false
```

If above tasks are place in a template YAML, for example `tasks.set-variables.yml` you can include it
from each job that requires token replacement. Be sure to match the qetza targetFiles with your
code checkout path.

A sample job in your main pipeline with template reference shows as follows.

```
(..)

  - job: InfraDeploymentBicep
    displayName: Infra Deployment Bicep
    steps:
      - checkout: self
        path: ./s/self

      - template: ./tasks.setup-variables.yml

(..)
```

## Pipeline variables

### Specifying complex JSON as pipeline YAML 

As stated above pipeline variables can only be specified as strings.

For example the YAML snippet below defines `ipRules` as a valid JSON _string_ that contains a JSON array.

```
variables:
  ipRules: >
    [
      {
        "action": "Allow",
        "value": "20.101.218.112/28"
      },
      {
        "action": "Allow",
        "value": "20.101.218.128/28"
      }
    ]
```

With a trick complex variables can also be specified as YAML and converted to JSON by a _pipeline expression_. It makes use of the fact that pipeline parameters may be complex objects. The FSCP Automation team assesses the trick as too complex for its advantage, which is JSON validation. In the end it produces a pipeline variable (a _string_) with a _validated_ JSON snippet.

First create a helper YAML template named `set.complex.variable.yml` with contents below.

```
parameters:
  - name: name
    type: string
  - name: value
    type: object

variables:
  ${{ parameters.name }}: ${{ convertToJSON(parameters.value ) }}
```

Then call this template from a variables template, for example:

```
variables:
  - template: set.complex.variable.yml
    parameters:
      name: ipRules
      value:
        - 20.101.218.112/28
        - 20.101.218.128/28
```
