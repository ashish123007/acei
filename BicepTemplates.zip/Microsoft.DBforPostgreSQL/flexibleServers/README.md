# Postgres Flexible Servers

This module creates Azure Postgres Flexible Servers.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/postgres-flexible-servers(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99172&branchName=main)

## Usage Guidance

### Prerequisites

The pre-requisities to use this module are:

- Key Vault for CMK
- Key for CMK
- Dedicated Subnet

If you don't have all the Prerequisites yet, you can choose to create a pipeline step.
In the file `pipelines/jobs.pre-deployment-setup.yml` you will find how to do this.

### Available Submodules

- [Database](./databases/README.md)

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

**Please note from version 2.1.0, default value of tier,sku name, storage size and postgres version has been updated.**

```code
module postgresFlexibleServerModule 'br/FSCPRegistry:bicep/modules/dip/core/postgres-flexible-servers:4.0.0' = {
  name: '<name of deployment>'
  params: {
    name: '<The resource name>'
    administratorLogin: '<Username of the administrator>'
    administratorLoginPassword: '<Password of the administrator, it's recommended that you use a secure variable for this>'
    primaryUserAssignedIdentityId: 'user managed identity'
    primaryKeyURI: 'key name'
    principalName: 'Group or Service Principal name'
    principalObjectId: 'object id of Service principal'
    delegatedSubnetResourceId: 'delegatedSubnetResourceId'
    intendedBackupInterval: '<Intended Backup Interval duration>'
  }
}
```

#### Note

In case you want to enable Geo Redundant make sure to provide encryption details of geo backup along with primary
server details as part of additional properties.

```code
dataEncryption: {
      geoBackupKeyURI: 'string'
      geoBackupUserAssignedIdentityId: 'string'
      primaryKeyURI: 'string'
      primaryUserAssignedIdentityId: 'string'
      type: 'string'
    }
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| administratorLogin | string | The administrator login name of a server. Can only be specified when the PostgreSQL server is being created. |
| administratorLoginPassword | string | The administrator login password. |
| delegatedSubnetResourceId | string | The name of the dedicated subnet. This subnet must have a delegation to Microsoft.DBforPostgreSQL/flexibleServers. |
| intendedBackupInterval | string | The intendedBackupInterval tag must be set to one of the following allowed values: Continuous, 1h, 4h, 1d, 7d, 14d, 30d & None. |
| name | string | The name of the PostgreSQL flexible servers. |
| primaryUserAssignedIdentityId | string | User-Assigned Managed Identity to be used for data encryption. |
| primaryKeyURI | string | key uri used for data encryption of the flexible servers. |
| principalName | string | The name of the Group or Service Principal to be configured as Azure AD administrator |
| principalObjectId | string | The object id of the Group or Service Principal to be configured as Azure AD administrator |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| activeDirectoryAuth | string | Enabled |If Enabled, Azure Active Directory authentication is enabled. |
| additionalProperties | object | {} | Additional Postgres server properties. |
| backupRetentionDays | int | 7 | Backup retention days for the server. |
| createMode | string | Default | The mode to create a new PostgreSQL server. |
| dataEncryptionType | string | AzureKeyVault | Data encryption type to depict if it is System Managed vs Azure Key vault. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| geoRedundantBackup | string | Disabled | A value indicating whether Geo-Redundant backup is enabled on the server. |
| identityType | string | UserAssigned | Data encryption type to depict if it is System Managed vs Azure Key vault. |
| location | string | location of the resource group | Postgres server location. |
| pdAuth | string | Disabled | f Enabled, Password authentication is enabled. |
| postgresqlVersion | string | 16 | PostgreSQL version. |
| principalType | string | ServicePrincipal | The principal type used to represent the type of Active Directory Administrator. |
| privateDnsZoneArmResourceId | string | /subscriptions/b658ffad-30c7-4be6-881c-e3dc1f6520af/resourceGroups/privatelinkdnszones01-p-rg/providers/Microsoft.Network/privateDnsZones/private01.postgres.database.azure.com | Private dns zone arm id. |
| skuName | string | Standard_B1ms | Azure database for PostgreSQL sku name.|
| storageSizeGB | int | 64 | The amount of storage expressed in gigabytes.|
| tags | object | {} | User provided resource tags in the form of json |
| tier | string | Burstable | The tier of the particular SKU. Tier must align with the "skuName" property. Example, tier cannot be "Burstable" if skuName is "Standard_D4s_v3".|

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| location | string | The location the resource was deployed into. |
| name | string | Name of the PostgreSQL flexible Server |
| postgresFlexibleServers | object | Postgres flexible Server |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

This section details which properties need to be set and what values should be used to create a compliant service.
They are already implemented in the provided template but this information can be used if you wish to create your
own template.

### Microsoft.DBforPostgreSQL/flexibleServers

| Name | Description | Value |
| :-- | :-- | :--|
| administrators | The Azure Active Directory Administrator Type should be present. | ServerAdministratorProperties |
| servers/sku.name | PostgreSQL should have the 'Pricing tier'; 'General Purpose' or 'Memory Optimized'. | 'General Purpose' or 'Memory Optimized' |

### Encryption

| Name | Description | Value |
| :-- | :-- | :-- |
| servers/infrastructureEncryption | Infrastructure encryption should be enabled for Azure Database for PostgreSQL servers | Enabled |
| servers/keys/uri | Azure Policy blocks the deployment of an Azure Database for PostgreSQL Flexible Server when the Customer Managed Key setting is not enabled. | A valid uri of a customer managed key. |

## Reference

- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/68271/AAB-PostgreSQL-v1>
