# Release and Upgrade Notes

## Version 4.0.0

- Released: 2025 Mar 03
- Description: Added the IntendedBackupInterval Manadatory tag
- Story: [4993374](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4993374/)

### Upgrade steps to 4.0.0

Upgrade of the module needs parameter intendedBackupInterval enabled.
The parameters for intendedBackupInterval -`Continuous`, `1h`, `4h`, `1d`, `7d`, `14d`, `30d` & `None`

---

## Version 3.1.0

- Released: 2024 Oct 28
- Description: New version of the MS bicep
- Story: [4470596](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/4470596)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 3.0.0

- Warning - Default value of few parameters (mentioned below) is changed
  due to which redeployment of an existing server will fail.
- Released: 2024 Aug 27
- Description: Default value of skuname,tier,storagesize and postgress
  version is changed.
- Story: [3816522](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3816522)

---

## Version 2.0.0

- Released: 2023 Oct 10
- Description: Added postgress flexible servers Administrator.
To upgrade to this version make sure to add new required parameters. Refer ReadMe file.
Automated remediation of DINE policies.
Prevent role assignment leakage.
- Story: [2765580](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2765580)
- Story: [2851990](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2851990)
- Story: [3457882](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3457882)

---

## Version 1.1.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 1.0.1

- Released: 2023 Aug 21
- Description: Updates in ReadMeand added default value of 'privatednszone'in bicep.
Automatic keyname rotation for testcases.
- Story: [2178291](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2178291)
- Story: [2654591](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2654591)

---

## Version 1.0.0

- Released: 2023 Jul 20
- Description: Initial version of the Postgress Database server
- Story: [2178291](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2178291)
