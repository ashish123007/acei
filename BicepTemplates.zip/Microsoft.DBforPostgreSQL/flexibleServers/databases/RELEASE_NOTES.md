# Release and Upgrade Notes

## Version 1.1.0

- Released: 2023 Oct 13

- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
Added new paramerters in pre-requisite file.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)
- Story: [2765580](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2765580)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)
Added new parameters in pre-requisite.
- Story: [5113541](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5113541)

---

## Version 1.0.0

- Released: 2023 Aug 07
- Description: Initial version of the Postgress Flexible Servers Database.
- Story: [2178291](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2178291)
