# Postgres Flexible Servers Database

This module creates Azure Postgres Flexible Servers Database.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/postgres-fs-database(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99173&branchName=main)

## Pre-Requisities

The pre-requisities to use this module are:

- A Postgres Flexible Servers

## Usage Guidance

### Prerequisites

If you don't have all the Prerequisites yet, you can choose to create a pipeline step.
In the file `pipelines/jobs.pre-deployment-setup.yml` you will find how to do this.

### Consume the module

You can also create databases when creating the database server. You can read how to do this in
[the readme of the postgres flexible server](../flexibleServers/README.md).

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module postgresDatabaseModule 'br/FSCPRegistry:bicep/modules/dip/core/postgres-flexible-servers-database:1.2.0' = {
  name: '<name of deployment>'
  params: {
    name: '<The resource name>'
    flexibleServersName: '<The server name, where this database should be deployed to>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| name | string | name of postgres flexible server database. |
| flexibleServersName | string | flexible server name |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalProperties | object | {} | Additional Postgres flexible servers database properties. |
| charset | string | '' | The character set of the database. |
| collation | string | '' | The collation of the database. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| tags | object | {} | User provided resource tags in the form of json |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| name | string | The name of the created resource. |
| postgresFlexibleServersDatabase | object | Postgres flexible servers Database |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Reference

- <https://confluence.int.abnamro.com/display/VEEJH/DIP+Bicep+FAQ>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/68271/AAB-PostgreSQL-v1>
