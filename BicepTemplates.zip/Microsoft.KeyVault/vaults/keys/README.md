# Keys

This repository can be used to deploy an instance of keys. [Learn more](https://learn.microsoft.com/en-us/azure/key-vault/general/about-keys-secrets-certificates)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/keys(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99168&branchName=main)

## Pre-Requisities

- You need a Key Vault to create a key inside it.

  Read more - [Key Vault](https://dev.azure.com/cbsp-abnamro/Azure/_git/BicepTemplates?path=/Microsoft.KeyVault/vaults/README.md&_a=preview)

## Usage Guidance

The module can only be used to (re)create an initial version of a key.
When a key already exists _all_ parameters must be provided exactly the same as
during initial creation.
If resource properties are not the same the ARM deployment will fail
with a clear message like `This API can only be used for creating the first version of a new key
(no subsequent versions can be created, and existing keys cannot be updated)`.
Special care is to be taken for optional parameters, as their defaults may change
from module version to module version.
For this reason the module will not add any FSCP resource tags, as other modules do.

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module keys 'br/FSCPRegistry:bicep/modules/dip/core/keys:3.2.0' = {
  name: '<name of deployment>'
  params: {
      keyName: '< Name of the key >'
      keyVaultName: '< Name of key vault >'
      expirationDate: '< Key expiration date >'
  }
}
```

#### How to skip key module in next deployment

Due to the limitations mentioned above, special care is needed to ensure your infrastructure pipeline is idempotent,
as it is not possible to deploy a second version of a key using Bicep. We recommend creating a parameter called
'keyExist' that can be used to skip the key deployment once it already exists. On the initial run of the pipeline
set the parameter to false, and then in future runs set it to true so that the Key module will be skipped.
This way you are free to run the infra pipeline multiple times without any failures.
**Make sure to update the value of 'keyExist' to true once the key is created.**

```code
param keyExist bool = false

 ......... keys 'br/FSCPRegistry:bicep/modules/dip/core/keys:X.X.X' = if (!keyExist) {
  name: '<name of deployment>'
  params: {
      keyName: '< Name of the key >'
      keyVaultName: '< Name of key vault >'
      expirationDate: '< Key expiration date >'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| expirationDate | string | Key expiration date in yyyy-mm-dd format or ISO 8601 format. (*) |
| keyName | string | Name of the key |
| keyVaultName | string | Name of key Vault |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| activationDate | string | | Key activation date in yyyy-mm-dd format or ISO 8601 format. |
| additionalkeysProperties | object | {} | Additional keys Properties |
| attributesEnabled | bool | true | Whether key to set Enabled or not |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| expiryTime | string | P1Y | The expiration time for the new key version. It should be in ISO8601 format. Eg: 'P90D', 'P1Y'|
| keyType | string | RSA | The type of key to create. Allowed values are 'RSA','RSA-HSM'|
| keySize | int | 2048 | The key size in bits. For example: 2048, 3072, or 4096 for RSA.|
| resourceTags | object | | User provided resource tags in the form of json. (*) |
| timeBeforeExpiry | string | P2M |The time duration before key expiring to rotate or notify. It will be in ISO 8601 duration format Eg: 'P90D', 'P1Y' |

(*)
Since version 2.1.0 the module will not set any resource tags unless
a `resourceTags` parameter is explicitely provided.

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| key | object | key resource as a object |
| name | string | Name of the Key |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### vaults/keys

| Name | Description | Default Value |
| :-- | :-- | :-- |
| name | The resource name | string |

### KeyProperties

| Name | Description | Default Value |
| :-- | :-- | :-- |
| attributes | The attributes of the key. | KeyAttributes |
| kty | The type of the key. For valid values, see JsonWebKeyType. | RSA |

### KeyAttributes

| Name | Description | Default Value |
| :-- | :-- | :-- |
| enabled | Determines whether or not the object is enabled. | true |
| exp | Expiry date in seconds since 1970-01-01T00:00:00Z. | int |
| nbf | Not before date in seconds since 1970-01-01T00:00:00Z. | int |

## Network Reference

Refer from [Key Vault](https://dev.azure.com/cbsp-abnamro/Azure/_git/BicepTemplates?path=/Microsoft.KeyVault/vaults/README.md&_a=preview)

## Reference

- <https://learn.microsoft.com/en-us/azure/key-vault/keys/about-keys>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/templates/microsoft.cache/redis?pivots=deployment-language-bicep>
