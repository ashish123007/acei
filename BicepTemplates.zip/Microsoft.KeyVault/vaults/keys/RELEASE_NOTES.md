# Release and Upgrade Notes

## Version 3.2.0

- Released: 2025 Feb 19
- Description: Updated API version.
- Story: [5016990](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/5016990)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 3.1.0

- Released: 2024 Oct 10
- Description: The 'activationDate' of a key is optional.
If the parameter is not specified by the end user, the 'notBefore'
attribute will not be set on the key.
- Story: Incident -SINC7749238

---

## Version 3.0.0

- Released: 2024 Sep 03
- Description: Enabled rotation policy with default values and expiration date of key
is now a mandatory parameter. This is required to prevent failure of infra pipeline
as rotation of key results in an empty activation date. Check out ReadMe for an
option to prevent infra pipeline failure.
- Story: [4146484](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/4146484)

---

## Version 2.2.1

- Released: 2024 Apr 22
- Description: Updated BICEP key vault version
to 2023-07-01.
- Story: [3543675](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3543675)

---

## Version 2.2.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 2.1.0

- Released: 2023 Sep 07
- Description: made `expirationDate` parameter optional.
Module will conserve existing tags when no `resourceTags`
parameter is provided.
Module will not set implicit parameters.
- Story: [2654088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2654088)

### Upgrade steps from 2.0.x to 2.1.0

1. for existing keys and if `resourceTags` were provided the parameter value
must be extended with FSCP tags,
with the same values as set by the module version that create the key originally.
For example:

```code
  resourceTags: {
    FSCPBicepTemplateVersion: '2.0.2'
    FSCPBicepTemplateName: 'Keys'
    FSCPBicepTemplateCriticality: 'critical'
    FSCPBicepTemplateEnvironment: 'PROD'
  }
```

Tag names are case-insensitive.

### Upgrade steps from 2.0.x to 2.0.y

1. for existing keys a `resourceTags` parameter must be added as above.

---

## Version 2.0.3

- Released: 2023 Aug 11
- Description: Changed FSCPBicepTemplateName value to lowercase
- Story: [2570697](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2570697)

---

## Version 2.0.2

- Released: 2023 Aug 09
- Description: Added key output parameter.
Use only local references for submodules.
- Story: [2573112](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2573112)
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 2.0.1

- Released: 2023 May 30
- Description: New version because of new version Bicep compiler. Clean up dangling resources
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)
- Story: [2221485](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2221485)
- Story: [2309076](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2309076)

---

## Version 2.0.0

- Released: 2022 Nov 14
- Description: Initial release of Key Vault FSCP 3.0.
Activated retry trigger in nightly.
- Story: [1314910](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1314910)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

### Upgrade steps from 1.0.1 to 2.0.0

- Update the version of your Bicep to 2.0.0 for latest FSCP 3.0 policy updates.

---

## Version 1.0.1

- Released: 2022 Jun 10
- Description: Lock is added to the released module tag and added template for pull request checklist.
