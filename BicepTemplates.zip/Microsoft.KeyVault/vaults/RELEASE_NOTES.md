# Release and Upgrade Notes

## Version 2.2.0

- Released: 2025 Feb 19
- Description: Updated API version
- Story: [3543675](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3543675)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 2.1.2

- Released: 2024 Apr 22
- Description: Updated BICEP key vault version
to 2023-07-01.
- Story: [3543675](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3543675)

---

## Version 2.1.1

- Released: 2023 Dec 04
- Bugfix keyvault purge protection
- Description: Setting the `enablePurgeProtection` parameter to false did not actually disable
the purge protection. This is fixed.
- Story: [2946081](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2946081)

---

## Version 2.1.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 2.0.4

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 2.0.3

- Released: 2022 Dec 07
- Description: made publicnetworkaccess enabled by default and updated readme.
Activated retry trigger in nightly.
- Story: [1801971](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1801971)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 2.0.2

- Released: 2022 Dec 02
- Description: Added name in output.
- Story: [1776142](https://dev.azure.com/cbsp-abnamro/GRD0001007/_sprints/backlog/BLK0003414/GRD0001007/BLK0003414/Sprint%20152?workitem=1776142)

---

## Version 2.0.0

- Released: 2022 Nov 14
- Description: Initial release of Key Vault
- Story: [1314910](https://dev.azure.com/cbsp-abnamro/GRD0001007/_sprints/backlog/BLK0003414/GRD0001007/BLK0003414/Sprint%20152?workitem=1314910)

### Upgrade steps from 1.1.2 to 2.0.0

- servicePrincipleObjectId and groupId are not mandatory parameters anymore and keyVaultName is changed to name.

---

## Version 1.1.2

- Released: 2022 Jun 16
- Description: bypassNetworkAcls is set as AzureServices.
