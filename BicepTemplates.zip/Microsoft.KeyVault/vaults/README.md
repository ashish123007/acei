# Key Vault

This repository can be used to deploy an instance of Key Vault. [Learn more](https://learn.microsoft.com/en-us/azure/key-vault/general/overview)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/keyvault(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99169&branchName=main)

## Pre-Requisities

- Vnet and a Subnet for creating Key Vault.

  Read more - SSNS <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/58963/Usage-Guidance>

## Usage Guidance

### Available Submodules

- [Key](./keys/README.md)

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module keyvault 'br/FSCPRegistry:bicep/modules/dip/core/keyvault:2.2.0'  =  {
  name: '<name of deployment>'
  params: {
      name: '<name of Key Vault>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| name | string | Key Vault name |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| accessPolicies | array | [] | An array of 0 to 1024 identities that have access to the Key Vault. All identities in the array must use the same tenant ID as the key vault's [See example](https://dev.azure.com/cbsp-abnamro/Azure/_git/BicepTemplates?path=/Microsoft.KeyVault/vaults/test/default.parameters.json)|
| additionalkeyVaultProperties | object | {} | Paramater to add more properties for existing Key Vault. |
| allowTrustedAzureServices | bool | true | Whether to allow Azure services on the trusted services list to access this Key Vault. |
| createMode | string | 'default' | The vault's create mode to indicate whether the vault need to be recovered or not. Options are recover or default. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| enablePurgeProtection | bool | true | Provide \'true\' to enable Key Vault\'s purge protection feature. |
| enableRbacAuthorization | bool | false | Property that controls how data actions are authorized. |
| enableSoftDelete | bool | true | Switch to enable/disable Key Vault\'s soft delete feature. |
| enableVaultForDeployment | bool | true | Specifies if the vault is enabled for deployment by script or compute. |
| enableVaultForDiskEncryption | bool | true | Specifies if the azure platform has access to the vault for enabling disk encryption scenarios.|
| enableVaultForTemplateDeployment | bool | true | Specifies if the vault is enabled for a template deployment. |
| ipRules | array | [] | The list of IP address rules.([See Example Parameters section below]) & also ([Allowed values](https://portal.azure.com/#view/Microsoft_Azure_Policy/InitiativeDetailBlade/id/%2Fproviders%2FMicrosoft.Management%2FmanagementGroups%2F823afb55-e37b-4f0e-aaa3-3cfeb3afd29c%2Fproviders%2FMicrosoft.Authorization%2FpolicySetDefinitions%2Faab-key-vault-critical-preproduction-v1/scopes/undefined)(go to Definition tab))|
| location | string | resourceGroup().location | Location of your keyVault. |
| publicNetworkAccess| string | Enabled | Whether or not public network access is allowed for the keyVault. |
| resourceTags| object | {} | User provided resource tags in the form of json. |
| softDeleteRetentionInDays | int | 90 | softDelete data retention days. It accepts >=7 and <=90. |
| vaultSku | string | Premium | Specifies the SKU for the vault.|
| virtualNetworkRules | array | [] | The list of virtual network rules.[See example](https://dev.azure.com/cbsp-abnamro/Azure/_git/BicepTemplates?path=/Microsoft.KeyVault/vaults/test/default.parameters.json) |

### Example Parameters

```code

ipRules: '[{ "value":"20.76.109.103/32" }, { "value":"20.76.109.106/32"},{ "value": "20.76.109.107/32"},\
{ "value": "20.76.109.102/32"},{ "value":"164.140.203.0/24"},{ "value":"164.140.188.0/24"}]'

```

If you're using the [Get-FirewallRules.ps1](https://dev.azure.com/cbsp-abnamro/Azure/_git/SecureContextBaseCatalog?version=GBmaster&path=/scripts/firewall-rules/Get-FirewallRules.ps1)
script to set the ipRules. The format will be incorrect, the script delivers a
string array, and it should be an array of ipRule objects.

You can fix this by adding this one-liner.

```code

  $firewallRules=($firewallRules | ConvertFrom-Json | 
  ForEach-Object { $_ =  '{"value": "' + $_ + '"}' | 
   ConvertFrom-Json; $_ } 
  | ConvertTo-Json -Compress)

```

### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| keyVault | object | keyVault resource as a object |
| location | string | The location the resource was deployed into. |
| name | string | name of the created key vault |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### KeyVault

| Name | Description | Value |
| :-- | :-- | :-- |
| location | Resource location. | string |
| name | The resource name | string |

### VaultProperties

| Name | Description | Value |
| :-- | :-- |:-- |
| accessPolicies | An array of 0 to 1024 identities that have access to the key vault. All identities in the array must use the same tenant ID as the key vault's tenant ID.| array |
| createMode | The vault's create mode to indicate whether the vault need to be recovered or not.| default |
| enabledForDeployment | Property to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault. | true |
| enabledForDiskEncryption | Property to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys. | true |
| enabledForTemplateDeployment | Property to specify whether Azure Resource Manager is permitted to retrieve secrets from the key vault. | true |
| enablePurgeProtection | Property specifying whether protection against purge is enabled for this vault. | true |
| enableRbacAuthorization | Property that controls how data actions are authorized. | false |
| enableSoftDelete | Property to specify whether the 'soft delete' functionality is enabled for this key vault. | true |
| ipRules | An IPv4 address range in CIDR notation, such as '124.56.78.91' (simple IP address) or '124.56.78.0/24' (all addresses that start with 124.56.78).| array |
| provisioningState | Provisioning state of the vault. | Succeeded |
| publicNetworkAccess | Property to specify whether the vault will accept traffic from public internet. | Disbaled |
| sku | SKU Details | premium |
| softDeleteRetentionInDays | softDelete data retention days. It accepts >=7 and <=90. | int |
| tenantId | The Azure Active Directory tenant ID that should be used for authenticating requests to the key vault. | string |

### AccessPolicyEntry

| Name | Description | Value |
| :-- | :-- | :-- |
| applicationId | Application ID of the client making request on behalf of a principal | string |
| objectId | The object ID of a user, service principal or security group in the Azure Active Directory tenant for the vault.The object ID must be unique for the list of access policies.| string |
| tenantId | The Azure Active Directory tenant ID that should be used for authenticating requests to the key vault. | string |

## Network Reference

### On-Premise to Azure

1. To invoke Key vault from on-premise a private link end point can be used.
Without PLE , in FSCP 3.0 KV cannot be invoked from on-premise as the KV,
firewall will restrict access to the KV with limited set of IP.

1. Please don't forget to add the necessary inbound rules to the Network Security Group (NSG) on the PLE subnet.

### Azure to Azure

### Azure Private to KV

From Azure private , you can reach key vault via two routes:

1. Service End point.

    SEP has been implemented in FSCP centralized NSP vnet ,
    which has been peered with customers VNET ( connectivity route 4).
    So the customer don't need to implement the same.

1. Private Link Endpoint.

    PLE can be implemented within customer own vnet . Via PLE , the private connectivity to key vault can be enabled.

### Azure Public to KV

  1. From azure public , when you are trying to connect azure key vault then you need to enable the azure KV firewall
  and trusted services needs to be enabled.
  This pattern needs an approval from Design team and architects as it doesn't use any PLE or SEP.

### Azure to On-premise

Not Applicable

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/64867/Product-Description>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/63594/AAB-Key-Vault-v1>
