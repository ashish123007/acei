# CosmosDB Account

This repository can be used to provision a CosmosDB Account. [Learn more](https://learn.microsoft.com/en-us/azure/cosmos-db/introduction)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/cosmosdb-account(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99157&branchName=main)

## Pre-Requisities

- Azure Key Vault as a keySource for encryption
- RSA2048 key for encryption
- User Assigned Managed Identity to access the Key Vault
- Private Endpoint Subnet

## Usage Guidance

To begin using Azure Cosmos DB, create an Azure Cosmos DB account in an Azure resource group in your subscription.
You then create databases and containers within the account.

### Available Submodules

- [SQL Database](./sqlDatabases/README.md)

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module cosmosDBAccountModuleDeploy 'br/FSCPRegistry:bicep/modules/dip/core/cosmosdb-account:4.3.4' = {
  name: '<name of deployment>'
  params: {
    name: '<Account Name>'
    keyVaultKeyUri: '<Key Vault Key URI>'
    keyVaultUserAssignedIdentity: '<ARM ID of Managed User Identity>'
    privateEndpointVnetResourceGroup: '<Private endpoint vnet resource group name.>'
    privateEndpointVnetName: '<Private endpoint vnet name.>'
    privateEndpointSubnetName: '<Private endpoint subnet name.>'
  }
}
```

Please find below parameter examples if you need to enable other API types than the default core Sql API.

**Required parameters**

| Parameter Name | Type |  Description |
| :-- | :-- | :-- |
| keyVaultKeyUri | string | Uri of KeyVaultKey for encryption. |
| name | string | Account Name. |
| privateEndpointSubnetName | string | Private endpoint subnet name. |
| privateEndpointVnetName | string | Private endpoint vnet name. |
| privateEndpointVnetResourceGroup | string | Private endpoint vnet resource group name. |

**Optional parameters**

| Parameter Name | Type | Default Value |  Description |
| :-- | :-- | :-- | :-- |
| additionalDatabaseAccountProperties | object | {} | Additional Database Account Properties. |
| assignKeyAccess | string | 'Rbac' | Whether to arrange key access for Database Accopunt. Possible values: 'None', 'AccessPolicy', 'Rbac'. |
| apiCannotDisableLocalAuth | bool | false | Whether `disableLocalAuth` parameter can be used for selected API. |
| databaseAccountOfferType | string | 'Standard' | The offer type for the database. |
| defaultConsistencyLevel | string | 'Session' | Allowed values are 'Eventual', 'ConsistentPrefix', 'Session', 'BoundedStaleness', 'Strong'. |
| defaultIdentity | string | 'UserAssignedIdentity' | Identity to use for CMK key access. Possible values: 'FirstPartyIdentity', 'SystemAssignedIdentity', 'UserAssignedIdentity'. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| disableLocalAuth | bool | true | Disables all authentication methods other than AAD authentication. Azure allows this parameter for core(Sql) or Table APIs only. Set `apiCannotDisableLocalAuth` to `true` if the API of your choice always enables local authentication. |
| enableMultipleWriteLocations | bool | true | Enables the account to write in multiple locations. |
| identity | object | {} | Identities to accosiate with Database Account. |
| ipRules | array | List of valid IPs | Sets the IP ACL rules. Array items may be filled based on the client's need, and it must be selected from the corresponding policy to be compliant. [Firewall Settings DENY Policy](https://portal.azure.com/#view/Microsoft_Azure_Policy/PolicyDetailBlade/definitionId/%2Fproviders%2Fmicrosoft.management%2Fmanagementgroups%2Fc7c0086e-e721-4f52-bcf8-effd9a2d53f0%2Fproviders%2Fmicrosoft.authorization%2Fpolicydefinitions%2Faab-cosmosdb-firewall-settings-deny-v1). |
| minimalTlsVersion | string | 'Tls12' | Minimum Transport Layer Security (TLS) protocol version to use. All Cosmos DB accounts must use TLS 1.2 or higher. |
| keyVaultUserAssignedIdentity | string | '' |  ARM ID of Managed User Identity selected to access the KeyVault. Must be set if defaultIdentity is set to 'UserAssignedIdentity'. |
| kind | string | 'GlobalDocumentDB' | Type of database account. |
| location | string | Resource Group Location | The Geo-location where the resource lives. |
| locations | array | [{ locationName: location }] | The enabled georeplication locations. |
| maxIntervalInSeconds | int | 300 | Max lag time (seconds). |
| maxStalenessPrefix | int | 100000 | Max stale requests. |
| privateEndpointGroupId | string | Sql | Private endpoint sub resource name. |
| privateEndpointName | string | ${name}-pep | Private endpoint name. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| databaseAccount | object | Database Object |
| location | string | The location the resource was deployed into. |
| name | string | Name of the Database Account |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

#### How to enable other APIs type than Core(Sql)

The resource supports more API types that the default.
If you want to enable another API types you need to make use of the
`additionalDatabaseAccountProperties` parameter and some other
parameters, depending on the API type.

The `kind` parameter is required for MongoDB API type.

The `privateEndpointGroupId` parameter
must be set if you want to activate
another private link service groupId than the default `Sql`.
Some API types do not support the `Sql` groupId.

You can also access the Gremlin and API for Table accounts
through the API for Sql.
In case you want to use both APIs you require
to create a second private endpoint from your
main Bicep with a dependency
on the CosmosDB Account module.

Some of these API types won't allow you to disable local authentication.
Set `apiCannotDisableLocalAuth` parameter to `true` for these.
This will prevent this error during deployment:
"DisableLocalAuth is only allowed to be configured for SQL
and Table API accounts."
Please note that for these API types an
FSCP API Audit policy might be violated, for
which you should create a deviation.
The policy name is "Cosmos DB database accounts
should have local authentication methods disabled".

Below the parameter specifics are given for some API types.

**MongoDB API type**

```code
(..)
  params: {
    (..)
    privateEndpointGroupId: 'MongoDB'
    kind: 'MongoDB'
    apiCannotDisableLocalAuth: true
    additionalDatabaseAccountProperties: {
      enableAutomaticFailover: true
      apiProperties: { serverVersion: '4.2' }
      capabilities: [ { name: 'DisableRateLimitingResponses' } ]
    }
  }
}
```

**Table API type**

```code
(..)
  params: {
    (..)
    privateEndpointGroupId: 'Table' // or 'Sql'
    kind: 'GlobalDocumentDB'
    additionalDatabaseAccountProperties: {
      capabilities: [ { name: 'EnableTable' } ]
      enableAutomaticFailover: true
    }
  }
}
```

**Gremlin API type**

```code
(..)
  params: {
    (..)
    privateEndpointGroupId: 'Gremlin' // or 'Sql'
    kind: 'GlobalDocumentDB'
    apiCannotDisableLocalAuth: true
    additionalDatabaseAccountProperties: {
      capabilities: [ { name: 'EnableGremlin' } ]
      enableAutomaticFailover: true
    }
  }
}
```

**Cassandra API type**

```code
(..)
  params: {
    (..)
    privateEndpointGroupId: 'Cassandra'
    kind: 'GlobalDocumentDB'
    apiCannotDisableLocalAuth: true
    additionalDatabaseAccountProperties: {
      EnabledApiTypes: 'Cassandra'
      capabilities: [ { name: 'EnableCassandra' } ]
      enableAutomaticFailover: true
    }
  }
}
```

## Policy Details

### CosmosDB Account Resource

| Name | Description | Value |
| :-- | :-- | :-- |
| properties | Properties of CosmosDB Account | CosmosDBProperties |

### CosmosDBProperties

| Name | Description | Value |
| :-- | :-- | :-- |
| ipRules | Sets the IP ACL rules | array |
| keyVaultKeyUri | Uri of KeyVault for encryption | string |
| enableMultipleWriteLocations | Enables the account to write in multiple locations | true |

## Network Connectivity

### Azure Public

Check the [Product Wiki](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/58824/AAB-Cosmos-DB-v1)

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/58824/AAB-Cosmos-DB-v1>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/cosmos-db/nosql/manage-with-bicep>
