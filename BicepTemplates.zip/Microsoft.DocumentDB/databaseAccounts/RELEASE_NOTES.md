# Release and Upgrade Notes

## Version 4.3.4

- Released: 2025 Jun 02
- Description: updated version due to BICEP PEP upgrade
- Story: [5444323](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5444323)

---

## Version 4.3.3

- Released: 2025 May 01
- API Update from 2024-11-15 to 2025-04-15 for Microsoft.DocumentDB/databaseAccounts.
- Change done by auto-heal-function.

---

## Version 4.3.2

- Released: 2025 Mar 11
- Description: updated version due to BICEP PEP upgrade
- Story: [5101539](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5101539)

---

## Version 4.3.1

- Released: 2025 Mrt 03
- Description: Updated API versions MI
- Story: [5059337](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5059337)

---

## Version 4.3.0

- Released: 2025 Feb 19
- Description: Updated API versions
- Story: [5016990](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5016990)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 4.2.0

- Released: 2025 Jan 22
- Description: support and documentation
for other API types than Core(Sql)
- Story: [4839485](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4839485)

---

## Version 4.1.1

- Released: 2024 Dec 09
- Description: updated version due to BICEP  PEP upgrade
- Story: [4707678](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4707678)

---

## Version 4.1.0

- Released: 2024 Dec 04
- Description: Updated Bicep versions to 2024-11-15.
  - Removed:
    DiagnosticLogSettings
  - Updated:
    DatabaseAccountCreateUpdatePropertiesOrDatabaseAccountGetProperties:
    - Removed property 'capacityMode'
    - Removed property 'capacityModeChangeTransitionState'
    - Removed property 'defaultPriorityLevel'
    - Removed property 'diagnosticLogSettings'
    - Removed property 'enableMaterializedViews'
    - Removed property 'enablePriorityBasedExecution'
    RestoreParameters: Removed property 'sourceBackupLocation'
- Story: [4690318](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4690318)

---

## Version 4.0.0

- Released: 2024 Dec 02
- Description: Support for mandatory private endpoint.
- Story: [4679337](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4679337)

### Upgrade steps to 4.0.0

A private endpoint (PEP) is mandatory by policy.
From v4.0.0 3 new parameters are required to
create the PEP:
`privateEndpointVnetResourceGroup`,
`privateEndpointVnetName` and
`privateEndpointSubnetName`.
When provided a private endpoint will be
created with the name `{name}-pep`.
In case you already created a private endpoint
in earlier deployment you can provide its name
through the optional parameter `privateEndpointName`

---

## Version 3.0.0

- Released: 2024 Oct 29
- Description: Updated to TLS 1.2 because [support for TLS 1.0 and TLS 1.1 will end by October 31, 2024](https://learn.microsoft.com/en-us/lifecycle/announcements/tls-support-ending-10-31-2024).
This may be a breaking change for Gremlin, SQL or Table APIs if your application does not support TLS 1.2.
Cassandra and Mongo APIs are not affected as they only work with TLS 1.2.
- Story: [4443439](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4443439)

---

## Version 2.5.1

- Released: 2024 Oct 16
- Description: Inserted some delay in SAMI Rbac creation, to allow for timely Rbac propagation
- Story: [4384645](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/4384645)

---

## Version 2.5.0

- Released: 2024 Aug 21
- Description: Added disableLocalAuth parameter in bicep to fix policy violation.
Exempted 2 DINE policies from nightly.
- Story: [4046559](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/4046559)
- Story: [4138265](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/4138265)

---

## Version 2.4.0

- Released: 2024 Jun 10
- Description: Updated Document DB BICEP  version
to 2024-05-15.
- Story: [3728201](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3728201)

---

## Version 2.3.2

- Released: 2024 Apr 22
- Description: Updated BICEP key vault version
to 2023-07-01.
- Story: [3543675](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3543675)

---

## Version 2.3.1

- Released: 2024 Mar 18
- Description: Updated BICEP version to 2023-11-15. From the MS change log:
  - Updated: [Microsoft.DocumentDB/databaseAccounts 2023-11-15](https://learn.microsoft.com/en-us/azure/templates/microsoft.documentdb/change-log/databaseaccounts#2023-11-15)
- Story: [3390807](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3390807)

---

## Version 2.3.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 2.2.1

- Released 2023 August 3
- Because of compile changes.
Use only local references for submodules.
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 2.2.0

- Released: 2023 May 08
- Description: Publish version failure
- Story: [2259486](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2259486)
- Story: [2389206](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2389206)

---

## Version 2.1.2

- Released: 2023 May 08
- Description: New version because of new api version.
- Story: [2259486](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2259486)

---

## Version 2.1.1

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 2.1.0

- Released: 2023 Feb 16
- Description: Support for CMK policy. Added locations parameter and more.
Activated retry trigger in nightly.
- Story: [2003237](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2003237)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 2.0.0

- Released: 2023 Jan 30
- Description: Added name as an output parameter and changed input parameter accountName to name.
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_sprints/taskboard/BLK0003414/GRD0001007/BLK0003414/Sprint%20158?workitem=1935001)

---

## Version 1.0.0

- Released: 2022 Nov 16
- Description: Initial release of Cosmos DB Account bicep
- Story: [1314894](https://dev.azure.com/cbsp-abnamro/GRD0001007/_backlogs/backlog/BLK0003414/Epic%20Backlog/?workitem=1314894)
