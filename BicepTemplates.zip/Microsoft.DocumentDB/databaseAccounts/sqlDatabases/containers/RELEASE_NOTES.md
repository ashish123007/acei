# Release and Upgrade Notes  

## Version 1.4.1

- Released: 2025 May 01
- API Update from 2024-11-15 to 2025-04-15 for Microsoft.DocumentDB/databaseAccounts/sqlDatabases.
- Change done by auto-heal-function.

---

## Version 1.4.0

- Released: 2024 Dec 04
- Description: Updated Bicep versions to 2024-11-15.
  - Added:
    VectorEmbedding
    VectorEmbeddingPolicy
    VectorIndex
  - Removed:
    Components1Jq1T4ISchemasManagedserviceidentityPropertiesUserassignedidentitiesAdditionalproperties
    ManagedServiceIdentity
    ManagedServiceIdentityUserAssignedIdentities
    MaterializedViewDefinition
  - Updated:
    IndexingPolicy: Added property 'vectorIndexes'
    Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers:
    - Removed property 'identity'
    SqlContainerResourceOrSqlContainerGetPropertiesResource:
    - Added property 'vectorEmbeddingPolicy'
    - Removed property 'materializedViewDefinition'
- Story: [4690318](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4690318)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 1.3.0

- Released: 2024 June 10

- Description: Updated  BICEP  version
to 2024-05-15.
- Story: [3728201](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3728201)

---

## Version 1.2.1

- Released: 2024 Mar 18

- Description: Updated BICEP version to 2023-11-15. From the MS change log:
  - Updated: [Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers 2023-11-15](https://learn.microsoft.com/en-us/azure/templates/microsoft.documentdb/change-log/databaseaccounts/sqldatabases/containers#2023-11-15)
- Story: [3390807](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3390807)

---

## Version 1.2.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 1.1.0

- Released: 2023 May 08
- Description: Publish version issue.
Use only local references for submodules.
- Story: [2259486](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2259486)
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 1.0.2

- Released: 2023 May 08
- Description: New version because of new api version.
- Story: [2259486](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2259486)

---

## Version 1.0.1

- Released: 2023 Apr 07
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 1.0.0

- Released: 2022 Nov 16
- Description: Initial release of CosmosDB Container bicep.
Activated retry trigger in nightly.
- Story: [1314894](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1314894)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)
