# CosmosDB Container

This repository can be used to provision a CosmosDB Container. [Learn more](https://learn.microsoft.com/en-us/azure/cosmos-db/introduction)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/cosmosdb-container(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99158&branchName=main)

## Pre-Requisities

- Azure Key Vault as a keySource for encryption
- RSA2048 key for encryption
- User Assigned Managed Identity to access the Key Vault
- Azure CosmosDB Account
- Azure CosmosDB Database

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module cosmosDBContainerModuleDeploy 'br/FSCPRegistry:bicep/modules/dip/core/cosmosdb-container:1.4.1' = {
  name: '<Resource Name>'
  params: {
    containerName: '<Container Name>'
    databaseName: '<Database Name>'
    accountName: '<Account Name>'
  }
}
```

**Required parameters**

| Parameter Name | Type |  Description |
| :-- | :-- | :-- |
| containerName | string  | Container Name. |
| databaseName | string  |  Database Name.   |
| accountName | string  | Account Name.  |

**Optional parameters**

| Parameter Name | Type | Default Value |  Description |
| :-- | :-- | :-- | :-- |
| additionalContainerProperties | object | {} | Additional Container Properties. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| paths | array | [ '/myPartitionKey' ] | List of paths using which data within the container can be partitioned. |
| kind | string | 'Hash' | Indicates the kind of algorithm used for partitioning. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| container | object | CosmosDb Container Object |
| name | string | The name of the created resource. |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### CosmosDB Container Resource

| Name | Description | Value |
| :-- | :-- | :-- |
| properties | Properties of CosmosDB Container  | CosmosDbContainerProperties |

### CosmosDbContainerProperties

| Name | Description | Value |
| :-- | :-- | :-- |
| resource | Parent Resource(CosmosDB Database) | object |

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/58824/AAB-Cosmos-DB-v1>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/cosmos-db/nosql/manage-with-bicep>
