# Databricks

This repository can be used to deploy an instance of Databricks. [Learn more](https://learn.microsoft.com/en-us/azure/databricks/)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/databricks(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99161&branchName=main)

## Pre-Requisites

- A virtual network with a private and public subnet (use SNSS)
[Learn more](https://learn.microsoft.com/en-us/azure/databricks/administration-guide/cloud-configurations/azure/vnet-inject)
- Azure Key Vault as a keySource for encryption with CMK (*)
- RSA2048 key with the required expiry date, to enable CMK for Managed Services
[Learn more](https://learn.microsoft.com/en-us/azure/databricks/security/keys/customer-managed-key-managed-services-azure)
(*)
- Role assignments that allow Azure Databricks to Unwrap Key, Get, Wrap Key from the Keyvault
(*) (**)

(*) One policy, to enable CMK-based encryption on Databricks and its managed resources, dictates these requirements.
The policy, however, is still in AUDIT mode for every workload type.
The managed storage account compliancy currently cannot be implemented fully by the module as a consequence
of lacking permissions in the resource group that is managed by the Databricks service.
How to register the violation as an exemption, please notice the remark in the Policy Details section below.
For more background, refer to this [backlog item](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2201930).

(**) Azure Databricks uses various system assigned identities for its managed resources.
To enable CMK for all managed resources first a workspace should be created,
then the role based access, then the CMK enabled on the workspace.

## Usage Guidance

### Prerequisites

If you don't have all the Prerequisites yet, you can also choose to create a pipeline step.
In the file `pipelines/jobs.pre-deployment-setup.yml` you will find an example on how to do this.

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module configurationStore 'br/FSCPRegistry:bicep/modules/dip/core/databricks:3.4.0' = {
  name: '<name of deployment>'
  params: {
    name: '<databricks name>'
    customPrivateSubnetName: '<private subnet name>'
    dbstorage: '<databricks stroage name>'
    customPublicSubnetName: '<public subnet name>'
    customVirtualNetworkId: '<customVirtualNetworkId>'
    managedResourceGroupName: '<managedResourceGroupName>'
   }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| customPrivateSubnetName | string | A custom container subnet. |
| customPublicSubnetName | string | A custom host subnet. |
| customVirtualNetworkId | string | A custom virtual network id. |
| dbstorage | string |  A custom name for the Blob storage created by Databricks. |
| name | string | The name of the Azure Databricks workspace to create. |
| managedResourceGroupName | string | Custom name for the resource group created by Databricks.|

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalDatabricksProperties | object | {} | User provided resource properties. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| dbfsRootEncryption | object | {} | The parameters.encryption.value object. See [MSFT documentation](https://learn.microsoft.com/en-us/azure/templates/microsoft.databricks/workspaces?pivots=deployment-language-bicep#encryption). |
| enableNoPublicIp | bool | true | Instance is not allowed to be open to internet. |
| location | string | resourceGroup().location | Location for all Resources. |
| resourceTags | object| {} | User provided resource tags in the form of json. |
| sku | string | Premium | The pricing tier of workspace. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| azureDB | object | Databricks resource as an object    |
| location | string | The location the resource was deployed into. |
| name | string | Name of the Databricks resource |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

### Enable CMK

CMK for DBFS Root storage cannot be enabled at Azure Databricks workspace creation time.
Azure will issue a message like this:

```code
Configure encryption for workspace at creation is not allowed,
configure encryption once workspace is created and key vault access policies are added
```

The enable CMK you require to:

1. create workspace
1. arrange keyvault access
1. update workspace with CMK settings

These 3 steps are _not_ engineered as part of the Bicep module,
hence you require to implement it in your own template.
Below you find sample code for steps 2 and 3.
Actually the `test/cmk.bicep` testcase contains a live sample.

```code
  resource kv 'Microsoft.KeyVault/vaults@2024-11-01' existing = {
    name: '<keyvault name>'
  }

  resource key 'Microsoft.KeyVault/vaults@2024-11-01' existing = {
    parent: kv
    name: '<key name>'
  }

  var strKeyVaultUri = kv.properties.vaultUri
  var strKeyName = '<key name>'
  var strKeyVersion = last(split(symbolicname.properties.keyUriWithVersion, '/'))
  var azureDatabricksObjectId = '346e54aa-2ff0-4ee9-bace-44ec6374fdb7'

  // create the RBAC for Azure Databricks and its System-Managed Identities
  module configurationStoreRbac 'br/FSCPRegistry:bicep/modules/dip/core/role-assignments:<version tag>' = {
    name: '<name of deployment>'
    params: {
      roleAssignments: [
        {
          principalId: configurationStore.outputs.azureDB.properties.authorizations[0].principalId
          roleDefinitionName: 'Key Vault Crypto Service Encryption User'
          resourceId: 'Microsoft.KeyVault/vaults/<keyvault name>'
        }
        {
          principalId: configurationStore.outputs.azureDB.properties.storageAccountIdentity.principalId
          roleDefinitionName: 'Key Vault Crypto Service Encryption User'
          resourceId: 'Microsoft.KeyVault/vaults/<keyvault name>'
        }
        {
          principalId: azureDatabricksObjectId
          roleDefinitionName: 'Key Vault Crypto Service Encryption User'
          resourceId: 'Microsoft.KeyVault/vaults/<keyvault name>'
        }
      ]
    }
  }

  // update Databricks with encryption
  module configurationStoreUpdate 'br/FSCPRegistry:bicep/modules/dip/core/databricks:<version tag>' = {
    name: '<name of deployment>'
    params: {
      name: '<databricks name>'
      customPrivateSubnetName: '<private subnet name>'
      dbstorage: '<databricks stroage name>'
      customPublicSubnetName: '<public subnet name>'
      customVirtualNetworkId: '<customVirtualNetworkId>'
      managedResourceGroupName: '<managedResourceGroupName>'
      dbfsRootEncryption: { 
        keySource: 'Microsoft.Keyvault'
        keyvaulturi: strKeyVaultUri
        KeyName: strKeyName
        keyversion: strKeyVersion
      }
      // when CMK is applied twice, the managed resources need to be referred in the deployment
      additionalDatabricksProperties: {
        encryption: {
          entities: {
            managedDisk: {
              keySource: 'Microsoft.Keyvault'
              keyVaultProperties: {
                keyVaultUri: strKeyVaultUri
                KeyName: strKeyName
                keyVersion: strKeyVersion
              }
              rotationToLatestKeyVersionEnabled: true
            }
            managedServices: {
              keySource: 'Microsoft.Keyvault'
              keyVaultProperties: {
                keyVaultUri: strKeyVaultUri
                KeyName: strKeyName
                keyVersion: strKeyVersion
              }
            }
          }
        }
      }
    }
    dependsOn: [ configurationStoreRbac ]
  }
```

## Policy Details

### SubnetIntegration

| Name | Description | Value |
| :-- | :-- | :-- |
| properties.parameters.customVirtualNetworkId.value | custom Virtual Network option should be used   | string |
| properties.parameters.customPublicSubnetName.value | should adhere to naming convention adbpublic##-subnet | string |
| properties.parameters.customPrivateSubnetName.value | should adhere to naming convention adbprivate##-subnet  | string |

### CustomerManagedKeys

Currently, due to the creation of a storage account for DBFS Root
in a different resourcegroup by Databricks,
it will not comply fully to the AAB policies.
Please request an exemption for the CMK policy of Databricks in your specific resource group using the documentation [here](https://confluence.int.abnamro.com/display/AZURE/Exemption+Process).

| Name | Description| Value |
| :-- | :-- | :-- |
| properties.parameters.encryption.value.keySource | should be set to a valid  value, e.g. 'Microsoft.Keyvault' | string |

### PublicWorkspace

| Name | Description | Value |
| :-- | :-- | :-- |
| properties.parameters.enableNoPublicIp.value | 'Enable no public IP' setting should set to 'true'. | boolean |

### SKUSetting

| Name | Description | Value |
| :-- | :-- | :-- |
| sku.name | 'SKU' setting should  set to 'Premium'. | string  |

## Network Connectivity

### Azure Public

From Azure Public PaaS services to Azure Databricks over HTTPS using TLS1.2.

### Azure Private

From Azure Private to Azure Databricks via the Azure Firewall Network Secure Perimeter over HTTPS using TLS 1.2.

## Reference

- <https://learn.microsoft.com/en-us/azure/templates/microsoft.databricks/workspaces?pivots=deployment-language-bicep>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/67486/AAB-Databricks-V1>
