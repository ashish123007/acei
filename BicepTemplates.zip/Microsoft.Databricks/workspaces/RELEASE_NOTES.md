# Release and Upgrade Notes

## Version 3.4.0

- Released: 2025 Jan 15
- Description: Allow for parameter overrides. Fix cmk testcase.
Renamed python script names.
- Story: [4851555](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4851555)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)
- Story: [5321420](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5321420)

---

## Version 3.3.1

- Released: 2024 Jul 15
- Description: Updated resource version from 2023-02-01 to 2024-05-01.
- Story: [3886777](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3886777)
- Story: [4851555](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4851555)

---

## Version 3.3.0

- Released: 2023 Sep 13

- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
Prevent role assignment leakage.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)
- Story: [3457882](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3457882)

---

## Version 3.2.0

- Released 2023 September 04
- Introduced addidionalDatabricksProperties and dbfsRootEncryption.
Enabled CMK testcase. Documented CMK setup.
- Story: [2632536](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2632536)

---

## Version 3.1.4

- Released 2023 August 8
- Upgraded Bicep versions.
Use only local references for submodules.
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 3.1.3

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 3.1.2

- Released: 2023 July 13
- Description: updated PLE version in the template from 2.2.0 to 2.2.1.
- Story: [2475562](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 3.1.1

- Released: 2023 July 03
- Description: Private Endpoint module version used has been updated.
- Story: [2438072](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2438072)

---

## Version 3.1.0

- Released: 2023 Apr 11
- Description: Update version of the databricks/workspace.
- Story: [2176786](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2176786)
- Story: [2221485](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2221485)

---

## Version 3.0.1

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 3.0.0

- Released: 2023 Jan 30
- Description: Added name as an output parameter and changed input parameter databricksName to name.
Activated retry trigger in nightly.
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1935001)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 2.0.0

- Released: 2022 Nov 18
- Description: updated module verison and release notes
- Story: [1706892](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1706892)
- Story: [1847324](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1847324)

---

## Version 1.0.1

- Released: 2022 Oct 10
- Description: PL and readme updates

---

## Version 1.0.0

- Released: 2022 Sep 30
- Description: Initial release of Databricks bicep
