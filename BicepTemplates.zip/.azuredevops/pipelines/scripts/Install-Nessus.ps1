$nessusCliPath = "$env:ProgramFiles\Tenable\Nessus Agent\nessuscli.exe"
$linkingKey = 'f0fa2bdc2cd741d259efc2b15404c7c12a0ed54a50c8276e1875151e7bd7890c'
$agentGroup = 'azure'
$bearer = 'f8cd107a7b02800760ac'
$nessusAgent = 'NessusAgent-latest-x64.msi'
$path = Join-Path -Path "c:/windows/temp/" -ChildPath $nessusAgent

function installAgent {
    Write-Host "Install the Nessus Agent"
    $headers = @{
	accept        = 'application/json'
	authorization = "Bearer $bearer"
    }
    $path = Join-Path -Path "c:/windows/temp/" -ChildPath $nessusAgent
    Write-Host "Downloading Nessus Agent to '$path'."
    $response = Invoke-WebRequest `
	-Uri "https://www.tenable.com/downloads/api/v2/pages/nessus-agents/files/$nessusAgent" `
	-Headers $headers `
	-Method GET `
	-OutFile $path
    Write-Host "Installing Nessus Agent from '$path'."
    msiexec /i $path NESSUS_SERVER='cloud.tenable.com:443' NESSUS_KEY=$linkingKey NESSUS_GROUPS=$agentGroup /qn
}

function downloadAgent {
    Write-Host "Download the Nessus Agent"
    $headers = @{
	accept        = 'application/json'
	authorization = "Bearer $bearer"
    }
    Write-Host "Downloading Nessus Agent to '$path'."
    $response = Invoke-WebRequest `
	-Uri "https://www.tenable.com/downloads/api/v2/pages/nessus-agents/files/$nessusAgent" `
	-Headers $headers `
	-Method GET `
	-OutFile $path
    Write-Host "Agent downloaded"
}


function linkAgent {
    Write-Host "Link the Nessus Agent"
    . $nessusCliPath agent link --key=$LinkingKey --cloud --groups=$agentGroup
    Write-Host "Agent linked"
}

function checkAgent {
    Write-Host "Check the Nessus Agent"
    $agentStatus = . $nessusCliPath agent status --remote
    Write-Host $agentStatus
    return $agentStatus
}

Write-Host "Check if Nessus is installed"
if (Test-Path -Path $nessusCliPath) {
    $agentStatus = checkAgent
    if ($agentStatus -match 'error|warn|not linked') {
	linkAgent
	return
    }
    Write-Host 'Nessus Agent installed and linked to Tenable.io.'

}
else {
    Write-Host 'Nessus Agent not present, will install'
    installAgent
    #checkAgent
    if ($agentStatus -match 'error|warn') {
	linkAgent
	return
    }
}
