# FSCP Bicep Templates

This repository contains a curated library of Bicep templates which can be used to kick start your
infrastructure code.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Support

These templates are owned and maintained by the Automation Team and we commit to keeping them compliant and helping
with any issues that teams have. Support queries can be asked by following the usual 
[FSCP 3.0 support process](https://confluence.int.abnamro.com/display/GRIDAD/Azure+Cloud+-+support)

## Updated ACR Location

As of December 2024 the Bicep modules have moved to a new ACR instance so its vital to update your bicepconfig.json 
file with the new location. Pull requests were raised to do this automatically, however you can also find the required
configuration below

```code
  "moduleAliases": {
    "br": {
      "FSCPRegistry": {
        "registry": "fscpbiceptemplates.azurecr.io"
      }
    }
```

## Available Resource Modules

| Name                                                                               | Nightly Compliance Check Status                                                                                                                                                                                                                                                                                                        | Available Submodules                                                                                                                                                          |
|------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| [App Config](./Microsoft.AppConfiguration/configurationStores/README.md)           | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/app-config(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99151&repoName=Azure&branchName=main)                        |                                                                                                                                                                               |
| [App Service](Microsoft.Web/sites/README.md)                                       | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/app-service(stable)?repoName=Azure)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99153&repoName=Azure)                                                       |                                                                                                                                                                               |
| [App Service Plan](Microsoft.Web/serverfarms/README.md)                            | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/app-service-plan(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99154&repoName=Azure&branchName=main)                  |                                                                                                                                                                               |
| [Application Gateway](Microsoft.Network/applicationGateways/README.md)             | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/application-gateway(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99156&repoName=Azure&branchName=main)               |                                                                                                                                                                               |
| [Application Gateway WAF Policies](Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies/README.md)             | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/app-gateway-waf-policies(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99152&repoName=Azure&branchName=main)               |                                                                                                                                                                               |
| [Backup Vault](Microsoft.DataProtection\backupVaults\README.md)                    | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/backup-vaults(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=106263&repoName=Azure&branchName=main)               |                                                                                                                                                                               |
| [CosmosDB](Microsoft.DocumentDB/databaseAccounts/README.md)                        | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/cosmosdb-account(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99157&repoName=Azure&branchName=main)                  | [SQL Database](./Microsoft.DocumentDB/databaseAccounts/sqlDatabases/README.md), [SQL DB Container](./Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers/README.md) |
| [Databricks](Microsoft.Databricks/workspaces/README.md)                            | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/databricks(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99161&repoName=Azure&branchName=main)                        |                                                                                                                                                                               |
| [Datafactory](Microsoft.DataFactory/factories/README.md)                           | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/datafactory(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99162&repoName=Azure&branchName=main)                       |                                                                                                                                                                               |
| [Disk Encrytion Set](Microsoft.Compute/diskEncryptionSets/README.md)               | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/disk-encryption-set(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99163&repoName=Azure&branchName=main)               |                                                                                                                                                                               |
| [Event Grid Domains](Microsoft.EventGrid/domains/README.md)                        | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/eventgrid-domain(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99166&repoName=Azure&branchName=main)                  |                                                                                                                                                                               |
| [Event Grid Topics](Microsoft.EventGrid/topics/README.md)                          | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/eventgrid-topics(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99167&repoName=Azure&branchName=main)                  |                                                                                                                                                                               |
| [Event Hubs](Microsoft.EventHub/namespaces/README.md)                              | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/event-hub(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99165&repoName=Azure&branchName=main)                         |                                                                                                                                                                               |
| [Key Vault](Microsoft.KeyVault/vaults/README.md)                                   | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/keyvault(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99169&repoName=Azure&branchName=main)                          | [Key](./Microsoft.KeyVault/vaults/keys/README.md)                                                                                                                             |
| [Load Balancer](Microsoft.Network/loadBalancers/README.md)                         | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/loadbalancer(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99170&repoName=Azure&branchName=main)                      |                                                                                                                                                                               |
| [MySQL Flexible Servers](Microsoft.DBforMySQL/flexibleServers/README.md)           | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status%2FBicepTemplates%2Fmysql-flexible-server(stable)?repoName=BicepTemplates&branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=98353&repoName=BicepTemplates&branchName=main) | [Database](./Microsoft.DBforMySQL/flexibleServers/databases/README.md)                                                                                                        |
| [Notification Hubs](Microsoft.NotificationHubs/namespaces/README.md)               | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/notification-hub(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99171&repoName=Azure&branchName=main)                  |                                                                                                                                                                               |
| [PostgreSQL Flexible Servers](Microsoft.DBforPostgreSQL/flexibleServers/README.md) | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/postgres-flexible-servers(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99172&repoName=Azure&branchName=main)         | [Database](./Microsoft.DBforPostgreSQL/flexibleServers/databases/README.md)                                                                                                   |
| [Private Endpoint](Microsoft.Network/privateEndpoints/README.md)                   | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/private-endpoints(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99174&branchName=main)                                                                         |                                                                                                                                                                               |
| [Recovery Services Vault](./Microsoft.RecoveryServices/vaults/README.md)           | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/recovery-services-vault(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99175&repoName=fscp-recovery-services-vault&branchName=main) |                                                                                                                                                                               |
| [Redis Cache](Microsoft.Cache/redis/README.md)                                     | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/redis(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99176&repoName=Azure&branchName=main)                             |                                                                                                                                                                               |
| [Role Assignments](Microsoft.Authorization/roleAssignments/README.md)              | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/role-assignments(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99132&repoName=Azure&branchName=main)                  |                                                                                                                                                                               |
| [Service Bus](Microsoft.ServiceBus/namespaces/README.md)                           | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/service-bus(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99177&repoName=Azure&branchName=main)                    |                                                                                                                                                                               |
| [SQL Database](Microsoft.Sql/servers/README.md)                                    | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/sql-server(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99179&repoName=Azure&branchName=main)                        | [Database](./Microsoft.Sql/servers/databases/README.md)                                                                                                                       |
| [Static Web App](./Microsoft.Web/staticSites/README.md)                            | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/static-web-app(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99181&repoName=Azure&branchName=main)                |                                                                                                                                                                               |
| [Storage Account](./Microsoft.Storage/storageAccounts/README.md)                   | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/storage-account(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99182&repoName=Azure&branchName=main)                   |                                                                                                                                                                               |
| [Virtual Machine](Microsoft.Compute/virtualMachines/README.md)                     | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/virtual-machine(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99183&repoName=Azure&branchName=main)                   |                                                                                                                                                                               |
| [Virtual Machine Scale Set](Microsoft.Compute/virtualMachineScaleSets/README.md)   | [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/virtual-machine-scale-set(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99184&repoName=Azure&branchName=main)         |                                                                                                                                                                               |

### Missing Modules

You may find a service you wish to use is missing from this repository, and that is because we are focussing on services which have
policies associated with them. We are making this choice as we feel creating 'ABN' modules for services without specific
requirements is just building an extra layer between ourselves and Microsoft. If you wish to use one of these missing services,
the best approach is to refer directly to the [Microsoft resource](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/resource-declaration?tabs=azure-powershell) 
in your bicep code, however there are a number of cases where this is extremely cumbersome, if not impossible. 
In these cases you have a few options
1. Create a 'local' module - This approach creates a wrapper module around the bicep resource, which is in the same 
repository as the bicep code instead of publishing to ACR, and examples can be found in the [Application Gateway Scenario](https://confluence.int.abnamro.com/display/AZURE/Azure+Key+vault+and+Application+Gateway+Communication2#AzureKeyvaultandApplicationGatewayCommunication2-Step1:Addtheprerequisitesresources)
as well as the [Automatcher](https://dev.azure.com/cbsp-abnamro/GRD0001007/_git/fscp-automatcher?path=/pipelines/template/id-module/uami.bicep)
1. Contribute the module - We are happy to accept pull request contributions to this repository to fill out the services
which the Automation team is not prioritising. Its mandatory that the same structure (including documentation) and pipeline 
is used to ensure all the services have a consistent implementation. 
1. Request the module - You can always reach out to the Automation team at FSCPAutomationTeam@nl.abnamro.com  to request
a service is added, however keep in mind that services with policies are being prioritized, so this will not be the quickest 
approach

## Contributing Guidelines

We invite everyone to contribute to the quality of our modules.
If you want to make an improvement, you can do so by following the steps below.

In this way we ensure the consistency and quality of the code. 

### Branching the repository

Everybody should be able to create a branch from the module repository.
If you cannot please get in contact to our team.

If you create a branch of this repo, please use a branch name that holds the user story
reference number you are working on, e.g.
`feature/1234567-my-sqldb-improvement`.
Also be sure that the branch is linked to the same work item.

Create a contribution branch from the `main` branch.

### Clone the repository and branch

Clone the module repository and activate the contribution branch.

### Identify your module pipeline

In the [Module Pipelines](https://dev.azure.com/cbsp-abnamro/Azure/_build?definitionScope=%5CBicepTemplates)
folder filter for `(dev)`.
Each module has its own development verification pipeline.
Identify the one that is applicable for the module you are going to improve.
The names of the pipelines should be self-explanatory.

### Run the pipeline

To check if the module meets the requirements you can run the pipeline.
This pipeline checks the following things.
1. Code style according to market standards (linting).
1. Are the parameters described in the `readme.md` file.

Click on the `Run Pipeline` button of the module pipeline.

Select the branch you just created and checkmark the `contributor` parameter.
When this parameter is checked only a minimal set of verifications will
be active during the pipeline run.
Above that unnecessary dependencies to pipeline resources are removed from the
pipeline run.

The pipeline should run successfully.

### Implement your change

As you implement your changes, don't forget to update the documentation
(`README.md`) and release notes(`RELEASE_NOTES.md`) as well.

In case of a breaking change, the 'upgrade steps' should be described in the
release notes.

After your changes you should run the pipeline again, to see if it still runs
successfully.

### Create a pull request

First revert the changes in the `variables.yml` file.

Create a pull request from the contributor branch towards the main branch.
In the description we would like to see the following things:
1. What has changed?
1. Is it a breaking change.
1. Is there a migration guide for this change, required for a breaking change.
1. The link to the succesful pipeline run.

## Additional Parameters

The modules follow a philosophy of providing the most important parameters, while also enabling consumers to use any
parameters found in the Microsoft documentation, and to do this we provide an `additionalProperties` parameter. This field
will be combined with the values that are preset for compliance, allowing complete control over the created resource.
This approach has an additional benefit in that the modules do not need to be updated if additional functionality is added
to the underlying Microsoft service.

### Example - Service Bus

If I wanted to create a Service Bus Namespace with an alternate name and without local auth then I can use the
`additionalServiceBusProperties` parameter to configure these, even though they aren't exposed as parameters.

```code
module serviceBusModuleDeploy 'br/FSCPRegistry:bicep/modules/dip/core/service-bus:X.X.X' = {
  name: '<Deployment Name>'
  params: {
    serviceBusNamespaceName: <Service Bus Namespace Name>
    keyVaultUserAssignedIdentity: '<ARM ID of Managed User Identity>'
    keyName: '<KeyVault Name>'
    keyVaultUri: '<KeyVault URI>'
    keyVersion: '<Key version>'
    additionalServiceBusProperties: {
        alternateName: '<An example name>'
        disableLocalAuth: false
    }
  }
}
```

The object passed in will be combined with the existing parameters using the
[Bicep union function](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/bicep-functions-object#union)
so its important the structure matches what can be found in the Microsoft documentation for the relevant service,
which in this example is [Service Bus](https://learn.microsoft.com/en-us/azure/templates/microsoft.servicebus/namespaces?pivots=deployment-language-bicep)

## Reusing modules across environments

When you use [Bicep](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/)
for your infrastructure deployments you will always end up with one or a few 'main' Bicep modules.
These main modules glue together parts or all of your infrastructure.
The plural _modules_ is intentionally here, as virtually all use cases that have the ambition to create
a complete infrastructure in _one pipeline run_ require a `prerequisite` stage and a `main` stage. 
For example, if your solution contains a private Application Gateway, you need to create a Key Vault
with a SSL Certificate signed by the ABN AMRO Infra CA in advance.
The certificate signing task cannot feasibly be triggered from Bicep directly.

Your infrastructure might have different properties from environment to environment.
Examples are resource names, IP white lists,
and resource SKUs.
The infrastructure also might contain resources that are only present in some environments.
For example extended role assignments for the devops team in development.
Environments are traditionally named `development`, `test`, `acceptance` and `production`.

It is good practice to discriminate between the infrastructure topology
and its properties and features.
Technically this can be arranged as follows.
- the main Bicep modules describe the topology
- the Bicep parameters specify the properties and features

Parameter files can either contain static, manually maintained values,
or be (partially) generated.

[Here](./infra-pipelines.md) you find more information on how you can utilize
parameter files and pass (complex) parameter values to the FSCP Bicep modules.

### Infra pipeline set-up as adviced by FSCP Automation Team

The FSCP Automation Team created a
[reference pipeline](https://dev.azure.com/cbsp-abnamro/GRD0001007/_git/fscp-automatcher?path=/pipelines).
This pipeline is based on the
[FTT QuickStart](https://dev.azure.com/cbsp-abnamro/FSCP%20Azure%20Community/_git/FSCPAzureCommunity?path=/FTT-Accelerator/Pipelines/quickStartPipeline).
It adopts the FTT naming standards and directory structure, and adds to its functionality, most notably:

- introduce a `prerequisite` infrastructure creation _stage_

- allow for generated Bicep parameter files

The reference cookbook is as follows:

1. Create as many top-level Bicep files in `template` subdirectory  as there are infra creation
stages based on Bicep in your solution.
For example, if you require 2 stages named `prerequisite` and `main`, you create 2 
top-level Bicep files: `template/prerequisite.infrastructure.bicep` and `template/main.infrastructure.bicep`.

1. In `template` subdirectory you can create any amount of local Bicep modules you like or require.

1. Create parameter files for each infra creation stage in `parameter` subdirectory: `parameter/bicep.parameter.$(stage).json`.  
Use place holders for each parameter value that differs, or might differ, in different environments.
Be prepared to accept syntax errors from you JSON editor,
if you use other datatypes than strings for your parameters.  
If syntax errors are intolerable, you should either use `"$[` and `]"` (or similar)
or stick to literal value for non-strings (see below).

1. Create a global variables file in `parameter` subdirectory: `parameter/global.variables.yml`.
This holds all values that are same in ALL environments
and loads shared variable groups from pipeline library and filesystem. 
Allow for a parameter `targetEnvironment` in this file, and switch over its value in this file,
to load environment specific variable groups and templates.
Also set `serviceshortname` and `shortenv` variable to hold a resource naming prefix
and the first letter of the `targetEnvironment`.

1. Create a variable file for each environment in your solution in `parameter` subdirectory:  `parameter/$(targetEnvironment).variables.yml`.  
These long environment names are only used for file naming.
All these files set environment specific values.
It is a matter of taste whether to define derived values in the global variables file or the
environment specific variable files. A derived variable value could be like
`$(serviceshortname)-$(shortenv)-cosmos` for your Cosmos namespace, assuming you have only one per environment.

1. Create a tokenizer tasks template that is aligned to your token separators.  
These tasks should be part of _every_ pipeline stage.
In these tasks you can also calculate dynamic values.
Most dynamic values have to be calculated only once,
but some are only known after a previous stage is completed.
An example of the latter is the version of a key that is created in in the prerequisite stage.  
The reference pipeline tasks template that uses token replacement can be found
[here](https://dev.azure.com/cbsp-abnamro/GRD0001007/_git/fscp-automatcher?path=/pipelines/tasks.setup-variables.yml).

1. Optionally split the infra pipeline in a trigger part and an extension template.  
If you require different pipeline triggers/schedules for different environments you can place the variables and stages section
in an extension template. The original pipeline YAML will then hold the triggers and schedule and extend from the template
for one environmenty only.
The reference pipeline definition that extends from an extension template can be found
[here](https://dev.azure.com/cbsp-abnamro/GRD0001007/_git/fscp-automatcher?path=/pipelines/infra-pipeline.yml).

### Troubleshooting Bicep errors


#### Looking for correct error:

When the error message is not clear in the azure devops pipeline logs or you need more information, it's always better to check in the deployments section in Resource Group using the Azure portal.

1. Go to https://portal.azure.com/#home
    
1. Select your own Resource group in which you are deploying your resource.

1. You can find section "settings" in left side coloumn.

1. There you can see "Deployments" section where you can find all your deployments of resources and related logs which gives you more insights.

1. Every bicep module creates a deployment in here and you can find the deployment name in pipeline logs and you can search the same here. 
For example in on our deployment pipeline I see my deployment name as `"deployment_name=loadbalancer_3688026_default_1"`

1. Once you know your deployment name check for it in Deployments and click on the resource which is failing, look for "operation details" for more clear information on the errors.

### FAQs

1. How is the versioning is being maintained and supported?
    
    - All versions of bicep modules are published in ACR. However, latest versions are AAB policy compliant and in line with latest released versions from Microsoft. In case teams are using extremely old version and has an issue or query, we will ask them to upgrade to latest one. 

1. How teams will be impacted due to version change?
    
    - Teams are being notified via our channel when ever there is a new version or a breaking change is introduced, instructions are clearly mentioned in ReadMe of particular bicep module. Teams are advised to go through ReleaseNotes to see what change has been introduced in new released version.

1. Support model to devops teams in case something does not work?

    - Bicep module specific quieries are answered in Automation teams channel [General](https://teams.microsoft.com/l/channel/19%3AGEUWt9eipBWmMxdiP18DWisrwSBDhDwkowU3uTG644c1%40thread.tacv2/General?groupId=4cee2311-953c-463f-ac3c-0193fe71d8e3&tenantId=3a15904d-3fd9-4256-a753-beb05cdf0c6d)


1. If the biceps status pipelines fails in [dashboard](https://dev.azure.com/cbsp-abnamro/Azure/_git/BicepTemplates?version=GBfeature/movecode&path=/README.md&_a=preview), automation team will fix it but how they will let consumer know something fixed.
    
    - Teams gets notification via Automation teams channel [Channel Updated](https://teams.microsoft.com/l/channel/19%3A1b02800bbd5649568662717f61ba8442%40thread.tacv2/Channel%20Updates?groupId=4cee2311-953c-463f-ac3c-0193fe71d8e3&tenantId=3a15904d-3fd9-4256-a753-beb05cdf0c6d) whenever there is a new version of bicep module.
