# Recovery Services vault

This module creates a Recovery Services vault.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/recovery-services-vault(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99175&branchName=main)

## Pre-Requisities

- Key Vault for CMK
- Key for CMK
- User managed identity for CMK
- Private Endpoint Subnet

## Usage Guidance

### Prerequisites

If you don't have all the Prerequisites yet, you can choose to create a pipeline step.
In the file `pipelines/jobs.pre-deployment-setup.yml` you will find how to do this.

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module recoveryServicesVaultModule 'br/FSCPRegistry:bicep/modules/dip/core/recovery-services-vault:2.6.1' = {
  name: '<name of deployment>'
  params: {
   name: '<The resource name.>'
   privateEndpointVnetResourceGroup: '<Private endpoint vnet resource group name.>'
   privateEndpointVnetName: '<Private endpoint vnet name.>'
   privateEndpointSubnetName: '<Private endpoint subnet name.>'
   privateEndpointGroupIds: [ 'AzureBackup', 'AzureSiteRecovery' ]
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| privateEndpointSubnetName | string | Private endpoint subnet name. |
| privateEndpointVnetName | string | Private endpoint vnet name. |
| privateEndpointVnetResourceGroup | string | Private endpoint vnet resource group name. |
| name | string | The resource name. |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalConfigurationProperties | object | {} | Additional configuration properties in the form of json. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| identity | object | { type: 'SystemAssigned' } | The identity of the vault (1) |
| location | string | location of the resource group | Resource location. |
| privateEndpointGroupIds | array |  [ 'AzureSiteRecovery' ] | Array containing private link service group IDs: 'AzureBackup', 'AzureSiteRecovery'. (2) |
| resourceTags | object | {} | User provided resource tags in the form of json. |
| userAssignedIdentities | string | '' | The list of user-assigned identities associated with the resource. The user-assigned identity dictionary keys will be ARM resource ids in the form: '/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/{identityName}'. |

(1) The default is dependent on value of `userAssignedIdentities`.
If a user assigned identity is passed the default is

```code
{
  type: 'UserAssigned'
  userAssignedIdentities: {
    <userAssignedIdentities.value>: {}
  }
}
```

If `identity` parameter is not empty it will override the defaults
as set by the module.
Please take following notes.

1. To create in-rest encryption a System-Assigned managed identity
is required.
Encryption cannot be enabled through the module .
1. The identity type `'SystemAssigned, UserAssigned'`
cannot be created through Bicep.
It will be silently reset to trype `'None'` due to a defect
in Azure Resource Manager.

(2) For each groupId a private endpoint will be created.

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| location | string | The location the resource was deployed into. |
| name | string | Name of the Recovery Services vault |
| recoveryServicesVault | object | Recovery Services vault |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Enable CMK

Enable encryption using customer-managed keys at vault creation is still in preview.
To comply with the policy '[Preview]: Azure Recovery Services vaults should use customer-managed keys for encrypting
backup data', you must enable CMK after the deployment.

How to do this can be found in the file `pipelines/jobs.post-deployment-test.yml`.

## Policy Details

This section details which properties need to be set and what values should be used to create a compliant service.
They are already implemented in the provided template but this information can be used if you wish to create your
own template.

### ResourceIdentity

| Name | Description | Value |
| :-- | :-- | :-- |
| type | The type of managed identity used. | 'UserAssigned' |
| userAssignedIdentities | The user-assigned identity dictionary keys will be ARM resource ids in the form:'/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/{identityName}'. | |

### KeyVaultProperties

| Name | Description | Value |
| :-- | :-- | :-- |
| identityClientId | The client id of the identity which will be used to access key vault. | string |
| keyIdentifier | The URI of the key vault key used to encrypt data. | string |

### BackupConfig

| Name | Description | Value |
| :-- | :-- | :-- |
| softDeleteFeatureState | State of softdelete feature, Enabled or Disabled. | 'Enabled' |
| isSoftDeleteFeatureStateEditable | True if the soft delete feature state is editable. | false |

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/69949/AAB-Recovery-Services-Vault-v1>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
