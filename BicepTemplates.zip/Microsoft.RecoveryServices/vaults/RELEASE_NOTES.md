# Release and Upgrade Notes

## Version 2.6.1

- Released: 2025 May 28
- Description: advanced version after PEP API change.
Create 2 PEPs in nightly to adher to preview audit policy.
- Story: [5435053](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5435053)

---

## Version 2.6.0

- Released: 2025 Mar 17 to latest
- Description: updated api version to latest
Renamed python script names.
- Story: [5122199](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5122199)
- Story: [5321420](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5321420)

---

## Version 2.5.1

- Released: 2025 Mar 11
- Description: updated version due to BICEP PEP upgrade
- Story: [5101539](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5101539)

---

## Version 2.5.0

- Released: 2024 Dec 04
- Description: Upgrade Bicep version to 2024-05-01
  No properties added, updated or removed.
- Story: [4693855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4693855)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 2.4.1

- Released: 2024 Oct 28
- Description: updated version due to PEP upgrade
KeyVault using RBAC Role instead of Access Policy
- Story: [4470596](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4470596)
- Story: [4523220](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4523220)

---

## Version 2.4.0

- Released: 2024 July 25
- Description: updated new release version
- Story: [3934336](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3934336)

---

## Version 2.3.1

- Released: 2024 May 10
- Description: updated version due to PEP upgrade
- Story: [3616182](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3616182)

---

## Version 2.3.0

- Released: 2023 Dec 29
- Description: added support for
System-Assigned managed identity.
Prevent role assignment leakage.
- Story: [2877354](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2877354)
- Story: [3457882](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3457882)

---

## Version 2.2.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 2.1.0

- Released 2023 September 9
- Workaround for AzureSiteRecovery PLS issue.
Temporary exempt PEP audit policy from nightly.
- Story: [2682983](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2682983)
- Story: [2692184](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2692184)

---

## Version 2.0.7

- Released 2023 August 8
- Upgraded Bicep versions.
Use only local references for submodules.
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)
- Story: [2567033](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2567033)

---

## Version 2.0.6

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 2.0.5

- Released: 2023 July 13
- Description: updated PLE version in the template from 2.2.0 to 2.2.1.
- Story: [2475562](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 2.0.4

- Released: 2023 July 03
- Description: Updated version of private endpoint.
- Story: [2438072](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2438072)

---

## Version 2.0.3

- Released: 2023 Apr 24
- Description: Updated version of private endpoint.
- Story: [2221485](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2221485)

---

## Version 2.0.2

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2167088)

---

## Version 2.0.1

- Released: 2023 Feb 14
- Description: Updated Microsoft API version.
Activated retry trigger in nightly.
- Story: [2000837](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2000837)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 2.0.0

- Released: 2023 Jan 30
- Description: Added name as an output parameter and changed input parameter recoveryServicesVaultName to name.
- Story: [1935001](https://dev.azure.com/cbsp-abnamro/GRD0001007/_sprints/taskboard/BLK0003414/GRD0001007/BLK0003414/Sprint%20158?workitem=1935001)

---

## Version 1.3.0

- Released: 2022 Nov 18
- Description: Fixed CMK in postdeployment and added a bicep consume test.
- Story: [1515538](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1515538)
- Story: [1847324](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1847324)

---

## Version 1.2.0

- Released: 2022 Nov 18
- Description: updated module version and release notes
- Story: [1706892](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1706892)

---

## Version 1.1.0

- Released: 2022 Oct 24
- Description: Consumption of published PE 2.0.0 module; output complete object.

---

## Version 1.0.0

- Released: 2022 Oct 10
- Description: Initial release of Recovery Services Vault
