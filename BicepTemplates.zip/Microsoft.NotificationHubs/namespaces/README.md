# Notification Hub

This repository can be used to provision a Notification Hubs Namespace. [Learn more](https://learn.microsoft.com/en-us/azure/notification-hubs/notification-hubs-push-notification-overview)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/notification-hub(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99171&branchName=main)

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

**Please note from version 1.3.0, default value of sku name has been updated.**

```code
module notificationHubModuleDeploy 'br/FSCPRegistry:bicep/modules/dip/core/notification-hub:1.4.0' = {
  name: '<name of deployment>'
  params: {
    name: '<name of the resource>'
  }
}
```

**Required parameters**

| Parameter Name | Type |  Description |
| :-- | :-- | :-- |
| name | string  | The Resource Name |

**Optional parameters**

| Parameter Name | Type | Default Value |  Description |
| :-- | :-- | :-- | :-- |
| additionalNotificationHubProperties | object | {} | Any additional properties of notification hub namespace which the user wants to provide. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| location | string | Resource Group Location | The Geo-location where the resource lives |
| skuName | string | 'Basic' | The SKU name of the Notification Hub |
| resourceTags | object | {} | User provided resource tags in the form of json. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| location | string | The location the resource was deployed into. |
| name | string | Name of the Notification Hubs Namespace |
| notificationHubNamespace | object | Notification Hubs Namespace |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

### Shared access policy

Policy denies the deployment  when the 'AuthorizationRules' property exists on the Notification Hub Namespace level.

## Network Reference

This module use has no relation to a virtual network.

## Reference

- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/69717/AAB-Notification-Hub-(Namespace)-v1>
- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://learn.microsoft.com/en-us/azure/templates/microsoft.notificationhubs/namespaces?pivots=deployment-language-bicep>
