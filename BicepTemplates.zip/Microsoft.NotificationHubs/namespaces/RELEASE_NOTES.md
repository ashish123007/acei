# Release and Upgrade Notes

## Version 1.4.0

- Released: 2024 Dec 17
- Description: Introduced additional properties parameter.
- Story: [4752798](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/4752798)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 1.3.0

- Released: 2024 Aug 27
- Description: Default value of sku from Standard with  Basic to save on cost
- Story: [3816522](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3816522)

---

## Version 1.2.1

- Released: 2024 Apr 30
- Description: Reverted to version @2017-04-01 since the newer one gives an Internal Server Error.
- Story: [3577913](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3577913)

---

## Version 1.2.0

- Released: 2024 Apr 26
- Description: updated api version to 2023-09-01
- Story: [3566098](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3566098)

---

## Version 1.1.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 1.0.1

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2167088)

---

## Version 1.0.0

- Released: 2023 Mar 07
- Description: Initial release of Notification Hub Namespace bicep
Activated retry trigger in nightly.
- Story: [1314874](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1314874)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)
