# Role Assignments

This repository can be used to deploy an instance of a Role Assignment. [Learn more](https://learn.microsoft.com/en-us/azure/role-based-access-control/overview)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/role-assignments(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99132&branchName=main)

## Pre-Requisities

Not Applicable

## Usage Guidance

This is an end user convenience module, which was created to avoid all customers creating their own RBAC module,
as it is not possible for Bicep resources to depend on the outputs of Bicep modules.
In addition, the `scope` property in pure Bicep role assignments adds complexity to
a generic RBAC module that handles resources of various types.
You can find an usage example in the [Automatcher](https://dev.azure.com/cbsp-abnamro/GRD0001007/_git/fscp-automatcher?path=/pipelines/template/main.infrastructure.bicep).

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module.
The snippet also shows a best practice for deployment names.
The `deploymentsNameFormat` optional parameter is passed from the context to
every child module, so that child deployments have uniform names with a common,
preferably unique piece of data.
For example, the main module could utilize the value of the pipeline
variable `$(Build.BuildId)` to feed this mechanism.

```code
// a format string initialized in main module and passed to every child module
param deploymentsNameFormat string = '<some unique string>-{0}'

module rbac 'br/FSCPRegistry:bicep/modules/dip/core/role-assignments:1.3.0'  = {
  name: format(deploymentsNameFormat, '<deployment name>')
  params: {
    roleAssignments: [
      {
        principalId: '<object ID>'
        principalType: 'ServicePrincipal'
        roleDefinitionId: '<role deninition ID>'
        resourceId: '<resource namespace>/<resource type>/<resource name>'
      }
    ]
    deploymentsNameFormat: deploymentsNameFormat
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| roleAssignments | array | list of role assignments (1). |

(1)
One `role assignment` (as input) is an object that links one principal, role
and resource scope to be used for RBAC resource creation.
Each of the 3 elements is provided as a single _string_.
The default fields of a `role assignment` are as follows:

```code
{
  userId: ''
  groupId: ''
  uamiName: ''
  principalId: ''
  principalType: 'ServicePrincipal'
  roleDefinitionId: ''
  roleDefinitionName: ''
  resourceId: ''
}
```

These fields have following semantics.

- `userId`,
one AD (Active Directory) User objectID. Used for RBAC assignee with principalType 'User'.

- `groupId`,
one AD Group objectID. Used for RBAC assignee with principalType 'Group'.

- `uamiName`,
one user-assigned managed identity name.
Used for RBAC assignee with principalType 'ServicePrincipal'.
Name will be resolved to a principalID.

- `principalId`,
one typed object ID. Used for RBAC assignee with principalType 'ServicePrincipal', or user-specified principalType.

- `principalType`,
principalType to use for object IDs that are specified as `principalId`.
Defaults to 'ServicePrincipal'.

- `roleDefinitionId`,
one role definition ID. Used for RBAC role.

- `roleDefinitionName`,
one role definition name.
Must be the _exact_ name of a
built-in role definition.
Used for RBAC role.

- `resourceId`,
one short resource ID. Used for RBAC scope.
A short resource ID is the concatenation of resource namespace, resource type and resource name.
Use '.' to refer to default scope (resource group).

The user inputs are expanded to an array that holds an entry for each
individual `Microsoft.Authorization/roleAssignments` resource to be created in the module.
If a role assignment resource for same assignee, same role definition and same scope already exists in the subscription,
its resource name _must_ be same, otherwise the module deployment will show an error.
So best practice is to create RBAC entries through this FSCP module only in your resource group, and not another mechanism.

When a `role assignment` (input) has no assignee, role definition, or resource specified, it is silently ignored.

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| roleAssignmentsInfo | array | The inputs for role assignments deployment |
| roleAssignmentsDeployment | object | The role assignments deployment. The list of created resources is available as `roleAssignmentsDeployment.properties.outputResources` |

## Policy Details

This is an end user convenience module. There are no applicable FSCP3 policies.

## Network Reference

The resources created in this module are not applicable to any networking

## Reference

- <https://learn.microsoft.com/en-us/azure/templates/microsoft.authorization/roleassignments?pivots=deployment-language-bicep>
