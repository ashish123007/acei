# Release and Upgrade Notes

## Version 1.3.0

- Released: 2024 Dec 04
- Description: updated version due to Bicep upgrade
- exempted API version check
- Story: [4693855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4693855)
- Story: [4752798](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4752798)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 1.2.1

- Released: 2024 Oct 07
- Description: Added newly published roles from Microsoft.
- Story: [4246477](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4246477)

---

## Version 1.2.0

- Released: 2024 May 08
- Description: Updated bicep version.
Activated retry trigger in nightly.
- Story: [3611564](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3611564)

---

## Version 1.1.1

- Released: 2024 Apr 18
- Included Key Vault Certificate User as allowed RBAC.
- Description: Updated builtin role definition map, added `Key Vault Certificate User`
- Task: [3535083](https://dev.azure.com/cbsp-abnamro/GRD0001354/_workitems/edit/3535083/)

---

## Version 1.1.0

- Released: 2023 Sep 13

- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Updated builtin role definition map.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 1.0.2

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2167088)

---

## Version 1.0.1

- Released: 2023 Feb 14
- Description: Updated Microsoft API version.
Activated retry trigger in nightly.
- Story: [2000837](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2000837)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)

---

## Version 1.0.0

- Released: 2023 Jan 26
- Description: Initial release of RBAC Bicep module
