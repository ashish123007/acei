# Virtual Machine Scale Set

This repository can be used to deploy an instance of a Virtual Machine Scale Set.
[Learn more](https://learn.microsoft.com/en-us/azure/virtual-machine-scale-sets/overview)
The Bicep module currently creates only Windows VMs.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/virtual-machine-scale-set(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99184&branchName=main)

## Prerequisites

To install a Virtual Machine Scale Set you require the following.

- Vnet with IaaS subnets.
This can be created by
[SSNS](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/58963/Usage-Guidance)
tasks.
- [Disk Encryption Set](../../Microsoft.Compute/diskEncryptionSets/README.md).

## Usage Guidance

_Warning: As the VM Scale Set resource is not yet GA in Acceptance/Production workloads, it
can only be used for Engineering/Development/Test workloads._

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module.

```code
module vmssModule 'br/FSCPegistry:bicep/modules/dip/core/virtual-machine-scale-set:1.6.0' = {
  name: '<deployment name>'
  params: {
    name: '<virtual machine scale set name>'
    location: '<virtual machin scale set location>'
    adminPassword: '<administrator password>'
    adminUsername: '<administrator name>'
    osDiskEncryptionSetName: '<disk encryption set name>'
    virtualNetworkName: '<virtual network name>'
    virtualNetworkResourceGroup: '<vnet resource group name>'
    subnetName: '<virtual machine subnet name>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| adminPassword | string | value of properties.osProfile.adminPassword (1). |
| adminUsername | string | value of properties.osProfile.adminUsername. |
| name | string | name of the virtual machine scale set. |
| osDiskEncryptionSetName | string | partial value of properties.storageProfile.osDisk.managedDisk.diskEncryptionSet.id. The disk encryption set must exist. |
| subnetName | string | subnet for virtual machine network interfaces. |
| virtualNetworkName | string | virtual network that holds virtual machine subnet. |
| virtualNetworkResourceGroup | string | resource group that holds virtual machine subnet. |

(1) The password constraints are described
[here](https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/virtualmachinescalesets?pivots=deployment-language-bicep#virtualmachinescalesetosprofile).

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalVirtualMachineScaleSetProperties | object | {} | user provided resource properties. |
| dataDisks | array | [] | value of properties.virtualMachineProfile.storageProfile.dataDisks (2). |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| enableAcceleratedNetworking | bool | true | value of properties.virtualMachineProfile.networkProfile.networkInterfaceConfigurations.properties.enableAcceleratedNetworking. |
| enableAvailabilityZones | bool | false | whether to use virtual machine availability zones. |
| forceDeletion | bool | false | value of properties.scaleInPolicy.forceDeletion |
| identity | object | { type: 'SystemAssigned' } | the identity of the virtual machine scale set. |
| imageName | string | 'WindowsServer2019' | Name of AAB approved image. |
| instanceCount | int | 1 | value of sku.capacity |
| instanceSize | string | 'Standard_D2as_v5' | value of sku.size (3). |
| location | string | resourceGroup().location | location of your resource. Although this in not a required parameter Microsoft advices you to provide it explicitely. If not provided the default Bicep linting will present you a warning (explicit-values-for-loc-params). |
| numberOfAvailabilityZones | int | 1 | number of availability zones. Zone names will be picked by template. |
| osDiskType | string | 'StandardSSD_LRS' | value of properties.virtualMachineProfile.storageProfile.osDisk.managedDisk.storageAccountType. |
| overprovision | bool | false | value of properties.overprovision |
| platformFaultDomainCount | int | 1 | value of properties.platformFaultDomainCount |
| resourceTags| object | {} | user provided resource tags in the form of Json. |
| scaleInPolicy | string | 'Default' | value of properties.scaleInPolicy.rules[0] |
| singlePlacementGroup | bool | false | value of properties.singlePlacementGroup. If`instanceCount > 100 this will always be false. |
| upgradePolicy | string | 'Manual' | value of properties.upgradePolicy.mode |

(2) The meaning of the various standard resource properties is documented [here](https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/virtualmachinescalesets?pivots=deployment-language-bicep).

(3) We recommend an instance size with at least 2 vCPU and 4 GB RAM.

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| location | string | The location the resource was deployed into. |
| name | string | resource name |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |
| virtualMachineScaleSet | object | created resource |

## Policy Details

This section details which properties need to be set and what values should be used to
create a compliant service.
They are already implemented in the provided template but this information can be used if you wish
to create your own template.

**Deny policies**

### properties.virtualMachineProfile.networkProfile.networkInterfaceConfigurations[\*].ipConfigurations[\*].publicIPAddressConfiguration

| Name | Description | Value |
| :-- | :-- | :--|
| publicIPAddressVersion | must not exist | |

### properties

| Name | Description | Value |
| :-- | :-- | :--|
| orchestrationMode | must be 'Uniform' | 'Uniform' |

### properties.upgradePolicy.automaticOSUpgradePolicy

| Name | Description | Value |
| :-- | :-- | :--|
| enableAutomaticOSUpgrade | must be true | true |

### properties.virtualMachineProfile.storageProfile.imageReference

| Name | Description | Value |
| :-- | :-- | :--|
| id | must exist and must be referencing an AAB approved resource group | |

**Audit policies**

### properties.virtualMachineProfile.osDisk

| Name | Description | Value |
| :-- | :-- | :--|
| vhdContainers | must not exist | |
| imageUrl | must not exist | |

## Network Reference

### Azure Public

Public access is not applicable as public address associations are blocked by policy.

### Azure Private

A network interface (NIC) resource is created by scale set for each VM
and associated with a dynamically allocated private IP in a private subnet.
The NIC is also associated with the virtual machine.

The private IP addresses that were allocated for your
Virtual Machine Scale Set can be listed with
the following CLI command:

```code
az vmss nic list --resource-group YourRgName \
--vmss-name YourVmssName \
--query "[].ipConfigurations[].privateIpAddress"
```

For administration over RDP (windows VM) or SSH (linux VM, not supported now) protocols
Azure Privileged Identity Management grants temporary access to the NICs IP.
See
[here](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/71577/Virtual-Machine-Using-integrations)
for more details.

## Reference

- <https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/virtualmachinescalesets?pivots=deployment-language-bicep>
