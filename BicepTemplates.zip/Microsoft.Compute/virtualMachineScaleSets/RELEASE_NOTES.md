# Release and Upgrade Notes

## Version 1.6.0

- Released: 2025 Feb 19 09
- Description: New API versions
- Story: [5016990](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/5016990)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

## Version 1.5.0

- Released: 2024 Aug 19

- Description: New Bicep Version
  [MS release notes](https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/change-log/virtualmachines#2024-07-01)
  Added:
    properties.skuProfile
    properties.skuProfile.allocationStrategy
    properties.skuProfile.vmSizes
    properties.skuProfile.vmSizes.name
    spotRestorePolicy
    spotRestorePolicy.enabled
    spotRestorePolicy.restoreTimeout
    upgradePolicy
    upgradePolicy.automaticOSUpgradePolicy
    upgradePolicy.automaticOSUpgradePolicy.disableAutomaticRollback
    upgradePolicy.automaticOSUpgradePolicy.enableAutomaticOSUpgrade
    upgradePolicy.automaticOSUpgradePolicy.osRollingUpgradeDeferral
    upgradePolicy.automaticOSUpgradePolicy.useRollingUpgradePolicy
    upgradePolicy.mode
    upgradePolicy.rollingUpgradePolicy
    upgradePolicy.rollingUpgradePolicy.enableCrossZoneUpgrade
    upgradePolicy.rollingUpgradePolicy.maxBatchInstancePercent
    upgradePolicy.rollingUpgradePolicy.maxSurge
    upgradePolicy.rollingUpgradePolicy.maxUnhealthyInstancePercent
    upgradePolicy.rollingUpgradePolicy.maxUnhealthyUpgradedInstancePercent
    upgradePolicy.rollingUpgradePolicy.pauseTimeBetweenBatches
    upgradePolicy.rollingUpgradePolicy.prioritizeUnhealthyInstances
    upgradePolicy.rollingUpgradePolicy.rollbackFailedInstancesOnPolicyBreach
    virtualMachineProfile
    virtualMachineProfile.applicationProfile
    virtualMachineProfile.applicationProfile.galleryApplications
    virtualMachineProfile.applicationProfile.galleryApplications.configurationReference
    virtualMachineProfile.applicationProfile.galleryApplications.enableAutomaticUpgrade
    virtualMachineProfile.applicationProfile.galleryApplications.order
    virtualMachineProfile.applicationProfile.galleryApplications.packageReferenceId
    virtualMachineProfile.applicationProfile.galleryApplications.tags
    virtualMachineProfile.applicationProfile.galleryApplications.treatFailureAsDeploymentFailure
    billingProfile
    billingProfile.maxPrice
    capacityReservation
    capacityReservation.capacityReservationGroup
    capacityReservation.capacityReservationGroup.id
    diagnosticsProfile
    diagnosticsProfile.bootDiagnostics
    diagnosticsProfile.bootDiagnostics.enabled
    diagnosticsProfile.bootDiagnostics.storageUri
    evictionPolicy
    extensionProfile
    extensionProfile.extensions
    extensionProfile.extensions.name
    extensionProfile.extensions.properties
    extensionProfile.extensions.properties.autoUpgradeMinorVersion
    extensionProfile.extensions.properties.enableAutomaticUpgrade
    extensionProfile.extensions.properties.forceUpdateTag
    extensionProfile.extensions.properties.protectedSettings
    extensionProfile.extensions.properties.protectedSettingsFromKeyVault
    extensionProfile.extensions.properties.protectedSettingsFromKeyVault.secretUrl
    extensionProfile.extensions.properties.protectedSettingsFromKeyVault.sourceVault
    extensionProfile.extensions.properties.protectedSettingsFromKeyVault.sourceVault.id
    extensionProfile.extensions.properties.provisionAfterExtensions
    extensionProfile.extensions.properties.publisher
    extensionProfile.extensions.properties.settings
    extensionProfile.extensions.properties.suppressFailures
    extensionProfile.extensions.properties.type
    extensionProfile.extensions.properties.typeHandlerVersion
    extensionsTimeBudget
    zonalPlatformFaultDomainAlignMode
  Removed:
    properties.spotRestorePolicy
    properties.spotRestorePolicy.enabled
    properties.spotRestorePolicy.restoreTimeout
    properties.upgradePolicy
    properties.upgradePolicy.automaticOSUpgradePolicy
    properties.upgradePolicy.automaticOSUpgradePolicy.disableAutomaticRollback
    properties.upgradePolicy.automaticOSUpgradePolicy.enableAutomaticOSUpgrade
    properties.upgradePolicy.automaticOSUpgradePolicy.osRollingUpgradeDeferral
    properties.upgradePolicy.automaticOSUpgradePolicy.useRollingUpgradePolicy
    properties.upgradePolicy.mode
    properties.upgradePolicy.rollingUpgradePolicy
    properties.upgradePolicy.rollingUpgradePolicy.enableCrossZoneUpgrade
    properties.upgradePolicy.rollingUpgradePolicy.maxBatchInstancePercent
    properties.upgradePolicy.rollingUpgradePolicy.maxSurge
    properties.upgradePolicy.rollingUpgradePolicy.maxUnhealthyInstancePercent
    properties.upgradePolicy.rollingUpgradePolicy.maxUnhealthyUpgradedInstancePercent
    properties.upgradePolicy.rollingUpgradePolicy.pauseTimeBetweenBatches
    properties.upgradePolicy.rollingUpgradePolicy.prioritizeUnhealthyInstances
    properties.upgradePolicy.rollingUpgradePolicy.rollbackFailedInstancesOnPolicyBreach
    properties.virtualMachineProfile
    properties.virtualMachineProfile.applicationProfile
    properties.virtualMachineProfile.applicationProfile.galleryApplications
    properties.virtualMachineProfile.applicationProfile.galleryApplications.configurationReference
    properties.virtualMachineProfile.applicationProfile.galleryApplications.enableAutomaticUpgrade
    properties.virtualMachineProfile.applicationProfile.galleryApplications.order
    properties.virtualMachineProfile.applicationProfile.galleryApplications.packageReferenceId
    properties.virtualMachineProfile.applicationProfile.galleryApplications.tags
    properties.virtualMachineProfile.applicationProfile.galleryApplications.treatFailureAsDeploymentFailure
    properties.billingProfile
    properties.billingProfile.maxPrice
    properties.capacityReservation
    properties.capacityReservation.capacityReservationGroup
    properties.capacityReservation.capacityReservationGroup.id
    properties.diagnosticsProfile
    properties.diagnosticsProfile.bootDiagnostics
    properties.diagnosticsProfile.bootDiagnostics.enabled
    properties.diagnosticsProfile.bootDiagnostics.storageUri
    properties.evictionPolicy
    properties.extensionProfile
    properties.extensionProfile.extensions
    properties.extensionProfile.extensions.name
    properties.extensionProfile.extensions.properties
    properties.extensionProfile.extensions.properties.autoUpgradeMinorVersion
    properties.extensionProfile.extensions.properties.enableAutomaticUpgrade
    properties.extensionProfile.extensions.properties.forceUpdateTag
    properties.extensionProfile.extensions.properties.protectedSettings
    properties.extensionProfile.extensions.properties.protectedSettingsFromKeyVault
    properties.extensionProfile.extensions.properties.protectedSettingsFromKeyVault.secretUrl
    properties.extensionProfile.extensions.properties.protectedSettingsFromKeyVault.sourceVault
    properties.extensionProfile.extensions.properties.protectedSettingsFromKeyVault.sourceVault.id
    properties.extensionProfile.extensions.properties.provisionAfterExtensions
    properties.extensionProfile.extensions.properties.publisher
    properties.extensionProfile.extensions.properties.settings
    properties.extensionProfile.extensions.properties.suppressFailures
    properties.extensionProfile.extensions.properties.type
    properties.extensionProfile.extensions.properties.typeHandlerVersion
    properties.extensionsTimeBudget
    enableVMAgentPlatformUpdates
- Story: [4028015](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4028015)

---

## Version 1.3.1

- Released: 2024 July 09
- Description: Updated default values of parameters for cost optimization
- Story: [3816483](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3816483)

---

## Version 1.3.0

- Released: 2024 Mar 07
- Description: Updated BICEP version to 2023-09-01. From the MS change log:
  - Added:
    - properties.resiliencyPolicy
    - properties.resiliencyPolicy.resilientVMCreationPolicy
    - properties.resiliencyPolicy.resilientVMCreationPolicy.enabled
    - properties.resiliencyPolicy.resilientVMDeletionPolicy
    - properties.resiliencyPolicy.resilientVMDeletionPolicy.enabled
    - properties.upgradePolicy.automaticOSUpgradePolicy.osRollingUpgradeDeferral
    - properties.virtualMachineProfile.securityProfile.encryptionIdentity
    - properties.virtualMachineProfile.securityProfile.encryptionIdentity.userAssignedIdentityResourceId
    - properties.virtualMachineProfile.securityProfile.proxyAgentSettings
    - properties.virtualMachineProfile.securityProfile.proxyAgentSettings.enabled
    - properties.virtualMachineProfile.securityProfile.proxyAgentSettings.keyIncarnationId
    - properties.virtualMachineProfile.securityProfile.proxyAgentSettings.mode
  - Updated:
    - properties.virtualMachineProfile.storageProfile.dataDisks.managedDisk.securityProfile.securityEncryptionType
      - Added values: 'NonPersistedTPM'
    - sku.apiVersion - Added values: '2023-09-01'
      - Removed values: '2023-07-01'
    - properties.virtualMachineProfile.storageProfile.dataDisks.managedDisk.securityEncryptionType
      - Added values: 'NonPersistedTPM'
- Story: [3353950](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3353950)

---

## Version 1.2.1

- Released: 2023 Oct 13
- Description: added tag `NSF-Format` parameter to comply with the policy
   aab-platform-nsf-tag-audit-v1.
   Improved keys cleanup.
- Story: [2807840](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2807840)
- Story: [3315826](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3315826)

---

## Version 1.2.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
   uniform deployment names and groups.
   Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 1.1.0

- Released 2023 August 8
- Upgraded Bicep versions
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)

---

## Version 1.0.1

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

---

## Version 1.0.0

- Released: 2023 May 15
- Description: Initial release of FSCP Virtual Machine Scale Set Bicep module.
- Story: [2006226](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2006226)
