# Disk Encryption Set

This repository can be used to deploy an instance of a Disk Encryption Set.
[Learn more](https://learn.microsoft.com/en-us/azure/virtual-machines/disk-encryption-overview)

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/disk-encryption-set(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99163&branchName=main)

## Prerequisites

You need following:

- key vault
- key

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module desModule 'br/FSCPRegistry:bicep/modules/dip/core/disk-encryption-set:1.7.1' = {
  name: '<deployment name>'
  params: {
    name: '<disk encryption set name>'
    keyVaultName: '<key vault name>'
    keyName: '<key name>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| keyName | string | name of key to use for in-rest encryption. |
| keyVaultName | string | name of key vault to use for in-rest encryption. |
| name | string | name of the disk encryption set resource to create. |

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalDiskEncryptionSetProperties | object | {} | user defined properties for resource. See MSFT documentation on format. |
| assignKeyAccess | string | 'Rbac' | whether to enable key access for DES identity (1). |
| autoKeyRotation | string | 'Disabled' | toggle auto-updating of this disk encryption set to the latest key version. See MSFT documentation on rotationToLatestKeyVersionEnabled. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| encryptionType | string | 'EncryptionAtRestWithCustomerKey' | type of encryption key. See MSFT documentation on encryptionType. |
| identity | object | { type: 'SystemAssigned' } | identity to be used for the resource. See MSFT documentation on format. |
| keyVersion | string | '' | version of key. If left empty the active key version will be used. |
| location | string | resourceGroup().location | Location of the resource. |
| rbacDeploymentNameHashBase | string | utcNow('ffffff') | Hash base to be used for generating a unique deployment suffix for Rbac deployments. Will be used as uniqueString() base string. |
| resourceTags | object | {} | User provided resource tags in the form of Json. |

(1) `assignKeyAccess` can have 3 values:

- `None`, do not arrange any access for DES identity.

- `AccessPolicy`, arrange access through vault access policy.
The granted access is [ get, wrapKey, unwrapKey ] on all keys in the key vault.

- `Rbac`, arrange access through azure role assignment.
The granted built-in role name is 'Key Vault Crypto Service Encryption User' on key scope.

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| diskEncryptionSet | object | created resource as an object |
| location | string | The location the resource was deployed into. |
| name | string | resource name |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

This module has no related FSCP3 policies yet.

## Network Reference

This module use has no relation to a virtual network.

## Reference

- <https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/diskencryptionsets?pivots=deployment-language-bicep>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/83786/AAB-Virtual-Machine-Scale-Sets-v1>
