# Release and Upgrade Notes

## Version 1.7.1

- Released: 2025 May 26
- Description: New API versions
- Story: [5420823](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5420823)

---

## Version 1.7.0

- Released: 2025 Feb 19
- Description: New API versions
- Story: [5016990](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5016990)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 1.6.1

- Released: 2024 Nov 08
- Description: Updated version caused by new Bicep Version for Roles
- Story: [4539209](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4539209)

---

## Version 1.6.0

- Released: 2024 Aug 19
- Description: New Bicep Version
  [MS release notes](https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/change-log/diskencryptionsets)
  The mentioned update from MS is: 'No new or updated properties'
- Story: [4028015](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4028015)

---

## Version 1.5.2

- Released: 2024 May 10
- Description: updated version due to PEP upgrade.
- Story: [3616182](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3616182)

---

## Version 1.5.1

- Released: 2024 Apr 22
- Description: Updated BICEP key vault version
to 2023-07-01.
- Story: [3543675](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3543675)

---

## Version 1.5.0

- Released: 2024 Mar 07
- Description: Updated BICEP version tot 2023-10-02. From the MS change log:
  - Updated:
    - properties.activeKey.sourceVault.apiVersion - Added values: '2023-10-02' - Removed values: '2023-04-02'
- Story: [3353950](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/335390)

---

## Version 1.4.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 1.3.0

- Released 2023 Aug 8
- Upgraded Bicep versions
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)

---

## Version 1.2.1

- Released 2023 Aug 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

## Version 1.2.0

- Released: 2023 May 15
- Description: Use unique deployment names for Rbac deployments
- Story: [2006226](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2006226)

---

## Version 1.0.1

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2167088)

---

## Version 1.0.0

- Released: 2023 Jan 23
- Description: Initial release of FSCP Virtual Machine Bicep module.
Activated retry trigger in nightly.
- Story: [1955452](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1955452)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)
