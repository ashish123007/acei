# Release and Upgrade Notes

## Version 2.1.0

- Released: 2025 Mar 10
- Description: New API versions.
3 more DINE exemptions.
- Story: [5094855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5094855)
- Story: [5374564](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5374564)

---

## Version 2.0.1

- Released: 2025 Feb 26
- Description: Restricted tag IntendedBackupInterval to vm resource
- Story: [4993374](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4993374)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)

---

## Version 2.0.0

- Released: 2025 Feb 25
- Description: Added the IntendedBackupInterval Manadatory tag
- Story: [4993374](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4993374/)

### Upgrade steps to 2.0.0

Upgrade of the module needs parameter intendedBackupInterval enabled.
The parameters for intendedBackupInterval -`Continuous`, `1h`, `4h`, `1d`, `7d`, `14d`, `30d` & `None`

---

## Version 1.10.0

- Released: 2025 Feb 19
- Description: New API versions
- Story: [5016990](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5016990)

---

## Version 1.9.3

- Released: 2024 Dec 30
- Description: Updated OS image to 2022-Datacenter
- Story: [4775081](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4775081)

---

## Version 1.9.2

- Released: 2024 Dec 05
- Description: Upgrade Bicep version of NIC to 2024-05-01
  - Updated:
    NetworkInterfacePropertiesFormat: Added property 'defaultOutboundConnectivityEnabled'
- Story: [4693855](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4693855)

---

## Version 1.9.1

- Released: 2024 Oct 28
- Description: New NIC
- Story: [4470596](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4470596)

---

## Version 1.9.0

- Released: 2024 Sep 26
- Description: New Default for RHEL
- Story: [4255496](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4028015)

---

## Version 1.8.0

- Released: 2024 Aug 19

- Description: New Bicep Version
  [MS release notes](https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/change-log/virtualmachinescalesets#2024-07-01)
  Removed:
  - enableVMAgentPlatformUpdates
- Story: [4028015](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4028015)

---

## Version 1.6.2

- Released: 2024 July 09
- Description: Changed to default value of osDiskSizeGB as per recommendation of finops
- Story: [3816483](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3816483)

---

## Version 1.6.1

- Released: 2024 May 10
- Description: updated version due to PEP upgrade
- Story: [3616182](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/3616182)

---

## Version 1.6.0

- Released: 2024 May 07
- Description: exempted from FSCPHardeningState audit policy.
Added support for static IPs.
- Story: [3604680](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3604680)

---

## Version 1.5.0

- Released: 2024 Mar 08
- Description: Updated the BICEP versions for VM and VM-extensions from 2023-03-01 to 2023-09-01
  - virtualMachines, Added:
    - properties.securityProfile.encryptionIdentity
    - properties.securityProfile.encryptionIdentity.userAssignedIdentityResourceId
    - properties.securityProfile.proxyAgentSettings
    - properties.securityProfile.proxyAgentSettings.enabled
    - properties.securityProfile.proxyAgentSettings.keyIncarnationId
    - properties.securityProfile.proxyAgentSettings.mode
  - virtualMachines, Updated:
    - properties.storageProfile.dataDisks.managedDisk.securityProfile.securityEncryptionType; Added values: 'NonPersistedTPM'
    - properties.storageProfile.osDisk.encryptionSettings.keyEncryptionKey.apiVersion;
      Added values: '2023-09-01' - Removed values: '2023-07-01'
  - virtualMachines/extension, Updated:
    - properties.protectedSettingsFromKeyVault.sourceVault.apiVersion - Added values: '2023-09-01' - Removed values: '2023-07-01'
- Story: [3360505](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3360505)

## Version 1.4.0

- Released: 2023 Dec 27
- Description: Aligned default Linux image reference with
SecureContextBaseCatalog to `8_6`.
Exempted one more instable DINE.
Improved keys cleanup.
- Story: [3076357](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3076357)
- Story: [3245166](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3245166)
- Story: [3315826](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/3315826)

### Upgrade steps to 1.4.0

Upgrade of the module version is accepted without any changes to the
parameters.
However, for existing virtual machines created by a previous version
of the module, set parameter `imageReference` explicitely to `8_5`.
When parameter `imageReference` is not explicitely set the deployment
will fail with the following message:
`Changing property 'imageReference' is not allowed.`

---

## Version 1.3.1

- Released: 2023 Oct 13
- Description: added tag `NSF-Format` parameter to comply with the policy
aab-platform-nsf-tag-audit-v1.
Exempted one more AINE and set longer delay for policy check.
- Story: [2807840](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2807840)
- Story: [2820673](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2820673)

---

## Version 1.3.0

- Released: 2023 Sep 13
- Description: added `deploymentsNameFormat` parameter to support
uniform deployment names and groups.
Implemented standard outputs.
- Story: [2600937](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2600937)
- Story: [2601290](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2601290)

---

## Version 1.2.0

- Released 2023 August 8
- Upgraded Bicep versions
- Story: [2566401](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2566401)

---

## Version 1.1.3

- Released 2023 August 3
- Because of compile changes
- Story: [2553252](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2475562)

## Version 1.1.2

- Released: 2023 July 11
- Description: Bicep version update
- Story: [2465551](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/2465551)

---

## Version 1.1.1

- Released: 2023 Apr 06
- Description: New version because of new version Bicep compiler.
Cleanup prerequisites.
- Story: [2167088](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2167088)
- Story: [2169152](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2169152)

---

## Version 1.1.0

- Released: 2023 Feb 16
- Description: introduction of `sshPublicKeys` parameter
- Story: [2033880](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2033880)

---

## Version 1.0.0

- Released: 2023 Jan 23
- Description: Initial release of FSCP Virtual Machine Bicep module.
Activated retry trigger in nightly.
- Story: [1935654](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/1935654)
- Story: [2072644](https://dev.azure.com/cbsp-abnamro/GRD0001007/_workitems/edit/2072644)
