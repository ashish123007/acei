#Requires -Modules @{ ModuleName = "Az.Accounts"; ModuleVersion = "2.17.0" }

<#
.SYNOPSIS
    Enables PIM role on a Resource Group for all Virtual Machines.

.DESCRIPTION
    Enables PIM role on a Resource Group for all Virtual Machines.

    The requestor and approver Azure AD Groups must not exceed the maximum amount of 1000 group members.

.PARAMETER SubscriptionId
    The ID of the Subscription.

.PARAMETER ResourceGroupName
    The name of the Resource Group.

.PARAMETER RequestorGroup
    The name of the requestor group in Azure AD.

.PARAMETER ApproverGroup
    The name of the approver group in Azure AD.

.EXAMPLE
    Invoke-PimRoleForVirtualMachines -SubscriptionId <SubscriptionId> -ResourceGroupName <ResourceGroupName> -RequestorGroup <RequestorGroup> ApproverGroup <ApproverGroup>
#>

[CmdletBinding()]
Param (
    [Parameter(Mandatory = $true)]
    [String] $SubscriptionId,

    [Parameter(Mandatory = $true)]
    [String] $ResourceGroupName,

    [Parameter(Mandatory = $true)]
    [String] $RequestorGroup,

    [Parameter(Mandatory = $true)]
    [String] $ApproverGroup
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Function Unprotect-SecureString {
    [CmdletBinding()]
    [OutputType([System.String])]
    Param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [System.Security.SecureString] $SecureString
    )

    Process {
        $ssPtr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)

        Try {
            $plainText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ssPtr)
        }
        Finally {
            [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ssPtr)
        }

        $plainText
    }
}

$armAccessToken  = (Get-AzAccessToken -AsSecureString -ErrorAction Stop).Token | Unprotect-SecureString
$msGraphAccessToken = (Get-AzAccessToken -ResourceTypeName MSGraph -AsSecureString -ErrorAction Stop).Token | Unprotect-SecureString

$body = ConvertTo-Json -InputObject @{
    SubscriptionId    = $SubscriptionId
    ResourceGroupName = $ResourceGroupName
    RequestorGroup    = $RequestorGroup
    ApproverGroup     = $ApproverGroup
    GraphAccessToken  = $msGraphAccessToken
}

$headers = @{
    Authorization = "Bearer $armAccessToken "
}

Write-Host "Enabling PIM for Resource Group '$ResourceGroupName'."
Invoke-RestMethod `
    -Uri "https://vm-pim-p-fa.azurewebsites.net/api/CreatePimRoleAssignment" `
    -Body $body `
    -ContentType "application/json" `
    -Headers $headers `
    -Method Post `
    -UseBasicParsing
