# Virtual Machine

This repository can be used to deploy an instance of a Virtual Machine. [Learn more](https://learn.microsoft.com/en-us/azure/virtual-machines/overview)
The Bicep module can create both Windows or Linux VMs.
Windows VM is default offering.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

- Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/virtual-machine(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=99183&branchName=main)

## Prerequisites

To install a virtual machine you require the following.

- Vnet with IaaS subnets.
This can be created by
[SSNS](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/58963/Usage-Guidance)
tasks.
- [Disk Encryption Set](../../Microsoft.Compute/diskEncryptionSets/README.md).
- In case of Linux VMs, you might want to generate a SSH keypair upfront.

## Usage Guidance

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.ContainerRegistry/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module.

```code
module vmModule 'br/FSCPRegistry:bicep/modules/dip/core/virtual-machine:2.1.0'  = {
  name: '<deployment name>'
  params: {
    name: '<virtual machine name>'
    virtualMachineSize: '<virtual machine SKU>'
    adminPassword: '<administrator password>'
    adminUsername: '<administrator name>'
    osDiskEncryptionSetName: '<disk encryption set name>'
    osDiskName: '<disk name>'
    virtualNetworkName: '<virtual network name>'
    virtualNetworkResourceGroup: '<vnet resource group name>'
    subnetName: '<virtual machine subnet name>'
    intendedBackupInterval: '<Intended Backup Interval duration>'
  }
}
```

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| adminPassword | string | value of properties.osProfile.adminPassword (1). |
| adminUsername | string | value of properties.osProfile.adminUsername. |
| intendedBackupInterval | string | The intendedBackupInterval tag must be set to one of the following allowed values: Continuous, 1h, 4h, 1d, 7d, 14d, 30d & None. |
| name | string | name of the virtual machine. |
| osDiskEncryptionSetName | string | partial value of properties.storageProfile.osDisk.managedDisk.diskEncryptionSet.id. The disk encryption set must exist. |
| osDiskName | string | value of properties.storageProfile.osDisk.name. |
| subnetName | string | subnet for virtual machine network interface. |
| virtualMachineSize | string | value properties.hardwareProfile.vmSize (2). |
| virtualNetworkName | string | virtual network that holds virtual machine subnet. |
| virtualNetworkResourceGroup | string | resource group that holds virtual machine subnet. |

(1) The Bicep properties for the VM resource are described
[here](https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/virtualmachines?pivots=deployment-language-bicep).

(2) We recommend a VM size with at least 2 vCPU and 4 GB RAM,
e.g. `Standard_B2s`.
The most cost effective VM size that runs all required extensions is `Standard_B1ms`.
Consult Microsoft infocenter for
[VM Sizes](https://learn.microsoft.com/en-us/azure/virtual-machines/sizes) and
[Pricing](https://azure.microsoft.com/en-us/pricing/details/virtual-machines/windows/).

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalVirtualMachineProperties | object | {} | user provided resource properties. |
| additionalVirtualMachineStorageProfileProperties | object | {} | user provided storageProfile properties, i.e. additional dataDisks. |
| availabilityZone | string | '1' | availability zone: '1', '2' or '3'. |
| deploymentsNameFormat | string | '${deployments().name}-{0}' | format to use for naming child deployments. It must contain one {0} placeholder and should contain some unique string that groups the deployments, e.g. '{0}-xhcgw' |
| enableAcceleratedNetworking | bool | false | if the network interface is configured for accelerated networking. |
| enableAvailabilityZone | bool | false | whether to set specify a virtual machine zone. |
| identity | object | { type: 'SystemAssigned' } | the identity of the virtual machine. |
| imageOffer | string | '' | value of properties.storageProfile.imageReference.offer (3). |
| imagePublisher | string | 'MicrosoftWindowsServer' | value of properties.storageProfile.imageReference.publisher. |
| imageSku | string | '' | value of properties.storageProfile.imageReference.sku (3). |
| imageVersion | string | 'latest' | value of properties.storageProfile.imageReference.version. |
| location | string | resourceGroup().location | location of your resource. |
| networkInterfaceDeleteOption | string | 'Delete' | specifies what happens to the Network Interface when the Virtual Machine is deleted, i.e., whether the Network Interface is deleted or detached. Value of properties.networkProfile.osDisk.deleteOption. |
| osDiskDeleteOption | string | 'Delete' | specifies what happens to the OS disk when the Virtual Machine is deleted, i.e., whether the OS disk is deleted or detached. Value of properties.storageProfile.osDisk.deleteOption. |
| osDiskType | string | 'StandardSSD_LRS' | value of properties.storageProfile.osDisk.managedDisk.storageAccountType. |
| osDiskSizeGB | int | 0 | value of properties.storageProfile.osDisk.diskSizeGB.  |
| patchMode | string | 'AutomaticByPlatform' | value of properties.osProfile.linuxConfiguration.patchSettings.patchMode (for linux VM) or properties.osProfile.windowsConfiguration.patchSettings.patchMode (for windows VM). |
| resourceTags| object | {} | user provided resource tags in the form of Json. |
| sshPublicKeys | array | [] | path and keyData of each SSH public key. If set password authentication will be blocked. Applicable for Linux VMs only. (4)  |
| staticPrivateIPAddress | string | '' | Static private IP address for virtual machine newtwork interface. If empty dynamic allocation is used. |

(3) If left empty, the value for `imageSku` and `imageOffer` are set dependent on `imagePublisher`.

(4) Access to a Linux VM is more often than not arranged
through SSH public key access.
The `sshPublicKeys` parameter is introduced to pass the
public key(s) of your SSH keypairs to the module, without
the need to repeat mandatory properties of the `osProfile`.
The format of the parameter is documented in the Azure Bicep reference of the
virtual machine resource (see references below).
A sample property value is as follows.

```code

    sshPublicKeys: [
      {
        path: '/home/sysman/<your administrator name here>/authorized_keys'
        keyData: '<your ssh public key here>'
      }
    ]

```

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| location | string | The location the resource was deployed into. |
| name | string | resource name |
| networkInterface | object | created network interface |
| privateIPAddress | string | private IP address of virtual machine |
| resourceGroupName | string | he name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |
| virtualMachine | object | created resource |

After you created a virtual machine through Bicep template, you need to perform a
few more integrations before the new resource is fully useable in your FSCP3 environment. See
[here](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/71577/Virtual-Machine-Using-integrations)
for more details.

## Policy Details

This section details which properties need to be set and what values should be used to
create a compliant service.
They are already implemented in the provided template but this information can be used if you wish
to create your own template.

Most policies, especially concerning guest configuration and required extensions,
concern so called Modify or AuditIfNotExists (AINE) policies,
and should be automatically resolved within a few hours after virtual machine creation.

**Deny policies**

### properties.osProfile.windowsConfiguration (for Windows VMs)

| Name | Description | Value |
| :-- | :-- | :--|
| patchSettings.assessmentMode | must have specific value. | 'AutomaticByPlatform' |
| patchSettings.patchMode | must have specific value. | 'AutomaticByPlatform' |

### properties.osProfile.linuxConfiguration (for Linux VMs)

| Name | Description | Value |
| :-- | :-- | :--|
| patchSettings.assessmentMode | must have specific value. | 'AutomaticByPlatform' |
| patchSettings.patchMode | must have specific value. | 'AutomaticByPlatform' |

**Modify policies**

### identity

| Name | Description | Value |
| :-- | :-- | :--|
| type | must contain system-assigned identity (applied by modify policy) | 'SystemAssigned' \| 'UserAssigned,SystemAssigned' |

**AINE policies**

### Microsoft.GuestConfiguration/guestConfigurationAssignments

| Name | Description | Value |
| :-- | :-- | :--|
| complianceStatus | must be in compliant state | 'Compliant' |
| parameterHash | must prove successfule domain join to launcher AD (windows VM only) | base64('[DomainMembership]WindowsDomainMembership;DomainName=launcher.int.abnamro.com') |

### Microsoft.Compute/virtualMachines/extensions

| Name | Description | Value |
| :-- | :-- | :--|
| type | must have MDE active (provisioned by Azure platform) | 'MDE.Windows' (windows VM only) or 'MDE.Linux' (linux VM only) |
| Publisher | must have specific value | 'Microsoft.Azure.AzureDefenderForServers' |

## Network Reference

### Azure Private

A network interface (NIC) resource is created by the template
and associated with a dynamically allocated private IP in a private subnet.
The NIC is also associated with the virtual machine.

For administration over RDP (windows VM) or SSH (linux VM) protocols Azure Privileged
Identity Management grants temporary access to the NICs IP.
See
[here](https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/71577/Virtual-Machine-Using-integrations)
for more details.

## Reference

- <https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/virtualmachines?pivots=deployment-language-bicep>
- <https://learn.microsoft.com/en-us/azure/templates/microsoft.network/networkinterfaces?pivots=deployment-language-bicep>
