# Azure Backup Vaults

This module creates Azure Backup Vaults.

## Owner team: FSCP Automation Team <FSCPAutomationTeam@nl.abnamro.com>

## Pipeline Status

Nightly compliance check [![Build Status](https://dev.azure.com/cbsp-abnamro/Azure/_apis/build/status/BicepTemplates/backup-vaults(stable)?branchName=main)](https://dev.azure.com/cbsp-abnamro/Azure/_build/latest?definitionId=106263&branchName=main)

## Usage Guidance

### Prerequisites

The pre-requisities to use this module are:

- Key Vault for CMK
- Key for CMK
- User-Assigned Managed Identity

If you don't have all the Prerequisites yet, you can choose to create a pipeline step.
In the file `pipelines/jobs.pre-deployment-setup.yml` you will find how to do this.

### Consume the module

#### Code snippet

This module has been published to [ACR](https://portal.azure.com/#@abnamro.onmicrosoft.com/resource/subscriptions/d122ba3f-c842-4aac-a354-579601380161/resourceGroups/fbmt-p-rg/providers/Microsoft.DataProtection/registries/fscpbiceptemplates/repository)
and the below code snippet shows how to consume the module

```code
module azureBackupVaultModule 'br/FSCPRegistry:bicep/modules/dip/core/azure-backup-vaults:1.0.2' = {
  name: '<name of deployment>'
  params: {
    backupVaultName: '<resource name>'
    keyName: '<key name>'
    keyVaultName: '<key vault name>'
    userAssignedIdentityName: '<user managed identity name for the cmk>'
  }
}
```

(*) NOTE: If you need information on how to deploy Backup Vault in your Subscription, you can use FSCP AZURE Backup
Vault [Cookbook](https://confluence.int.abnamro.com/x/tQRfLw) for detailed process.

**Required parameters**

| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| backupVaultName | string | The name of the Backup Vault. |
| keyName | string | The name of the key to use for data encryption. Encryption is only supported with an RSA 2048 cryptographic key set to never expire. |
| keyVaultName | string | The name of the Key Vault where the Customer-Managed Key is stored to use for data encryption. |
| userAssignedIdentityName | string | The name of the User-Assigned Managed Identity to associate with the Backup Vault. It must have \'Key Vault Crypto Service Encryption User\' built-in role on the Key Vault. Must be set if \'identityType\' is set to \'UserAssignedIdentity\'.|

**Optional parameters**

| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| additionalProperties | object | {} | Additional Azure Backup Vault properties. |
| azureMonitorAlertsForAllJobFailures | string |  Enabled  | The behavior of built-in Azure Monitor alerts upon backup job failures. |
| backupStorageRedundancy | string | GeoRedundant | Storage redundancy of a Backup Vault cannot be changed once the Backup Vault has registered backups. Geo-Redundant Storage provides the highest level of data durability, followed by Zone-Redundant Storage and then Locally-Redundant Storage. The costs are proportionate to the durability guarantees. |
| featureSettings | object | The property \'crossRegionRestoreSettings\' is set to \'Enabled\'. The property \'crossSubscriptionRestoreSettings\' is set to \'Disabled\'. | An object containing the cross Subscription and optionally the cross region restore settings of the backups. The property \'crossRegionRestoreSettings\' can only be set if the parameter \'backupStorageRedundancy\' is set to \'GeoRedundant\'. |
| immutabilityState | string |  Disabled  | Whether to enable or disable immutability of the Backup Vault. Once locked, it cannot be reverted to a disabled state. |
| infrastructureEncryption | string |  Disabled  | Whether to enable encryption on the backup storage infrastructure. Note that this can only be enabled only on a new Backup Vault. |
| location | string |  westeurope  | The location of the Backup Vault. |
| softDeleteRetentionDurationInDays | int |  14  | The number of days a backup is kept after deletion. Soft delete does not cost you for 14 days of retention; however, you are charged for the period beyond 14 days. |
| softDeleteState | string |  On  | Whether to enable enhanced soft delete on the Backup Vault. Always-on soft delete is irreversible. Once enabled, it cannot be reverted to a disabled state. |
| tags | object | {} | Tags of the resource. |

#### Output parameters

| Output | type | Description |
| :-- | :-- | :-- |
| backupVaults | object | The created Backup Vault. |
| location | string | The location the resource was deployed into. |
| name | string | The created Backup Vault name |
| resourceGroupName | string | The name of the resource group the resource was created in. |
| resourceId | string | The resource ID of the created resource. |

## Policy Details

This section details which properties need to be set and what values should be used to create a compliant service.
They are already implemented in the provided template but this information can be used if you wish to create your
own template.

### Encryption

| Name | Description | Value |
| :-- | :-- | :-- |
| encryptionSettings/state | Azure Backup Vaults should use customer-managed keys for encrypting backup data. | Enabled |

## Reference

- <https://docs.microsoft.com/en-us/azure/azure-resource-manager/bicep/modules#private-module-registry>
- <https://dev.azure.com/cbsp-abnamro/Azure/_wiki/wikis/Azure.wiki/110090/AAB-Azure-Backup-Vault-v1>
