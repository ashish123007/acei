# Release and Upgrade Notes

## Version 1.0.2

- Released: 2025 Mar 17
- Description: Default value of datastoreType is now 'VaultStore'.
- Story: [5124953](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5124953)

---

## Version 1.0.1

- Released: 2025 Mar 17
- Description: Default value of the resource identity is now 'SystemAssigned,UserAssigned'.
 Added link to FSCP Cookbook.
- Story: [5088546](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/5088546)

---

## Version 1.0.0

- Released: 2025 Feb 28
- Description: Initial version of the Azure Backup Vault
- Story: [4828214](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4828214)
- Story: [4997170](https://dev.azure.com/cbsp-abnamro/Azure/_workitems/edit/4997170)
