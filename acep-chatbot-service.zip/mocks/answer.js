const _ = require('lodash');

const answerBase = [
  {
    request: {
      workspace: 'Masterflow',
      utterance: 'Hi',
      context: { counterRetry: 0 },
    },
    response: {
      intents: [
        {
          intent: 'Hello',
          confidence: 1,
        },
      ],
      entities: [],
      input: {
        text: 'Hi',
      },
      output: {
        text: [
          'Hello. How can I help you?',
        ],
        nodes_visited: [
          'Welcome',
        ],
        log_messages: [],
      },
      context: {
        conversation_id: '50ccb8f1-8a80-442b-ba52-1e0050a0271b',
        system: {
          initialized: true,
          dialog_stack: [
            {
              dialog_node: 'Welcome',
            },
          ],
          dialog_turn_counter: 1,
          dialog_request_counter: 1,
          _node_output_map: {
            Welcome: {
              0: [
                0,
              ],
            },
          },
        },
      },
    },
  },
];

const textAnswer = _.cloneDeep(answerBase);
const textAnswerOutput = {
  text: 'Hello. How can I help you?',
};
textAnswer[0].response.output.generic = [
  { ...textAnswerOutput, response_type: 'text' },
];

const suggestionAnswer = _.cloneDeep(answerBase);
const suggestionTitle = 'Did you mean:';
const suggestions = [{
  label: 'Example suggestion',
  value: { intents: [], entities: [], input: [] },
}];
suggestionAnswer[0].response.output.generic = [
  { suggestions, title: suggestionTitle, response_type: 'suggestion' },
];
const buttons = _.map(suggestions, (suggestion) => {
  const { label, value } = suggestion;
  return { isObject: true, title: label, value: JSON.stringify(value) };
});
const suggestionsOutputObject = { text: suggestionTitle, buttons, response_type: 'suggested-action' };
const suggestionAnswerOutput = [JSON.stringify({ default: [suggestionsOutputObject] })];

const optionAnswer = _.cloneDeep(answerBase);
const optionAnswerOutput = {
  title: 'User options',
  description: 'Pick one option',
  options: [
    { label: 'Option A', value: { input: { text: 'Pick Option A' } } },
    { label: 'Option B', value: { input: { text: 'Pick Option B' } } },
  ],
};
optionAnswer[0].response.output.generic = [
  { ...optionAnswerOutput, response_type: 'option' },
];

const imageAnswer = _.cloneDeep(answerBase);
const imageAnswerOutput = {
  response_type: 'image',
  title: 'Welcome image',
  description: 'Welcome large image',
  source: 'https://welcome-image.com',
};
imageAnswer[0].response.output.generic = [
  { ...imageAnswerOutput, response_type: 'image' },
];

const invalidAnswer = _.cloneDeep(answerBase);
invalidAnswer[0].response.output.generic = [
  { response_type: '' },
];

const privAnswerWithArray = _.cloneDeep(answerBase);
privAnswerWithArray[0].response.output.generic = [
  {
    text: 'Hello {{#if author}}\n {{firstName}} {{lastName}}\n{{/if}}!',
    response_type: 'text',
  },
  {
    text: 'Your family members registered in our system are\n{{#each people}} \n      {{this}} \n{{/each}}',
    response_type: 'text',
  },
  {
    text: 'And your have a joint account with {{people.[1]}}',
    response_type: 'text',
  },
];
privAnswerWithArray[0].response.output.text = [
  `Hello {{#if author}}\n {{firstName}} {{lastName}}\n{{/if}}!', 'Your family members 
  registered in our system are\n{{#each people}} {{this}} {{/each}}', 'And your have a joint account
   with {{people.[1]}}`,
];
const privAnswerWithNegetiveValue = _.cloneDeep(answerBase);
privAnswerWithNegetiveValue[0].response.output.generic = [
  {
    text: 'Employee details found for {{employeeId}} are name: {{firstName}} {{lastname}}, phone number : {{mobileNumber}}, email: {{emailId}}',
    response_type: 'text',
  },
];
privAnswerWithNegetiveValue[0].response.output.text = [
  'Employee details found for {{employeeId}} are name: {{firstName}} {{lastname}}, phone number : {{mobileNumber}}, email: {{emailId}}',
];
const privAnswerWithForStatement = _.cloneDeep(answerBase);
privAnswerWithForStatement[0].response.output.generic = [
  {
    text: 'Hello {{#with person}} \n {{firstname}} {{lastname}} \n {{/with}}',
    response_type: 'text',
  },
];
privAnswerWithForStatement[0].response.output.text = [
  'Hello {{#with person}} \n {{firstname}} {{lastname}} \n {{/with}}',
];
const answerWithDebugResponse = _.cloneDeep(answerBase);
answerWithDebugResponse[0].response.output = {
  generic: [
    {
      response_type: 'text',
      text: '-----PRE-----',
    },
    {
      response_type: 'text',
      text: `workspace => Masterflow\nutterance => Hoe duur is een overboeking naar Slowakije?\ncontext.
      abTest => true\ncontext.counterRetry => 0\ncontext.metadata.user_id => 
      d4c6fabf-c32c-4f94-a6c9-dc4d627a882a\ncontext.triggerLivechat => 1\ncontext.timeAsANumber => 
      125643\ncontext.isLiveChatOpen => false\ncontext.triggerRephrase => 1\ncontext.timezone => Europe/
      Amsterdam\ncontext.dayOfTheWeek => 3\ncontext.triggerCursing => 1\ncontext.global => [object 
        Object]\ncontext.counterComplain => 0\ncontext.counterCursing => 0\ncontext.abTestRandom => 
        false\ncontext.counterLivechat => 0\ncontext.triggerFeedback => 0.9\ncontext.conversation_id =>
         d4c6fabf-c32c-4f94-a6c9-dc4d627a882a\ncontext.triggerRetry => 1\ncontext.counterRephrase => 
         0\ncontext.chatStartedLocation => null\norc => undefined\nglobal => [object Object]`,
    },
  ],
  text: `{"default":[{"response_type":"text","text":"-----PRE-----"},{"response_type":"text",
  "text":"workspace => Masterflow\\nutterance => Hoe duur is een overboeking naar Slowakije?\\ncontext.
  abTest => true\\ncontext.counterRetry => 0\\ncontext.metadata.user_id => 
  d4c6fabf-c32c-4f94-a6c9-dc4d627a882a\\ncontext.triggerLivechat => 1\\ncontext.timeAsANumber => 
  125643\\ncontext.isLiveChatOpen => false\\ncontext.triggerRephrase => 1\\ncontext.timezone => Europe/
  Amsterdam\\ncontext.dayOfTheWeek => 3\\ncontext.triggerCursing => 1\\ncontext.global => [object 
  Object]\\ncontext.counterComplain => 0\\ncontext.counterCursing => 0\\ncontext.abTestRandom => 
  false\\ncontext.counterLivechat => 0\\ncontext.triggerFeedback => 0.9\\ncontext.conversation_id =>
   d4c6fabf-c32c-4f94-a6c9-dc4d627a882a\\ncontext.triggerRetry => 1\\ncontext.counterRephrase => 
   0\\ncontext.chatStartedLocation => null\\norc => undefined\\nglobal => [object Object]"},
   {"response_type":"text","text":"-----POST-----"},{"response_type":"text","text":"intents.0.intent =>
    Overboekingen\\nintents.0.confidence => 0.9776321887969972\\nintents.1.intent => Beleggen\\nintents
    1.confidence => 0.24155228137969972\\nintents.2.intent => Grey_Intents\\nintents.2.confidence => 0.
    2394982546567917\\nintents.3.intent => Hypotheken\\nintents.3.confidence => 0.
    23378265500068665\\nintents.4.intent => Betaalpas\\nintents.4.confidence => 0.
    22247159630060198\\nintents.5.intent => iDEAL\\nintents.5.confidence => 0.
    22036450803279878\\nintents.6.intent => 1120-Ik..wil..een..medewerker..spreken\\nintents.6.
    confidence => 0.21780906915664675\\nintents.7.intent => Incasso\\nintents.7.confidence => 0.
    2134502172470093\\nintents.8.intent => Overzichten\\nintents.8.confidence => 0.
    21087931767106058\\nintents.9.intent => Leningen\\nintents.9.confidence => 0.
    2078996241092682\\nnodes_visited.0 => node_8_1580203957319\\nnodes_visited.1 => 
    node_3_1562599319043\\ndialog_stack.0.dialog_node => root\\ncontext.abTest => true\\ncontext.
    counterRetry => 0\\ncontext.metadata.user_id => d4c6fabf-c32c-4f94-a6c9-dc4d627a882a\\ncontext.
    triggerLivechat => 1\\ncontext.timeAsANumber => 125643\\ncontext.isLiveChatOpen => false\\ncontext.
    triggerRephrase => 1\\ncontext.timezone => Europe/Amsterdam\\ncontext.dayOfTheWeek => 3\\ncontext.
    triggerCursing => 1\\ncontext.global => [object Object]\\ncontext.counterComplain => 0\\ncontext.
    counterCursing => 0\\ncontext.abTestRandom => false\\ncontext.counterLivechat => 0\\ncontext.
    triggerFeedback => 0.9\\ncontext.conversation_id => d4c6fabf-c32c-4f94-a6c9-dc4d627a882a\\ncontext.
    triggerRetry => 1\\ncontext.counterRephrase => 0\\ncontext.chatStartedLocation => null\\ncontext.
    orc.ctx.chatSubject => null\\ncontext.orc.ctx.counterRetry => 0\\ncontext.orc.ctx.isClosedDomain =>
     null\\ncontext.orc.ctx.isLiveChatOpen => false\\ncontext.orc.ctx.counterLivechat => 0\\ncontext.
     orc.ctx.counterRephrase => 0\\ncontext.orc.ctx.uniqueVisitorId => null\\ncontext.orc.ctx.
     currentWorkspace => Overboekingen\\ncontext.orc.ctx.chatStartedLocation => null\\ncontext.orc.
     passTo => Overboekingen\\norc.ctx.chatSubject => null\\norc.ctx.counterRetry => 0\\norc.ctx.
     isClosedDomain => null\\norc.ctx.isLiveChatOpen => false\\norc.ctx.counterLivechat => 0\\norc.ctx.
     counterRephrase => 0\\norc.ctx.uniqueVisitorId => null\\norc.ctx.currentWorkspace => 
     Overboekingen\\norc.ctx.chatStartedLocation => null\\norc.passTo => Overboekingen\\nglobal =>
      [object Object]"},{"response_type":"text","text":"-----ACTUAL-----"}]}`,
  nodes_visited: [
    'node_8_1580203957319',
    'node_3_1562599319043',
  ],
  log_messages: [],
};

const vahAnswer = [
  {
    response: {
      output: {
        generic: [
          {
            response_type: 'text',
            text: `{ "default": [{ "text": "Hello, this is VAH PoC test bot.", "response_type": "text" },
              { "text": "How can I help you today?",  "response_type": "text" }, 
              { "response_type": "event", "name": "disableInputField", "payload": { "value": false }}], "generic": [] }`,
          },
        ],
        text: [
          `{ "default": [{ "text": "Hello, this is VAH PoC test bot.", "response_type": "text" }, 
           { "text": "How can I help you today?", "response_type": "text" }, 
           { "response_type": "event", "name": "disableInputField", "payload": { "value": false }}], "generic": [] }`,
        ],
      },
    },
  },
];

const vahAnswerHandover = [
  {
    response: {
      output: {
        generic: [
          {
            response_type: 'text',
            text: `{"default": [{"text": "Handing conversation to agent", "response_type": "text" }, 
            {"response_type": "event", "name": "disableInputField", "payload": {"value": true }},
            {"response_type": "event", "name": "liveAgentTransfer", "payload": {"chatSubject": "mortgage" }}], "generic": [] }`,
          },
        ],
        text: [
          `{"default": [{ "text": "Handing conversation to agent", "response_type": "text" }, 
          {"response_type": "event", "name": "disableInputField", "payload": { "value": true }},
          {"response_type": "event", "name": "liveAgentTransfer", "payload": { "chatSubject": "mortgage" }}], "generic": [] }`,
        ],
      },
    },
  },
];

module.exports = {
  imageAnswer,
  imageAnswerOutput,
  invalidAnswer,
  optionAnswer,
  optionAnswerOutput,
  textAnswer,
  textAnswerOutput,
  suggestionAnswer,
  suggestionAnswerOutput,
  privAnswerWithArray,
  privAnswerWithNegetiveValue,
  privAnswerWithForStatement,
  answerWithDebugResponse,
  vahAnswer,
  vahAnswerHandover,
};
