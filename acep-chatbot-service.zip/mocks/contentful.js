module.exports.contentfulResponse = {
  sys: {
    type: 'Array',
  },
  total: 1,
  skip: 0,
  limit: 100,
  items: [
    {
      metadata: {
        tags: [],
      },
      sys: {
        space: {
          sys: {
            type: 'Link',
            linkType: 'Space',
            id: 'riy4ayq9brzz',
          },
        },
        id: '2ugCPv7MQHO2dwxmpwaWqo',
        type: 'Entry',
        createdAt: '2022-04-12T14:45:25.795Z',
        updatedAt: '2022-07-11T08:41:03.100Z',
        environment: {
          sys: {
            id: 'master',
            type: 'Link',
            linkType: 'Environment',
          },
        },
        revision: 12,
        contentType: {
          sys: {
            type: 'Link',
            linkType: 'ContentType',
            id: 'node',
          },
        },
        locale: 'nl',
      },
      fields: {
        title: '#Z02 Betaalpas verlopen (with link image)',
        chatbot: 'CB',
        skill: 'Betaalpas',
        id: 202001,
        responses: [
          {
            metadata: {
              tags: [],
            },
            sys: {
              space: {
                sys: {
                  type: 'Link',
                  linkType: 'Space',
                  id: 'riy4ayq9brzz',
                },
              },
              id: '39xHwRVcjUQ26JNweNU4Qz',
              type: 'Entry',
              createdAt: '2022-04-12T14:39:07.580Z',
              updatedAt: '2022-07-18T09:53:17.350Z',
              environment: {
                sys: {
                  id: 'master',
                  type: 'Link',
                  linkType: 'Environment',
                },
              },
              revision: 16,
              contentType: {
                sys: {
                  type: 'Link',
                  linkType: 'ContentType',
                  id: 'botResponse2',
                },
              },
              locale: 'nl',
            },
            fields: {
              title: 'Oké! Een aantal weken voordat uw betaalpas verloopt, sturen we u automagisch een nieuwe',
              answerText: {
                nodeType: 'document',
                data: {},
                content: [
                  {
                    nodeType: 'paragraph',
                    data: {},
                    content: [
                      {
                        nodeType: 'text',
                        value: '',
                        marks: [],
                        data: {},
                      },
                      {
                        nodeType: 'embedded-entry-inline',
                        data: {
                          target: {
                            metadata: {
                              tags: [],
                            },
                            sys: {
                              space: {
                                sys: {
                                  type: 'Link',
                                  linkType: 'Space',
                                  id: 'riy4ayq9brzz',
                                },
                              },
                              id: '3ozMe4xOFiAmIxtjGhjCeN',
                              type: 'Entry',
                              createdAt: '2022-03-21T10:56:04.866Z',
                              updatedAt: '2022-05-03T15:14:28.788Z',
                              environment: {
                                sys: {
                                  id: 'master',
                                  type: 'Link',
                                  linkType: 'Environment',
                                },
                              },
                              revision: 4,
                              contentType: {
                                sys: {
                                  type: 'Link',
                                  linkType: 'ContentType',
                                  id: 'response',
                                },
                              },
                              locale: 'nl',
                            },
                            fields: {
                              title: 'Oké!',
                              answerText: {
                                nodeType: 'document',
                                data: {},
                                content: [
                                  {
                                    nodeType: 'paragraph',
                                    data: {},
                                    content: [
                                      {
                                        nodeType: 'text',
                                        value: 'Oké!',
                                        marks: [],
                                        data: {},
                                      },
                                    ],
                                  },
                                ],
                              },
                            },
                          },
                        },
                        content: [],
                      },
                      {
                        nodeType: 'text',
                        value: 'Oké! Een aantal weken voordat uw betaalpas verloopt, sturen we automatisch een nieuwe. Hier hoeft u niets voor te doen. ',
                        marks: [],
                        data: {},
                      },
                      {
                        nodeType: 'hyperlink',
                        data: {
                          uri: 'https://www.google.com',
                        },
                        content: [
                          {
                            nodeType: 'text',
                            value: 'Extra link',
                            marks: [],
                            data: {},
                          },
                        ],
                      },
                      {
                        nodeType: 'text',
                        value: '',
                        marks: [],
                        data: {},
                      },
                    ],
                  },
                ],
              },
            },
          },
          {
            metadata: {
              tags: [],
            },
            sys: {
              space: {
                sys: {
                  type: 'Link',
                  linkType: 'Space',
                  id: 'riy4ayq9brzz',
                },
              },
              id: 'Ha2tRQ4mt9sqrimGPVwL5',
              type: 'Entry',
              createdAt: '2022-04-12T14:42:18.406Z',
              updatedAt: '2022-07-08T10:29:22.982Z',
              environment: {
                sys: {
                  id: 'master',
                  type: 'Link',
                  linkType: 'Environment',
                },
              },
              revision: 4,
              contentType: {
                sys: {
                  type: 'Link',
                  linkType: 'ContentType',
                  id: 'botResponse2',
                },
              },
              locale: 'nl',
            },
            fields: {
              title: 'De vervaldatum van uw betaalpas vindt u rechts onderin op de pas (with link image)',
              answerText: {
                data: {},
                content: [
                  {
                    data: {},
                    content: [
                      {
                        data: {},
                        marks: [],
                        value: 'De vervaldatum van uw betaalpas vindt u rechts onderin op de pas.',
                        nodeType: 'text',
                      },
                    ],
                    nodeType: 'paragraph',
                  },
                ],
                nodeType: 'document',
              },
              images: {
                metadata: {
                  tags: [],
                },
                sys: {
                  space: {
                    sys: {
                      type: 'Link',
                      linkType: 'Space',
                      id: 'riy4ayq9brzz',
                    },
                  },
                  id: '12uGyJPfu3dkmHb8recfLm',
                  type: 'Entry',
                  createdAt: '2022-04-21T07:53:13.100Z',
                  updatedAt: '2022-04-21T09:45:33.017Z',
                  environment: {
                    sys: {
                      id: 'master',
                      type: 'Link',
                      linkType: 'Environment',
                    },
                  },
                  revision: 2,
                  contentType: {
                    sys: {
                      type: 'Link',
                      linkType: 'ContentType',
                      id: 'image',
                    },
                  },
                  locale: 'nl',
                },
                fields: {
                  name: 'Plaatje betaalpas vervaldatum',
                  source: 'https://www.abnamro.nl/mijn-abnamro/web-chat/images/Passen_Betaalpas_geldig.jpg',
                  altText: 'Plaatje van betaalpas met omcircelde vervaldatum',
                },
              },
              link: {
                metadata: {
                  tags: [],
                },
                sys: {
                  space: {
                    sys: {
                      type: 'Link',
                      linkType: 'Space',
                      id: 'riy4ayq9brzz',
                    },
                  },
                  id: '722P8Yzhoif5QP4NNz83yX',
                  type: 'Entry',
                  createdAt: '2022-07-08T10:29:08.857Z',
                  updatedAt: '2022-07-08T10:29:08.857Z',
                  environment: {
                    sys: {
                      id: 'master',
                      type: 'Link',
                      linkType: 'Environment',
                    },
                  },
                  revision: 1,
                  contentType: {
                    sys: {
                      type: 'Link',
                      linkType: 'ContentType',
                      id: 'link',
                    },
                  },
                  locale: 'nl',
                },
                fields: {
                  name: 'test sam',
                  linkText: 'Test Sam',
                  linkUrl: 'https://www.google.com',
                },
              },
            },
          },
          {
            metadata: {
              tags: [],
            },
            sys: {
              space: {
                sys: {
                  type: 'Link',
                  linkType: 'Space',
                  id: 'riy4ayq9brzz',
                },
              },
              id: '2b76ZwoPInEAJLDzvv4czT',
              type: 'Entry',
              createdAt: '2022-04-21T10:57:41.023Z',
              updatedAt: '2022-07-11T10:29:25.406Z',
              environment: {
                sys: {
                  id: 'master',
                  type: 'Link',
                  linkType: 'Environment',
                },
              },
              revision: 21,
              contentType: {
                sys: {
                  type: 'Link',
                  linkType: 'ContentType',
                  id: 'response',
                },
              },
              locale: 'nl',
            },
            fields: {
              title: 'Variable test',
              answerText: {
                nodeType: 'document',
                data: {},
                content: [
                  {
                    nodeType: 'paragraph',
                    data: {},
                    content: [
                      {
                        nodeType: 'text',
                        value: 'U wilt iets weten over: <? chatSubject ?>.',
                        marks: [],
                        data: {},
                      },
                    ],
                  },
                  {
                    nodeType: 'paragraph',
                    data: {},
                    content: [
                      {
                        nodeType: 'text',
                        value: '',
                        marks: [],
                        data: {},
                      },
                    ],
                  },
                  {
                    nodeType: 'paragraph',
                    data: {},
                    content: [
                      {
                        nodeType: 'text',
                        value: 'some other text',
                        marks: [],
                        data: {},
                      },
                    ],
                  },
                ],
              },
              syncWithDrawIo: false,
            },
          },
        ],
        options: [
          {
            metadata: {
              tags: [],
            },
            sys: {
              space: {
                sys: {
                  type: 'Link',
                  linkType: 'Space',
                  id: 'riy4ayq9brzz',
                },
              },
              id: 'Pimyh3WhgTex2kEvLnY1i',
              type: 'Entry',
              createdAt: '2022-04-12T14:44:49.731Z',
              updatedAt: '2022-07-11T09:20:04.903Z',
              environment: {
                sys: {
                  id: 'master',
                  type: 'Link',
                  linkType: 'Environment',
                },
              },
              revision: 2,
              contentType: {
                sys: {
                  type: 'Link',
                  linkType: 'ContentType',
                  id: 'botResponseButton',
                },
              },
              locale: 'nl',
            },
            fields: {
              title: 'Vertel verder',
              buttonText: 'Vertel verder',
              synchWithDrawIo: true,
              payload: {
                endChat: true,
              },
            },
          },
        ],
        event: [
          {
            metadata: {
              tags: [],
            },
            sys: {
              space: {
                sys: {
                  type: 'Link',
                  linkType: 'Space',
                  id: 'riy4ayq9brzz',
                },
              },
              id: '1VNtuiXkYDBvNHPjRFpn4f',
              type: 'Entry',
              createdAt: '2022-07-08T15:14:31.698Z',
              updatedAt: '2022-07-11T09:11:19.687Z',
              environment: {
                sys: {
                  id: 'master',
                  type: 'Link',
                  linkType: 'Environment',
                },
              },
              revision: 4,
              contentType: {
                sys: {
                  type: 'Link',
                  linkType: 'ContentType',
                  id: 'event',
                },
              },
              locale: 'nl',
            },
            fields: {
              name: 'disableInputField',
              title: 'disableInputField:true',
            },
          },
        ],
        demo: true,
      },
    },
  ],
  includes: {
    Entry: [
      {
        metadata: {
          tags: [],
        },
        sys: {
          space: {
            sys: {
              type: 'Link',
              linkType: 'Space',
              id: 'riy4ayq9brzz',
            },
          },
          id: '12uGyJPfu3dkmHb8recfLm',
          type: 'Entry',
          createdAt: '2022-04-21T07:53:13.100Z',
          updatedAt: '2022-04-21T09:45:33.017Z',
          environment: {
            sys: {
              id: 'master',
              type: 'Link',
              linkType: 'Environment',
            },
          },
          revision: 2,
          contentType: {
            sys: {
              type: 'Link',
              linkType: 'ContentType',
              id: 'image',
            },
          },
          locale: 'nl',
        },
        fields: {
          name: 'Plaatje betaalpas vervaldatum',
          source: 'https://www.abnamro.nl/mijn-abnamro/web-chat/images/Passen_Betaalpas_geldig.jpg',
          altText: 'Plaatje van betaalpas met omcircelde vervaldatum',
        },
      },
      {
        metadata: {
          tags: [],
        },
        sys: {
          space: {
            sys: {
              type: 'Link',
              linkType: 'Space',
              id: 'riy4ayq9brzz',
            },
          },
          id: '1VNtuiXkYDBvNHPjRFpn4f',
          type: 'Entry',
          createdAt: '2022-07-08T15:14:31.698Z',
          updatedAt: '2022-07-11T09:11:19.687Z',
          environment: {
            sys: {
              id: 'master',
              type: 'Link',
              linkType: 'Environment',
            },
          },
          revision: 4,
          contentType: {
            sys: {
              type: 'Link',
              linkType: 'ContentType',
              id: 'event',
            },
          },
          locale: 'nl',
        },
        fields: {
          name: 'disableInputField',
          title: 'disableInputField:true',
        },
      },
      {
        metadata: {
          tags: [],
        },
        sys: {
          space: {
            sys: {
              type: 'Link',
              linkType: 'Space',
              id: 'riy4ayq9brzz',
            },
          },
          id: '2b76ZwoPInEAJLDzvv4czT',
          type: 'Entry',
          createdAt: '2022-04-21T10:57:41.023Z',
          updatedAt: '2022-07-11T10:29:25.406Z',
          environment: {
            sys: {
              id: 'master',
              type: 'Link',
              linkType: 'Environment',
            },
          },
          revision: 21,
          contentType: {
            sys: {
              type: 'Link',
              linkType: 'ContentType',
              id: 'response',
            },
          },
          locale: 'nl',
        },
        fields: {
          title: 'Variable test',
          answerText: {
            nodeType: 'document',
            data: {},
            content: [
              {
                nodeType: 'paragraph',
                data: {},
                content: [
                  {
                    nodeType: 'text',
                    value: 'U wilt iets weten over: <? chatSubject ?>.',
                    marks: [],
                    data: {},
                  },
                ],
              },
              {
                nodeType: 'paragraph',
                data: {},
                content: [
                  {
                    nodeType: 'text',
                    value: '',
                    marks: [],
                    data: {},
                  },
                ],
              },
              {
                nodeType: 'paragraph',
                data: {},
                content: [
                  {
                    nodeType: 'text',
                    value: 'some other text',
                    marks: [],
                    data: {},
                  },
                ],
              },
            ],
          },
          syncWithDrawIo: false,
        },
      },
      {
        metadata: {
          tags: [],
        },
        sys: {
          space: {
            sys: {
              type: 'Link',
              linkType: 'Space',
              id: 'riy4ayq9brzz',
            },
          },
          id: '39xHwRVcjUQ26JNweNU4Qz',
          type: 'Entry',
          createdAt: '2022-04-12T14:39:07.580Z',
          updatedAt: '2022-07-18T09:53:17.350Z',
          environment: {
            sys: {
              id: 'master',
              type: 'Link',
              linkType: 'Environment',
            },
          },
          revision: 16,
          contentType: {
            sys: {
              type: 'Link',
              linkType: 'ContentType',
              id: 'botResponse2',
            },
          },
          locale: 'nl',
        },
        fields: {
          title: 'Oké! Een aantal weken voordat uw betaalpas verloopt, sturen we u automagisch een nieuwe',
          answerText: {
            nodeType: 'document',
            data: {},
            content: [
              {
                nodeType: 'paragraph',
                data: {},
                content: [
                  {
                    nodeType: 'text',
                    value: '',
                    marks: [],
                    data: {},
                  },
                  {
                    nodeType: 'embedded-entry-inline',
                    data: {
                      target: {
                        metadata: {
                          tags: [],
                        },
                        sys: {
                          space: {
                            sys: {
                              type: 'Link',
                              linkType: 'Space',
                              id: 'riy4ayq9brzz',
                            },
                          },
                          id: '3ozMe4xOFiAmIxtjGhjCeN',
                          type: 'Entry',
                          createdAt: '2022-03-21T10:56:04.866Z',
                          updatedAt: '2022-05-03T15:14:28.788Z',
                          environment: {
                            sys: {
                              id: 'master',
                              type: 'Link',
                              linkType: 'Environment',
                            },
                          },
                          revision: 4,
                          contentType: {
                            sys: {
                              type: 'Link',
                              linkType: 'ContentType',
                              id: 'response',
                            },
                          },
                          locale: 'nl',
                        },
                        fields: {
                          title: 'Oké!',
                          answerText: {
                            nodeType: 'document',
                            data: {},
                            content: [
                              {
                                nodeType: 'paragraph',
                                data: {},
                                content: [
                                  {
                                    nodeType: 'text',
                                    value: 'Oké!',
                                    marks: [],
                                    data: {},
                                  },
                                ],
                              },
                            ],
                          },
                        },
                      },
                    },
                    content: [],
                  },
                  {
                    nodeType: 'text',
                    value: 'Oké! Een aantal weken voordat uw betaalpas verloopt, sturen we automatisch een nieuwe. Hier hoeft u niets voor te doen. ',
                    marks: [],
                    data: {},
                  },
                  {
                    nodeType: 'hyperlink',
                    data: {
                      uri: 'https://www.google.com',
                    },
                    content: [
                      {
                        nodeType: 'text',
                        value: 'Extra link',
                        marks: [],
                        data: {},
                      },
                    ],
                  },
                  {
                    nodeType: 'text',
                    value: '',
                    marks: [],
                    data: {},
                  },
                ],
              },
            ],
          },
        },
      },
      {
        metadata: {
          tags: [],
        },
        sys: {
          space: {
            sys: {
              type: 'Link',
              linkType: 'Space',
              id: 'riy4ayq9brzz',
            },
          },
          id: '3ozMe4xOFiAmIxtjGhjCeN',
          type: 'Entry',
          createdAt: '2022-03-21T10:56:04.866Z',
          updatedAt: '2022-05-03T15:14:28.788Z',
          environment: {
            sys: {
              id: 'master',
              type: 'Link',
              linkType: 'Environment',
            },
          },
          revision: 4,
          contentType: {
            sys: {
              type: 'Link',
              linkType: 'ContentType',
              id: 'response',
            },
          },
          locale: 'nl',
        },
        fields: {
          title: 'Oké!',
          answerText: {
            nodeType: 'document',
            data: {},
            content: [
              {
                nodeType: 'paragraph',
                data: {},
                content: [
                  {
                    nodeType: 'text',
                    value: 'Oké!',
                    marks: [],
                    data: {},
                  },
                ],
              },
            ],
          },
        },
      },
      {
        metadata: {
          tags: [],
        },
        sys: {
          space: {
            sys: {
              type: 'Link',
              linkType: 'Space',
              id: 'riy4ayq9brzz',
            },
          },
          id: '722P8Yzhoif5QP4NNz83yX',
          type: 'Entry',
          createdAt: '2022-07-08T10:29:08.857Z',
          updatedAt: '2022-07-08T10:29:08.857Z',
          environment: {
            sys: {
              id: 'master',
              type: 'Link',
              linkType: 'Environment',
            },
          },
          revision: 1,
          contentType: {
            sys: {
              type: 'Link',
              linkType: 'ContentType',
              id: 'link',
            },
          },
          locale: 'nl',
        },
        fields: {
          name: 'test sam',
          linkText: 'Test Sam',
          linkUrl: 'https://www.google.com',
        },
      },
      {
        metadata: {
          tags: [],
        },
        sys: {
          space: {
            sys: {
              type: 'Link',
              linkType: 'Space',
              id: 'riy4ayq9brzz',
            },
          },
          id: 'Ha2tRQ4mt9sqrimGPVwL5',
          type: 'Entry',
          createdAt: '2022-04-12T14:42:18.406Z',
          updatedAt: '2022-07-08T10:29:22.982Z',
          environment: {
            sys: {
              id: 'master',
              type: 'Link',
              linkType: 'Environment',
            },
          },
          revision: 4,
          contentType: {
            sys: {
              type: 'Link',
              linkType: 'ContentType',
              id: 'botResponse2',
            },
          },
          locale: 'nl',
        },
        fields: {
          title: 'De vervaldatum van uw betaalpas vindt u rechts onderin op de pas (with link image)',
          answerText: {
            data: {},
            content: [
              {
                data: {},
                content: [
                  {
                    data: {},
                    marks: [],
                    value: 'De vervaldatum van uw betaalpas vindt u rechts onderin op de pas.',
                    nodeType: 'text',
                  },
                ],
                nodeType: 'paragraph',
              },
            ],
            nodeType: 'document',
          },
          images: {
            metadata: {
              tags: [],
            },
            sys: {
              space: {
                sys: {
                  type: 'Link',
                  linkType: 'Space',
                  id: 'riy4ayq9brzz',
                },
              },
              id: '12uGyJPfu3dkmHb8recfLm',
              type: 'Entry',
              createdAt: '2022-04-21T07:53:13.100Z',
              updatedAt: '2022-04-21T09:45:33.017Z',
              environment: {
                sys: {
                  id: 'master',
                  type: 'Link',
                  linkType: 'Environment',
                },
              },
              revision: 2,
              contentType: {
                sys: {
                  type: 'Link',
                  linkType: 'ContentType',
                  id: 'image',
                },
              },
              locale: 'nl',
            },
            fields: {
              name: 'Plaatje betaalpas vervaldatum',
              source: 'https://www.abnamro.nl/mijn-abnamro/web-chat/images/Passen_Betaalpas_geldig.jpg',
              altText: 'Plaatje van betaalpas met omcircelde vervaldatum',
            },
          },
          link: {
            metadata: {
              tags: [],
            },
            sys: {
              space: {
                sys: {
                  type: 'Link',
                  linkType: 'Space',
                  id: 'riy4ayq9brzz',
                },
              },
              id: '722P8Yzhoif5QP4NNz83yX',
              type: 'Entry',
              createdAt: '2022-07-08T10:29:08.857Z',
              updatedAt: '2022-07-08T10:29:08.857Z',
              environment: {
                sys: {
                  id: 'master',
                  type: 'Link',
                  linkType: 'Environment',
                },
              },
              revision: 1,
              contentType: {
                sys: {
                  type: 'Link',
                  linkType: 'ContentType',
                  id: 'link',
                },
              },
              locale: 'nl',
            },
            fields: {
              name: 'test sam',
              linkText: 'Test Sam',
              linkUrl: 'https://www.google.com',
            },
          },
        },
      },
      {
        metadata: {
          tags: [],
        },
        sys: {
          space: {
            sys: {
              type: 'Link',
              linkType: 'Space',
              id: 'riy4ayq9brzz',
            },
          },
          id: 'Pimyh3WhgTex2kEvLnY1i',
          type: 'Entry',
          createdAt: '2022-04-12T14:44:49.731Z',
          updatedAt: '2022-07-11T09:20:04.903Z',
          environment: {
            sys: {
              id: 'master',
              type: 'Link',
              linkType: 'Environment',
            },
          },
          revision: 2,
          contentType: {
            sys: {
              type: 'Link',
              linkType: 'ContentType',
              id: 'botResponseButton',
            },
          },
          locale: 'nl',
        },
        fields: {
          title: 'Vertel verder',
          buttonText: 'Vertel verder',
          synchWithDrawIo: true,
          payload: {
            endChat: true,
          },
        },
      },
    ],
  },
};
