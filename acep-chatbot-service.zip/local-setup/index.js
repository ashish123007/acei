async function main() {
  console.log('Starting initialisation');

  const endpoint = process.env.DATABASE_ENDPOINT;
  const key = process.env.DATABASE_KEY;
  const databaseId = process.env.DATABASE_NAME;

  const { CosmosClient } = require('@azure/cosmos');
  const client = new CosmosClient({ endpoint, key });

  while (true) {
    try {
      await delay(1);
      await client.getReadEndpoint();
      break;
    } catch (err) {
      console.error(err.message);
    }
  }

  const { database } = await client.databases.createIfNotExists({ id: databaseId });
  console.log('Created database', databaseId);

  const secondsPerMonth = 60 * 60 * 24 * 30;

  const containerDefinitions = [
    {
      id: 'SESSION_TABLE',
      partitionKey: { kind: 'Hash', paths: ['/partition'] },
      indexingPolicy: {
        indexingMode: 'consistent',
        automatic: true,
        includedPaths: [
          { path: '/botId/?' },
          { path: '/conversationId/?' },
          { path: '/partition/?' },
          { path: '/type/?' },
          { path: '/userId/?' },
        ],
        excludedPaths: [{ path: '/*' }],
      },
      defaultTtl: secondsPerMonth,
    },
  ];

  for (const containerDefinition of containerDefinitions) {
    await database.containers.createIfNotExists(containerDefinition);
    console.log('Created', containerDefinition.id);
  }

  console.log('Finished initialisation');
}
main();

async function delay(seconds) {
  return new Promise((resolve, reject) => setTimeout(resolve, seconds * 1000));
}
