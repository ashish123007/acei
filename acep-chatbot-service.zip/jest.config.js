module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  setupFiles: [
    "dotenv/config",
    "./setupTests.js",
  ],
  testMatch: [
    "**/*.spec.ts"
  ],
  collectCoverage: true,
  watchPathIgnorePatterns: ['node_modules'],
  collectCoverageFrom: [
      'src/**/*.ts',
      '!**/node_modules/**',
      '!src/types/**',
      '!src/machines/**',
      '!src/utils/graphql.ts'
  ],
  coverageDirectory: 'coverage',
  coverageReporters: ['lcov', 'text', 'cobertura'],
  reporters: [
    "default",
    [ "jest-junit", { 
      outputDirectory: "testresults",
      outputName: 'results.xml'
    } ]
  ],
};