import { Activity } from '../types/copilotApi.model';
import { LogType } from './azureMonitorConfig';

export const getLogsForAzureMonitor = (
  options: {
    conversationId: string;
    copilotConversationId: string;
    botId: string;
    chat_session_id: string;
  },
  customMetric: { userActivityStringified?: string; activities?: Activity[] },
  type: LogType = LogType['REQUEST']
) => {
  const { conversationId, copilotConversationId, botId, chat_session_id } = options;
  const log = {
    conversation_id: conversationId,
    copilot_studio_id: copilotConversationId,
    chat_session_id, // empty for now
    bot_id: botId,
    bot_env: '',
    timestamp: Date.now(),
    type,
  };
  return {
    ...log,
    ...customMetric,
  };
};
