import { DataCollectorClient } from 'azure-log-analytics-data-collector-client';
import config from '../config';
import loggerUtils from '../utils/logger';
import { CopilotRequest, CopilotResponse, LogConfigProviders } from './azureMonitorConfig';

const { logger } = loggerUtils;
const { primarySharedKey, workspaceId, ENVIRONMENT } = config;

const azureMonitor = async (
  provider: LogConfigProviders,
  tableName: string,
  messages: (CopilotRequest | CopilotResponse)[]
) => {
  if (ENVIRONMENT === 'local') {
    return;
  }
  setImmediate(async () => {
    try {
      logger.info(`${provider} :: invoked :: with ${messages.length} message(s)`);
      const dataCollectorClient = new DataCollectorClient(workspaceId, primarySharedKey);
      const { code, status } = await dataCollectorClient.send(tableName, messages);
      logger.info(`${provider} :: ${messages.length} message(s) successfully finished with status:${code}: ${status}`);
    } catch (error) {
      logger.error(`${provider} :: error ::`, error);
    }
  });
};

export default azureMonitor;
