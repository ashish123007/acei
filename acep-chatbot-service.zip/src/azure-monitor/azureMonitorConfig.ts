import { Activity } from '../types/copilotApi.model';

export enum LogConfigProviders {
  AZURE_MONITOR = 'azure Monitor',
}
export enum LogType {
  REQUEST = 'request',
  RESPONSE = 'response',
}
export interface CopilotRequest {
  conversation_id: string;
  copilot_studio_id: string;
  chat_session_id: string;
  bot_id: string;
  bot_env: string;
  type: LogType.REQUEST;
  timestamp: number;
  userActivityStringified: string;
}
export interface CopilotResponse extends Omit<CopilotRequest, 'type' | 'userActivityStringified'> {
  activities?: Activity[];
  type: LogType.RESPONSE;
}
