import { z } from 'zod';
import { createZodDto } from 'nestjs-zod';
import { JsonMap } from './utils';
import { BotEnvironment } from './bot';
import { Activity } from './copilotApi.model';
const VahResponse = z
  .object({
    branchName: z.string(),
    customPayload: z
      .object({
        AgentNotes: z.string().optional(),
        subject: z.string().optional(),
        language: z.string().optional(),
      })
      .optional(),
    nextPromptSequence: z
      .object({
        prompts: z.array(
          z
            .object({
              transcript: z.string().optional(),
              mediaSpecificObject: z
                .object({
                  type: z.string(),
                  text: z.string().optional(),
                  contents: z.array(z.record(z.string(), z.unknown()).optional()).optional(),
                  buttons: z.array(z.record(z.string(), z.unknown()).optional()).optional(),
                  payload: z.record(z.unknown()).optional(),
                  timestamp: z.string().optional(),
                })
                .strict(),
            })
            .strict()
        ),
      })
      .strict(),
  })
  .strict();
// class is required for using DTO as a type
export class VahResponseDto extends createZodDto(VahResponse) {}
export type CosmosItem = {
  id: string;
  ttl: number;
};
export type CopilotSessionTable = CosmosItem & {
  botId: string;
  partition: string;
  type: string;
  isFirstMessage?: boolean;
  privateData?: JsonMap;
  copilotConversationId: string;
  chatSessionId?: string;
  languageSelected?: string;
  privateInput?: string;
};
export type PrehookRequest = {
  context?: CopilotSessionTable;
  privateData?: JsonMap;
  [key: string]: unknown;
};
export type PrehookResponse = {
  message: Activity;
  context?: CopilotSessionTable;
  privateData?: JsonMap;
};
export type PosthookResponse = {
  activities: unknown;
  context?: CopilotSessionTable;
  privateData?: JsonMap;
};
export type CopilotSession = CopilotSessionTable & {
  isNew: boolean;
};
export type MaskFn = RegExp | ((word: string) => boolean);
export interface ChatbotError {
  code: number;
  type: string;
  message: string;
  id: string;
}
export interface VoiceIVRCallbackRequests {
  params: { botId: string; channelEnv: string };
  query: { conversationId: string | null };
  headers: {
    authorization?: string;
    defaultpreintent?: string;
  };
  botEnvConfig?: BotEnvironment;
}
export interface MessageHubRequest {
  params: { botId: string };
  headers: { [key: string]: string };
  botEnvConfig?: BotEnvironment;
}
export interface voiceHubEventRequest {
  headers: { [key: string]: string };
}
export enum HTTPMethod {
  get = 'GET',
  post = 'POST',
  delete = 'DELETE',
}
export interface VahBody {
  executionInfo: {
    contactId: string;
  };
  [k: string]: unknown;
}
export interface VoiceBody {
  conversationId: string;
  [k: string]: unknown;
}
