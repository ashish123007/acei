import { CopilotSessionTable } from '.';
import { BotEnvironment } from './bot';
import { VahAnswer } from './machineTypes';
import { JsonMap } from './utils';
import {
  Activity as BotframeworkActivity,
  Attachment as BotframeworkAttachment,
  MessageBackCardAction,
  Conversation,
} from 'botframework-directlinejs';

export type ConversationResponse = Conversation;

export type PostActivitiesResponse = {
  id: string;
};

export const CPS_CUSTOM_EVENTS = {
  NO_INPUT: 'noInput',
  DISCONNECT: 'disconnect',
  START_CONVERSATION: 'startConversation',
  ASK_FOR_CUSTOMER_INPUT: 'askForCustomerInput',
  HANDOFF_INITIATE: 'handoff.initiate',
  START_DTMF: 'startDtmf',
  CAAS_EVENT: 'caasEvent',
  METRICS: 'metrics',
  WEBHOOK_REQUEST: 'webhookRequest',
  SET_CONTEXT: 'setContext',
  NICE_HANDOVER: 'NiceHandover',
  PRIVATE_INPUT: 'privateInput',
  RESTART_CONVERSATION: 'resetConversation',
  LANGUAGE_CHANGED: 'languageChanged',
} as const;

export type PrivateInputEvent = {
  payload: {
    value: string;
  };
};

export type EventName = (typeof CPS_CUSTOM_EVENTS)[keyof typeof CPS_CUSTOM_EVENTS];

export type Activity = Omit<BotframeworkActivity, 'timestamp' | 'text' | 'value'> & {
  name?: string;
  timestamp?: string;
  text?: string;
  value?: unknown;
  attachments?: Omit<BotframeworkAttachment, 'AdaptiveCard'> &
    {
      contentType: 'application/vnd.microsoft.card.adaptive';
      content: {
        type: string;
        body: AttachmentContentBody;
      };
    }[];
  suggestedActions?: {
    actions: MessageBackCardAction[];
    to?: string[];
  };
};

export type vahHandover = {
  livechatSubject: string;
  va_AgentMessage: string;
};

export type PrehookMessage = ActivityToSend & {
  event?: string;
};

export type ActivityToSend = Partial<Activity> & {
  text?: string;
};

export type HandoverValues = {
  handoverCode: string;
  va_AgentMessage: string;
};

export type DtmfValues = {
  interToneTimeoutInSeconds: number;
  maxTonesToCollect: number;
  stopTones: string[];
};

export type AttachmentContentBody = {
  platformType?: string;
  type: string;
  text?: string;
  altText?: string;
  wrap?: boolean;
  url?: string;
  isVisible?: boolean;
  title?: string;
  intro?: string;
  list?: [{ icon: string; text: string }];
  value?: [{ text: string; title: string; url: string }];
  actions?: {
    isQrCode?: boolean;
    type: string;
    title: string;
    data?: JsonMap;
    url?: string;
    iconUrl?: string;
    responseType?: string;
  }[];
  columns?: {
    type: string;
    width: string;
    items: { type: string; text?: string; wrap?: boolean; url?: string; altText?: string }[];
  }[];
};

export type GetActivitiesResponse = {
  activities: Activity[];
  watermark: string;
};

export type ExtractorFn = (activity: Activity) => VahAnswer | undefined;

export type CopilotHookOptions = {
  context: CopilotSessionTable;
  conversationId: string;
  envConfig: BotEnvironment;
  privateData?: JsonMap;
};
