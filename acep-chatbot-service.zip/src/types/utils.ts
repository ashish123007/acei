export type ArrayElement<ArrayType extends readonly unknown[]> = ArrayType extends readonly (infer ElementType)[]
  ? ElementType
  : never;

export type Stricten<T> = {
  [K in keyof T as string extends K ? never : number extends K ? never : K]: T[K];
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type AnyFunction = (...args: any[]) => any;

export type Entity = {
  id: string;
};

export type LegitFunction = (...args: JsonArray) => void | AnyJson | Promise<void | AnyJson>;

export type AnyJson = boolean | number | string | null | JsonArray | JsonMap;

export type JsonMap = {
  [key: string]: AnyJson;
};

export type JsonArray = AnyJson[];

export type IagHeaders = {
  'Trace-Id': 'team-chatbot';
  'X509-OU'?: 'Service Token Application';
  'X509v3-SAN'?: string;
  'X509v3-SAN2'?: string;
  'Accept-Encoding'?: string;
};

export type IagRequestConfig = {
  method: string;
  url: string;
  headers: {
    'Content-Type'?: string;
    Authorization: string;
  };
  data: AnyJson;
};

export type NiceTokenInfo = {
  token: AnyJson | null;
  expiryDate: number | null;
};

export type ServBusScheduleId = string;

export enum MSDSessionType {
  MSD = 'msd',
}
