import { BotkitMessage as B_BokitMessage } from 'botkit';
import { AnyJson, JsonMap } from './utils';
import { VoiceBotResponse } from './voice';

export interface Utterance {
  text: string;
  type: string | unknown;
  response_type: string;
  model_resp?: boolean;
}

export interface ErrorFormat {
  code: number;
  type: string;
  message: string;
}

export interface Event {
  name: string;
  value: AnnaEventValue;
}

export type AnnaEventValue = {
  messageId: string;
  utterance: string;
  chatStartedLocation: string;
  uvId: string;
};

export type VahContent = {
  type: string;
  text?: string;
};

export type InitContext = {
  userInputText: string;
};

export type VahButtons = {
  text: string;
  value?: string | Record<string, unknown>;
  isObject?: boolean;
};

export type VahAnswer = {
  type: string;
  text?: string;
  contents?: VahContent[];
  buttons?: VahButtons[];
  payload?:
    | {
        type?: string;
        chatSubject?: string;
        value?: AnyJson;
        askForCustomerInput?: boolean;
      }
    | JsonMap;
  timestamp?: string;
};

export type BotMessage<T = unknown> = T &
  Pick<B_BokitMessage, 'type' | 'text' | 'value' | 'user' | 'channel'> & {
    reference: B_BokitMessage['reference'] & { email?: string };
    incoming_message: Omit<B_BokitMessage['incoming_message'], 'channelData'> & { channelData?: T };
    messages: Utterance[] | unknown[];
  };

export type BaseWebMessage = {
  type: string;
  conversationId: string;
  userId: string;
  bcNumber: string;
};

export type WebMessage = BaseWebMessage & {
  message: {
    text: string;
  };
  botConfig?: string;
  context: JsonMap;
  userInputType: number;
  executionInfo: {
    contactId: string | number;
  };
  customPayload?: CustomPayload | string;
  userInput?: string;
  uvid: string;
};

export type CustomPayload = {
  appversion: string;
  bcnumber: string;
  cgccode: string;
  domain: string;
  environment: string;
  customEvent?: string;
  frontenddevice: string;
  initcontext: string;
  os: string;
  startedlocation: string;
  subject: string;
  useragent: string;
  uvid: string;
  chatmessagepayloadvalue?: string;
  chatmessagetype?: string;
  chatmessagepayloadindex?: unknown;
  chatmessagepayloadishidden?: unknown;
};

export type WebEvent = BaseWebMessage & {
  name: string;
  event: string;
  value?: AnnaEventValue;
};

export type VahUserEvent = {
  type: string;
  payload: { value: { text: string } };
  text?: string;
};

export type BotWebMessage = BotMessage<WebMessage>;
export type BotWebEvent = BotMessage<WebEvent>;

export type Message = BotMessage & BotWebMessage & BotWebEvent;

export type VoiceIvrMessageBody = {
  conversationId: string;
  message: {
    text: string;
  };
  event?: string;
};

export type AllResponses = VoiceBotResponse | Utterance;

export type VAHEventPayload = {
  appversion: string;
  cgccode: string;
  os: string;
  useragent: string;
  frontenddevice: string;
  domain: string;
  subject: string;
  startedlocation: string;
  initcontext: unknown;
  bcnumber: string;
  uvid: string;
  environment: string;
};
