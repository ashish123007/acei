import { ArrayElement } from './utils';
import { AxiosRequestConfig } from 'axios';

export type BotConfig = {
  environments: {
    admins: { __typename?: 'user'; email: string }[];
    viewers: { __typename?: 'user'; email: string }[];
    editors: { __typename?: 'user'; email: string }[];
    logs: {
      __typename?: 'log';
      provider: string;
      connection: { __typename?: 'logkv'; key: string; value: string }[];
    }[];
    posthooks: { __typename?: 'webhook'; alias: string; requestOptions: AxiosRequestConfig }[];
    prehooks: { __typename?: 'webhook'; alias: string; requestOptions: AxiosRequestConfig }[];
    skills: { apiKey: string; __typename?: 'skill'; name: string; provider: string; skillId: string }[];
    __typename?: 'environment';
    name: string;
    meta?: {
      genAi?: boolean;
      vaAuthUrl?: string;
      pollingInterval?: number;
      vaMessageUrl?: string;
      token?: string;
      authOptions?: {
        client_id: string;
        grant_type: string;
        client_secret: string;
        refresh_token: string;
      };
    };
    appKey: string;
    masterSkill?: { __typename?: 'skill'; name: string; provider: string };
    mainAssistant?: { __typename?: 'mainAssistant'; name: string; assistantId: string };
    webhook?: { __typename?: 'webhook'; alias: string; requestOptions: AxiosRequestConfig };
    channel?: {
      __typename?: 'channel';
      provider: string;
      debug: boolean;
      isSwagFormat: boolean;
      allowedEvents: string[];
      inputMasking: boolean;
      renderers: {
        __typename?: 'renderer';
        source: string;
        typeButtons?: string;
        typeImage?: string;
        typeText?: string;
      }[];
      connection: { __typename?: 'channelkv'; key: string; value: string }[];
    };
    assistants?: {
      name: string;
      assistantId: string;
      draftEnvironmentId: string;
      apiKey: string;
      serviceUrl: string;
    }[];
    cpsInstance?: {
      name: string;
      secretKey: string;
      timeout: number;
      pollingInterval?: number;
      errorMessage?: string | undefined;
    };
  }[];
  __typename?: 'bot';
  language: string;
  name: string;
  tags: string[];
  active: boolean;
  botId: string;
  superKey: string;
  conversationTtlSeconds: number;
  tenant?: { __typename?: 'tenant'; name: string };
};

export type header = {
  defaultpreintent: string;
};

export type BotEnvironment = ArrayElement<BotConfig['environments']> &
  Pick<BotConfig, 'botId' | 'conversationTtlSeconds'>;
