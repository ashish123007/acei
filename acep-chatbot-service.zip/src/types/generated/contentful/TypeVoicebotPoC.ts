import * as Contentful from 'contentful';
import { TypeBotResponse2Fields } from './TypeBotResponse2';
import { TypeConfimationFields } from './TypeConfimation';
import { TypeGoodToKnowFields } from './TypeGoodToKnow';
import { TypeHowToAnswerFields } from './TypeHowToAnswer';
import { TypeInstructionalAnswerFields } from './TypeInstructionalAnswer';
import { TypePreHandoverFields } from './TypePreHandover';
import { TypeQuestionFields } from './TypeQuestion';
import { TypeResponseFields } from './TypeResponse';
import { TypeUntypedResponseFields } from './TypeUntypedResponse';

export interface TypeVoicebotPoCFields {
  title: Contentful.EntryFields.Symbol;
  voicebot: 'CB' | 'Retail' | 'TestBot';
  skill:
    | 'Beleggen'
    | 'Betaalpas'
    | 'Betaalrekening'
    | 'Diversen'
    | 'Grey intents'
    | 'Hypotheken'
    | 'Leningen'
    | 'Masterflow'
    | 'Overboekingen'
    | 'Overzichten'
    | 'Transacties'
    | 'Verzekeringen'
    | 'testSkill';
  intent: Contentful.EntryFields.Symbol;
  responses: Contentful.Entry<
    | TypeBotResponse2Fields
    | TypeConfimationFields
    | TypeGoodToKnowFields
    | TypeHowToAnswerFields
    | TypeInstructionalAnswerFields
    | TypePreHandoverFields
    | TypeQuestionFields
    | TypeResponseFields
    | TypeUntypedResponseFields
  >[];
  audioFile?: Contentful.Asset;
}

export type TypeVoicebotPoC = Contentful.Entry<TypeVoicebotPoCFields>;
