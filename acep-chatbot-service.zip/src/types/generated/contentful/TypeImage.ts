import * as Contentful from 'contentful';

export interface TypeImageFields {
  name?: Contentful.EntryFields.Symbol;
  source?: Contentful.EntryFields.Symbol;
  altText?: Contentful.EntryFields.Symbol;
}

export type TypeImage = Contentful.Entry<TypeImageFields>;
