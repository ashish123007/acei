import * as Contentful from 'contentful';

export interface TypeBotResponseButtonFields {
  title?: Contentful.EntryFields.Symbol;
  buttonText: Contentful.EntryFields.Symbol;
  genericLevel?: 'Chat only';
  payload?: Contentful.EntryFields.Object;
}

export type TypeBotResponseButton = Contentful.Entry<TypeBotResponseButtonFields>;
