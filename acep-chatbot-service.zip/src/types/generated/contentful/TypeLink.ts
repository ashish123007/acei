import * as Contentful from 'contentful';

export interface TypeLinkFields {
  name?: Contentful.EntryFields.Symbol;
  linkText?: Contentful.EntryFields.Symbol;
  linkUrl?: Contentful.EntryFields.Symbol;
  external?: Contentful.EntryFields.Boolean;
}

export type TypeLink = Contentful.Entry<TypeLinkFields>;
