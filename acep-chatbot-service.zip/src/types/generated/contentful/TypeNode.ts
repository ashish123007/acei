import * as Contentful from 'contentful';
import { TypeBotResponse2Fields } from './TypeBotResponse2';
import { TypeBotResponseButtonFields } from './TypeBotResponseButton';
import { TypeConfimationFields } from './TypeConfimation';
import { TypeEventFields } from './TypeEvent';
import { TypeGoodToKnowFields } from './TypeGoodToKnow';
import { TypeInstructionalAnswerFields } from './TypeInstructionalAnswer';
import { TypePreHandoverFields } from './TypePreHandover';
import { TypeQuestionFields } from './TypeQuestion';
import { TypeResponseFields } from './TypeResponse';
import { TypeUntypedResponseFields } from './TypeUntypedResponse';

export interface TypeNodeFields {
  title?: Contentful.EntryFields.Symbol;
  chatbot?: 'Agent Assist' | 'CB' | 'Retail' | 'TestBot';
  skill?:
    | 'AA Masterflow'
    | 'AA OT'
    | 'AA Overige'
    | 'AA Pashandelingen'
    | 'Beleggen'
    | 'Betaalpas'
    | 'Betaalrekening'
    | 'ChitChat'
    | 'Diversen'
    | 'GenesysTestBot'
    | 'GreyIntents'
    | 'Hypotheken'
    | 'Kredieten'
    | 'Leningen'
    | 'Masterflow'
    | 'Overboekingen'
    | 'Overzichten'
    | 'ProActive'
    | 'ProActiveHercules'
    | 'Services'
    | 'Transacties'
    | 'Verzekeringen';
  intent?: Contentful.EntryFields.Symbol;
  responses?: Contentful.Entry<
    | TypeBotResponse2Fields
    | TypeConfimationFields
    | TypeGoodToKnowFields
    | TypeInstructionalAnswerFields
    | TypePreHandoverFields
    | TypeQuestionFields
    | TypeResponseFields
    | TypeUntypedResponseFields
  >[];
  options?: Contentful.Entry<TypeBotResponseButtonFields>[];
  event?: Contentful.Entry<TypeEventFields>[];
  nodeId?: Contentful.EntryFields.Symbol;
}

export type TypeNode = Contentful.Entry<TypeNodeFields>;
