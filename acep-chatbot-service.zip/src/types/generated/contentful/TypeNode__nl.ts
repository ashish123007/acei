import * as Contentful from 'contentful';
import { TypeBotResponse2Fields } from './TypeBotResponse2';
import { TypeConfimationFields } from './TypeConfimation';
import { TypeGoodToKnowFields } from './TypeGoodToKnow';
import { TypeHowToAnswerFields } from './TypeHowToAnswer';
import { TypeInstructionalAnswerFields } from './TypeInstructionalAnswer';
import { TypeNodeFields } from './TypeNode';
import { TypePreHandoverFields } from './TypePreHandover';
import { TypeQuestionFields } from './TypeQuestion';
import { TypeResponseFields } from './TypeResponse';
import { TypeSsmlTagFields } from './TypeSsmlTag';
import { TypeUntypedResponseFields } from './TypeUntypedResponse';

export interface TypeNode__nlFields {
  title?: Contentful.EntryFields.Symbol;
  voicebot?: 'CB' | 'Retail';
  skill?:
    | 'Beleggen'
    | 'Betaalpas'
    | 'Betaalrekening'
    | 'Diversen'
    | 'Grey intents'
    | 'Hypotheken'
    | 'Leningen'
    | 'Masterflow'
    | 'Overboekingen'
    | 'Overzichten'
    | 'Transacties'
    | 'Verzekeringen';
  intentString?: Contentful.EntryFields.Symbol;
  responses?: Contentful.Entry<
    | TypeBotResponse2Fields
    | TypeConfimationFields
    | TypeGoodToKnowFields
    | TypeHowToAnswerFields
    | TypeInstructionalAnswerFields
    | TypePreHandoverFields
    | TypeQuestionFields
    | TypeResponseFields
    | TypeUntypedResponseFields
  >[];
  voiceRendering?: Contentful.Asset;
  noMatchnoInputResponses?: Contentful.Entry<
    | TypeBotResponse2Fields
    | TypeConfimationFields
    | TypeGoodToKnowFields
    | TypeHowToAnswerFields
    | TypeInstructionalAnswerFields
    | TypePreHandoverFields
    | TypeQuestionFields
    | TypeResponseFields
    | TypeUntypedResponseFields
  >[];
  noMatchnoInputResponses2nd?: Contentful.Entry<
    | TypeBotResponse2Fields
    | TypeConfimationFields
    | TypeGoodToKnowFields
    | TypeHowToAnswerFields
    | TypeInstructionalAnswerFields
    | TypePreHandoverFields
    | TypeQuestionFields
    | TypeResponseFields
    | TypeSsmlTagFields
  >[];
  repeat?: Contentful.Entry<
    | TypeBotResponse2Fields
    | TypeConfimationFields
    | TypeGoodToKnowFields
    | TypeHowToAnswerFields
    | TypeInstructionalAnswerFields
    | TypePreHandoverFields
    | TypeQuestionFields
    | TypeResponseFields
    | TypeSsmlTagFields
  >[];
  variants?: Contentful.Entry<TypeNodeFields>[];
}

export type TypeNode__nl = Contentful.Entry<TypeNode__nlFields>;
