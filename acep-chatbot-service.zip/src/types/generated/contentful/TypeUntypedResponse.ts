import * as CFRichTextTypes from '@contentful/rich-text-types';
import * as Contentful from 'contentful';
import { TypeImageFields } from './TypeImage';
import { TypeLinkFields } from './TypeLink';

export interface TypeUntypedResponseFields {
  title?: Contentful.EntryFields.Symbol;
  type:
    | 'Confirmation'
    | 'Good to know'
    | 'How to answer'
    | 'How to help'
    | 'Informational answer'
    | 'Instructional answer'
    | 'Pre-handover'
    | 'Question';
  answerText: CFRichTextTypes.Block | CFRichTextTypes.Inline;
  images?: Contentful.Entry<TypeImageFields>;
  link?: Contentful.Entry<TypeLinkFields>;
  attributes?: Contentful.EntryFields.Object;
}

export type TypeUntypedResponse = Contentful.Entry<TypeUntypedResponseFields>;
