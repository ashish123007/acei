import * as Contentful from 'contentful';

export interface TypeResponseTypeFields {
  name?: Contentful.EntryFields.Symbol;
  description?: Contentful.EntryFields.Symbol;
  category?: 'Conversational answer' | 'Conversational routing' | 'Conversational talk';
}

export type TypeResponseType = Contentful.Entry<TypeResponseTypeFields>;
