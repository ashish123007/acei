import * as Contentful from 'contentful';

export interface TypeEventFields {
  name:
    | 'changePlaceholderText'
    | 'disableInputField'
    | 'enableStepBack'
    | 'getCookie'
    | 'inputValidation'
    | 'instantNavigation'
    | 'liveAgentTransfer'
    | 'overwriteWaitingMessage'
    | 'polling'
    | 'privateInput'
    | 'setSessionStorage'
    | 'instantVideoCard'
    | 'changePlaceholderText'
    | 'prevInputAckId';
  title?: Contentful.EntryFields.Symbol;
  eventAttributes?: Contentful.EntryFields.Object;
}

export type TypeEvent = Contentful.Entry<TypeEventFields>;
