import * as Contentful from 'contentful';

export interface TypeMessageAttributesFields {
  attributes?: Contentful.EntryFields.Object;
  title?: Contentful.EntryFields.Symbol;
}

export type TypeMessageAttributes = Contentful.Entry<TypeMessageAttributesFields>;
