import * as CFRichTextTypes from '@contentful/rich-text-types';
import * as Contentful from 'contentful';
import { TypeImageFields } from './TypeImage';
import { TypeLinkFields } from './TypeLink';

export interface TypeHowToAnswerFields {
  title?: Contentful.EntryFields.Symbol;
  answerText: CFRichTextTypes.Block | CFRichTextTypes.Inline;
  genericLevel?: 'Chat only' | 'Voice and chat' | 'Voice only';
  attributes?: Contentful.EntryFields.Object;
  images?: Contentful.Entry<TypeImageFields>;
  link?: Contentful.Entry<TypeLinkFields>;
}

export type TypeHowToAnswer = Contentful.Entry<TypeHowToAnswerFields>;
