import * as Contentful from 'contentful';

export interface TypeAssetFields {
  name: Contentful.EntryFields.Symbol;
  description?: Contentful.EntryFields.Text;
  asset: Contentful.Asset;
}

export type TypeAsset = Contentful.Entry<TypeAssetFields>;
