import * as CFRichTextTypes from '@contentful/rich-text-types';
import * as Contentful from 'contentful';
import { TypeImageFields } from './TypeImage';
import { TypeLinkFields } from './TypeLink';

export interface TypePreHandoverFields {
  title?: Contentful.EntryFields.Symbol;
  answerText?: CFRichTextTypes.Block | CFRichTextTypes.Inline;
  genericLevel?: 'Chat only' | 'Voice and chat' | 'Voice only';
  link?: Contentful.Entry<TypeLinkFields>;
  images?: Contentful.Entry<TypeImageFields>;
  attributes?: Contentful.EntryFields.Object;
}

export type TypePreHandover = Contentful.Entry<TypePreHandoverFields>;
