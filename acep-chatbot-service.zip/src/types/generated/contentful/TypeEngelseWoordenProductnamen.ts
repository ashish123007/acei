import * as CFRichTextTypes from '@contentful/rich-text-types';
import * as Contentful from 'contentful';

export interface TypeEngelseWoordenProductnamenFields {
  title?: Contentful.EntryFields.Symbol;
  phoneticSpelling: CFRichTextTypes.Block | CFRichTextTypes.Inline;
}

export type TypeEngelseWoordenProductnamen = Contentful.Entry<TypeEngelseWoordenProductnamenFields>;
