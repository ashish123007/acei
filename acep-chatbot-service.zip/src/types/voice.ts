import { BotEnvironment } from './bot';
import { z } from 'nestjs-zod/z';
import { createZodDto } from 'nestjs-zod';
import { DtmfValues } from './copilotApi.model';

export interface ContentfulVoiceAnswer {
  type: 'staticPrompt';
  promptUrl: string;
}

export interface ContentfulSsmlAnswer {
  type: 'ssmlPart';
  ssml: string;
}

export enum VoiceRequestUserType {
  DTMF = 'dtmf',
  SPEECH = 'speech',
  NONE = 'none',
}

export interface dtmfOptions {
  interToneTimeoutInSeconds: number;
  maxTonesToCollect: number;
  stopTones: string[];
}

export interface VoiceBotResponse {
  requestTypeFromUser: VoiceRequestUserType;
  bargeIn: boolean;
  handoverCode?: string;
  handoverText?: string;
  type: 'ssml' | 'staticAudioLink' | 'none';
  payload: string;
  dtmfOptions?: dtmfOptions;
}

export interface ACSTargetParticipant {
  kind: 'phoneNumber';
  phoneNumber: { value: string };
}

export enum MicrosoftAcsEventType {
  SubscriptionValidationEvent = 'Microsoft.EventGrid.SubscriptionValidationEvent',
  IncomingCall = 'Microsoft.Communication.IncomingCall',
  CallConnected = 'Microsoft.Communication.CallConnected',
  CallDisconnected = 'Microsoft.Communication.CallDisconnected',
  RecognizeCompleted = 'Microsoft.Communication.RecognizeCompleted',
  PlayCompleted = 'Microsoft.Communication.PlayCompleted',
  PlayFailed = 'Microsoft.Communication.PlayFailed',
  RecognizeFailed = 'Microsoft.Communication.RecognizeFailed',
}

const AcsValidationEvent = z.object({
  eventType: z.literal(MicrosoftAcsEventType.SubscriptionValidationEvent),
  data: z.object({
    validationCode: z.string(),
  }),
});

interface AcsEventGeneric {
  eventType: MicrosoftAcsEventType;
  data: unknown;
}
interface AcsDataCommunicationEventGeneric {
  serverCallId: string;
  callConnectionId: string;
  correlationId: string;
  operationContext: string;
}

const AcsIncomingCallEvent = z.object({
  eventType: z.literal(MicrosoftAcsEventType.IncomingCall),
  data: z.object({
    incomingCallContext: z.string(),
    customContext: z
      .object({
        sipHeaders: z.any().optional(),
      })
      .optional(),
    from: z.any(),
  }),
});

const eventType = z.array(z.union([AcsValidationEvent, AcsIncomingCallEvent]));

export class acsEvenDto extends createZodDto(eventType) {}

interface AcsCallbackGeneric {
  type: MicrosoftAcsEventType;
  data: unknown;
}

interface AcsCallConnectedEvent extends AcsCallbackGeneric {
  type: MicrosoftAcsEventType.CallConnected;
  data: AcsDataCommunicationEventGeneric;
}
interface AcsCallDisconnectedEvent extends AcsCallbackGeneric {
  type: MicrosoftAcsEventType.CallDisconnected;
  data: AcsDataCommunicationEventGeneric;
}

interface AcsPlayCompletedEvent extends AcsCallbackGeneric {
  type: MicrosoftAcsEventType.PlayCompleted;
  data: AcsDataCommunicationEventGeneric;
}

interface AcsRecognizeFailedEvent extends AcsCallbackGeneric {
  type: MicrosoftAcsEventType.RecognizeFailed;
  data: AcsDataCommunicationEventGeneric & {
    resultInformation: {
      code: number;
      subCode: number;
      message: string;
    };
  };
}

interface AcsPlayFailedEvent extends AcsCallbackGeneric {
  type: MicrosoftAcsEventType.PlayFailed;
  data: AcsDataCommunicationEventGeneric;
}

interface AcsRecognitionDTMFSuccess {
  recognitionType: 'dtmf';
  dtmfResult: { tones: string[] };
}

interface AcsRecognitionSpeechSuccess {
  recognitionType: 'speech';
  speechResult: { speech: string };
}

interface AcsRecognizeCompletedEvent extends AcsCallbackGeneric {
  type: MicrosoftAcsEventType.RecognizeCompleted;
  data: (AcsRecognitionDTMFSuccess | AcsRecognitionSpeechSuccess) & AcsDataCommunicationEventGeneric;
}

export type AcsCallbacks =
  | AcsCallConnectedEvent
  | AcsRecognizeCompletedEvent
  | AcsPlayCompletedEvent
  | AcsRecognizeFailedEvent
  | AcsPlayFailedEvent
  | AcsCallDisconnectedEvent;

export interface AcsPlayDataSsml {
  kind: 'ssml';
  ssml: {
    ssmlText: string;
  };
}

export interface AcsPlayDataStatic {
  kind: 'file';
  playSourceCacheId?: string;
  file: {
    uri: string;
  };
}

export type AcsPlayData = AcsPlayDataSsml | AcsPlayDataStatic;

export interface VoiceOrchestratorParams {
  env: BotEnvironment;
  conversationId: string;
  callConnectionId: string;
  target: ACSTargetParticipant;
  voiceName: string;
  speechLanguage: string;
  contactId: string;
  preIntent: string | null;
  sipHeaders?: { [key: string]: string };
}

export interface AcsRecognizeParameters {
  targetParticipantInfo: ACSTargetParticipant;
  requestType: VoiceRequestUserType;
  bargeInEnabled: boolean;
  speechLanguage?: string;
  playPrompt?: AcsPlayData;
  operationContext?: string;
  dtmfOptions?: DtmfValues;
}

export interface HandoverParams {
  code: string;
  handText: string;
  callConnectionId: string;
  conversationId: string;
  contactId: string;
}

export interface CallbacksQsParams {
  sourceFromData?: ACSTargetParticipant;
  conversationId?: string;
  contactId?: string;
  preIntent?: string | null;
  sipHeaders?: { [key: string]: string };
}

export interface sipHeaders {
  languagePreference: string;
}
