const processVars = process.env;

const PRE_PROD_CERT_PATH = '../../certs/pre-prod.truststore.pem';
const PROD_CERT_PATH = '../../certs/truststore.pem';

export const config = {
  FEATURE_FLAGS: processVars.FEATURE_FLAGS || '',
  ALB_PATH: processVars.ALB_PATH || 'message-hub',
  PORT: processVars.PORT || 8080,
  TEST: processVars.TEST === 'true',
  LOG_LEVEL: processVars.LOG_LEVEL || 'info',
  ENVIRONMENT: processVars.ENVIRONMENT || 'local',
  BOTSTUDIO_BASE_URL: processVars.BOTSTUDIO_BASE_URL,
  OVERWRITE_ANNA_SERVICES_LOCAL: processVars.OVERWRITE_ANNA_SERVICES_LOCAL || false,
  BOTSTUDIO_SECRET_KEY: processVars.BOTSTUDIO_SECRET_KEY,
  SESSION_TABLE: processVars.SESSION_TABLE || 'SESSION_TABLE',
  IVR_CALL_QUEUE_NAME: processVars.IVR_CALL_QUEUE_NAME || '',
  MSD_QUEUE_NAME: processVars.MSD_QUEUE_NAME || '',
  ACS_CONNECTION_STRING: processVars.ACS_CONNECTION_STRING || '',
  ACS_API_VERSION: processVars.ACS_API_VERSION || '2024-04-15',
  ACS_URL: processVars.ACS_URL || '',
  CHATBOT_PUBLIC_ENDPOINT: processVars.CHATBOT_PUBLIC_ENDPOINT || '',
  ACS_COGNITIVE_SERVICE_URL:
    processVars.ACS_COGNITIVE_SERVICE_URL || 'https://test-acs-cs.cognitiveservices.azure.com/',
  ACS_AUDIENCE: processVars.ACS_AUDIENCE || 'f76dd051-a579-40b8-bbc6-f5724adc8dc4',
  APPINSIGHTS_CONNECTION_STRING: processVars.APPINSIGHTS_CONNECTION_STRING || '',
  SERVICEBUS_NAMESPACE: processVars.SERVICEBUS_NAMESPACE || 'acep-d-servicebus.servicebus.windows.net',
  REDIS_URL: processVars.REDIS_URL,
  REDIS_SECRET_KEY: processVars.REDIS_SECRET_KEY,
  workspaceId: processVars.WORKSPACE_ID || '',
  primarySharedKey: processVars.PRIMARY_SHARED_KEY || '',
  databaseOpts: {
    endpoint: processVars.DATABASE_ENDPOINT || 'https://cosmosdb-emulator.local:8081',
    key: processVars.DATABASE_KEY,
    name: processVars.DATABASE_NAME || '',
  },
  contentful: {
    space: processVars.CONTENTFUL_SPACE || 'riy4ayq9brzz',
    environment: processVars.CONTENTFUL_ENV || 'master',
    accessToken: processVars.CONTENTFUL_TOKEN_SECRET_KEY || '',
  },
  contentfulPreview: {
    space: processVars.CONTENTFUL_SPACE || 'riy4ayq9brzz',
    environment: processVars.CONTENTFUL_ENV || 'master',
    accessToken: processVars.CONTENTFUL_PREVIEW_TOKEN_SECRET_KEY || '',
    host: 'preview.contentful.com',
  },
  contentfulPreviewEnvironments: ['local', 'dev', 'test'],
  vaLocalConfig: {
    authUrl: 'https://aabsiamdemo.service-now.com/oauth_token.do',
    messageUrl: 'https://aabsiamdemo.service-now.com/api/sn_va_as_service/bot/integration',
    token: '7e3b368b-166b-4e7c-ad7f-cfba221c3b39',
    authOptions: {
      grant_type: 'refresh_token',
      client_id: '5770f9840848a8503ae7ec9fa514ac3c',
      client_secret: 'Q1v-5I4.sM',
      refresh_token: 'xh3kqJaM8lBd7GJCbTBgTCNWx4hKW6T0oEA0dYlVrF_gzuW8aI72MQ7tYo_P4Yp96gQP4CYd0MxLG17xTp2UcQ',
    },
  },
  iagApi: {
    localSanValue: processVars.IAG_SAN_VALUE || '',
    endpoint: processVars.IAG_ENDPOINT || 'http://api-st-iag.nl.eu.abnamro.com',
  },
  niceApi: {
    authBodyUsername: processVars.NICE_API_AUTH_BODY_USERNAME || '',
    authBodyPassword: processVars.NICE_API_AUTH_BODY_PASSWORD || '',
    authHeader: processVars.NICE_API_AUTH_HEADER || '',
  },
  copilotApi: {
    url: processVars.COPILOT_URL || 'https://europe.directline.botframework.com/v3/directline',
    copilotUser: processVars.COPILOT_USER || 'CAI-Platform',
  },
  IAG_CERT_KV_NAME: processVars.IAG_CERT_KV_NAME || '',
  AZURE_KEYVAULT_URL: processVars.AZURE_KEYVAULT_URL || '',
  TRUST_STORE_PATH: processVars.ENVIRONMENT === 'Production' ? PROD_CERT_PATH : PRE_PROD_CERT_PATH,
};

export default config;
