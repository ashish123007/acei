import _ from 'lodash';
import mask from './masking';

/**
 * @method updateMaskedInput
 * @description Function to mask numbers and email addresses in the text, with some non-masking
 * exceptions like MT940, CAMT053 and CAMT.053.
 * @returns masked text
 */
const updateMaskedInput = (text: string) => {
  const maskedText = mask(
    text,
    [
      (word) => {
        const numberRegex = /\d+/g;
        const cesRegex = /^([0-9]|10)([.!?,;:]+)?$/g;
        const yearRegex = /(?:(?:^(19|20)[0-9]{2})|2100)([.!?,;:]+)?$/gm;
        const exceptionWords = word.match('MT940') || word.match('CAMT053') || word.match('CAMT.053');
        const hasNumbers = numberRegex.test(word);
        const numbers = hasNumbers ? word.match(numberRegex) : null;
        const hasErrorMessageCode = word.toLowerCase().includes('message_') || word.toLowerCase().includes('msg_');
        const hasYears = yearRegex.test(word);
        const hasCes = cesRegex.test(word);
        if (exceptionWords || hasCes || hasYears || hasErrorMessageCode) {
          return false;
        }
        if (numbers !== null) {
          return hasNumbers;
        }
        return false;
      },
      'numericInput',
    ],
    [(word: string) => word.indexOf('@') > -1, '[@monkeyTail]']
  );
  return maskedText;
};

export default updateMaskedInput;
