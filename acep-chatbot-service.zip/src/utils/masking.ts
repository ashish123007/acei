import _ from 'lodash';
import { MaskFn } from '../types';

function mask(utterance: string, ...masks: [MaskFn, string][]) {
  return _.chain(utterance)
    .split(' ')
    .filter((word) => !_.isEmpty(word))
    .map((word) => {
      const firstMask = _.chain(masks)
        .map((maskPair) => {
          const [maskFn, replaceStr] = maskPair;
          const maskTestFn = _.isRegExp(maskFn) ? (text: string) => maskFn.test(text) : maskFn;
          const isMasked = maskTestFn(word);
          return {
            word: isMasked ? replaceStr : word,
            isMasked,
          };
        })
        .find('isMasked')
        .value();
      return _.get(firstMask, 'word', word);
    })
    .join(' ')
    .value();
}

export default mask;
