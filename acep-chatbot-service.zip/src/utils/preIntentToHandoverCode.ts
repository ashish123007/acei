import { VoiceConstants } from '../constants/voice';

const { DEFAULT_HANDOVER_CODE, BBCB_HANDOVER_CODE, HYPL_HANDOVER_CODE, ONET_HANDOVER_CODE } = VoiceConstants;

const handoverCodeMap: { [key: string]: string } = {
  [DEFAULT_HANDOVER_CODE]: DEFAULT_HANDOVER_CODE,
  [HYPL_HANDOVER_CODE]: HYPL_HANDOVER_CODE,
  [BBCB_HANDOVER_CODE]: ONET_HANDOVER_CODE,
};

const preIntentToHandoverCode = (preIntent: string): string => {
  return handoverCodeMap[preIntent] || DEFAULT_HANDOVER_CODE;
};

export default preIntentToHandoverCode;
