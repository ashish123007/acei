import { Test, TestingModule } from '@nestjs/testing';
import { HttpService } from '@nestjs/axios';
import { of, throwError } from 'rxjs';
import { ConfigurationService } from './configuration.service';
import config from '../config';
import { BotConfig } from '../types/bot';
import { AxiosRequestConfig } from 'axios';

jest.mock('../config', () => ({
  ENVIRONMENT: 'test',
  BOTSTUDIO_BASE_URL: 'http://mock-base-url',
  BOTSTUDIO_SECRET_KEY: 'mock-secret-key',
}));

const mockAxiosRequestConfig: AxiosRequestConfig = {
  url: 'https://example.com',
  method: 'GET',
};

const mockBotConfig: BotConfig = {
  environments: [
    {
      admins: [{ __typename: 'user', email: 'admin@example.com' }],
      viewers: [{ __typename: 'user', email: 'viewer@example.com' }],
      editors: [{ __typename: 'user', email: 'editor@example.com' }],
      logs: [
        {
          __typename: 'log',
          provider: 'logProvider',
          connection: [{ __typename: 'logkv', key: 'logKey', value: 'logValue' }],
        },
      ],
      posthooks: [{ __typename: 'webhook', alias: 'posthookAlias', requestOptions: mockAxiosRequestConfig }],
      prehooks: [{ __typename: 'webhook', alias: 'prehookAlias', requestOptions: mockAxiosRequestConfig }],
      skills: [
        {
          apiKey: 'skillApiKey',
          __typename: 'skill',
          name: 'Skill Name',
          provider: 'Skill Provider',
          skillId: 'skillId',
        },
      ],
      __typename: 'environment',
      name: 'Environment Name',
      meta: {
        genAi: true,
        vaAuthUrl: 'https://auth.example.com',
        vaMessageUrl: 'https://message.example.com',
        token: 'someToken',
        authOptions: {
          client_id: 'clientId',
          grant_type: 'refresh_token',
          client_secret: 'clientSecret',
          refresh_token: 'refreshToken',
        },
      },
      appKey: 'AppKey',
      masterSkill: { __typename: 'skill', name: 'Master Skill', provider: 'Skill Provider' },
      mainAssistant: { __typename: 'mainAssistant', name: 'Main Assistant', assistantId: 'assistantId' },
      webhook: { __typename: 'webhook', alias: 'webhookAlias', requestOptions: mockAxiosRequestConfig },
      channel: {
        __typename: 'channel',
        provider: 'Channel Provider',
        debug: true,
        isSwagFormat: true,
        allowedEvents: ['event1', 'event2'],
        inputMasking: true,
        renderers: [
          {
            __typename: 'renderer',
            source: 'Renderer Source',
            typeButtons: 'buttonType',
            typeImage: 'imageType',
            typeText: 'textType',
          },
        ],
        connection: [{ __typename: 'channelkv', key: 'channelKey', value: 'channelValue' }],
      },
      assistants: [
        {
          name: 'Assistant Name',
          assistantId: 'assistantId',
          draftEnvironmentId: 'draftEnvId',
          apiKey: 'assistantApiKey',
          serviceUrl: 'https://service.example.com',
        },
      ],
      cpsInstance: {
        name: 'CPS Instance Name',
        secretKey: 'SecretKey',
        timeout: 1000,
      },
    },
  ],
  __typename: 'bot',
  language: 'en',
  name: 'Bot Name',
  tags: ['tag1', 'tag2'],
  active: true,
  botId: 'botId',
  superKey: 'superKey',
  conversationTtlSeconds: 3600,
  tenant: { __typename: 'tenant', name: 'Tenant Name' },
};

describe('ConfigurationService', () => {
  let service: ConfigurationService;
  let httpService: HttpService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ConfigurationService,
        {
          provide: HttpService,
          useValue: {
            get: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<ConfigurationService>(ConfigurationService);
    httpService = module.get<HttpService>(HttpService);
  });

  describe('getConfig', () => {
    it('should return bots configuration when the request is successful', async () => {
      const mockBots: BotConfig = mockBotConfig;
      const mockResponse = { data: { bots: mockBots } };
      (httpService.get as jest.Mock).mockReturnValue(of(mockResponse));

      const result = await service.getConfig();

      expect(httpService.get).toHaveBeenCalledWith(`${config.BOTSTUDIO_BASE_URL}/config/`, {
        headers: {
          'x-api-secret': config.BOTSTUDIO_SECRET_KEY,
          'Content-Type': 'application/json',
        },
      });
      expect(result).toEqual({ bots: mockBots });
    });

    it('should throw an error if the request fails', async () => {
      const errorMessage = 'Network Error';
      (httpService.get as jest.Mock).mockReturnValue(throwError(() => new Error(errorMessage)));

      await expect(service.getConfig()).rejects.toThrow(`Failed to fetch configuration: ${errorMessage}`);
    });
  });
});
