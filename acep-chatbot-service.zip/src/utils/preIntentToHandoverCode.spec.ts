import preIntentToHandoverCode from './preIntentToHandoverCode';
import { VoiceConstants } from '../constants/voice';

const { DEFAULT_HANDOVER_CODE, BBCB_HANDOVER_CODE, HYPL_HANDOVER_CODE, ONET_HANDOVER_CODE } = VoiceConstants;

describe('preIntentToHandoverCode', () => {
  it('should return the correct handover code according to its mapping', () => {
    expect(preIntentToHandoverCode('test')).toBe(DEFAULT_HANDOVER_CODE);
    expect(preIntentToHandoverCode(DEFAULT_HANDOVER_CODE)).toBe(DEFAULT_HANDOVER_CODE);
    expect(preIntentToHandoverCode(HYPL_HANDOVER_CODE)).toBe(HYPL_HANDOVER_CODE);
    expect(preIntentToHandoverCode(BBCB_HANDOVER_CODE)).toBe(ONET_HANDOVER_CODE);
    expect(preIntentToHandoverCode('')).toBe(DEFAULT_HANDOVER_CODE);
  });
});
