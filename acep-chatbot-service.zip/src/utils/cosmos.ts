import { CosmosClient, Container, Item, PatchOperation } from '@azure/cosmos';
import { DefaultAzureCredential } from '@azure/identity';
import config from '../config';
import loggerUtils from './logger';
import constants from '../constants';
import { CosmosItem } from '../types';
import _ from 'lodash';

const { logger } = loggerUtils;
const { AZURE_SDK_SERVICE_TIMEOUT } = constants;
const { databaseOpts, ENVIRONMENT } = config;

const connectionPolicy = {
  requestTimeout: AZURE_SDK_SERVICE_TIMEOUT,
};
const clientOpts =
  ENVIRONMENT === 'local' || ENVIRONMENT === 'test'
    ? { endpoint: databaseOpts.endpoint, key: databaseOpts.key, connectionPolicy }
    : { endpoint: databaseOpts.endpoint, aadCredentials: new DefaultAzureCredential(), connectionPolicy };

const database = new CosmosClient(clientOpts).database(databaseOpts.name);

export class CosmosV2<T extends CosmosItem> {
  private container: Container;
  private item: Item;

  constructor(containerId: string, pk: string, partitionKey?: unknown) {
    this.container = database.container(containerId);
    this.item = this.container.item(pk, partitionKey);
  }

  async get() {
    logger.debug('Cosmos getting item');
    const { resource } = await this.item.read<T>();
    return resource;
  }

  async create(item: T) {
    logger.debug('Cosmos creating item %j', item);
    const { resource } = await this.container.items.create<T>(item);
    return resource;
  }

  async patch(operations: PatchOperation[]) {
    logger.debug('Cosmos patch item with %j', operations);
    try {
      await this.item.patch({
        operations,
      });
    } catch (err) {
      logger.error('Cosmos:: Unable to patch item with error %o', err);
    }
  }

  async update(item: T) {
    const initItem = await this.get();
    const newItem = { ...initItem, ...item };
    logger.debug('Making a Cosmos update: %j', newItem);
    const { resource } = await this.container.items.upsert<T>(newItem);
    return resource;
  }
}
