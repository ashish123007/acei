import { delay } from './delay';

describe('delay function', () => {
  beforeAll(() => {
    jest.useFakeTimers();
  });

  afterAll(() => {
    jest.useRealTimers();
  });

  it('should resolve after the specified delay', async () => {
    const ms = 1000;
    const promise = delay(ms);

    // Fast-forward until all timers have been executed
    jest.advanceTimersByTime(ms);

    await expect(promise).resolves.toBeUndefined();
  });

  it('should not resolve before the specified delay', async () => {
    const ms = 1000;
    const promise = delay(ms);

    let resolved = false;

    // Check if promise resolves before advancing the time
    promise.then(() => (resolved = true));

    // Fast-forward just before the specified delay
    jest.advanceTimersByTime(ms - 1);

    expect(resolved).toBe(false);

    // Now fast-forward to the exact delay time
    jest.advanceTimersByTime(1);

    await promise; // Ensure all pending promises are resolved
    expect(resolved).toBe(true);
  });
});
