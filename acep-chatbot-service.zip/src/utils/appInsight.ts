/* eslint-disable @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment, prefer-rest-params, @typescript-eslint/no-unsafe-return */
import * as appInsights from 'applicationinsights';
import config from '../config';
import loggerUtils from '../utils/logger';
const { logger } = loggerUtils;
const { APPINSIGHTS_CONNECTION_STRING, ENVIRONMENT } = config;

export function startAppInsight() {
  if (APPINSIGHTS_CONNECTION_STRING) {
    appInsights.setup(APPINSIGHTS_CONNECTION_STRING).setAutoCollectConsole(true, true);

    appInsights.defaultClient.context.tags[appInsights.defaultClient.context.keys.cloudRole] = 'chatbot-service';
    appInsights.start();
    logger.info('appinsight started');
  }
}

function trackDependencyAppInsight(name: string, duration: number, success: boolean) {
  if (ENVIRONMENT === 'local') {
    return;
  }
  const client = appInsights.defaultClient;
  client?.trackDependency({
    target: name,
    name: name,
    data: name,
    duration,
    resultCode: 0,
    success,
    dependencyTypeName: 'custom',
  });
}

export function trackCustomDepedency(name: string) {
  return (
    _target: any,
    _propertyKey: string,
    descriptor: TypedPropertyDescriptor<(...params: any[]) => Promise<any>>
  ) => {
    const oldFunc = descriptor.value;
    descriptor.value = async function () {
      const start = Date.now();

      try {
        const result = await oldFunc?.apply(this, arguments);
        trackDependencyAppInsight(name, Date.now() - start, true);
        return result;
      } catch (err) {
        trackDependencyAppInsight(name, Date.now() - start, false);
        throw err;
      }
    };
  };
}
