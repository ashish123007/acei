import { createClient } from 'redis';

jest.mock('redis');

let connect = jest.fn().mockResolvedValueOnce({});
let on = jest.fn();
let get = jest.fn();
let set = jest.fn();
let del = jest.fn();
let sendCommand = jest.fn();
let multi = jest.fn();

const createClientMock = createClient as jest.MockedFn<typeof createClient>;
createClientMock.mockReturnValueOnce({
  isReady: true,
  isOpen: true,
  connect,
  on,
  get,
  set,
  del,
  sendCommand,
  multi,
} as any);

import { contentfulRedisClient } from './redis';

describe('contentfulRedisClient', () => {
  beforeEach(() => {
    get.mockReset();
    set.mockReset();
    del.mockReset();
    sendCommand.mockReset();
    multi.mockReset();
  });

  it('should be able to getCache', async () => {
    await contentfulRedisClient.getCache('key');

    expect(get).toHaveBeenCalledWith('contentful::key');
  });

  it('should be able to setCache', async () => {
    await contentfulRedisClient.setCache('key', 'val');

    expect(set).toHaveBeenCalledWith('contentful::key', 'val', { EX: 259200 });
  });

  it('should be able to delCache', async () => {
    await contentfulRedisClient.delCache('key');

    expect(del).toHaveBeenCalledWith('contentful::key');
  });

  it('should be able to getCacheList', async () => {
    await contentfulRedisClient.getCacheList(['key1', 'key2']);

    expect(sendCommand).toHaveBeenCalledWith(['MGET', 'contentful::key1', 'contentful::key2']);
  });

  it('should be able to getCacheList', async () => {
    const multiSet = jest.fn();
    const multiExec = jest.fn();

    const multiObj = {
      set: multiSet,
      exec: multiExec,
    };

    multiSet.mockReturnValue(multiObj);
    multi.mockReturnValue(multiObj);

    await contentfulRedisClient.setCacheList([
      { id: 'key1', value: 'val1' },
      { id: 'key2', value: 'val2' },
    ]);

    expect(multiSet).toHaveBeenCalledTimes(2);
    expect(multiExec).toHaveBeenCalled();
  });
});
