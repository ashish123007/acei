import dtmfToNumber from './dtmfToNumber';

describe('dtmfToNumber', () => {
  it('should return the correct number for valid words', () => {
    expect(dtmfToNumber('zero')).toBe(0);
    expect(dtmfToNumber('four')).toBe(4);
    expect(dtmfToNumber('nine')).toBe(9);
  });

  it('should return word for invalid words', () => {
    expect(dtmfToNumber('ten')).toBe('ten');
    expect(dtmfToNumber('')).toBe('');
    expect(dtmfToNumber('invalid')).toBe('invalid');
  });

  it('should handle case insensitivity correctly', () => {
    expect(dtmfToNumber('ZERO')).toBe(0);
    expect(dtmfToNumber('TwO')).toBe(2);
  });
});
