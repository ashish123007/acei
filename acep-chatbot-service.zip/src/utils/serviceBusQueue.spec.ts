import { ServiceBusQueue } from './serviceBusQueue';

jest.mock('@azure/identity');
jest.mock('@azure/service-bus');

describe('servicebusQueue', () => {
  describe('subscribe', () => {
    it('should call receiver.subscribe when starting receiver', () => {
      const receiver = {
        subscribe: jest.fn(),
        close: jest.fn(),
      };
      const serviceBusClient = new ServiceBusQueue('', '');
      const createReceiver = jest.spyOn(serviceBusClient.sbClient, 'createReceiver');
      createReceiver.mockReturnValue(receiver as any);

      serviceBusClient.subscribe(
        async (body) => {},
        async () => {}
      );
      expect(receiver.subscribe).toHaveBeenCalled();
    });

    it('should trigger the callback when processMessage is called via the sdk', async () => {
      const serviceBusClient = new ServiceBusQueue('', '');
      const sbMessage = {
        body: 'hello world',
      };
      const onReceive = jest.fn();
      const receiver = {
        subscribe: jest.fn(),
        close: jest.fn(),
      };
      const createReceiver = jest.spyOn(serviceBusClient.sbClient, 'createReceiver');
      createReceiver.mockReturnValue(receiver as any);
      serviceBusClient.subscribe(onReceive, async () => {});
      const { processMessage } = receiver.subscribe.mock.calls[0][0];

      expect(onReceive).toHaveBeenCalledTimes(0);
      processMessage(sbMessage);
      expect(onReceive).toHaveBeenCalled();
      const [message] = onReceive.mock.calls[0];
      expect(message).toBe(sbMessage);
    });

    it('should be able to close connection', () => {
      const receiver = {
        subscribe: jest.fn(),
        close: jest.fn(),
      };
      const serviceBusClient = new ServiceBusQueue('', '');
      const createReceiver = jest.spyOn(serviceBusClient.sbClient, 'createReceiver');
      createReceiver.mockReturnValue(receiver as any);
      const r = serviceBusClient.subscribe(
        async () => {},
        async () => {}
      );
      r.close();
      expect(receiver.close).toHaveBeenCalled();
    });

    describe('sendProactiveMessage', () => {
      it('should call azure sdk: createMessageBatch and sendMessages', async () => {
        const serviceBusClient = new ServiceBusQueue('', '');
        const batch = {
          tryAddMessage: jest.fn().mockReturnValue(true),
        };
        const sender = {
          createMessageBatch: jest.fn().mockReturnValue(batch),
          sendMessages: jest.fn(),
          close: jest.fn(),
        } as any;
        serviceBusClient.sender = sender;

        await serviceBusClient.send({ id: '1' });
        expect(sender.createMessageBatch).toHaveBeenCalled();
        expect(batch.tryAddMessage).toHaveBeenCalled();
        expect(sender.sendMessages).toHaveBeenCalled();
      });
    });
    it('should twice tryAddMessage when there is 2 messages', async () => {
      const serviceBusClient = new ServiceBusQueue('', '');
      const batch = {
        tryAddMessage: jest.fn().mockReturnValue(true),
      };
      const sender = {
        createMessageBatch: jest.fn().mockReturnValue(batch),
        sendMessages: jest.fn(),
        close: jest.fn(),
      } as any;
      serviceBusClient.sender = sender;
      await serviceBusClient.sendBatch([{ id: '1' }, { id: '2' }]);

      expect(batch.tryAddMessage).toHaveBeenCalledTimes(2);
    });
  });
});
