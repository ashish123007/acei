import _ from 'lodash';
import rp, { AxiosRequestConfig } from 'axios';
import loggerUtils from './logger';
import constants from '../constants';
import config from '../config';
import * as https from 'https';

const { logger } = loggerUtils;
const { API_TIMEOUT } = constants;
const { ENVIRONMENT } = config;

export default async <T>(apiConfig: AxiosRequestConfig, postData = {}, kind = 'webhook') => {
  if (_.isEmpty(apiConfig)) {
    throw new Error(`${kind} not configured`);
  }
  const httpsAgent = new https.Agent({
    rejectUnauthorized: false,
  });
  const options: AxiosRequestConfig = {
    httpsAgent,
    method: 'post',
    timeout: API_TIMEOUT,
    data: postData,
    ...apiConfig,
  };
  if (ENVIRONMENT === 'local' && options.url && options.url.includes('http://acep-anna-services:80')) {
    options.url = options.url.replace('http://acep-anna-services:80', 'https://anna-service-ace03-a.nl.eu.abnamro.com');
  }
  logger.debug(`${kind} API is being called with options :: ${JSON.stringify(options)}`);
  const { data } = await rp.request<T>(options);
  return data;
};
