import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import config from '../config';
import { BotConfig } from '../types/bot';

const { BOTSTUDIO_BASE_URL, BOTSTUDIO_SECRET_KEY } = config;

@Injectable()
export class ConfigurationService {
  bots: BotConfig[];
  constructor(private readonly httpService: HttpService) {
    this.bots = [];
  }

  async getConfig(): Promise<{ bots: BotConfig[] }> {
    if (!BOTSTUDIO_BASE_URL) {
      console.error('missing BOTSTUDIO_BASE_URL');
      return {
        bots: [],
      };
    }
    if (BOTSTUDIO_BASE_URL && BOTSTUDIO_SECRET_KEY) {
      const options = {
        url: `${BOTSTUDIO_BASE_URL}/config/`,
        headers: {
          'x-api-secret': BOTSTUDIO_SECRET_KEY,
          'Content-Type': 'application/json',
        },
      };
      try {
        const { data } = await firstValueFrom(
          this.httpService.get<{ bots: BotConfig[] }>(options.url, {
            headers: options.headers,
          })
        );
        return data as { bots: BotConfig[] };
      } catch (error: unknown) {
        const message = error instanceof Error ? error.message : 'An unknown error occured.';
        throw new Error(`Failed to fetch configuration: ${message}`);
      }
    } else {
      throw new Error(
        'Configuration not defined. Either BOTSTUDIO_BASE_URL or BOTSTUDIO_SECRET_KEY is not set properly'
      );
    }
  }
}
