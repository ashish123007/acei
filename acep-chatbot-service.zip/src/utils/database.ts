import { CosmosClient, SqlQuerySpec, JSONObject } from '@azure/cosmos';
import { DefaultAzureCredential } from '@azure/identity';
import _ from 'lodash';
import config from '../config';
import loggerUtils from '../utils/logger';
import constants from '../constants';
import { CosmosItem } from '../types';

const { logger } = loggerUtils;
const { AZURE_SDK_SERVICE_TIMEOUT } = constants;
const { databaseOpts, ENVIRONMENT } = config;

const connectionPolicy = {
  requestTimeout: AZURE_SDK_SERVICE_TIMEOUT,
};
const clientOpts =
  ENVIRONMENT === 'local' || ENVIRONMENT === 'test'
    ? { endpoint: databaseOpts.endpoint, key: databaseOpts.key, connectionPolicy }
    : { endpoint: databaseOpts.endpoint, aadCredentials: new DefaultAzureCredential(), connectionPolicy };

const database = new CosmosClient(clientOpts).database(databaseOpts.name);

export class Cosmos<T extends CosmosItem> {
  items;

  constructor(
    private containerId: string,
    private defaultWhereClause?: Partial<T>,
    private ttl?: number
  ) {
    this.containerId = containerId;
    this.items = database.container(containerId).items;
    this.ttl = ttl;
    this.defaultWhereClause = defaultWhereClause;
  }

  async query(whereClause?: Partial<T>) {
    const parameters = _.merge(whereClause, this.defaultWhereClause) as JSONObject;
    const queryStringSuffix = Object.keys(parameters)
      .map((key) => `s.${key} = @${key}`)
      .join(' AND ');
    const querySpec = {
      query: `SELECT * FROM ${this.containerId} s WHERE ${queryStringSuffix}`,
      parameters: Object.entries(parameters).map(([key, value]) => ({ name: `@${key}`, value })),
    };
    logger.debug('Making a Cosmos query with spec: %j', querySpec);
    const { resources } = await this.items.query<T>(querySpec).fetchAll();
    logger.debug('Result of Cosmos query: %j', resources);
    return resources;
  }

  async queryRaw(querySpec: string | SqlQuerySpec) {
    const { resources } = await this.items.query<T>(querySpec).fetchAll();
    return resources;
  }

  async create(item: Omit<T, 'ttl'>) {
    const newItem = _.assign(item, { ttl: this.ttl }, this.defaultWhereClause) as T;
    logger.debug('Making a Cosmos create: %j', newItem);
    const { resource } = await this.items.create<T>(newItem);
    return resource;
  }

  async update(data: Partial<T>) {
    const initItem = await this.get();
    // const initItem = await this.get({ id: item.id } as Partial<T>)
    const newItem = _.assign({ ttl: this.ttl }, initItem, data, this.defaultWhereClause);
    logger.debug('Making a Cosmos update: %j', newItem);
    const { resource } = await this.items.upsert<T>(newItem);
    return resource;
  }

  async get(whereClause?: Partial<T>) {
    return this.query(whereClause).then((result) => result[0]);
  }
}
