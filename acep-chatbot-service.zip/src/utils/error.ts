import { v4 as uuidv4 } from 'uuid';
import { ChatbotError } from '../types';

const createError = (code: number, type: string, message: string): ChatbotError => ({
  code,
  type,
  message,
  id: uuidv4(),
});

export default createError;
