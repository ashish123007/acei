import { ProcessErrorArgs, ServiceBusClient, ServiceBusReceivedMessage } from '@azure/service-bus';
import { DefaultAzureCredential } from '@azure/identity';
import Long from 'long';
import loggerUtils from './logger';
import constants from '../constants';
import { ServBusScheduleId, Entity } from '../types/utils';

const { AZURE_SDK_SERVICE_TIMEOUT } = constants;
const { logger } = loggerUtils;

export class ServiceBusQueue<T extends Entity> {
  queueName;
  sbClient;
  sender;

  constructor(fullyQualifiedNamespace: string, queueName: string) {
    const credential = new DefaultAzureCredential();
    this.queueName = queueName;
    this.sbClient = new ServiceBusClient(fullyQualifiedNamespace, credential, {
      retryOptions: {
        timeoutInMs: AZURE_SDK_SERVICE_TIMEOUT,
        retryDelayInMs: 0,
      },
    });
    this.sender = this.sbClient.createSender(this.queueName);
  }

  async sendBatch(messages: T[]) {
    let batch = await this.sender.createMessageBatch();
    for (const message of messages) {
      const serviceBusMessage = {
        messageId: message.id,
        body: message,
      };

      // code from https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-nodejs-how-to-use-queues
      if (!batch.tryAddMessage(serviceBusMessage)) {
        await this.sender.sendMessages(batch);
        batch = await this.sender.createMessageBatch();
        if (!batch.tryAddMessage(serviceBusMessage)) {
          throw new Error('Message too big to fit in a batch');
        }
      }
    }
    await this.sender.sendMessages(batch);
  }

  async send(message: T) {
    return this.sendBatch([message]);
  }

  subscribe(
    processMessage: (message: Omit<ServiceBusReceivedMessage, 'body'> & { body: T }) => Promise<void>,
    processError: (args: ProcessErrorArgs) => Promise<void>
  ) {
    const receiver = this.sbClient.createReceiver(this.queueName);
    receiver.subscribe({
      processMessage,
      processError,
    });
    return receiver;
  }

  async sendScheduledMessages(messages: T[], scheduledEnqueueTimeUtc: Date) {
    logger.debug('sending scheduled message %j', messages);
    return await this.sender.scheduleMessages(
      messages.map((message) => ({ messageId: message.id, body: message })),
      scheduledEnqueueTimeUtc
    );
  }

  async cancelScheduledMessages(sequenceNumbers: ServBusScheduleId) {
    return await this.sender.cancelScheduledMessages(Long.fromString(sequenceNumbers));
  }

  close() {
    return this.sbClient.close();
  }
}

export class ServiceBusQueueLocal {
  sendBatch() {
    logger.warn('ServiceBusClient not usable locally, skipping sendBatch');
  }

  send() {
    logger.warn('ServiceBusClient not usable locally, skipping send');
  }

  subscribe() {
    logger.warn('ServiceBusClient not usable locally, skipping subscribe');
  }

  close() {
    logger.warn('ServiceBusClient not usable locally, skipping close');
  }
  sendScheduledMessages() {
    logger.warn('ServiceBusClient not usable locally, skipping sendScheduledMessages');
  }
}
