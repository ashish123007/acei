import { startAppInsight, trackCustomDepedency } from './appInsight';
import * as appInsights from 'applicationinsights';

jest.mock('applicationinsights');
const appInsightsMocked = appInsights as jest.Mocked<typeof appInsights>;

jest.mock('../config', () => ({
  APPINSIGHTS_CONNECTION_STRING: 'APPINSIGHTS_CONNECTION_STRING',
}));

it('should launch app insight', () => {
  appInsightsMocked.setup = jest.fn().mockReturnValue({
    setAutoCollectConsole: jest.fn(),
  });
  appInsightsMocked.defaultClient = {
    context: {
      tags: {},
      keys: {
        cloudRole: 'cloudRole',
      },
    },
  } as appInsights.TelemetryClient;
  startAppInsight();
});

describe('trackCustomDepedency', () => {
  let trackDependency: jest.Mock;

  beforeEach(() => {
    trackDependency = jest.fn();

    appInsightsMocked.defaultClient = {
      trackDependency,
    } as any;
  });

  it('should work on class', async () => {
    class Test {
      @trackCustomDepedency('dep1')
      async func1() {}
    }

    const t = new Test();
    await t.func1();

    expect(trackDependency).toHaveBeenCalledWith(
      expect.objectContaining({
        name: 'dep1',
        success: true,
      })
    );
  });

  it('should work on class and handle errors', async () => {
    class Test {
      @trackCustomDepedency('dep2')
      async func1() {
        throw new Error('some error');
      }
    }

    const t = new Test();

    await expect(t.func1()).rejects.toThrow('some error');

    expect(trackDependency).toHaveBeenCalledWith(
      expect.objectContaining({
        name: 'dep2',
        success: false,
      })
    );
  });
});
