import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom, catchError } from 'rxjs';
import { AxiosError } from 'axios';
import config from '../config';
import https from 'https';
import { IagHeaders, IagRequestConfig, JsonMap } from '../types/utils';
import loggerUtils from './logger';
import { DefaultAzureCredential } from '@azure/identity';
import { SecretClient } from '@azure/keyvault-secrets';
import forge from 'node-forge';
import fs from 'fs';
import path from 'path';

const { ENVIRONMENT, iagApi, AZURE_KEYVAULT_URL, IAG_CERT_KV_NAME, TRUST_STORE_PATH } = config;
const { localSanValue, endpoint } = iagApi;
const { logger } = loggerUtils;

const certificatePath = path.resolve(__dirname, TRUST_STORE_PATH);

@Injectable()
export class IagService {
  private static instance: IagService;
  private httpsAgent: https.Agent | undefined;
  private pfxBuffer: Buffer;
  private iagHeaders: IagHeaders = {
    'Trace-Id': 'team-chatbot',
    'Accept-Encoding': '', // IAG doesn't accept us setting this field, if left undefined axios will set it
  };
  // Injecting HttpService from @nestjs/axios
  constructor(private readonly httpService: HttpService) {}

  // Singleton access point
  public static async getInstance(httpService: HttpService): Promise<IagService> {
    if (!IagService.instance) {
      IagService.instance = new IagService(httpService);
      await IagService.instance.setup();
    }
    return IagService.instance;
  }

  // Setup method to download the certificate
  public async setup() {
    try {
      // Initialize the credential and client to interact with key-vault
      const credential = new DefaultAzureCredential();
      const secretClient = new SecretClient(AZURE_KEYVAULT_URL, credential);
      // Retrieve the certificate contents in PEM format
      const certificateSecret = await secretClient.getSecret(IAG_CERT_KV_NAME);
      const pemContent = certificateSecret.value!;

      const pemObjects = forge.pem.decode(pemContent);
      let privateKeyObject: forge.pki.PrivateKey | null = null;
      const certificates: forge.pki.Certificate[] = [];

      // Process each PEM object based on its type
      for (const pemObject of pemObjects) {
        if (pemObject.type === 'PRIVATE KEY') {
          // This is the private key
          privateKeyObject = forge.pki.privateKeyFromPem(forge.pem.encode(pemObject));
        } else if (pemObject.type === 'CERTIFICATE') {
          // This is a certificate
          certificates.push(forge.pki.certificateFromPem(forge.pem.encode(pemObject)));
        } else {
          // unsupported type
          throw new Error(`Unsupported PEM type :: ${pemObject.type}`);
        }
      }
      // Ensure private key is present
      if (!privateKeyObject) {
        throw new Error('No private key found in PEM data.');
      }
      if (!certificates.length) {
        throw new Error('No certificates found in PEM data.');
      }

      // Convert PEM to PFX using node-forge(with a private key)
      const p12Asn1 = forge.pkcs12.toPkcs12Asn1(
        privateKeyObject,
        certificates,
        '' // Empty paraphrase
      );

      //Convert ASN.1 structure to DER-encoded buffer
      this.pfxBuffer = Buffer.from(forge.asn1.toDer(p12Asn1).getBytes(), 'binary');
      if (ENVIRONMENT === 'local') {
        this.iagHeaders = {
          ...this.iagHeaders,
          'X509-OU': 'Service Token Application',
          'X509v3-SAN': localSanValue,
          'X509v3-SAN2': localSanValue,
        };
      } else if (this.pfxBuffer.length) {
        this.httpsAgent = new https.Agent({
          pfx: this.pfxBuffer,
          passphrase: '',
          ca: fs.readFileSync(certificatePath, 'utf-8'),
        });
      } else {
        throw new Error('Certificate not found');
      }
    } catch (error) {
      logger.error('Error setting up certificate for IagService %o', error);
    }
  }

  async iagRequest<Type = JsonMap>(iagRequestConfig: IagRequestConfig): Promise<Type> {
    const iagInstance = await IagService.getInstance(this.httpService);
    iagRequestConfig.headers = {
      ...this.iagHeaders,
      ...iagRequestConfig.headers,
    };
    logger.debug('IAG API is being called with options :: %j', iagRequestConfig);
    const { data } = await firstValueFrom(
      this.httpService
        .request<Type>({
          baseURL: endpoint,
          httpsAgent: iagInstance.httpsAgent,
          ...iagRequestConfig,
        })
        .pipe(
          catchError((error: AxiosError) => {
            logger.error('Error IAG API :: %o', error.message);
            throw error;
          })
        )
    );
    return data as Type;
  }
}
