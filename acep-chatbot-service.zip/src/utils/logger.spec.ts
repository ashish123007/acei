import loggers from './logger';

const { logWrap, logWrapAsync } = loggers;

describe('logWrap', () => {
  it('should return data', () => {
    const fn = function () {
      return 5;
    };
    const lw = logWrap(fn, '', '')();
    expect(lw).toEqual(5);
  });
  it('should break if fn throws an error', () => {
    const fn = function () {
      throw new Error('Error message');
    };
    expect(logWrap(fn, '', '')).toThrow(new Error('Error message'));
  });
});

describe('logWrapAsync', () => {
  it('should return data', async () => {
    const fn = function () {
      return Promise.resolve(5);
    };
    const lwa = await logWrapAsync(fn, '', '')();
    expect(lwa).toEqual(5);
  });
  it('it should break if fn throws an error', async () => {
    const fn = function () {
      return Promise.reject(new Error('abcdef'));
    };
    await expect(logWrapAsync(fn, '', '')).rejects.toThrow('abcdef');
  });
});
