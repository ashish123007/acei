const dtmfToNumber = (word: string): number | null => {
  const numberMap: { [key: string]: number } = {
    zero: 0,
    one: 1,
    two: 2,
    three: 3,
    four: 4,
    five: 5,
    six: 6,
    seven: 7,
    eight: 8,
    nine: 9,
  };

  const lowerCaseWord = word.toLowerCase();
  return numberMap[lowerCaseWord] ?? word;
};

export default dtmfToNumber;
