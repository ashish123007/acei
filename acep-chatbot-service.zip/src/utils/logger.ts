/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import _ from 'lodash';
import { createLogger, format, transports } from 'winston';
import config from '../config';
import { AnyFunction } from '../types/utils';
import { LEVEL, MESSAGE } from 'triple-beam';
const { TEST, LOG_LEVEL } = config;

class WinstonConsoleLogTransport extends transports.Console {
  log(info: any, callback: () => void) {
    setImmediate(() => this.emit('logged', info));

    if (this.stderrLevels[info[LEVEL]]) {
      console.error(info[MESSAGE]);

      if (callback) {
        callback();
      }
      return;
    }

    console.log(info[MESSAGE]);

    if (callback) {
      callback();
    }
  }
}

export const logger = createLogger({
  level: LOG_LEVEL,
  format: format.combine(format.errors({ stack: true }), format.splat(), format.json()),
  silent: TEST,
  transports: [
    new WinstonConsoleLogTransport({
      format: format.simple(),
    }),
  ],
});

const logWrap =
  <T extends AnyFunction>(
    fn: T,
    tag: string,
    cid: string,
    isGuard = false
  ): ((...funcArgs: Parameters<T>) => ReturnType<T>) =>
  (...args) => {
    if (!isGuard) {
      logger.info(`${cid} %j`, tag);
    }
    logger.debug('%j %j called with \n context : %j \n event %j', cid, tag, args[0], args[1]);
    try {
      const data = fn(...args);
      if (isGuard && data === true) {
        logger.info(`${cid} %j`, tag);
      }
      logger.debug('%j Output of %j is : %j', cid, tag, data);
      return data;
    } catch (ex) {
      logger.error('%j Error while executing "%j"', cid, tag);
      logger.error('%j %j', cid, ex);
      throw ex;
    }
  };

const logWrapAsync = <T extends AnyFunction>(
  fn: T,
  tag: string,
  cid: string
): ((...funcArgs: Parameters<T>) => ReturnType<T>) =>
  (async (...args) => {
    logger.info(`${cid} %j`, tag);
    logger.debug('%j %j called with \n context : %j \n event %j', cid, tag, args[0], args[1]);
    let data;
    try {
      //TODO: Fix before Merge
      if (typeof fn === 'object') {
        data = await (_.values(fn)[0] as any)(...args);
      } else {
        data = await fn(...args);
      }

      // data = await fn(...args)
      logger.debug('%j Output of %j is : %j', cid, tag, data);
      return data;
    } catch (ex) {
      logger.error('%j Error while executing "%j"', cid, tag);
      logger.error(ex);
      throw ex;
    }
  }) as (...funcArgs: Parameters<T>) => ReturnType<T>;

const loggerUtils = { logger, logWrap, logWrapAsync };
export default loggerUtils;
