// import { Botkit } from 'botkit'
// import { BotKitMiddleware } from '../types'

// declare module 'botkit/lib/core' {
//   interface Botkit extends Omit<Botkit, 'middleware'> {
//     doMymagic(): void
//     // middleware: {
//     //   spawn: BotKitMiddleware
//     //   // ingest: BotKitMiddleware
//     //   // send: BotKitMiddleware
//     //   // receive: BotKitMiddleware
//     //   // interpret: BotKitMiddleware
//     // }
//   }
// }
