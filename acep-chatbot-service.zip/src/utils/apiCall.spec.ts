import { faker } from '@faker-js/faker';
import { textAnswer } from '../../mocks/answer';
import axios from 'axios';
import apiCall from './apiCall';
jest.mock('axios');

const mockedAxios = axios as jest.Mocked<typeof axios>;

// -const apiCall = proxyquire('./apiCall', {
//   -  axios: (options) => {
//   -    if (!options.data) {
//   -      return (Promise.reject(new Error('Failure')));
//   -    }
//   -    return (Promise.resolve({ data: 'success' }));
//   -  },
//   -});

describe('apiCall', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  const password = faker.internet.password();
  const apiConfig = { auth: { password, username: 'myApiUsername' }, url: 'https://mockUrl' };
  it('should call the given api url with given incoming message', async () => {
    mockedAxios.request.mockImplementationOnce(() => Promise.resolve({ data: 'success' }));

    const response = await apiCall(apiConfig, textAnswer, '');
    expect(response).toEqual('success');
  });

  it('should return error message if api fails', async () => {
    mockedAxios.request.mockImplementationOnce(() => Promise.reject(new Error('Failure')));

    await expect(apiCall(apiConfig, '', '')).rejects.toThrowError('Failure');
  });

  it('should return error message if apiConfig is not configured fails', async () => {
    mockedAxios.request.mockImplementationOnce(() => Promise.reject(new Error('Failure')));

    await expect(apiCall(apiConfig, '', '')).rejects.toThrowError('Failure');
  });
});
