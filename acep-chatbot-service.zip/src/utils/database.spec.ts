import { Cosmos } from './database';

jest.mock('../config', () => ({
  ENVIRONMENT: 'jest',
  databaseOpts: {
    endpoint: 'https://local.cosmos',
  },
}));

var containerFn: jest.Mock;
jest.mock('@azure/cosmos', () => {
  containerFn = jest.fn();
  return {
    CosmosClient: jest.fn(() => ({
      database: jest.fn(() => ({
        container: containerFn,
      })),
    })),
  };
});
jest.mock('@azure/identity');

describe('Database', () => {
  let query: jest.Mock;
  let create: jest.Mock;
  let upsert: jest.Mock;

  beforeEach(async () => {
    query = jest.fn().mockReturnValue({
      fetchAll: jest.fn().mockReturnValue({
        resources: { foo: 'bar' },
      }),
    });

    create = jest.fn().mockReturnValue({
      resource: jest.fn(),
    });
    upsert = jest.fn();

    containerFn.mockReturnValue({
      items: {
        query,
        create,
        upsert,
      },
    });
  });

  it('should work with constructor', () => {
    const db = new Cosmos('cid');

    expect(containerFn).toHaveBeenCalledWith('cid');
  });

  it('should work with query', async () => {
    const db = new Cosmos('cid');

    const res = await db.query({});

    expect(query).toHaveBeenCalled();
    expect(res).toEqual({ foo: 'bar' });
  });

  it('should work with queryRaw', async () => {
    const db = new Cosmos('cid');

    await db.queryRaw('SELECT 1');

    expect(query).toHaveBeenCalled();
  });

  it('should work with get', async () => {
    const db = new Cosmos('cid');

    await db.get({});

    expect(query).toHaveBeenCalled();
  });

  it('should work with create', async () => {
    const db = new Cosmos('cid');

    await db.create({ id: '1' });

    expect(create).toHaveBeenCalled();
  });
});
