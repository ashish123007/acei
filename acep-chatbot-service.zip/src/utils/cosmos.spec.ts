import { CosmosV2 } from './cosmos';

jest.mock('../config', () => ({
  ENVIRONMENT: 'jest',
  databaseOpts: {
    endpoint: 'https://local.cosmos',
  },
}));

var containerFn: jest.Mock;
jest.mock('@azure/cosmos', () => {
  containerFn = jest.fn();
  return {
    CosmosClient: jest.fn(() => ({
      database: jest.fn(() => ({
        container: containerFn,
      })),
    })),
  };
});
jest.mock('@azure/identity');

describe('Database', () => {
  let read: jest.Mock;
  let create: jest.Mock;
  let patch: jest.Mock;
  let upsert: jest.Mock;

  beforeEach(async () => {
    read = jest.fn().mockReturnValue({
      resource: jest.fn(),
    });

    create = jest.fn().mockReturnValue({
      resource: jest.fn(),
    });
    patch = jest.fn();

    upsert = jest.fn().mockReturnValue({
      resource: jest.fn(),
    });

    containerFn.mockReturnValue({
      items: {
        create,
        upsert,
      },
      item: jest.fn().mockReturnValue({
        read,
        patch,
      }),
    });
  });

  it('should work with create', async () => {
    const db = new CosmosV2('cid', 'pk');
    await db.create({ id: '1', ttl: 0 });
    expect(create).toHaveBeenCalled();
  });

  it('should work being able to read', async () => {
    const db = new CosmosV2('cid', 'pk');
    await db.get();
    expect(read).toHaveBeenCalled();
  });

  it('should work being able to read', async () => {
    const db = new CosmosV2('cid', 'pk');
    await db.patch([]);
    expect(patch).toHaveBeenCalled();
  });

  it('should work being able to upsert', async () => {
    const db = new CosmosV2('cid', 'pk');
    await db.update({ id: 'test', ttl: 12334 });
    expect(upsert).toHaveBeenCalled();
  });
});
