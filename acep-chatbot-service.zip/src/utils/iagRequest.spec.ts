import { HttpService } from '@nestjs/axios';
import { of } from 'rxjs';
import { Test, TestingModule } from '@nestjs/testing';
import { AxiosResponse } from 'axios';
import { IagService } from './iagRequest.service';

describe('IagRequest', () => {
  let service: IagService;
  let httpService: HttpService;
  const IAG_REQUEST_CONFIG = {
    method: 'post',
    url: 'test-url',
    headers: {
      Authorization: 'Test Token',
    },
    data: 'Test Data',
  };
  const IAG_AXIOS_RESULT = { data: 'success' } as AxiosResponse;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [IagService, { provide: HttpService, useValue: { request: jest.fn() } }],
    }).compile();
    service = module.get<IagService>(IagService);
    httpService = module.get<HttpService>(HttpService);
  });
  afterEach(() => {
    jest.clearAllMocks();
  });
  it('should be defined', () => {
    expect(service).toBeDefined();
  });
  it('should successfully invoke IAG API', async () => {
    jest.spyOn(httpService, 'request').mockReturnValue(of(IAG_AXIOS_RESULT));
    const result = await service.iagRequest(IAG_REQUEST_CONFIG);
    expect(result).toEqual(IAG_AXIOS_RESULT.data);
  });
  it('should handle error correctly when API call fails', async () => {
    const errorMessage = 'API call fail';
    jest.spyOn(httpService, 'request').mockImplementationOnce(() => {
      throw new Error(errorMessage);
    });
    await expect(service.iagRequest(IAG_REQUEST_CONFIG)).rejects.toThrow(errorMessage);
  });
});
