import { createClient } from 'redis';
import config from '../config';
import loggerUtils from './logger';
import constants from '../constants';

const { logger } = loggerUtils;
const { REDIS_URL, REDIS_SECRET_KEY, FEATURE_FLAGS } = config;
const { TTL_CACHE_CONTENTFUL_DAYS } = constants;

const IS_REDIS_ENABLED = FEATURE_FLAGS.includes('redis');

const redisClient = createClient({
  url: REDIS_URL,
  password: REDIS_SECRET_KEY,
  disableOfflineQueue: true,
  socket: {
    timeout: 1000,
    connectTimeout: 5000,
    reconnectStrategy: 10000, // wait 10s before reconnecting
  },
  pingInterval: 1000,
});

if (IS_REDIS_ENABLED) {
  logger.info('Connecting RedisClient');
  redisClient
    .connect()
    .then(() => {
      logger.verbose('RedisClient Connected');
    })
    .catch((err) => {
      logger.error('RedisClient error %o', err);
    });
  redisClient.on('error', (err) => logger.error('RedisClient Error %o', err));
}

function safeRedisDecorator<T>(fallbackValue: T) {
  return (_target: unknown, memberName: string, propertyDescriptor: PropertyDescriptor) => {
    return {
      get() {
        const wrapperFn = async (...args: unknown[]) => {
          logger.verbose('RedisClient calling %s', memberName);
          if (IS_REDIS_ENABLED && redisClient.isOpen && redisClient.isReady) {
            // eslint-disable-next-line
            const promise = propertyDescriptor.value.apply(this, args) as Promise<T>;
            return promise
              .then((result: T) => {
                if (Array.isArray(result)) {
                  logger.info(
                    'RedisClient called %s with parameter %j with result %j',
                    memberName,
                    args,
                    result.map((r) => !!r)
                  );
                  logger.debug('RedisClient called %s with parameter %j with result %j', memberName, args, result);
                } else {
                  logger.info('RedisClient called %s with parameter %j with result %j', memberName, args, !!result);
                  logger.debug('RedisClient called %s with parameter %j with result %j', memberName, args, result);
                }
                return result;
              })
              .catch((err) => {
                logger.warn('RedisClient error %o, skipping %s', err, memberName);
                return fallbackValue;
              });
          } else if (IS_REDIS_ENABLED) {
            logger.warn('RedisClient not ready, skipping %s', memberName);
          }
          return Promise.resolve(fallbackValue);
        };

        Object.defineProperty(this, memberName, {
          value: wrapperFn,
          configurable: true,
          writable: true,
        });
        return wrapperFn;
      },
    };
  };
}
/*
  documentation: https://www.npmjs.com/package/redis
  namespace should be used to avoid key collision between cache users

  set,get,del are standard redis operations

  getCacheList used the native redis command MGET to fetch multiple key at once
  setCacheList is multiple .set in a transaction
*/
class RedisClient {
  constructor(
    private namespace: string,
    private expiryTtl: number
  ) {}

  private formatKey(key: string) {
    return `${this.namespace}::${key}`;
  }

  @safeRedisDecorator<string | null>(null)
  public async getCache(id: string) {
    return await redisClient.get(this.formatKey(id));
  }

  @safeRedisDecorator<null>(null)
  public async setCache(id: string, data: string) {
    await redisClient.set(this.formatKey(id), data, {
      EX: this.expiryTtl,
    });
    return null;
  }

  @safeRedisDecorator<null>(null)
  public async delCache(id: string) {
    await redisClient.del(this.formatKey(id));
    return null;
  }

  @safeRedisDecorator<Array<string | null>>([])
  public async getCacheList(ids: string[]) {
    const keys = ids.map((id) => this.formatKey(id));
    const response = await redisClient.sendCommand<Array<string | null>>(['MGET', ...keys]);
    return response;
  }

  @safeRedisDecorator<null>(null)
  public async setCacheList(list: Array<{ id: string; value: string }>) {
    let multi = redisClient.multi();
    for (const item of list) {
      multi = multi.set(this.formatKey(item.id), item.value, {
        EX: this.expiryTtl,
      });
    }

    await multi.exec();
    return null;
  }
}

export const contentfulRedisClient = new RedisClient('contentful', TTL_CACHE_CONTENTFUL_DAYS);
