import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { ConfigModule } from '@nestjs/config';
import { BotConfigService } from './nestjs/providers/botconfig.service';
import { DatabaseCosmosService, DatabaseLocalService, DatabaseService } from './nestjs/providers/database.service';
import { NiceService } from './nestjs/providers/nice.service';
import { MessageHubController } from './nestjs/routes/messageHub';
import { VahController } from './nestjs/routes/vah';
import { AcsClientFactory } from './nestjs/providers/acsCustomSdk.service';
import { VoiceOrchestrator } from './nestjs/providers/voiceOrchestrator.service';
import { VoiceHubController } from './nestjs/routes/voiceHub/voiceHub';
import { IvrCallQueueService } from './nestjs/providers/IvrCallQueue.service';
import { ContentfulController } from './nestjs/routes/contentful/contentful.controller';
import { IVRSessionFactory } from './nestjs/providers/ivrSession.service';
import { MSDSessionFactory } from './nestjs/providers/msdSession.service';
import { MSDQueueService } from './nestjs/providers/MSDQueue.service';
import { CopilotService } from './nestjs/providers/copilot.service';
import { WebsocketService } from './nestjs/providers/websocket.service';
import { ContentfulService } from './nestjs/providers/contentful.service';
import { ConsumeCopilot } from './nestjs/providers/copilotConsumer.service';
import { WebhookService } from './nestjs/providers/webhook.service';
import { CpsVoiceBotProcessor } from './nestjs/providers/cpsVoiceBotProcessor.service';
import { VoiceBotResponseProcessor } from './nestjs/providers/voiceBotResponseProcessor.service';
import { IagService } from './utils/iagRequest.service';
import { ConfigurationService } from './utils/configuration.service';
import { IntegrationTestController } from './nestjs/routes/integration/integration.controller';
import { OrchestratorService } from './nestjs/providers/orchestrator.service';
import { WebhookNCDService } from './nestjs/providers/webhook-ncd.service';
import { VahService } from './nestjs/providers/vah/vah.service';

@Module({
  imports: [
    ConfigModule.forRoot({
      envFilePath: ['../local-setup/chatbot-service.env', '../local-setup/chatbot-service-secret.env'],
    }),
    HttpModule,
  ],
  controllers: [
    MessageHubController,
    VoiceHubController,
    ContentfulController,
    VahController,
    IntegrationTestController,
  ],
  providers: [
    VoiceOrchestrator,
    AcsClientFactory,
    BotConfigService,
    {
      provide: DatabaseService,
      useClass: process.env.ENVIRONMENT === 'local' ? DatabaseLocalService : DatabaseCosmosService,
    },
    ContentfulService,
    IVRSessionFactory,
    NiceService,
    IvrCallQueueService,
    MSDSessionFactory,
    MSDQueueService,
    CopilotService,
    WebsocketService,
    ConsumeCopilot,
    WebhookService,
    CpsVoiceBotProcessor,
    VoiceBotResponseProcessor,
    IagService,
    ConfigurationService,
    WebhookNCDService,
    OrchestratorService,
    VahService,
  ],
})
export class AppModule {}
