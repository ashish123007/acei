import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../../../app.module';
import { BotConfigService } from '../../providers/botconfig.service';
import { OrchestratorService } from '../../providers/orchestrator.service';
import { ApiKeyGuard } from '../../guards/apiKey.guard';
import { CanActivate, ExecutionContext } from '@nestjs/common';
import { MessageHubRequest } from '../../../types';
import { BotEnvironment } from '../../../types/bot';
import request from 'supertest';
import { ContentfulService } from '../../providers/contentful.service';

const SECRET_KEY = 'secretKey';
const BOT_ENV_CONFIG = {
  cpsInstance: {
    name: 'dev',
    secretKey: SECRET_KEY,
  },
} as unknown as BotEnvironment;

class CpsApiKeyGuardMocked implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<MessageHubRequest>();
    request.botEnvConfig = BOT_ENV_CONFIG;
    return true;
  }
}

describe('VAH - no channel data endpoint', () => {
  let module: TestingModule;
  let handleRequest: jest.Mock;

  beforeEach(async () => {
    handleRequest = jest.fn();
    module = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(BotConfigService)
      .useValue({})
      .overrideProvider(OrchestratorService)
      .useValue({
        handleRequest,
      })
      .overrideProvider(ContentfulService)
      .useValue({})
      .overrideGuard(ApiKeyGuard)
      .useClass(CpsApiKeyGuardMocked)
      .compile();
    jest.spyOn(global.Math, 'random').mockReturnValue(0.123456789);
  });

  afterEach(() => {
    jest.spyOn(global.Math, 'random').mockRestore();
  });

  it('should invoke orchestrator service with proper conversation id and unchanged body', async () => {
    let app = module.createNestApplication();
    await app.init();
    const body = {
      virtualAgentId: 'Chatbot_Anna_DV',
      userInput: 'Buttons',
      userInputType: 5,
      executionInfo: {
        contactId: '1234567890',
      },
      base64wavFile: null,
      botSessionState: null,
      customPayload: {},
      mediaType: 'Digital',
    };

    const response = await request(app.getHttpServer()).post('/text-messages').send(body);
    expect(handleRequest).toHaveBeenCalledWith('1234567890', body, BOT_ENV_CONFIG);
  });

  it('should validate hook response structure and return hook response if structure is valid', async () => {
    let app = module.createNestApplication();
    await app.init();
    const body = {
      virtualAgentId: 'Chatbot_Anna_DV',
      userInput: 'Buttons',
      userInputType: 5,
      executionInfo: {
        contactId: '1234567890',
      },
      base64wavFile: null,
      botSessionState: null,
      customPayload: {},
      mediaType: 'Digital',
    };
    const expectedResponse = {
      branchName: 'PromptAndCollectNextResponse',
      nextPromptSequence: {
        prompts: [
          {
            transcript: '',
            mediaSpecificObject: {
              type: 'featureToggle',
              buttons: [],
              contents: [],
              payload: {
                features: [
                  {
                    name: 'cps',
                    value: true,
                  },
                ],
              },
            },
          },
          {
            transcript: '',
            mediaSpecificObject: {
              type: 'disableInputField',
              buttons: [],
              contents: [],
              payload: {
                value: false,
              },
            },
          },
          {
            transcript: 'Goedemorgen, ik ben chatbot Anna. Ik help u graag vooruit met het regelen van uw bankzaken.',
            mediaSpecificObject: {
              type: 'bot',
              buttons: [],
              contents: [
                {
                  type: 'text',
                  text: 'Goedemorgen, ik ben chatbot Anna. Ik help u graag vooruit met het regelen van uw bankzaken.',
                },
              ],
            },
          },
          {
            transcript: 'Als het nodig is helpt een medewerker u in deze chat.',
            mediaSpecificObject: {
              type: 'bot',
              buttons: [],
              contents: [
                {
                  type: 'text',
                  text: 'Als het nodig is helpt een medewerker u in deze chat.',
                },
              ],
            },
          },
          {
            transcript: 'Wat is uw vraag?',
            mediaSpecificObject: {
              type: 'bot',
              buttons: [],
              contents: [
                {
                  type: 'text',
                  text: 'Wat is uw vraag?',
                },
              ],
            },
          },
        ],
      },
    };
    handleRequest.mockResolvedValueOnce(expectedResponse);

    const response = await request(app.getHttpServer()).post('/text-messages').send(body);
    expect(response.body).toEqual(expectedResponse);
  });

  it('should validate hook response structure and fail in case of bad structure', async () => {
    let app = module.createNestApplication();
    await app.init();
    const body = {
      virtualAgentId: 'Chatbot_Anna_DV',
      userInput: 'Buttons',
      userInputType: 5,
      executionInfo: {
        contactId: '1234567890',
      },
      base64wavFile: null,
      botSessionState: null,
      customPayload: {},
      mediaType: 'Digital',
    };
    const expectedResponse = {
      branchName: 'PromptAndCollectNextResponse',
      nextPromptSequence: {
        fakeProp: true,
        prompts: [
          {
            transcript: '',
            mediaSpecificObject: {
              type: 'featureToggle',
              buttons: [],
              contents: [],
              payload: {
                features: [
                  {
                    name: 'cps',
                    value: true,
                  },
                ],
              },
            },
          },
        ],
      },
    };
    handleRequest.mockResolvedValueOnce(expectedResponse);

    const response = await request(app.getHttpServer()).post('/text-messages').send(body);
    expect(response.status).toEqual(500);
  });
});
