import { Body, Controller, HttpCode, Post, UseGuards } from '@nestjs/common';
import { ApiKeyGuard, BotEnvDecorator } from '../../guards/apiKey.guard';
import { VahService } from '../../providers/vah/vah.service';
import { BotEnvironment } from '../../../types/bot';
import { Message } from '../../../types/machineTypes';

@Controller('/text-messages')
@UseGuards(ApiKeyGuard)
export class VahController {
  constructor(private vahService: VahService) {}
  @Post('/')
  @HttpCode(200)
  async vahMessage(@BotEnvDecorator() envConfig: BotEnvironment, @Body() body: Message) {
    return await this.vahService.handleVahRequest(body, envConfig);
  }
}
