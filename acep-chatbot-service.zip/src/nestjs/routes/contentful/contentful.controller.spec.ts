jest.mock('redis');

var delCache = jest.fn();

jest.mock('../../../utils/redis', () => {
  delCache = jest.fn();

  return {
    contentfulRedisClient: {
      delCache,
    },
  };
});

import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../../../app.module';
import request from 'supertest';
import { BotConfigService } from '../../providers/botconfig.service';
import { ContentfulService } from '../../providers/contentful.service';

describe('ContentfulController', () => {
  let module: TestingModule;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(BotConfigService)
      .useValue({
        getBotEnvConfigViaTeams: () => ({}),
      })
      .overrideProvider(ContentfulService)
      .useValue({})
      .compile();
  });

  it(`should be able to ping`, async () => {
    let app = module.createNestApplication();

    await app.init();
    await request(app.getHttpServer()).post('/contentful/webhook/').send({ entityId: 'enrty123' }).expect(200);

    expect(delCache).toHaveBeenCalledWith('enrty123');
  });
});
