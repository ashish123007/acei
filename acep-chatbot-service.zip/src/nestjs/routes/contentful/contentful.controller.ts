import { Body, Controller, HttpCode, Post } from '@nestjs/common';
import loggerUtils from '../../../utils/logger';
import { contentfulRedisClient } from '../../../utils/redis';

const { logger } = loggerUtils;

@Controller('/contentful')
export class ContentfulController {
  @Post('webhook')
  @HttpCode(200)
  async contentfulWebhook(@Body() body: { entityId: string; spaceId: string }) {
    const { entityId } = body;

    logger.info('Node edited from contentful %s', entityId);

    await contentfulRedisClient.delCache(entityId);

    return { success: true };
  }
}
