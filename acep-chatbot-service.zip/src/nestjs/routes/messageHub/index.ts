import { Body, Controller, Get, HttpCode, InternalServerErrorException, Post, UseGuards } from '@nestjs/common';
import _ from 'lodash';
import { ApiKeyGuard, BotEnvDecorator } from '../../guards/apiKey.guard';
import { BotEnvironment } from '../../../types/bot';
import { Message, VoiceIvrMessageBody } from '../../../types/machineTypes';
import loggerUtils from '../../../utils/logger';
import { CpsVoiceBotProcessor } from '../../providers/cpsVoiceBotProcessor.service';
import { ActivityToSend, CPS_CUSTOM_EVENTS } from '../../../types/copilotApi.model';

const { logger } = loggerUtils;
const { NO_INPUT } = CPS_CUSTOM_EVENTS;

@Controller('/message-hub')
export class MessageHubController {
  constructor(private cpsVoiceBotProcessor: CpsVoiceBotProcessor) {}

  @Get('ping')
  @HttpCode(200)
  ping() {
    return { message: 'FSCP 3.0 Server alive!' };
  }

  // ACS Voice Bot route
  private async getVoiceResponseWithCopilot(envConfig: BotEnvironment, body: VoiceIvrMessageBody) {
    const conversationId = body.conversationId?.toString();
    const text = body.message.text || '';
    const event = body?.event;
    if (!conversationId) {
      throw new Error('Conversation Id is required');
    }

    let activityToSend: ActivityToSend;
    if (event === NO_INPUT) {
      activityToSend = {
        type: 'event',
        name: NO_INPUT,
      };
    } else {
      activityToSend = {
        type: 'message',
        text,
      };
    }
    const voiceBotResponse = await this.cpsVoiceBotProcessor.process({
      sessionId: conversationId,
      envConfig,
      activityToSend,
      sipHeaderLanguage: 'nl',
    });
    return {
      type: 'message',
      voice: voiceBotResponse,
    };
  }

  @UseGuards(ApiKeyGuard)
  @HttpCode(200)
  @Post(':botId/:channelEnv/voice/receive')
  async voiceReceive(@BotEnvDecorator() envConfig: BotEnvironment, @Body() body: Message) {
    try {
      delete body.botConfig;
      logger.info('Received messague-hub request for voice with values  %j', body);
      return await this.getVoiceResponseWithCopilot(envConfig, body);
    } catch (err) {
      logger.error('Unable to process voicebot response %o', err);
      throw new InternalServerErrorException();
    }
  }
}
