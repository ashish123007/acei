import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../../../app.module';
import { MessageHubRequest } from '../../../types';
import { BotEnvironment } from '../../../types/bot';
import { ApiKeyGuard } from '../../guards/apiKey.guard';
import { BotConfigService } from '../../providers/botconfig.service';
import { ContentfulService } from '../../providers/contentful.service';
import mockedContentful from '../../../../mocks/contentful/cpsintegration.json';
import mockedActivities from '../../../../mocks/cps/contentful-ids.json';
import { ConsumeCopilot } from '../../providers/copilotConsumer.service';
import { CpsVoiceBotProcessor } from '../../providers/cpsVoiceBotProcessor.service';

jest.mock('../../../utils/database', () => {
  class Cosmos {
    containerId: string;
    constructor() {
      this.containerId = this.containerId;
    }
    queryRaw() {
      return [
        {
          userDetails: {
            user: {
              id: '1',
              name: 'abc',
            },
            bot: {
              id: 'b:123',
            },
            conversation: {
              id: 'a:1923',
            },
          },
        },
      ];
    }
  }
  return {
    __esModule: true,
    Cosmos,
  };
});

@Injectable()
export class ApiKeyGuardMocked implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<MessageHubRequest>();
    request.botEnvConfig = { a: 1, cpsInstance: request.headers['cpsinstance'] || false } as unknown as BotEnvironment;
    return true;
  }
}

describe('Guards', () => {
  let module: TestingModule;
  let getCopilotActivities: jest.Mock;
  let getEntries: jest.Mock;
  let processVoiceBot: jest.Mock;
  let getCPSConversationAndSession: jest.Mock;

  beforeEach(async () => {
    getCopilotActivities = jest.fn();
    getEntries = jest.fn();
    processVoiceBot = jest.fn();
    getCPSConversationAndSession = jest.fn();

    module = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(CpsVoiceBotProcessor)
      .useValue({
        process: processVoiceBot,
      })
      .overrideGuard(ApiKeyGuard)
      .useClass(ApiKeyGuardMocked)
      .overrideProvider(BotConfigService)
      .useValue({
        getBotEnvConfigViaTeams: () => ({}),
      })
      .overrideProvider(ConsumeCopilot)
      .useValue({
        getCopilotActivities,
        getCPSConversationAndSession,
      })
      .overrideProvider(ContentfulService)
      .useValue({
        getEntries: getEntries,
      })
      .compile();
  });

  it(`should be able to ping`, async () => {
    let app = module.createNestApplication();

    await app.init();
    return request(app.getHttpServer()).get('/message-hub/ping').expect(200);
  });

  it(`should return empty data when no activities returned`, async () => {
    let app = module.createNestApplication();
    await app.init();
    getCopilotActivities.mockResolvedValue([]);
    getCPSConversationAndSession.mockResolvedValue([]);
    getEntries.mockResolvedValue([]);

    await request(app.getHttpServer())
      .post('/message-hub/anna/test/voice/receive')
      .set('cpsinstance', 'true')
      .send({
        message: { text: 'private' },
        context: { sessionId: '0822' },
        conversationId: 'gautier-1',
      })
      .expect(200);
    expect(processVoiceBot).toHaveBeenCalled();
  });

  it(`should return formatted data`, async () => {
    let app = module.createNestApplication();
    await app.init();
    getCopilotActivities.mockResolvedValue(mockedActivities);
    getCPSConversationAndSession.mockResolvedValue([]);
    getEntries.mockResolvedValue(mockedContentful);
    await request(app.getHttpServer())
      .post('/message-hub/anna/test/voice/receive')
      .set('cpsInstance', 'true')
      .send({
        message: { text: 'private' },
        context: { sessionId: '0822' },
        conversationId: 'gautier-1',
      })
      .expect(200);

    expect(processVoiceBot).toHaveBeenCalled();
  });
});
