import {
  Body,
  Controller,
  HttpCode,
  InternalServerErrorException,
  Param,
  Post,
  Req,
  UseGuards,
  UsePipes,
} from '@nestjs/common';
import qs from 'qs';
import { AcsClientFactory } from '../../providers/acsCustomSdk.service';
import loggerUtls from '../../../utils/logger';
import config from '../../../config';
import { FastifyRequest } from 'fastify';
import { VoiceOrchestrator } from '../../providers/voiceOrchestrator.service';
import { VoiceAcs } from '../../guards/voiceAcs.guard';
import { BotEnvDecorator } from '../../guards/apiKey.guard';
import { BotEnvironment } from '../../../types/bot';
import crypto from 'node:crypto';
import {
  AcsCallbacks,
  acsEvenDto,
  CallbacksQsParams,
  MicrosoftAcsEventType,
  VoiceOrchestratorParams,
  VoiceRequestUserType,
} from '../../../types/voice';
import { VoiceConstants } from '../../../constants/voice';
import { IvrCallQueueService } from '../../providers/IvrCallQueue.service';
import constants from '../../../constants';
import { IVRSessionFactory } from '../../providers/ivrSession.service';
import { ZodValidationPipe } from 'nestjs-zod';
import { CpsVoiceBotProcessor } from '../../providers/cpsVoiceBotProcessor.service';
import { CPS_CUSTOM_EVENTS } from '../../../types/copilotApi.model';
import dtmfToNumber from '../../../utils/dtmfToNumber';
import preIntentToHandoverCode from '../../../utils/preIntentToHandoverCode';
import { voiceHubEventRequest } from '../../../types';

const { CHATBOT_PUBLIC_ENDPOINT } = config;
const { logger } = loggerUtls;
const { SPEECH_LANGUAGE, SPEECH_VOICE, DEFAULT_SPEECH_VOICE, DEFAULT_SPEECH_LANGUAGE } = VoiceConstants;
const ANNA_VOICE_PREFIX = 'voice-hub';
const { DEFAULT_HANDOVER_CODE } = VoiceConstants;
const { IVR_CALL_TIMEOUT_MINS } = constants;

@Controller(ANNA_VOICE_PREFIX)
export class VoiceHubController {
  constructor(
    private acsClientFactory: AcsClientFactory,
    private voiceOrchestrator: VoiceOrchestrator,
    private ivrCallQueue: IvrCallQueueService,
    private ivrSessionFactory: IVRSessionFactory,
    private cpsVoiceBotProcessor: CpsVoiceBotProcessor
  ) {}

  // Step 1: Incoming request is received from NICE and :botId/:channelEnv/events route is invoked
  @HttpCode(200)
  @UsePipes(ZodValidationPipe)
  @Post(':botId/:channelEnv/events')
  async voiceEvents(
    @Body() body: acsEvenDto,
    @Param('botId') botId: string,
    @Param('channelEnv') channelEnv: string,
    @Req() request: voiceHubEventRequest
  ) {
    logger.verbose(`[ACS] Received acs events %j`, body);
    logger.debug(`[ACS], Received acs events header %j`, request.headers);

    try {
      for (const event of body) {
        if (event?.data && event?.eventType == MicrosoftAcsEventType.SubscriptionValidationEvent) {
          const code = event.data.validationCode;
          return {
            validationResponse: code,
          };
        } else if (event?.data && event?.eventType == MicrosoftAcsEventType.IncomingCall) {
          let skillBasedQueryString: Pick<CallbacksQsParams, 'contactId' | 'preIntent'>;
          const userToUserHeaders = event.data.customContext?.sipHeaders?.['user-To-User'];
          logger.info('Incoming userToUserHeaders coming from sipHeaders(NICE) :: %j', userToUserHeaders);
          let preIntent = request.headers['defaultpreintent'];
          let conversationIdIdentifier = event.data.from.phoneNumber.value;
          if (userToUserHeaders) {
            const [contactId, sipPreIntent] = userToUserHeaders?.split('+');
            preIntent = sipPreIntent;
            skillBasedQueryString = {
              contactId,
              preIntent,
            };
            conversationIdIdentifier = contactId;
          } else {
            skillBasedQueryString = {
              contactId: undefined,
              preIntent,
            };
          }

          const conversationId = `${conversationIdIdentifier}-${crypto.randomBytes(16).toString('hex')}`;
          const commonQueryStrings = {
            sourceFromData: event.data.from,
            sipHeaders: event.data.customContext?.sipHeaders || {},
            conversationId,
          };
          const queryStrings = { ...commonQueryStrings, ...skillBasedQueryString };
          const callbackUrl = `${CHATBOT_PUBLIC_ENDPOINT}/${ANNA_VOICE_PREFIX}/${botId}/${channelEnv}/callbacks?${qs.stringify(queryStrings)}`;
          logger.info('[%s] received %s', conversationId, MicrosoftAcsEventType.IncomingCall);
          const acsClient = this.acsClientFactory.createService('', conversationId);
          await acsClient.acceptCall(event.data.incomingCallContext, callbackUrl);
        }
      }
    } catch (err) {
      logger.error('unable to process voice events got error %o', err);
      throw new InternalServerErrorException();
    }
  }

  // Step 2: Platform calls ACS api using the callbackUrl created in the :botId/:channelEnv/events handler.
  // The controller is invoked after Microsoft ACS api accepts the call and returns the response
  @HttpCode(200)
  @UseGuards(VoiceAcs)
  @Post(':botId/:channelEnv/callbacks')
  async voiceCallbacks(
    @Body() body: AcsCallbacks[],
    @BotEnvDecorator() env: BotEnvironment,
    @Req() req: FastifyRequest
  ) {
    {
      logger.debug(`[ACS], Received acs callbacks header %j`, req.headers);
      try {
        const qsParsed: CallbacksQsParams = qs.parse(req.url.replace(/\+/g, '%2B'));
        const { sourceFromData, conversationId, contactId = '', preIntent = '', sipHeaders = {} } = qsParsed;

        logger.verbose(
          '[%s] ACS Received acs callback %j from %j, number %j and preIntent %j, sipHeaders %j',
          conversationId,
          body,
          sourceFromData,
          contactId,
          preIntent,
          sipHeaders
        );
        if (!sourceFromData || !conversationId) {
          logger.error('Query parameter sourceFromData has not been set!');
          throw new Error('Invalid query parameters!');
        }
        const connection = env.channel?.connection;
        const voiceName = connection?.find((c) => c.key === SPEECH_VOICE)?.value || DEFAULT_SPEECH_VOICE;
        const speechLanguage =
          sipHeaders?.['x-MS-Custom-Lang_Pref'] ||
          connection?.find((c) => c.key === SPEECH_LANGUAGE)?.value ||
          DEFAULT_SPEECH_LANGUAGE;
        for (const event of body) {
          const { callConnectionId, correlationId } = event.data;
          logger.info('[%s] received %s with %j', conversationId, event.type, {
            callConnectionId,
            correlationId,
          });
          const voiceOrchestratorParams: VoiceOrchestratorParams = {
            env,
            conversationId,
            callConnectionId,
            target: sourceFromData,
            voiceName,
            speechLanguage,
            contactId,
            preIntent,
            sipHeaders,
          };
          // IVR Message scheduling logic to IVR queue for termination of ghost calls that last longer than 15mins
          const ivrSession = this.ivrSessionFactory.createService(callConnectionId);
          if (event.type === MicrosoftAcsEventType.CallConnected) {
            setImmediate(async () => {
              const scheduledEnqueueTimeUtc = new Date(Date.now() + 1000 * 60 * IVR_CALL_TIMEOUT_MINS);
              logger.info(
                `Messages will appear in IVR Service Bus queue after ${IVR_CALL_TIMEOUT_MINS} mins at : ${scheduledEnqueueTimeUtc}`
              );
              try {
                const sequenceNumbers = (
                  await this.ivrCallQueue.sendScheduledMessages(
                    [{ id: callConnectionId, conversationId }],
                    scheduledEnqueueTimeUtc
                  )
                )[0];
                await ivrSession.createSession({
                  conversationId,
                  hangupScheduledId: sequenceNumbers.toString(),
                });
              } catch (e) {
                logger.error(`[%s] CallConnected post processing :: error %o`, conversationId, e);
              }
            });
            await this.voiceOrchestrator.main('', voiceOrchestratorParams);
          } else if (event.type === MicrosoftAcsEventType.RecognizeCompleted) {
            if (event.data.recognitionType == 'dtmf') {
              const words = event.data.dtmfResult.tones;
              const numbers = words.map(dtmfToNumber);
              const input = numbers.join('');
              logger.info('[%s] RecognizeCompleted with input %s', conversationId, input);
              await this.voiceOrchestrator.main(input, voiceOrchestratorParams);
            } else if (event.data.recognitionType == 'speech') {
              const input = event.data.speechResult.speech;
              logger.info('[%s] RecognizeCompleted with input %s', conversationId, input);
              await this.voiceOrchestrator.main(input, voiceOrchestratorParams);
            }
          } else if (event.type === MicrosoftAcsEventType.PlayCompleted) {
            const operationContext = event.data.operationContext;
            const acsClient = this.acsClientFactory.createService(callConnectionId, conversationId);
            if (operationContext === 'handover') {
              const session = await ivrSession.getSession();
              logger.verbose('[%s] Receive handover for session %j', conversationId, session);
              let handoverCode = session?.handover?.handoverCode;
              const handoverText = session?.handover?.handoverText;

              if (!handoverCode) {
                logger.error(
                  '[%s] handoverCode was not found in session going to preIntent or default',
                  conversationId
                );
                handoverCode = preIntentToHandoverCode(preIntent || '');
              }

              await this.voiceOrchestrator.handover(
                {
                  code: handoverCode,
                  handText: handoverText || '',
                  conversationId,
                  callConnectionId,
                  contactId,
                },
                env
              );
            } else if (!operationContext || operationContext === 'none') {
              await acsClient.terminateCall();
            } else if (
              VoiceRequestUserType.DTMF === operationContext ||
              VoiceRequestUserType.SPEECH === operationContext
            ) {
              await acsClient.recognize({
                targetParticipantInfo: sourceFromData,
                requestType: operationContext,
                speechLanguage,
                bargeInEnabled: true,
              });
            }
          } else if (event.type === MicrosoftAcsEventType.RecognizeFailed) {
            if (event.data.resultInformation.subCode === VoiceConstants.RECOGNIZE_FAILED_TIMEOUT_BREACHED_CODE) {
              await this.voiceOrchestrator.main('', voiceOrchestratorParams, true);
            } else {
              logger.warn(
                '[%s] ACS-Failure-Event received unexpected RecognizeFailed with params %j',
                conversationId,
                event.data.resultInformation
              );
              await this.voiceOrchestrator.handover(
                {
                  code: preIntentToHandoverCode(preIntent || ''),
                  handText: '',
                  callConnectionId,
                  conversationId,
                  contactId,
                },
                env
              );
            }
          } else if (event.type === MicrosoftAcsEventType.PlayFailed) {
            logger.warn('[%s] ACS-Failure-Event received unexpected PlayFailed', conversationId);
            await this.voiceOrchestrator.handover(
              {
                code: preIntentToHandoverCode(preIntent || ''),
                handText: '',
                callConnectionId,
                conversationId,
                contactId,
              },
              env
            );
          } else if (event.type === MicrosoftAcsEventType.CallDisconnected) {
            const session = await ivrSession.getSession();
            logger.debug('[%s] Disconnected session %j', session);
            // Happy flow: For calls that gets terminated before the scheduled time(15mins)
            if (session?.hangupScheduledId) {
              try {
                await this.ivrCallQueue.cancelScheduledMessages(session.hangupScheduledId);
                logger.info('[%s] ivrCallQueue message canceled', conversationId);
              } catch (e) {
                logger.error('[%s] Unable to cancelScheduledMessages %o', conversationId, e);
              }
            }

            await this.cpsVoiceBotProcessor.process({
              sessionId: conversationId,
              envConfig: env,

              activityToSend: {
                type: 'event',
                name: CPS_CUSTOM_EVENTS.DISCONNECT,
              },
              sipHeaderLanguage: speechLanguage,
            });

            await ivrSession.closeSession(!!session?.hangupScheduledId);
          }
        }
      } catch (err) {
        logger.error('unable to process voice events got events %o', err);
        throw new InternalServerErrorException();
      }
    }
  }
}
