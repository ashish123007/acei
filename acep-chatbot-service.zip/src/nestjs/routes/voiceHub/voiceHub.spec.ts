import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../../../app.module';
import { MessageHubRequest } from '../../../types';
import { BotEnvironment } from '../../../types/bot';
import { MicrosoftAcsEventType } from '../../../types/voice';
import { VoiceAcs } from '../../guards/voiceAcs.guard';
import { VoiceOrchestrator } from '../../providers/voiceOrchestrator.service';
import { AcsClientFactory } from '../../providers/acsCustomSdk.service';
import { IvrCallQueueService } from '../../providers/IvrCallQueue.service';
import { IVRSessionFactory } from '../../providers/ivrSession.service';
import { ContentfulService } from '../../providers/contentful.service';
import { BotConfigService } from '../../providers/botconfig.service';

@Injectable()
export class VoiceGuardsMocked implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<MessageHubRequest>();
    request.botEnvConfig = { a: 1 } as unknown as BotEnvironment;
    return true;
  }
}

const SOURCE_FROM_DATA_QP = 'sourceFromData%5Bkind%5D=phoneNumber&sourceFromData%5BphoneNumber%5D%5Bvalue%5D=%2B31020';
const CALLBACKS_QPS = `${SOURCE_FROM_DATA_QP}&conversationId=fakeCid`;

describe('VoiceHubController', () => {
  let module: TestingModule;
  let acceptCall: jest.Mock;
  let voiceOrchestratorMain: jest.Mock;
  let handover: jest.Mock;
  let terminateCall: jest.Mock;
  let recognize: jest.Mock;
  let sendScheduledMessages: jest.Mock;
  let getIvrSession: jest.Mock;

  beforeEach(async () => {
    acceptCall = jest.fn();
    voiceOrchestratorMain = jest.fn();
    handover = jest.fn();
    terminateCall = jest.fn();
    recognize = jest.fn();
    sendScheduledMessages = jest.fn();
    getIvrSession = jest.fn();
    module = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(BotConfigService)
      .useValue({})
      .overrideProvider(AcsClientFactory)
      .useValue({
        createService: () => ({
          acceptCall,
          terminateCall,
          recognize,
        }),
      })
      .overrideProvider(IvrCallQueueService)
      .useValue({
        sendScheduledMessages,
      })
      .overrideProvider(IVRSessionFactory)
      .useValue({
        createService: () => ({
          createSession: jest.fn(),
          getSession: getIvrSession,
        }),
      })
      .overrideProvider(VoiceOrchestrator)
      .useValue({
        main: voiceOrchestratorMain,
        handover,
      })
      .overrideGuard(VoiceAcs)
      .useClass(VoiceGuardsMocked)
      .overrideProvider(ContentfulService)
      .useValue({})
      .compile();
  });

  describe('/events', () => {
    it(`be able to process SubscriptionValidationEvent`, async () => {
      const app = module.createNestApplication();
      await app.init();

      const res = await request(app.getHttpServer())
        .post('/voice-hub/voice-bot/prod/events')
        .send([
          {
            eventType: MicrosoftAcsEventType.SubscriptionValidationEvent,
            data: { validationCode: '123' },
          },
        ])
        .expect(200);

      expect(res.body.validationResponse).toBe('123');
    });

    it(`be able to process IncomingCall`, async () => {
      const app = module.createNestApplication();
      await app.init();

      const res = await request(app.getHttpServer())
        .post('/voice-hub/voice-bot/prod/events')
        .send([
          {
            eventType: MicrosoftAcsEventType.IncomingCall,
            data: {
              incomingCallContext: 'incomingCallContext',
              from: {
                phoneNumber: { value: '+31' },
              },
            },
          },
        ])
        .expect(200);

      expect(acceptCall).toHaveBeenCalled();
    });
  });

  describe('/callbacks', () => {
    it(`be able to process CallConnected`, async () => {
      const app = module.createNestApplication();
      await app.init();

      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
        .send([
          {
            data: {
              callConnectionId: '123',
            },
            type: MicrosoftAcsEventType.CallConnected,
          },
        ])
        .expect(200);
      expect(voiceOrchestratorMain).toHaveBeenCalledWith('', expect.anything());
    });

    it(`be able to process RecognizeCompleted dtmf`, async () => {
      const app = module.createNestApplication();
      await app.init();
      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
        .send([
          {
            data: {
              callConnectionId: '123',
              recognitionType: 'dtmf',
              dtmfResult: {
                tones: ['one', 'two'],
              },
            },
            type: MicrosoftAcsEventType.RecognizeCompleted,
          },
        ])
        .expect(200);
      expect(voiceOrchestratorMain).toHaveBeenCalledWith('12', expect.anything());
    });

    it(`be able to process RecognizeCompleted speech`, async () => {
      const app = module.createNestApplication();
      await app.init();
      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
        .send([
          {
            data: {
              callConnectionId: '123',
              recognitionType: 'speech',
              speechResult: {
                speech: 'hypo',
              },
            },
            type: MicrosoftAcsEventType.RecognizeCompleted,
          },
        ])
        .expect(200);
      expect(voiceOrchestratorMain).toHaveBeenCalledWith('hypo', expect.anything());
    });

    it(`be able to process PlayCompleted with operationContext=handover`, async () => {
      const app = module.createNestApplication();
      await app.init();
      getIvrSession.mockResolvedValue({
        handover: {
          handoverCode: 'handoverCode',
          handoverText: 'handoverText',
        },
      });
      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
        .send([
          {
            data: {
              callConnectionId: '123',
              operationContext: 'handover',
            },
            type: MicrosoftAcsEventType.PlayCompleted,
          },
        ])
        .expect(200);
      expect(handover).toHaveBeenCalledWith(
        {
          callConnectionId: '123',
          code: 'handoverCode',
          conversationId: 'fakeCid',
          contactId: '',
          handText: 'handoverText',
        },
        { a: 1 }
      );
    });

    it(`be able to process PlayCompleted with operationContext=none`, async () => {
      const app = module.createNestApplication();
      await app.init();

      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
        .send([
          {
            data: {
              callConnectionId: '123',
              operationContext: 'none',
            },
            type: MicrosoftAcsEventType.PlayCompleted,
          },
        ])
        .expect(200);
      expect(terminateCall).toHaveBeenCalled();
    });

    it(`should hadover to default intent when recognized failed and there is no preIntent`, async () => {
      const app = module.createNestApplication();
      await app.init();

      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
        .send([
          {
            data: {
              resultInformation: { subCode: 'test' },
            },
            type: MicrosoftAcsEventType.RecognizeFailed,
          },
        ])
        .expect(200);
      expect(handover).toHaveBeenCalledWith(
        {
          callConnectionId: undefined,
          code: 'DFLT',
          conversationId: 'fakeCid',
          contactId: '',
          handText: '',
        },
        { a: 1 }
      );
    });

    it(`should hadover to pre Intent when recognized failed`, async () => {
      const app = module.createNestApplication();
      await app.init();

      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}&preIntent=HYPL`)
        .send([
          {
            data: {
              resultInformation: { subCode: 'test' },
            },
            type: MicrosoftAcsEventType.RecognizeFailed,
          },
        ])
        .expect(200);
      expect(handover).toHaveBeenCalledWith(
        {
          callConnectionId: undefined,
          code: 'HYPL',
          conversationId: 'fakeCid',
          contactId: '',
          handText: '',
        },
        { a: 1 }
      );
    });

    it(`should handover to pre Intent when play failed and there is preIntent in QS`, async () => {
      const app = module.createNestApplication();
      await app.init();

      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}&preIntent=HYPL`)
        .send([
          {
            data: {
              resultInformation: { subCode: 'test' },
            },
            type: MicrosoftAcsEventType.PlayFailed,
          },
        ])
        .expect(200);
      expect(handover).toHaveBeenCalledWith(
        {
          callConnectionId: undefined,
          code: 'HYPL',
          conversationId: 'fakeCid',
          contactId: '',
          handText: '',
        },
        { a: 1 }
      );
    });

    it(`should handover to DFLT when play failed and there is no preIntent in QS`, async () => {
      const app = module.createNestApplication();
      await app.init();

      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
        .send([
          {
            data: {
              resultInformation: { subCode: 'test' },
            },
            type: MicrosoftAcsEventType.PlayFailed,
          },
        ])
        .expect(200);
      expect(handover).toHaveBeenCalledWith(
        {
          callConnectionId: undefined,
          code: 'DFLT',
          conversationId: 'fakeCid',
          contactId: '',
          handText: '',
        },
        { a: 1 }
      );
    });

    it(`be able to process PlayCompleted with operationContext=speech`, async () => {
      const app = module.createNestApplication();
      await app.init();

      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
        .send([
          {
            data: {
              callConnectionId: '123',
              operationContext: 'speech',
            },
            type: MicrosoftAcsEventType.PlayCompleted,
          },
        ])
        .expect(200);
      expect(recognize).toHaveBeenCalled();
    });

    it(`return error in case of a missing parameter`, async () => {
      const app = module.createNestApplication();
      await app.init();

      await request(app.getHttpServer())
        .post(`/voice-hub/voice-bot/prod/callbacks?${SOURCE_FROM_DATA_QP}`)
        .send([
          {
            data: {
              callConnectionId: '123',
              operationContext: 'speech',
            },
            type: MicrosoftAcsEventType.PlayCompleted,
          },
        ])
        .expect(500);
    });
  });
});
