import { Test, TestingModule } from '@nestjs/testing';
import { IntegrationTestController } from './integration.controller';
import { NiceService } from '../../providers/nice.service';
import { logger } from '../../../utils/logger';

jest.mock('../../../utils/logger');

describe('IntegrationTestController', () => {
  let controller: IntegrationTestController;
  let niceService: NiceService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [IntegrationTestController],
      providers: [
        {
          provide: NiceService,
          useValue: {
            onSignal: jest.fn(),
          },
        },
      ],
    }).compile();

    controller = module.get<IntegrationTestController>(IntegrationTestController);
    niceService = module.get<NiceService>(NiceService);
  });

  it('should return 200 status code on success', async () => {
    const contactId = '12345';
    (niceService.onSignal as jest.Mock).mockResolvedValue(undefined);

    const result = await controller.onSignalIT({ contactId });

    expect(niceService.onSignal).toHaveBeenCalledWith(contactId, 'ITEGRATION_TEST_CODE', 'INTEGRATION_TEST_TEXT');
    expect(result).toEqual({ statusCode: 200 });
  });

  it('should return 500 status code on unknown error', async () => {
    const contactId = '54321';
    const error = new Error('Unexpected Error');
    (niceService.onSignal as jest.Mock).mockRejectedValue(error);

    const result = await controller.onSignalIT({ contactId });

    expect(niceService.onSignal).toHaveBeenCalledWith(contactId, 'ITEGRATION_TEST_CODE', 'INTEGRATION_TEST_TEXT');
    expect(logger.warn).toHaveBeenCalledWith('Onsignal receive an error %o', error);
    expect(logger.info).toHaveBeenCalledWith('err.statusCode :: %j', undefined);
    expect(logger.error).toHaveBeenCalledWith('error %o', error);
    expect(result).toEqual({ statusCode: 500 });
  });
});
