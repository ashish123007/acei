import { Body, Controller, Post } from '@nestjs/common';
import { logger } from '../../../utils/logger';
import { NiceService } from '../../providers/nice.service';

@Controller('integration-test')
export class IntegrationTestController {
  constructor(private nice: NiceService) {}

  @Post('onSignal')
  async onSignalIT(@Body() body: { contactId: string }): Promise<{ statusCode: number }> {
    try {
      await this.nice.onSignal(body.contactId, 'ITEGRATION_TEST_CODE', 'INTEGRATION_TEST_TEXT');
      return {
        statusCode: 200,
      };
    } catch (err) {
      logger.warn('Onsignal receive an error %o', err);
      logger.info('err.statusCode :: %j', err.statusCode);
      logger.error('error %o', err);
      return {
        statusCode: err.status || 500,
      };
    }
  }
}
