import { Injectable } from '@nestjs/common';
import { AcsClientFactory } from './acsCustomSdk.service';
import { NiceService } from './nice.service';
import { AcsPlayData, HandoverParams, VoiceOrchestratorParams, VoiceRequestUserType } from '../../types/voice';
import _ from 'lodash';
import loggerUtils from '../../utils/logger';
import preIntentToHandoverCode from '../../utils/preIntentToHandoverCode';
import { IVRSessionFactory } from './ivrSession.service';

import { VoiceBotResponseProcessor } from './voiceBotResponseProcessor.service';
import { ConsumeCopilot } from './copilotConsumer.service';
import constants from '../../constants';
import { BotEnvironment } from '../../types/bot';
import { CPS_CUSTOM_EVENTS } from '../../types/copilotApi.model';

const { logger } = loggerUtils;

@Injectable()
export class VoiceOrchestrator {
  constructor(
    private acsClientFactory: AcsClientFactory,
    private voiceBotResponseProcessor: VoiceBotResponseProcessor,
    private niceService: NiceService,
    private ivrSessionFactory: IVRSessionFactory,
    private cpsService: ConsumeCopilot
  ) {}

  async main(input: string, voiceOrchestratorParams: VoiceOrchestratorParams, timeout = false) {
    const { callConnectionId, contactId, conversationId, speechLanguage, target, env, preIntent } =
      voiceOrchestratorParams;
    try {
      const voiceResponse = await this.voiceBotResponseProcessor.process(input, voiceOrchestratorParams, timeout);
      if (!voiceResponse) {
        return null;
      }
      logger.info('[%s] voiceResponse %j', conversationId, voiceResponse);
      const { type, payload, requestTypeFromUser, bargeIn, handoverCode, handoverText, dtmfOptions } = voiceResponse;

      const acsClient = this.acsClientFactory.createService(callConnectionId, conversationId);

      let playPrompt: AcsPlayData | undefined;
      if (type === 'staticAudioLink') {
        playPrompt = {
          kind: 'file',
          playSourceCacheId: payload, // provide link, used for cache
          file: {
            uri: payload,
          },
        };
      } else if (type === 'ssml') {
        playPrompt = {
          kind: 'ssml',
          ssml: {
            ssmlText: payload,
          },
        };
      } else if (type === 'none') {
        await this.handover(
          {
            code: handoverCode || preIntentToHandoverCode(preIntent || ''),
            handText: handoverText || '',
            callConnectionId,
            conversationId,
            contactId,
          },
          env
        );
        return;
      }
      if (requestTypeFromUser == VoiceRequestUserType.DTMF || requestTypeFromUser == VoiceRequestUserType.SPEECH) {
        await acsClient.recognize({
          targetParticipantInfo: target,
          requestType: requestTypeFromUser,
          speechLanguage,
          bargeInEnabled: bargeIn,
          playPrompt,
          dtmfOptions,
        });
      } else if (playPrompt) {
        let operationContext: string = requestTypeFromUser;
        if (handoverCode) {
          operationContext = 'handover';
          const ivrSession = this.ivrSessionFactory.createService(callConnectionId);
          await ivrSession.updateHandoverInfo({
            handoverCode,
            handoverText,
          });
        }
        await acsClient.play(playPrompt, operationContext);
      }
    } catch (e) {
      logger.error('[%s] error processing voice call %o, fallback to handover', conversationId, e);
      // eslint-disable-next-line @typescript-eslint/require-await
      this.handover(
        {
          code: preIntentToHandoverCode(preIntent || ''),
          handText: '',
          callConnectionId,
          conversationId,
          contactId,
        },
        env
      )
        .then(() => {
          logger.debug('[%s] handover ok for callConnectionId %s', conversationId, callConnectionId);
        })
        .catch(() => {
          logger.error('[%s] handover failed for callConnectionId %s', conversationId, callConnectionId);
        });
    }
  }

  async handover(handoverParams: HandoverParams, envConfig: BotEnvironment) {
    const { code, callConnectionId, contactId, conversationId, handText } = handoverParams;
    logger.info('[%s] Handover invoked with the code: %s and the contact Id: %s', conversationId, code, contactId);
    const acsClient = this.acsClientFactory.createService(callConnectionId, conversationId);
    // contactId is present only on acceptance and production
    try {
      if (contactId) {
        logger.info('[%s] doing onSignal', conversationId);
        await this.niceService.onSignal(contactId, code, handText);
        logger.info('[%s] OnSignal handover successful', conversationId);
        this.cpsService.getAllActivities({
          activity: { type: 'event', name: CPS_CUSTOM_EVENTS.NICE_HANDOVER, value: code },
          conversationId,
          envConfig,
        });
      } else {
        logger.info(`[%s] contactId missing on env:: ${envConfig.name}`, conversationId);
      }
    } catch (e) {
      logger.error('[%s] Error in the handover', conversationId, e);
    }
    // For lower environments(DTA) ONLY: Simulate handover to live agent
    if (envConfig.name.toLowerCase() !== 'prod' && !contactId) {
      try {
        await acsClient.play(
          {
            kind: 'ssml',
            ssml: {
              ssmlText: `<speak version='1.0' xml:lang='nl-NL'>
                    <voice name="nl-NL-FennaNeural">
                      Handover met code <say-as interpret-as="characters">${code}</say-as>
                    </voice>
                  </speak>`,
            },
          },
          'none'
        );
      } catch (e) {
        logger.error('[%s] Unable to play tts static handover code', conversationId);
      }
    } else {
      try {
        await acsClient.terminateCall();
      } catch (e) {
        logger.error('[%s] Unable to terminate call', conversationId);
      }
    }
  }
}
