import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../../app.module';
import { ServiceBusQueue } from '../../utils/serviceBusQueue';
import { IvrCallQueueService } from './IvrCallQueue.service';
import { MSDQueueService } from './MSDQueue.service';
import { MSDSessionFactory } from './msdSession.service';
import { ContentfulService } from './contentful.service';
import { BotConfigService } from './botconfig.service';
import path from 'path';

jest.mock('path');

jest.spyOn(global, 'setImmediate').mockImplementation((callback: () => any) => {
  return callback() as any;
});

jest.mock('../../config', () => ({
  ENVIRONMENT: 'jest',
  FEATURE_FLAGS: 'autoSubscribeMsdQueue',
  IVR_CALL_QUEUE_NAME: 'queue-name',
  MSD_QUEUE_NAME: 'queue-name',
  databaseOpts: {
    endpoint: 'https://local.cosmos',
  },
  iagApi: {
    localSanValue: '',
    cert: '',
    key: '',
    endpoint: '',
  },
}));
const ServiceBusQueueMocked = ServiceBusQueue as jest.MockedClass<typeof ServiceBusQueue>;

jest.mock('../../utils/serviceBusQueue');

describe('MSDQueueService', () => {
  let service: MSDQueueService;
  let createService: jest.Mock;
  let subscribeMock: jest.Mock;
  let replaceSession: jest.Mock;
  let getSession: jest.Mock;
  let createSession: jest.Mock;
  let cancelScheduledMessages: jest.Mock;

  beforeEach(async () => {
    createService = jest.fn();
    replaceSession = jest.fn();
    getSession = jest.fn();
    createSession = jest.fn();
    cancelScheduledMessages = jest.fn();
    ServiceBusQueueMocked.mockReset();

    const module: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(BotConfigService)
      .useValue({})
      .overrideProvider(MSDSessionFactory)
      .useValue({
        createService: () => ({
          replaceSession,
          getSession,
          createSession,
        }),
      })
      .overrideProvider(IvrCallQueueService)
      .useValue({})
      .overrideProvider(ContentfulService)
      .useValue({})
      .compile();

    service = module.get<MSDQueueService>(MSDQueueService);
    service.sendScheduledMessages = jest.fn().mockResolvedValue(['seqNum']);
    service.cancelScheduledMessages = cancelScheduledMessages;

    subscribeMock = ServiceBusQueueMocked.mock.instances[0].subscribe as jest.Mock;
  });

  it('should be defined and subscribeMock called', () => {
    expect(service).toBeDefined();
    expect(subscribeMock).toHaveBeenCalled();
  });

  it('should be able to schedule a first a message with an active session', async () => {
    getSession.mockResolvedValueOnce({
      messageDeletionId: 'messageDeletionId123',
    });

    await service.updateMsdSession('conv:123', 'bc:12');

    expect(getSession).toHaveBeenCalled();
    expect(cancelScheduledMessages).toHaveBeenCalledWith('messageDeletionId123');
    expect(replaceSession).toHaveBeenCalledWith('seqNum');
  });

  it('should be able to schedule a first a message with no active session', async () => {
    getSession.mockResolvedValueOnce(null);

    await service.updateMsdSession('conv:123', 'bc:12');

    expect(getSession).toHaveBeenCalled();
    expect(createSession).toHaveBeenCalledWith({ messageDeletionId: 'seqNum' });
  });
});
