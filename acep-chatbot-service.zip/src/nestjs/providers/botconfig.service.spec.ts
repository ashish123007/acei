import { Test, TestingModule } from '@nestjs/testing';
import { BotConfigService } from './botconfig.service';
import { ConfigurationService } from '../../utils/configuration.service';

describe('BotConfigService', () => {
  let service: BotConfigService;
  let configService: ConfigurationService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        { provide: ConfigurationService, useValue: { getConfig: jest.fn(() => ({ bots: [] })) } },
        BotConfigService,
      ],
    }).compile();

    service = module.get<BotConfigService>(BotConfigService);
  });
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
