import { Injectable } from '@nestjs/common';
import { Activity, GetActivitiesResponse, CPS_CUSTOM_EVENTS } from '../../types/copilotApi.model';
import WebSocket from 'ws';
import loggerUtils from '../../utils/logger';

const { logger } = loggerUtils;

const askForCustomerInputEventReceived = (activities?: Activity[]) => {
  if (!activities) {
    return false;
  }
  return activities.some(
    (activity: Activity) => activity.type === 'event' && activity.value === CPS_CUSTOM_EVENTS.ASK_FOR_CUSTOMER_INPUT
  );
};

@Injectable()
export class WebsocketService {
  private getTimeoutPromise = async (timeoutMs: number): Promise<never> =>
    new Promise((_resolve, reject) => {
      setTimeout(() => reject(new Error('Copilot timeout')), timeoutMs);
    });

  private getWebSocketPromise = async (wsClient: WebSocket, onConnected?: () => void): Promise<Activity[]> => {
    const wsPromise = new Promise<Activity[]>((resolve, reject) => {
      const activities: Activity[] = [];
      wsClient.onmessage = function handleNewWebSocketMessage(data: WebSocket.MessageEvent) {
        try {
          logger.debug('received websocket message %s', data.data);
          const webSocketActivities = JSON.parse(data.data.toString()) as GetActivitiesResponse;
          if (webSocketActivities.activities.some((activity) => activity.channelData?.askForCustomerInput)) {
            // in case we receive askForCustomerInput: true in channelData we need to immediately resolve all the activities (including current one)
            activities.push(...webSocketActivities.activities);
            resolve(activities);
          } else if (askForCustomerInputEventReceived(webSocketActivities && webSocketActivities.activities)) {
            // in case we receive askForCustomerInput as an activity we need to resolve all the activities (excluding current one)
            resolve(activities);
          } else {
            // in case we dont receive askForCustomerInput in the channelData or as a separate activity we need to store current activities so they can be returned later
            logger.debug('no end activity detected %o', { activities: webSocketActivities.activities });
            activities.push(...webSocketActivities.activities);
          }
        } catch (err) {
          logger.error('Error processing websocket message: %o, data that caused issue: %o', err, data);
          reject(err);
        }
      };
      wsClient.onerror = function (event: WebSocket.ErrorEvent) {
        logger.error('An error has occured while consuming CPS websocket %o', event);
        reject(event);
      };
      wsClient.on('open', function open() {
        onConnected && onConnected();
      });
    });

    return wsPromise;
  };

  async fetchActivitiesFromWebSocket(url: string, onConnected: () => void, timeout = 5000): Promise<Activity[]> {
    const wsClient = new WebSocket(url);

    return Promise.race([this.getWebSocketPromise(wsClient, onConnected), this.getTimeoutPromise(timeout)])
      .catch((error) => {
        logger.error('Error while fetching activities from websocket: %o', error);
        return [];
      })
      .finally(() => {
        logger.debug('ws closed');
        wsClient.close();
      });
  }
}
