import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { validate } from 'nestjs-zod';
import { logger } from '../../../utils/logger';
import { VahResponseDto } from '../../../types';
import { BotEnvironment } from '../../../types/bot';
import { Message } from '../../../types/machineTypes';
import { OrchestratorService } from '../orchestrator.service';

@Injectable()
export class VahService {
  constructor(private orchestratorService: OrchestratorService) {}

  async handleVahRequest(body: Message, envConfig: BotEnvironment) {
    delete body.botConfig;
    logger.info('Received VAH request :: request body: %j', body);
    const { contactId } = body.executionInfo;
    const conversationId = String(contactId);
    const response = await this.orchestratorService.handleRequest(conversationId, body, envConfig);
    logger.info('Recieved response ::  response ', response);
    const validatedResponse = validate(
      response,
      VahResponseDto,
      (zodError) => new InternalServerErrorException(zodError)
    );
    logger.info('Validate response :: ', validatedResponse);
    return validatedResponse;
  }
}
