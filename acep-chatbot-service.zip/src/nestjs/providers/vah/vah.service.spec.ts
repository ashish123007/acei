import { Test, TestingModule } from '@nestjs/testing';
import { VahService } from './vah.service';
import { OrchestratorService } from '../orchestrator.service';

describe('VahService', () => {
  let service: VahService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        VahService,
        {
          provide: OrchestratorService,
          useValue: {
            handleRequest: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<VahService>(VahService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
