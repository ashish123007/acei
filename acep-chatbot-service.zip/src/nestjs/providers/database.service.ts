import { Injectable } from '@nestjs/common';
import config from '../../config';
import { CopilotSessionTable } from '../../types';
import { CosmosV2 } from '../../utils/cosmos';

const { SESSION_TABLE } = config;

export abstract class DatabaseService {
  abstract getSessionById(sessionId: string): Promise<CopilotSessionTable | undefined>;
  abstract updateSession(sessionId: string, newSession: CopilotSessionTable): Promise<void>;
  abstract createSession(conversationId: string, payload: CopilotSessionTable): Promise<unknown>;
}

@Injectable()
export class DatabaseCosmosService implements DatabaseService {
  async getSessionById(sessionId: string) {
    const sessionService = new CosmosV2<CopilotSessionTable>(SESSION_TABLE, sessionId, sessionId);
    return await sessionService.get();
  }

  async updateSession(sessionId: string, newSession: CopilotSessionTable) {
    const sessionService = new CosmosV2<CopilotSessionTable>(SESSION_TABLE, sessionId, sessionId);
    await sessionService.update(newSession);
  }

  async createSession(conversationId: string, payload: CopilotSessionTable) {
    try {
      const sessionService = new CosmosV2<CopilotSessionTable>(SESSION_TABLE, conversationId, conversationId);
      return await sessionService.create(payload);
    } catch (error) {
      throw new Error('Error encountered upon creating a new session.');
    }
  }
}

@Injectable()
export class DatabaseLocalService implements DatabaseService {
  private sessionLocalStorage = new Map<string, CopilotSessionTable>();

  async getSessionById(sessionId: string): Promise<CopilotSessionTable | undefined> {
    return Promise.resolve(this.sessionLocalStorage.get(sessionId));
  }

  async updateSession(sessionId: string, newSession: CopilotSessionTable): Promise<void> {
    this.sessionLocalStorage.set(sessionId, newSession);
  }

  async createSession(conversationId: string, payload: CopilotSessionTable) {
    this.sessionLocalStorage.set(conversationId, payload);
  }
}
