import { Injectable } from '@nestjs/common';
import { CosmosV2 } from '../../utils/cosmos';

import config from '../../config';
import constants from '../../constants';
import { ServBusScheduleId } from '../../types/utils';
import { PatchOperation, PatchOperationType } from '@azure/cosmos';

const { SESSION_TABLE } = config;
const { TTL_IVR_SESSION_MINS } = constants;

export interface IVRSession {
  id: string;
  partition: string;
  type: string;
  ttl: number;
  conversationId: string;
  hangupScheduledId?: ServBusScheduleId;
  callConnectedAt?: number;
  callDisconnectedAt?: number;
  handover?: {
    handoverCode: string;
    handoverText?: string;
  };
}

class IvrSesion {
  private cosmos: CosmosV2<IVRSession>;

  constructor(private callId: string) {
    this.cosmos = new CosmosV2<IVRSession>(SESSION_TABLE, callId, callId);
  }

  async createSession(session: Pick<IVRSession, 'conversationId' | 'hangupScheduledId'>) {
    await this.cosmos.create({
      id: this.callId,
      partition: this.callId,
      type: 'ivr',
      ttl: TTL_IVR_SESSION_MINS,
      callConnectedAt: Date.now(),
      ...session,
    });
  }

  async closeSession(removeSchedulerId: boolean) {
    const operations: PatchOperation[] = [
      { op: PatchOperationType.set, path: '/callDisconnectedAt', value: Date.now() },
    ];

    if (removeSchedulerId) {
      operations.push({ op: PatchOperationType.remove, path: '/hangupScheduledId' });
    }

    await this.cosmos.patch(operations);
  }

  async updateHandoverInfo(handover: Exclude<IVRSession['handover'], undefined>) {
    const operations: PatchOperation[] = [{ op: PatchOperationType.set, path: '/handover', value: handover }];

    await this.cosmos.patch(operations);
  }

  async removeSchedulerId() {
    await this.cosmos.patch([{ op: PatchOperationType.remove, path: '/hangupScheduledId' }]);
  }

  getSession() {
    return this.cosmos.get();
  }
}

@Injectable()
export class IVRSessionFactory {
  createService(callId: string): IvrSesion {
    return new IvrSesion(callId);
  }
}
