import { Injectable } from '@nestjs/common';
import loggerUtils from '../../utils/logger';
import config from '../../config';
import { ServiceBusQueue } from '../../utils/serviceBusQueue';
import { AcsClientFactory } from './acsCustomSdk.service';
import { IVRSessionFactory } from './ivrSession.service';

const { logger } = loggerUtils;
const { ENVIRONMENT, SERVICEBUS_NAMESPACE, IVR_CALL_QUEUE_NAME } = config;

@Injectable()
export class IvrCallQueueService extends ServiceBusQueue<{ id: string; conversationId: string }> {
  constructor(
    private acsClientFactory: AcsClientFactory,
    private ivrSessionFactory: IVRSessionFactory
  ) {
    super(SERVICEBUS_NAMESPACE, IVR_CALL_QUEUE_NAME);
    this.subscribeFromQueue();
  }

  subscribeFromQueue() {
    if (ENVIRONMENT !== 'local') {
      if (IVR_CALL_QUEUE_NAME === undefined) {
        throw new Error('IvrCall Queue Name is not defined');
      }
      logger.info('Starting to listen on %j', IVR_CALL_QUEUE_NAME);
      this.subscribe(
        async (messageReceived) => {
          logger.info('Received message from ivr queue %j', messageReceived.body);
          const connectionId = messageReceived.body?.id;
          const conversationId = messageReceived.body?.conversationId;
          const acsClient = this.acsClientFactory.createService(connectionId, conversationId);
          const ivrSession = this.ivrSessionFactory.createService(connectionId);

          try {
            await ivrSession.removeSchedulerId();
            await acsClient.terminateCall();
          } catch (error) {
            logger.error('[%s] Unable to process ivr queue message with error %o', conversationId, error);
          }
        },
        async (error) => {
          logger.error('IvrCallQueue Consumer error :: %o', error);
          return Promise.resolve();
        }
      );
    } else {
      logger.info('IvrCallQueue.subscribe not available locally.');
    }
  }
}
