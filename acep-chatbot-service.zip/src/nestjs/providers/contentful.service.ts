import { Injectable } from '@nestjs/common';
import config from '../../config';
import * as Contentful from 'contentful';
import constants from '../../constants';
import { TypeVoicebotPoCFields } from '../../types/generated/contentful';
import { getContentfulEntries } from '../../utils-cps/contentfulCps';

const { API_CALL_DEFAULT_TIMEOUT } = constants;
const { contentful, contentfulPreview, contentfulPreviewEnvironments, ENVIRONMENT } = config;

@Injectable()
export class ContentfulService {
  private client;

  constructor() {
    const settings = contentfulPreviewEnvironments.includes(ENVIRONMENT) ? contentfulPreview : contentful;
    this.client = Contentful.createClient({
      timeout: API_CALL_DEFAULT_TIMEOUT,
      ...settings,
    });
  }

  async getEntries(ids: string[], languagePreference: string) {
    const contentfulEntries = await getContentfulEntries<TypeVoicebotPoCFields>(ids, this.client, languagePreference);
    return contentfulEntries;
  }
}
