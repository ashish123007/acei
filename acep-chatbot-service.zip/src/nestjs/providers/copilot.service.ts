import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom, catchError, EmptyError, throwError } from 'rxjs';
import { AxiosError } from 'axios';
import config from '../../config';
import loggerUtils from '../../utils/logger';
import { HTTPMethod } from '../../types';
import { ActivityToSend, ConversationResponse } from '../../types/copilotApi.model';

const { logger } = loggerUtils;

const REQUEST_TIMEOUT_MS = 5000;

@Injectable()
export class CopilotService {
  constructor(private readonly httpService: HttpService) {}

  private getRequestConfig<T>(secretKey: string, path: string, method: HTTPMethod, data?: T) {
    return {
      method,
      url: `${config.copilotApi.url}${path}`,
      headers: {
        Authorization: `Bearer ${secretKey}`,
        'Content-Type': 'application/json',
      },
      data,
      timeout: REQUEST_TIMEOUT_MS,
    };
  }

  async initiateConversation<T = ConversationResponse>(secretKey: string, conversationId: string) {
    const payload = {
      user: {
        id: conversationId,
      },
    };
    const requestConfig = this.getRequestConfig(secretKey, '/conversations', HTTPMethod.post, payload);
    const { data } = await firstValueFrom(
      this.httpService.request<T>(requestConfig).pipe(
        catchError((error: AxiosError) => {
          logger.error('Error initiating conversation on /conversations :: %o', error);
          throw error;
        })
      )
    );
    return data as T;
  }

  async getConversation<T>(secretKey: string, conversationId: string) {
    const requestConfig = this.getRequestConfig(secretKey, `/conversations/${conversationId}`, HTTPMethod.get);
    const { data } = await firstValueFrom(
      this.httpService.request<T>(requestConfig).pipe(
        catchError((error: AxiosError) => {
          if (error instanceof EmptyError) {
            return throwError(() => new Error('No response from the API'));
          }
          logger.error(`Error while doing a GET on /conversations/${conversationId} :: %o`, error);
          throw error;
        })
      )
    );
    return data as T;
  }

  async sendActivity<T>(secretKey: string, conversationId: string, activity: ActivityToSend, sessionId: string) {
    logger.verbose('[%s] Sending activity %j', conversationId, activity);
    const requestConfig = this.getRequestConfig(
      secretKey,
      `/conversations/${conversationId}/activities`,
      HTTPMethod.post,
      {
        ...activity,
        from: {
          id: sessionId,
        },
      }
    );
    const { data } = await firstValueFrom(
      this.httpService.request<T>(requestConfig).pipe(
        catchError((error: AxiosError) => {
          logger.error(`Error while doing a POST on /conversations/${conversationId}/activities:: %o`, error);
          throw error;
        })
      )
    );
    return data as T;
  }

  async getActivities(secretKey: string, conversationId: string, watermark: string) {
    const requestConfig = this.getRequestConfig(
      secretKey,
      `/conversations/${conversationId}/activities?watermark=${watermark}`,
      HTTPMethod.get
    );
    const { data } = await firstValueFrom(
      this.httpService.request(requestConfig).pipe(
        catchError((error: AxiosError) => {
          logger.error('An error has accured while using Copilot service %o', error);
          throw error;
        })
      )
    );
    return data;
  }
}
