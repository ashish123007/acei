import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { Activity, ActivityToSend, CPS_CUSTOM_EVENTS, PrivateInputEvent } from '../../types/copilotApi.model';
import loggerUtils from '../../utils/logger';
import { DatabaseService } from './database.service';
import { BotEnvironment } from '../../types/bot';
import constants from '../../constants';
import { CopilotSessionTable, PrehookResponse, VahBody, VoiceBody } from '../../types';
import { WebhookNCDService } from './webhook-ncd.service';
import _ from 'lodash';
import { CopilotRequest, CopilotResponse, LogConfigProviders, LogType } from '../../azure-monitor/azureMonitorConfig';
import { ConsumeCopilot } from './copilotConsumer.service';
import updateMaskedInput from '../../utils/UpdateMaskedInput';
import { JsonMap } from '../../types/utils';
import { replacePrivateData } from '../../utils-cps/replacePrivateData';
import { getLogsForAzureMonitor } from '../../azure-monitor/azureMonitorService';
import azureMonitor from '../../azure-monitor';

const { TTL_ANNA_BOT_SESSION_SECONDS, DB_ITEM_TYPES } = constants;
const { logger } = loggerUtils;
const {
  SET_CONTEXT,
  RESTART_CONVERSATION,
  LANGUAGE_CHANGED,
  ASK_FOR_CUSTOMER_INPUT,
  CAAS_EVENT,
  METRICS,
  WEBHOOK_REQUEST,
} = CPS_CUSTOM_EVENTS;

export const copilotChatLogsProvider = LogConfigProviders.AZURE_MONITOR;
export const COPILOT_ACTIVITIES_CL = 'COPILOT_ACTIVITIES_CL';
const errorInPrehookMessage = {
  branchName: 'PromptAndCollectNextResponse',
  nextPromptSequence: {
    prompts: [
      {
        transcript: 'Er lijkt wat fout te gaan. Probeer het later nog eens.',
        mediaSpecificObject: {
          buttons: [],
          type: 'bot',
          contents: [
            {
              type: 'text',
              text: 'Er lijkt wat fout te gaan. Probeer het later nog eens.',
            },
          ],
        },
      },
    ],
  },
};

@Injectable()
export class OrchestratorService {
  constructor(
    private hooksService: WebhookNCDService,
    private consumeCopilotService: ConsumeCopilot,
    private databaseService: DatabaseService
  ) {}

  handleSetContext(activities: Activity[], context: CopilotSessionTable) {
    let updatedContext: CopilotSessionTable | undefined = context;
    activities.forEach(({ name, value }: Activity) => {
      if (name === SET_CONTEXT) {
        const objectProps = (value as Partial<CopilotSessionTable>) ?? {};
        updatedContext = {
          ...updatedContext,
          ...objectProps,
        } as CopilotSessionTable;
      }
    });
    return updatedContext;
  }

  handlePrivateInput(message: Activity | undefined, context: CopilotSessionTable, privateData: JsonMap) {
    const tempPrivateData = privateData;
    const tempContext = context;
    let text = message?.text;
    if (message?.text && context.privateInput && message.type !== 'event') {
      tempPrivateData[context.privateInput] = message.text;
      text = context.privateInput;
      tempContext.privateInput = '';
    }
    if (LANGUAGE_CHANGED === message?.name || RESTART_CONVERSATION === message?.name) {
      tempContext.privateInput = '';
    }
    return { text: text ? updateMaskedInput(text) : undefined, context: tempContext, privateData: tempPrivateData };
  }

  removeCpsEvents(activities: Activity[]) {
    const NOT_SUPPORTED_EVENT_NAMES: string[] = [
      METRICS,
      CAAS_EVENT,
      ASK_FOR_CUSTOMER_INPUT,
      WEBHOOK_REQUEST,
      SET_CONTEXT,
    ];
    return activities.filter((activity) => !NOT_SUPPORTED_EVENT_NAMES.includes(activity.name ?? ''));
  }

  async handleRequest(conversationId: string, requestBody: VahBody | VoiceBody, envConfig: BotEnvironment) {
    try {
      const session = await this.getOrCreateSession(conversationId, envConfig);

      const prehookResponse = await this.hooksService.preHook(
        { ...requestBody, context: session, privateData: session.privateData },
        envConfig
      );
      logger.info('prehook response: %o', prehookResponse);

      if (!prehookResponse?.message) {
        logger.warn('No message after prehook response, input was %o', requestBody);
        return errorInPrehookMessage;
      }

      const { text, context, privateData } = this.handlePrivateInput(
        prehookResponse.message,
        { ...session, ...prehookResponse?.context },
        { ...session.privateData, ...prehookResponse?.privateData }
      );

      const userRequests = [
        getLogsForAzureMonitor(
          {
            conversationId,
            copilotConversationId: context.copilotConversationId,
            botId: context.botId || '',
            chat_session_id: context.chatSessionId || '',
          },
          { userActivityStringified: JSON.stringify(prehookResponse?.message) }
        ) as CopilotRequest,
      ];
      await azureMonitor(copilotChatLogsProvider, COPILOT_ACTIVITIES_CL, userRequests);

      const cpsActivities = await this.consumeCopilotService.getCopilotActivities(
        session.copilotConversationId,
        { ...((prehookResponse as PrehookResponse).message as ActivityToSend), text } as ActivityToSend,
        envConfig,
        conversationId
      );

      const botResponses = [
        getLogsForAzureMonitor(
          {
            conversationId,
            copilotConversationId: context.copilotConversationId,
            botId: session.botId || '',
            chat_session_id: context.chatSessionId ?? '',
          },
          { activities: cpsActivities },
          LogType.RESPONSE
        ) as CopilotResponse,
      ];
      await azureMonitor(copilotChatLogsProvider, COPILOT_ACTIVITIES_CL, botResponses);

      const updatedContext = this.handleSetContext(cpsActivities, context);
      let {
        context: webhookContext,
        privateData: webhookPrivateData,
        activities: webhookActivities,
      } = await this.hooksService.webhook(session.copilotConversationId, cpsActivities, {
        conversationId,
        envConfig,
        context: updatedContext,
        privateData,
      });

      webhookActivities = webhookActivities.filter((activity) => {
        if (activity.name === CPS_CUSTOM_EVENTS.PRIVATE_INPUT) {
          const {
            payload: { value: requestedInput },
          } = activity.value as PrivateInputEvent;
          webhookContext.privateInput = requestedInput;
          return false;
        }
        return true;
      });

      webhookActivities = replacePrivateData(webhookActivities, webhookPrivateData);
      webhookActivities = this.removeCpsEvents(webhookActivities);

      const posthookResponse = await this.hooksService.postHook(
        webhookActivities,
        { ...webhookContext, privateData: webhookPrivateData },
        envConfig
      );

      this.updateSession(conversationId, session, {
        ...posthookResponse.context,
        privateData: posthookResponse.privateData,
        isFirstMessage: false,
      });
      return posthookResponse.activities;
    } catch (error) {
      logger.error('[%s] Error: %j', conversationId, error);
      throw new InternalServerErrorException();
    }
  }

  async updateSession(conversationId: string, oldSession: CopilotSessionTable, newSession: CopilotSessionTable) {
    const isSessionModified = !_.isEqual(oldSession, newSession);
    if (isSessionModified) {
      await this.databaseService.updateSession(conversationId, newSession);
    }
  }

  async getOrCreateSession(conversationId: string, envConfig: BotEnvironment): Promise<CopilotSessionTable> {
    const { botId, cpsInstance } = envConfig;
    const secret = cpsInstance?.secretKey;

    if (!secret) {
      throw new InternalServerErrorException(`[${conversationId}] CPS Key not defined`);
    }

    const existingSession = await this.databaseService.getSessionById(conversationId);
    if (existingSession) {
      return existingSession;
    } else {
      const cpsConversation = await this.consumeCopilotService.initiateNewConversation(secret, conversationId);
      const payload = {
        botId,
        partition: conversationId,
        type: DB_ITEM_TYPES.SESSION,
        copilotConversationId: cpsConversation.conversationId,
        id: conversationId,
        ttl: TTL_ANNA_BOT_SESSION_SECONDS,
        privateData: {},
        isFirstMessage: true,
        noChannelData: true,
        meta: envConfig?.meta,
      };

      await this.databaseService.createSession(conversationId, payload);
      return payload;
    }
  }
}
