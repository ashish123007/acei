import { parseClientArguments, createCommunicationAuthPolicy } from '@azure/communication-common';
import * as coreClient from '@azure/core-client';
import { createHttpHeaders, createPipelineRequest, createEmptyPipeline } from '@azure/core-rest-pipeline';
import config from '../../config';
import loggerUtls from '../../utils/logger';
import { Injectable } from '@nestjs/common';
import { AcsPlayData, VoiceRequestUserType, AcsRecognizeParameters } from '../../types/voice';
import { HTTPMethod } from '../../types';
import { DefaultAzureCredential } from '@azure/identity';

const { ACS_COGNITIVE_SERVICE_URL, ACS_URL, ACS_API_VERSION } = config;

const { logger } = loggerUtls;
const { ACS_CONNECTION_STRING } = config;

const authPolicy = createCommunicationAuthPolicy(new DefaultAzureCredential());
const pipeline = createEmptyPipeline();
pipeline.addPolicy(authPolicy);

class AcsClient {
  private acsHost: string;
  private acsEndpoint: string;
  private client: coreClient.ServiceClient;

  constructor(
    private connectionId: string,
    private conversationId: string
  ) {
    const { url } = parseClientArguments(ACS_CONNECTION_STRING);
    this.acsHost = new URL(url).host;
    this.acsEndpoint = ACS_URL;
    this.client = new coreClient.ServiceClient({
      pipeline,
    });
  }

  private async acsApiCall(body: unknown, path: string, method: HTTPMethod = HTTPMethod['post']) {
    const operationId = path.split(':').at(-1);
    logger.info('[%s] sending acs api for operationId: %s', this.conversationId, operationId);
    logger.verbose('[%s] sending acs api for operationId: %s with body %s', this.conversationId, operationId, body);
    const isGet = method === HTTPMethod['get'];
    const request = createPipelineRequest({
      url: `${this.acsEndpoint}/${path}?api-version=${ACS_API_VERSION}`,
      method,
      ...(!isGet && { body: JSON.stringify(body) }),
      headers: createHttpHeaders({
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Forwarded-Host': this.acsHost,
      }),
    });
    try {
      const response = await this.client.sendRequest(request);
      if (response.status >= 200 && response.status < 300) {
        logger.info('[%s] acs api success %s', this.conversationId, operationId);
        logger.verbose('[%s] acs api success %s :: with response %s', this.conversationId, operationId, response);
      } else {
        logger.error('[%s] ACS-Failure-API :: response: %j', this.conversationId, response);
        throw new Error('acs api failure');
      }
    } catch (err) {
      logger.error('[%s] ACS-Failure-API :: with err %o', this.conversationId, err);
      throw err;
    }
  }

  async play(playSourceInfo: AcsPlayData, operationContext?: string) {
    const body = {
      playSources: [playSourceInfo],
      playOptions: {
        loop: false,
      },
      operationContext,
    };
    return await this.acsApiCall(body, `calling/callConnections/${this.connectionId}:play`);
  }

  async recognize(recognizeParams: AcsRecognizeParameters) {
    let recognizeInputType;
    let recognizeOptions;

    const { requestType, bargeInEnabled, targetParticipantInfo, operationContext, playPrompt, dtmfOptions } =
      recognizeParams;

    let { speechLanguage } = recognizeParams;

    if (speechLanguage === 'nl') {
      speechLanguage = 'nl-NL';
    }
    if (speechLanguage === 'en') {
      speechLanguage = 'en-US';
    }

    if (requestType === VoiceRequestUserType.SPEECH) {
      recognizeInputType = 'speech';
      recognizeOptions = {
        interruptPrompt: bargeInEnabled,
        initialSilenceTimeoutInSeconds: 5,
        speechLanguage: speechLanguage,
        targetParticipant: targetParticipantInfo,
        speechOptions: {
          endSilenceTimeoutInMs: 500,
        },
      };
    } else {
      recognizeInputType = 'dtmf';
      const dtmfParameters = {
        stopTones: ['pound'],
        maxTonesToCollect: dtmfOptions?.maxTonesToCollect,
      };
      recognizeOptions = {
        interruptPrompt: bargeInEnabled,
        initialSilenceTimeoutInSeconds: 5,
        targetParticipant: targetParticipantInfo,
        dtmfOptions: dtmfParameters,
      };
    }

    const recognizeRequest = {
      recognizeInputType,
      recognizeOptions,
      operationContext,
      playPrompt,
    };

    return await this.acsApiCall(recognizeRequest, `calling/callConnections/${this.connectionId}:recognize`);
  }

  async acceptCall(incomingCallContext: string, callbackUri: string) {
    const acceptCallbody = {
      incomingCallContext: incomingCallContext,
      callbackUri: callbackUri,
      callIntelligenceOptions: {
        cognitiveServicesEndpoint: ACS_COGNITIVE_SERVICE_URL,
      },
    };
    return await this.acsApiCall(acceptCallbody, 'calling/callConnections:answer');
  }

  async terminateCall() {
    return await this.acsApiCall({}, `calling/callConnections/${this.connectionId}`, HTTPMethod['delete']);
  }
}

@Injectable()
export class AcsClientFactory {
  createService(connectionId: string, conversationId: string): AcsClient {
    return new AcsClient(connectionId, conversationId);
  }
}
