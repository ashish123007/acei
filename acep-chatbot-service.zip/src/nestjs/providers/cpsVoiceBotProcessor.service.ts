import { Injectable } from '@nestjs/common';
import { BotEnvironment } from '../../types/bot';
import * as Contentful from 'contentful';
import * as CFRichTextTypes from '@contentful/rich-text-types';
import _ from 'lodash';
import loggerUtils from '../../utils/logger';
import { TypeResponse, TypeVoicebotPoCFields } from '../../types/generated/contentful';
import { VoiceBotResponse, VoiceRequestUserType } from '../../types/voice';
import { VoiceConstants } from '../../constants/voice';
import { ConsumeCopilot } from './copilotConsumer.service';
import { ContentfulService } from './contentful.service';
import { Activity, ActivityToSend, HandoverValues, CPS_CUSTOM_EVENTS, DtmfValues } from '../../types/copilotApi.model';
import { filterByCustomConditions } from '../../utils-cps/formatter';
import updateMaskedInput from '../../utils/UpdateMaskedInput';
import preIntentToHandoverCode from '../../utils/preIntentToHandoverCode';

const { logger } = loggerUtils;

@Injectable()
export class CpsVoiceBotProcessor {
  constructor(
    private getCopilotActivitiesClient: ConsumeCopilot,
    private contentfulService: ContentfulService
  ) {}

  static getAggregatedTextContentFromEntryResponses(
    entry: Contentful.EntryWithLinkResolutionAndWithUnresolvableLinks<TypeVoicebotPoCFields>
  ) {
    return (entry.fields.responses as TypeResponse[])
      .flatMap((response) => response.fields.answerText.content.flatMap((c) => (c as CFRichTextTypes.Block).content))
      .filter((c) => c.nodeType === 'text')
      .reduce((acc, current) => {
        return acc + (current as CFRichTextTypes.Text).value;
      }, '');
  }

  static formatPayload(payloadContent: string) {
    return `<speak version='1.0' xml:lang='${VoiceConstants.DEFAULT_SPEECH_LANGUAGE}'>
        <voice name="${VoiceConstants.DEFAULT_SPEECH_VOICE}">
            ${payloadContent}
        </voice>
      </speak>`;
  }

  public cpsActivitiesToVoiceBotFormat(
    contenfulEntries: Contentful.EntryWithLinkResolutionAndWithUnresolvableLinks<TypeVoicebotPoCFields>[],
    handover?: Activity,
    dtmf?: Activity
  ): VoiceBotResponse {
    let handoverCode: VoiceBotResponse['handoverCode'];
    let handoverText: VoiceBotResponse['handoverText'];
    const handoverValue = handover?.value as HandoverValues;
    let dtmfOptions = dtmf?.value as DtmfValues;
    if (dtmfOptions) {
      const stopTones = ['pound'];
      dtmfOptions = {
        ...dtmfOptions,
        stopTones,
      };
    }
    if (handoverValue) {
      // TypeScript-narrowing check: handoverValue to be present and is always object but not an array
      if (_.isObject(handoverValue) && !_.isArray(handoverValue)) {
        handoverCode = handoverValue.handoverCode;
        handoverText = handoverValue.va_AgentMessage;
      }
    }
    let requestTypeFromUser: VoiceBotResponse['requestTypeFromUser'];
    const bargeIn: VoiceBotResponse['bargeIn'] = false;
    if (handoverCode) {
      requestTypeFromUser = VoiceRequestUserType.NONE;
    } else if (dtmfOptions) {
      requestTypeFromUser = VoiceRequestUserType.DTMF;
    } else {
      requestTypeFromUser = VoiceRequestUserType.SPEECH;
    }
    if (!contenfulEntries.length) {
      return {
        handoverCode,
        handoverText,
        dtmfOptions,
        bargeIn,
        requestTypeFromUser,
        type: 'none',
        payload: '',
      };
    }
    // When contentful response contains only audio return it in a format to play it.
    if (contenfulEntries.length === 1 && contenfulEntries[0].fields.audioFile?.fields.file?.url) {
      const entry = contenfulEntries[0];
      return {
        handoverCode,
        handoverText,
        dtmfOptions,
        bargeIn,
        requestTypeFromUser,
        type: 'staticAudioLink',
        payload: `https:${entry.fields.audioFile!.fields.file?.url}`,
      };
    }
    // When contentful response contains multiple parts, create ssml to read/play it.
    const ssmlContent = contenfulEntries.reduce((acc, entry) => {
      if (entry.fields.audioFile?.fields.file?.url) {
        return acc + `<audio src="https:${entry.fields.audioFile?.fields.file?.url}" />  `;
      } else {
        const ssmlText = CpsVoiceBotProcessor.getAggregatedTextContentFromEntryResponses(entry);
        logger.debug('ssmlText: ' + JSON.stringify(ssmlText));
        if (ssmlText) {
          return acc + ssmlText;
        }
      }
      return acc;
    }, '');
    const payload = CpsVoiceBotProcessor.formatPayload(ssmlContent);
    return {
      handoverCode,
      handoverText,
      dtmfOptions,
      bargeIn,
      requestTypeFromUser,
      type: 'ssml',
      payload,
    };
  }

  public async process(options: {
    sessionId: string;
    envConfig: BotEnvironment;
    activityToSend: ActivityToSend;
    sipHeaderLanguage: any;
  }): Promise<VoiceBotResponse | null> {
    const { sessionId, envConfig, activityToSend, sipHeaderLanguage } = options;
    if (activityToSend.text) {
      activityToSend.text = updateMaskedInput(activityToSend.text);
    }
    try {
      const activities = await this.getCopilotActivitiesClient.getAllActivities({
        conversationId: sessionId,
        envConfig,
        activity: activityToSend,
      });
      const contentfulIds = activities
        .filter(({ from, text }) => from.role === 'bot' && text)
        .map((activity) => activity.text?.split(','))
        .flat() as string[];
      logger.debug('[%s] getCopilotActivities returned following contentful ids: %j', sessionId, contentfulIds);
      const nodes = await this.contentfulService.getEntries(contentfulIds, sipHeaderLanguage);
      logger.debug('[%s] getVoiceResponseWithCopilot found contentfulNode: %j', sessionId, nodes);
      logger.debug('[%s] activities: %j', sessionId, activities);
      const handover = filterByCustomConditions(activities, {
        type: 'event',
        name: CPS_CUSTOM_EVENTS.HANDOFF_INITIATE,
      }).at(-1);
      const dtmf = filterByCustomConditions(activities, {
        type: 'event',
        name: CPS_CUSTOM_EVENTS.START_DTMF,
      }).at(-1);
      logger.debug('[%s] handover request %j', sessionId, handover);
      if (!!nodes) {
        return this.cpsActivitiesToVoiceBotFormat(nodes, handover, dtmf);
      }
      return null;
    } catch (error) {
      logger.error('[%s] Unable to process copilot activity: %o', sessionId, error);
      const preIntent = (activityToSend.value as any)?.preIntent;
      return {
        requestTypeFromUser: VoiceRequestUserType.NONE,
        bargeIn: false,
        handoverCode: preIntentToHandoverCode(preIntent),
        type: 'none',
        payload: '',
      };
    }
  }
}
