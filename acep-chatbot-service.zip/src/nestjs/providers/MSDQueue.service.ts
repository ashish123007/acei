import { Injectable } from '@nestjs/common';
import config from '../../config';
import constants from '../../constants';
import loggerUtils from '../../utils/logger';
import { ServiceBusQueue } from '../../utils/serviceBusQueue';
import crypto from 'node:crypto';
import { MSDSessionFactory } from './msdSession.service';

const { logger } = loggerUtils;

const { SERVICEBUS_NAMESPACE, MSD_QUEUE_NAME, ENVIRONMENT, FEATURE_FLAGS } = config;
const { TTL_ANNA_BOT_SESSION_SECONDS } = constants;

@Injectable()
export class MSDQueueService extends ServiceBusQueue<{ id: string; bcNumber: string }> {
  constructor(private msdSessionFactory: MSDSessionFactory) {
    super(SERVICEBUS_NAMESPACE, MSD_QUEUE_NAME);
    if (FEATURE_FLAGS.includes('autoSubscribeMsdQueue')) {
      this.subscribeFromQueue();
    }
  }

  subscribeFromQueue() {
    if (ENVIRONMENT !== 'local') {
      if (MSD_QUEUE_NAME === undefined) {
        throw new Error('MSD_QUEUE_NAME is not defined');
      }
      logger.info('Starting to listen on %j', MSD_QUEUE_NAME);
      this.subscribe(
        async (messageReceived) => {
          logger.info('Received message from msd queue %j', messageReceived.body);
        },
        async (error) => {
          logger.error('MSD_QUEUE_NAME Consumer error :: %o', error);
          return Promise.resolve();
        }
      );
    } else {
      logger.info('MSD_QUEUE_NAME.subscribe not available locally.');
    }
  }

  async updateMsdSession(conversationId: string, bcNumber: string) {
    const getScheduledMessageSequences = async (id: string) => {
      const scheduledEnqueueTimeUtc = new Date(Date.now() + 1000 * TTL_ANNA_BOT_SESSION_SECONDS);
      logger.info(
        '[%s] Messages will appear in %s queue after %s mins at : %s. bc=%s',
        conversationId,
        MSD_QUEUE_NAME,
        TTL_ANNA_BOT_SESSION_SECONDS,
        scheduledEnqueueTimeUtc,
        bcNumber
      );
      const uniqueId = `${id}-${crypto.randomBytes(16).toString('hex')}`;
      const sequenceNumbers = (
        await this.sendScheduledMessages([{ id: uniqueId, bcNumber }], scheduledEnqueueTimeUtc)
      )[0];
      return sequenceNumbers;
    };

    const msdSession = this.msdSessionFactory.createService(conversationId);
    const activeSession = await msdSession.getSession();
    if (activeSession) {
      if (activeSession.messageDeletionId) {
        // cancel the scheduled message from the queue
        await this.cancelScheduledMessages(activeSession.messageDeletionId);
        const newSequences = await getScheduledMessageSequences(conversationId);
        // replace the existing session item with new message
        await msdSession.replaceSession(newSequences.toString());
      }
    } else {
      const sequences = await getScheduledMessageSequences(conversationId);
      await msdSession.createSession({
        messageDeletionId: sequences.toString(),
      });
    }
  }
}
