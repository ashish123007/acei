import { Test, TestingModule } from '@nestjs/testing';
import { CosmosV2 } from '../../utils/cosmos';
import { DatabaseCosmosService } from './database.service';

jest.mock('../../utils/cosmos');

describe('Copilot Service Tests', () => {
  let service: DatabaseCosmosService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [DatabaseCosmosService],
    }).compile();

    service = module.get<DatabaseCosmosService>(DatabaseCosmosService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should invoke get', () => {
    const sessionId = '1234';
    service.getSessionById(sessionId);
    expect(CosmosV2).toHaveBeenCalled();
  });

  it('should invoke upsert', () => {
    const sessionId = '1234';
    service.updateSession(sessionId, {
      id: sessionId,
      botId: 'test',
      copilotConversationId: 'test',
      partition: 'test',
      ttl: 123,
      type: 'test',
    });
    expect(CosmosV2).toHaveBeenCalled();
  });

  it('should create a new session', () => {
    const sessionId = '100';
    service.createSession(sessionId, {
      id: sessionId,
      botId: 'test',
      copilotConversationId: 'test1-eu',
      partition: 'abc',
      ttl: 123,
      type: 'session',
    });
    expect(CosmosV2).toHaveBeenCalled();
  });
});
