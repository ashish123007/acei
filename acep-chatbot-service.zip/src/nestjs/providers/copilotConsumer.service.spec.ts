import { Test, TestingModule } from '@nestjs/testing';
import { ConsumeCopilot, defaultActivityWithError } from './copilotConsumer.service';
import { DatabaseService } from './database.service';
import { CopilotService } from './copilot.service';
import { WebsocketService } from './websocket.service';
import { InternalServerErrorException } from '@nestjs/common';
import { BotEnvironment } from '../../types/bot';
import { WebhookService } from './webhook.service';
import { BotConfigService } from './botconfig.service';

const EXISTING_SESSION_ID = 'session-a';
const NON_EXISTING_SESSION_ID = 'session-b';
const NO_CONVERSATION_SESSION_ID = 'session-c';
const CONVERSATION_THAT_DONT_EXISTS_ID = 'conv-a';
const CONVERSATION_ID = 'conversation1234';
const FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT: number = 7000;
const sessions: { [k: string]: { copilotConversationId: string | undefined } } = {
  [EXISTING_SESSION_ID]: { copilotConversationId: CONVERSATION_ID },
  [NO_CONVERSATION_SESSION_ID]: { copilotConversationId: CONVERSATION_THAT_DONT_EXISTS_ID },
};

const streamUrl = 'streamUrl';
const conversations: { [k: string]: { conversationId?: string; streamUrl?: string } } = {
  [CONVERSATION_ID]: { conversationId: CONVERSATION_ID, streamUrl },
};
const errorMessage = 'error message';
let mockConfig = {
  cpsInstance: { secretKey: 'aabbcc', timeout: 7000, name: 'test', errorMessage },
  channel: { provider: 'Voice' },
} as BotEnvironment;

jest.mock('applicationinsights', () => ({
  defaultClient: { trackDependency: jest.fn() },
}));

jest.mock('../../azure-monitor', () => {
  return (_config: any, _logs: any) => {};
});

describe('CopilotConsumer Service tests', () => {
  let service: ConsumeCopilot;

  let getSessionById: jest.Mock;
  let updateSession: jest.Mock;
  let getConversation: jest.Mock;
  let getActivities: jest.Mock;
  let sendActivity: jest.Mock;
  let initiateConversation: jest.Mock;
  let startConversation: jest.Mock;
  let prehook: jest.Mock;
  let webhook: jest.Mock;
  let posthook: jest.Mock;
  let createSession: jest.Mock;

  beforeEach(async () => {
    getSessionById = jest.fn((id: string) => sessions[id]);
    updateSession = jest.fn();
    getConversation = jest.fn((secretKey, id) => conversations[id]);
    getActivities = jest.fn();
    sendActivity = jest.fn();
    initiateConversation = jest.fn(() => conversations[CONVERSATION_ID]);
    startConversation = jest.fn();
    prehook = jest.fn((message, options) => ({ message, context: options.context, privateData: options.privateData }));
    posthook = jest.fn((activities, options) => ({
      activities,
      context: options.context,
      privateData: options.privateData,
    }));
    webhook = jest.fn((_cid, activities, options, _secretKey) => ({ activities, privateData: options.privateData }));
    createSession = jest.fn((conversationId, _payload) => {
      if (!conversationId) {
        throw new Error('Error encountered upon creating a new session.');
      }
    });

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ConsumeCopilot,
        {
          provide: DatabaseService,
          useValue: {
            getSessionById,
            updateSession,
            createSession,
          },
        },
        CopilotService,
        WebsocketService,
        {
          provide: WebhookService,
          useValue: {
            preHook: prehook,
            webhook: webhook,
            postHook: posthook,
          },
        },
      ],
    })
      .overrideProvider(BotConfigService)
      .useValue({})
      .overrideProvider(CopilotService)
      .useValue({
        getConversation,
        initiateConversation,
        startConversation,
        getActivities,
        sendActivity,
      })

      .compile();

    service = module.get<ConsumeCopilot>(ConsumeCopilot);
  });

  afterEach(() => {
    jest.clearAllMocks();
    mockConfig = {
      cpsInstance: { secretKey: 'aabbcc', timeout: 7000, name: 'test', errorMessage },
      channel: { provider: 'Voice' },
    } as BotEnvironment;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should return special activity when there is an error', async () => {
    const activities = await service.getCopilotActivities(
      'cps1',
      {
        type: 'event',
        name: 'startConversation',
      },
      { ...mockConfig, cpsInstance: { ...mockConfig.cpsInstance!, errorMessage: undefined } },
      'def'
    );
    expect(activities).toHaveLength(1);
    expect(activities[0]).toEqual(defaultActivityWithError);
  });

  it('should return special activity with error message taken from env config when there is an error', async () => {
    const activities = await service.getCopilotActivities(
      'cps1',
      {
        type: 'event',
        name: 'startConversation',
      },
      mockConfig,
      'def'
    );
    expect(activities).toHaveLength(1);
    expect(activities[0]).toEqual({ ...defaultActivityWithError, text: errorMessage });
  });

  it('should not create a new conversation when EXISTING_SESSION_ID is passed', async () => {
    await service.getCPSSession('mySecretKey', 'cpsBot', EXISTING_SESSION_ID);
    expect(initiateConversation).not.toHaveBeenCalled();
  });

  it('should throw an error when conversation details are not fetched from copilot', async () => {
    initiateConversation.mockResolvedValue({ conversationId: undefined });
    await service.getCPSSession('mySecretKey', 'cpsBot', NON_EXISTING_SESSION_ID);
    expect(createSession).toThrow('Error encountered upon creating a new session.');
  });

  it('should create a new session when NON_EXISTING_SESSION_ID is passed', async () => {
    await service.getCPSSession('aabbcc', 'cpsBot', NON_EXISTING_SESSION_ID);
    expect(initiateConversation).toHaveBeenCalled();
    expect(createSession).toHaveBeenCalled();
  });

  it('should throw an error if no conversation was fetched ', async () => {
    service
      .getCopilotActivities(
        'cps1',
        {
          type: 'event',
          name: 'startConversation',
        },
        mockConfig,
        'def'
      )
      .catch((error) => {
        expect(error).toBeInstanceOf(InternalServerErrorException);
      });
  });

  it('should throw an error if empty secret key is passed', async () => {
    const config = { cpsInstance: {} };
    await service
      .getCopilotActivities(
        'cps1',
        {
          type: 'event',
          name: 'startConversation',
        },
        config as BotEnvironment,
        'def'
      )
      .then(() => {
        expect(true).toBe(false);
      })
      .catch((error) => {
        expect(error).toBeInstanceOf(Error);
      });
  });

  it('should throw an error if no timeout is passed', async () => {
    const config = { cpsInstance: { secretKey: 'aabbcc' } };
    await service
      .getCopilotActivities(
        'cps1',
        {
          type: 'event',
          name: 'startConversation',
        },
        config as BotEnvironment,
        'def'
      )
      .then(() => {
        expect(true).toBe(false);
      })
      .catch((error) => {
        expect(error).toBeInstanceOf(Error);
      });
  });

  const cpsPayload = () => {
    const conversation = {
      conversationId: 'cps1',
      streamUrl: 'https://ws.streamUrl.com',
      token: 'a',
    };
    const activity = {
      type: 'message' as const,
      text: 'Text message',
      id: 'a',
    };
    const conversationId = 'abc';
    const envConfig = mockConfig;
    const secretKey = 'a';
    const timeout = FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT;
    const session = undefined;
    const payload = {
      conversation,
      activity,
      conversationId,
      envConfig,
      secretKey,
      session,
      timeout,
    };
    return payload;
  };

  describe('sendMessage method', () => {
    beforeEach(() => {
      sendActivity.mockImplementation(async (_secretKey, _cid, activity) => ({ id: activity.id }));
    });

    it('should throw error if no secret key given', async () => {
      const p = cpsPayload();
      if (p.envConfig.cpsInstance) {
        p.envConfig.cpsInstance.secretKey = '';
      }
      await expect(service.getAllActivities(p)).rejects.toThrow();
    });

    it('should go through all steps correctly', async () => {
      const p = cpsPayload();
      p.envConfig.botId = 'anna-nice';
      await service.getAllActivities(p);
      expect(prehook).toHaveBeenCalled();
      expect(webhook).toHaveBeenCalled();
      expect(posthook).toHaveBeenCalled();
      expect(getActivities).toHaveBeenCalled();
      expect(updateSession).not.toHaveBeenCalled();
    });

    it('should upsert context if updated by posthook/prehook', async () => {
      const p = cpsPayload();
      p.envConfig.botId = 'voice-ivr';
      p.envConfig.meta = { pollingInterval: 500 };

      prehook.mockImplementationOnce((message, { context }) => ({
        message,
        context: { ...context, updatedContext: true },
        privateData: {},
      }));
      await service.getAllActivities(p);
      expect(prehook).toHaveBeenCalled();
      expect(webhook).toHaveBeenCalled();
      expect(posthook).toHaveBeenCalled();
      expect(getActivities).toHaveBeenCalled();
      expect(updateSession).toHaveBeenCalled();
    });

    it('should update context with setContext method', async () => {
      const mockedObject = { textMockup: 'text' };
      const cpsID = 1234;
      const contextName = 'setContext';

      prehook.mockImplementationOnce((message, { context }) => ({
        message,
        context: { ...context, copilotConversationId: cpsID, name: contextName, value: mockedObject },
      }));
      const p = cpsPayload();
      await service.getAllActivities({ ...p, activity: { ...p.activity, text: contextName } });
      expect(prehook).toHaveBeenCalled();
      expect(webhook).toHaveBeenCalled();
      expect(posthook).toHaveBeenCalled();
      expect(updateSession).toHaveBeenCalledWith(
        'abc',
        expect.objectContaining({
          copilotConversationId: cpsID,
          name: contextName,
          value: mockedObject,
        })
      );
    });
  });

  describe('Private data tests', () => {
    beforeEach(() => {
      sendActivity.mockImplementation(async (_secretKey, _cid, activity) => ({ id: activity.id }));
      posthook.mockImplementation(async (activities, { context, privateData }) => ({
        activities,
        context: { ...context, updatedContext: true },
        privateData,
      }));
      getActivities.mockResolvedValue({
        activities: [
          { type: 'message', text: 'this was send', id: 'a' },
          {
            type: 'message',
            text: 'random name: ((name))',
            id: 'b',
            replyToId: 'a',
            channelData: { askForCustomerInput: true },
          },
        ],
      });
    });
    it('should replace placeholders with private data from hooks', async () => {
      prehook.mockImplementation(async (activity, { context }) => ({
        message: activity,
        context: { ...context, updatedContext: true },
        privateData: { name: 'John Doe' },
      }));

      const activities = await service.getAllActivities({ ...cpsPayload(), conversationId: EXISTING_SESSION_ID });
      expect(activities[0].text).toEqual('random name: John Doe');
    });

    it('should return placeholders when there is no private data from hooks', async () => {
      prehook.mockImplementation((message, { context }) => ({
        message,
        context: { ...context, updatedContext: true },
        privateData: { lastName: 'John Doe' },
      }));

      const activities = await service.getAllActivities({ ...cpsPayload(), conversationId: EXISTING_SESSION_ID });

      expect(activities[0].text).toEqual('random name: ((name))');
    });
  });

  describe('Private data fail scenario tests', () => {
    beforeEach(() => {
      sendActivity.mockImplementation(async (_secretKey, _cid, activity) => ({ id: activity.id }));

      getActivities.mockResolvedValue({
        activities: [
          { type: 'message', text: 'this was send', id: 'a' },
          {
            type: 'message',
            text: 'random name: ((name))',
            id: 'b',
            replyToId: 'a',
            channelData: { askForCustomerInput: true },
          },
        ],
      });
    });
    it('should work even when prehook returns no privateData', async () => {
      prehook.mockImplementation(async (activity, { context }) => ({
        message: activity,
        context: { ...context, updatedContext: true },
      }));

      const activities = await service.getAllActivities({ ...cpsPayload(), conversationId: EXISTING_SESSION_ID });
      expect(activities[0].text).toEqual('random name: ((name))');
    });

    it('should work even when webhook returns no privateData', async () => {
      webhook.mockImplementation(async (_cid, activities, { context }) => ({
        activities,
        context: { ...context, updatedContext: true },
      }));

      const activities = await service.getAllActivities({ ...cpsPayload(), conversationId: EXISTING_SESSION_ID });
      expect(activities[0].text).toEqual('random name: ((name))');
    });

    it('should work even when posthook returns no privateData', async () => {
      posthook.mockImplementation(async (activities, { context }) => ({
        activities,
        context: { ...context, updatedContext: true },
      }));

      const activities = await service.getAllActivities({ ...cpsPayload(), conversationId: EXISTING_SESSION_ID });
      expect(activities[0].text).toEqual('random name: ((name))');
    });

    it('should work even when all webhooks returns no privateData', async () => {
      prehook.mockImplementation(async (activity, { context }) => ({
        message: activity,
        context: { ...context, updatedContext: true },
      }));

      webhook.mockImplementation(async (_cid, activities, { context }) => ({
        activities,
        context: { ...context, updatedContext: true },
      }));

      posthook.mockImplementation(async (activities, { context }) => ({
        activities,
        context: { ...context, updatedContext: true },
      }));

      const activities = await service.getAllActivities({ ...cpsPayload(), conversationId: EXISTING_SESSION_ID });
      expect(activities[0].text).toEqual('random name: ((name))');
    });

    it('should pass additional props for prehook when start conversation event is sent', async () => {
      const activities = await service.getAllActivities({
        ...cpsPayload(),
        activity: { type: 'event', name: 'startConversation' },
        conversationId: EXISTING_SESSION_ID,
      });
      expect(prehook).toHaveBeenCalledWith(
        { type: 'event', name: 'startConversation', event: 'startConversation' },
        {
          context: { copilotConversationId: 'conversation1234', isNew: false },
          conversationId: 'session-a',
          envConfig: {
            channel: { provider: 'Voice' },
            cpsInstance: { secretKey: 'aabbcc', name: 'test', timeout: 7000, errorMessage },
          },
          privateData: undefined,
        }
      );
    });

    it('should not pass additional props for prehook when no start conversation event is sent', async () => {
      const activities = await service.getAllActivities({
        ...cpsPayload(),
        activity: { type: 'message', text: 'message' },
        conversationId: EXISTING_SESSION_ID,
      });
      expect(prehook).toHaveBeenCalledWith(
        { type: 'message', text: 'message' },
        {
          context: { copilotConversationId: 'conversation1234', isNew: false },
          conversationId: 'session-a',
          envConfig: {
            channel: { provider: 'Voice' },
            cpsInstance: { secretKey: 'aabbcc', name: 'test', timeout: 7000, errorMessage },
          },
          privateData: undefined,
        }
      );
    });
  });
});
