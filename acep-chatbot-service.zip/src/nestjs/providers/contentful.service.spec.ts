import { Test, TestingModule } from '@nestjs/testing';
import { ContentfulService } from './contentful.service';
import { contentfulRedisClient } from '../../utils/redis';
import mockedContentful from '../../../mocks/contentful/cpsintegration.json';

var getCacheListMocked: jest.Mock;
var setCacheListMocked: jest.Mock;
jest.mock('../../utils/redis', () => {
  getCacheListMocked = jest.fn();
  setCacheListMocked = jest.fn();
  return {
    contentfulRedisClient: {
      getCacheList: getCacheListMocked,
      setCacheList: setCacheListMocked,
    },
  };
});

var createClientMocked: jest.Mock;
var getEntriesMocked: jest.Mock;
jest.mock('contentful', () => {
  getEntriesMocked = jest.fn();
  createClientMocked = jest.fn();
  return {
    createClient: createClientMocked,
  };
});

describe('contentful service tests', () => {
  let service: ContentfulService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ContentfulService],
    }).compile();

    service = module.get<ContentfulService>(ContentfulService);

    getCacheListMocked.mockResolvedValue([]);
    createClientMocked.mockReturnValue({ getEntries: getEntriesMocked });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  // it('should write to cache if there is data', async () => {
  //   getEntriesMocked.mockReturnValue({ items: mockedContentful })

  //   const items = await service.getEntries(['2o8yFG4DRySy3l8acm4z1M'])
  //   expect(setCacheListMocked).toHaveBeenCalled()
  //   expect(items.length).toBe(1)
  // })

  // it('should not write to cache if there is no data', async () => {
  //   getEntriesMocked.mockReturnValue({ items: [] })
  //   const items = await service.getEntries(['2o8yFG4DRySy3l8acm4z1M'])
  //   expect(setCacheListMocked).not.toHaveBeenCalled()
  //   expect(items.length).toBe(0)
  // })
});
