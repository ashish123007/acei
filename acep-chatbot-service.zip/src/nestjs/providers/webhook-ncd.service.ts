import { Injectable, InternalServerErrorException } from '@nestjs/common';
import loggerUtils from '../../utils/logger';
import apiInvoke from '../../utils/apiCall';
import { BotEnvironment } from '../../types/bot';
import { Activity, CPS_CUSTOM_EVENTS, CopilotHookOptions } from '../../types/copilotApi.model';
import { JsonMap } from '../../types/utils';
import { COPILOT_ACTIVITIES_CL, ConsumeCopilot, copilotChatLogsProvider } from './copilotConsumer.service';
import { getLogsForAzureMonitor } from '../../azure-monitor/azureMonitorService';
import { CopilotRequest, CopilotResponse, LogType } from '../../azure-monitor/azureMonitorConfig';
import azureMonitor from '../../azure-monitor';
import { CopilotSessionTable, PosthookResponse, PrehookRequest, PrehookResponse } from '../../types';

const { logger } = loggerUtils;
const { WEBHOOK_REQUEST } = CPS_CUSTOM_EVENTS;

@Injectable()
export class WebhookNCDService {
  constructor(private consumeCopilotService: ConsumeCopilot) {}

  async preHook(message: PrehookRequest, envConfig: BotEnvironment): Promise<PrehookResponse | undefined> {
    const hookConfig = envConfig?.prehooks && envConfig.prehooks[0]?.requestOptions;
    if (hookConfig) {
      logger.debug('[%s] Prehook invoked %o', message);
      try {
        const prehookResult = (await apiInvoke<unknown>(hookConfig, message as any, 'prehook')) as PrehookResponse;
        return prehookResult;
      } catch (error) {
        logger.error('[%s] Prehook Failed with message : %o ', 'PLACEHOLDER', error.message);
        throw error;
      }
    }
    throw new InternalServerErrorException(
      `PreHooksConfig is missing in bot with id ${envConfig.botId} :: Please configure in ace admin tool`
    );
  }

  async webhook(
    cpsConversationId: string,
    activities: Activity[],
    { conversationId, envConfig, context: cpsContext, privateData }: CopilotHookOptions,
    callCount = 0
  ): Promise<{ activities: Activity[]; privateData: JsonMap; context: CopilotSessionTable }> {
    const webhookConfig = envConfig.webhook?.requestOptions;
    const webhookContext = activities.find(
      (activity) => activity.type === 'event' && activity.name === WEBHOOK_REQUEST
    )?.value;

    let updatedPrivateData: JsonMap | undefined = privateData;
    if (webhookContext && webhookConfig && callCount < 10) {
      logger.debug('[%s] Webhook invoked %o', conversationId, {
        cpsContext,
        activities,
        context: webhookContext,
        webhookConfig,
      });
      let webhookResults: { success: boolean; [k: string]: unknown; privateData?: JsonMap } = { success: false };
      try {
        const webhookPayload = {
          context: {
            ...cpsContext,
            ...webhookContext,
            conversationId,
          },
          privateData,
        };
        webhookResults = await apiInvoke<{ success: boolean; [k: string]: unknown; privateData?: JsonMap }>(
          webhookConfig,
          webhookPayload,
          'webhook'
        );
        updatedPrivateData = webhookResults.privateData || {};
        delete webhookResults.privateData;
      } catch (error) {
        logger.error('[%s] webhookService error while invoking webhook :: %o', conversationId, error);
      } finally {
        const activity = {
          type: 'message' as const,
          text: 'SystemMessage - Webhook results',
          value: { ...webhookResults },
        };
        logger.debug('[%s] webhookService webhook results %o', conversationId, activity);
        const copilotConfig = {
          conversationId,
          copilotConversationId: cpsConversationId,
          botId: envConfig.botId,
          chat_session_id: cpsContext?.chatSessionId ?? '',
        };
        const azureMonitorLogsPreCopilot = [
          getLogsForAzureMonitor(copilotConfig, {
            userActivityStringified: JSON.stringify(webhookResults),
          }) as CopilotRequest,
        ];
        await azureMonitor(copilotChatLogsProvider, COPILOT_ACTIVITIES_CL, azureMonitorLogsPreCopilot);
        const webhookReplies = await this.consumeCopilotService.getCopilotActivities(
          cpsConversationId,
          activity,
          envConfig,
          conversationId
        );
        const azureMonitorLogsPostCopilot = [
          getLogsForAzureMonitor(copilotConfig, { activities: webhookReplies }, LogType.RESPONSE) as CopilotResponse,
        ];
        await azureMonitor(copilotChatLogsProvider, COPILOT_ACTIVITIES_CL, azureMonitorLogsPostCopilot);
        const nonWebhookResponses = activities.filter((activityNode) => activityNode.name !== WEBHOOK_REQUEST);
        return this.webhook(
          cpsConversationId,
          [...nonWebhookResponses, ...webhookReplies],
          {
            conversationId,
            envConfig,
            context: cpsContext,
            privateData: { ...privateData, ...updatedPrivateData },
          },
          callCount + 1
        );
      }
    }
    return { activities, privateData: { ...privateData, ...updatedPrivateData }, context: cpsContext };
  }

  async postHook(activities: Activity[], session: CopilotSessionTable, envConfig: BotEnvironment) {
    const hookConfig = envConfig?.posthooks && envConfig.posthooks[0]?.requestOptions;
    if (hookConfig) {
      const { id: conversationId, privateData } = session;
      logger.debug('[%s] Posthook invoked %o', conversationId, { activities, hookConfig });
      try {
        const posthookPayload = { activities, conversationId, context: session, privateData };
        const posthookResult = (await apiInvoke<{ activities: unknown }>(
          hookConfig,
          posthookPayload,
          'posthook'
        )) as PosthookResponse;
        return {
          ...posthookResult,
          context: { ...session, ...posthookResult.context },
          privateData: { ...session.privateData, ...posthookResult.privateData },
        };
      } catch (error) {
        logger.error('[%s] Posthook Failed with message : %o ', conversationId, error.message);
        throw error;
      }
    } else {
      logger.warn(`PostooksConfig is missing :: bot might not work as expected`);
    }
    return { activities, context: session, privateData: session.privateData };
  }
}
