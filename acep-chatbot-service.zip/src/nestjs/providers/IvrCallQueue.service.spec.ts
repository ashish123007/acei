import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../../app.module';
import { IvrCallQueueService } from './IvrCallQueue.service';
import { ServiceBusQueue } from '../../utils/serviceBusQueue';
import { AcsClientFactory } from './acsCustomSdk.service';
import { IVRSessionFactory } from './ivrSession.service';
import { MSDQueueService } from './MSDQueue.service';
import { ContentfulService } from './contentful.service';
import { BotConfigService } from './botconfig.service';
import path from 'path';

jest.mock('path');

jest.mock('../../config', () => ({
  ENVIRONMENT: 'jest',
  FEATURE_FLAGS: 'f1,f2',
  IVR_CALL_QUEUE_NAME: 'queue-name',
  MSD_QUEUE_NAME: 'queue-name',
  databaseOpts: {
    endpoint: 'https://local.cosmos',
  },
  iagApi: {
    localSanValue: '',
    cert: '',
    key: '',
    endpoint: '',
  },
}));
const ServiceBusQueueMocked = ServiceBusQueue as jest.MockedClass<typeof ServiceBusQueue>;

jest.mock('../../utils/serviceBusQueue');

describe('IVRCallQueueService', () => {
  let service: IvrCallQueueService;
  let createService: jest.Mock;
  let terminateCall: jest.Mock;
  let removeSchedulerId: jest.Mock;
  let subscribeMock: jest.Mock;

  beforeEach(async () => {
    createService = jest.fn();
    removeSchedulerId = jest.fn();
    terminateCall = jest.fn();

    ServiceBusQueueMocked.mockReset();

    const module: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(BotConfigService)
      .useValue({})
      .overrideProvider(AcsClientFactory)
      .useValue({
        createService: () => ({
          terminateCall,
        }),
      })
      .overrideProvider(MSDQueueService)
      .useValue({})
      .overrideProvider(IVRSessionFactory)
      .useValue({
        createService: () => ({
          removeSchedulerId,
        }),
      })
      .overrideProvider(ContentfulService)
      .useValue({})
      .compile();

    service = module.get<IvrCallQueueService>(IvrCallQueueService);

    subscribeMock = ServiceBusQueueMocked.mock.instances[0].subscribe as jest.Mock;
  });

  it('should be defined and subscribeMock called', () => {
    expect(service).toBeDefined();
    expect(subscribeMock).toHaveBeenCalled();
  });

  // it("should be able to process message", async () => {
  //   let messageReceived: (m: ServiceBusMessage) => void = subscribeMock.mock.calls[0][0];
  //   messageReceived({ body: { conversationId: 'conversationId', id: 'id' } });

  //   expect(removeSchedulerId).toHaveBeenCalled();
  //   expect(terminateCall).toHaveBeenCalled();
  // })

  // it("should be able to process failed message", async () => {
  //   let messageReceivedFailed: () => void = subscribeMock.mock.calls[0][1];

  //   await messageReceivedFailed();
  // })
});
