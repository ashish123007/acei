import { Injectable } from '@nestjs/common';
import { CosmosV2 } from '../../utils/cosmos';

import config from '../../config';
import constants from '../../constants';
import { MSDSessionType, ServBusScheduleId } from '../../types/utils';
import { PatchOperation, PatchOperationType } from '@azure/cosmos';

const { SESSION_TABLE } = config;
const { TTL_ANNA_BOT_SESSION_SECONDS } = constants;

export interface MSDSession {
  id: string;
  partition: string;
  type?: string;
  ttl: number;
  messageDeletionId?: ServBusScheduleId;
  createdAt: number;
}

class MSDSesion {
  private cosmos: CosmosV2<MSDSession>;
  constructor(private conversationId: string) {
    this.cosmos = new CosmosV2<MSDSession>(SESSION_TABLE, conversationId, conversationId);
  }

  async createSession(session: Pick<MSDSession, 'messageDeletionId'>) {
    await this.cosmos.create({
      ...session,
      partition: this.conversationId,
      ttl: TTL_ANNA_BOT_SESSION_SECONDS,
      type: MSDSessionType.MSD,
      id: this.conversationId,
      createdAt: Date.now(),
    });
  }

  async replaceSession(sequences: string) {
    const operations: PatchOperation[] = [
      { op: PatchOperationType.replace, path: '/messageDeletionId', value: sequences },
      { op: PatchOperationType.replace, path: '/createdAt', value: Date.now() },
    ];
    await this.cosmos.patch(operations);
  }

  getSession() {
    return this.cosmos.get();
  }
}

@Injectable()
export class MSDSessionFactory {
  createService(conversationId: string): MSDSesion {
    return new MSDSesion(conversationId);
  }
}
