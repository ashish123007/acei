import { Injectable } from '@nestjs/common';
import hash from 'object-hash';
import { delay } from 'bluebird';
import loggerUtils from '../../utils/logger';
import { BotEnvironment } from '../../types/bot';
import { ConfigurationService } from '../../utils/configuration.service';

const { logger } = loggerUtils;

@Injectable()
export class BotConfigService {
  private appKeyToBotEnv: Map<string, BotEnvironment> = new Map();
  private botIdToEnvToConfig: Map<string, Map<string, BotEnvironment>> = new Map();

  constructor(private readonly configurationService: ConfigurationService) {
    if (process.env.IS_JEST != '1') {
      // eslint-disable-next-line @typescript-eslint/no-floating-promises
      this.load();
    }
  }

  private async load(): Promise<void> {
    let lastConfig: string | undefined;

    while (true) {
      try {
        const { bots } = await this.configurationService.getConfig();
        const configHash = hash(bots);
        if (lastConfig !== configHash) {
          logger.info('Change detected, re-creating botconfig');
          const appKeyToBotEnv: Map<string, BotEnvironment> = new Map();
          const botIdToEnvToConfig: Map<string, Map<string, BotEnvironment>> = new Map();
          for (const bot of bots) {
            const envToConfig: Map<string, BotEnvironment> = new Map();
            for (const botEnv of bot.environments) {
              appKeyToBotEnv.set(botEnv.appKey, {
                ...botEnv,
                botId: bot.botId,
                conversationTtlSeconds: bot.conversationTtlSeconds,
              });
              envToConfig.set(botEnv.name.toLowerCase(), {
                ...botEnv,
                botId: bot.botId,
                conversationTtlSeconds: bot.conversationTtlSeconds,
              });
            }
            botIdToEnvToConfig.set(bot.botId, envToConfig);
          }
          this.botIdToEnvToConfig = botIdToEnvToConfig;
          this.appKeyToBotEnv = appKeyToBotEnv;
          lastConfig = configHash;
        }
        await delay(30000);
      } catch (error) {
        logger.error('Botstudio Config: Error while attempting a reload. Retrying in 10 seconds: %o', error);
        await delay(10000);
      }
    }
  }

  public getBotEnvConfig(apiKey: string): BotEnvironment | undefined {
    return this.appKeyToBotEnv.get(apiKey);
  }

  public getBotEnvConfigViaTeams(botId: string, envName: string): BotEnvironment | undefined {
    return this.botIdToEnvToConfig.get(botId)?.get(envName);
  }

  public isHealthy() {
    return this.appKeyToBotEnv.size > 0;
  }
}
