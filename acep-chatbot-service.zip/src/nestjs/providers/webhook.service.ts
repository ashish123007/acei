import { forwardRef, Inject, Injectable } from '@nestjs/common';
import loggerUtils from '../../utils/logger';
import { Activity, CopilotHookOptions, PrehookMessage, CPS_CUSTOM_EVENTS } from '../../types/copilotApi.model';
import apiInvoke from '../../utils/apiCall';
import { JsonMap } from '../../types/utils';
import _ from 'lodash';
import { ConsumeCopilot, COPILOT_ACTIVITIES_CL, copilotChatLogsProvider } from './copilotConsumer.service';
import { CopilotSessionTable } from '../../types';
import { getLogsForAzureMonitor } from '../../azure-monitor/azureMonitorService';
import azureMonitor from '../../azure-monitor';
import { CopilotRequest, CopilotResponse, LogType } from '../../azure-monitor/azureMonitorConfig';

const { logger } = loggerUtils;
const { WEBHOOK_REQUEST } = CPS_CUSTOM_EVENTS;

const getValueByTypeAndName = (activities: Activity[], type: string, name: string) => {
  return activities.find((activity) => activity.type === type && activity.name === name)?.value as JsonMap;
};

@Injectable()
export class WebhookService {
  constructor(
    @Inject(forwardRef(() => ConsumeCopilot))
    private client: ConsumeCopilot
  ) {}

  async preHook(activity: PrehookMessage, { conversationId, envConfig, context, privateData }: CopilotHookOptions) {
    const prehookConfig = envConfig.prehooks?.[0]?.requestOptions;
    const body = { message: activity, context, privateData };
    if (prehookConfig) {
      logger.debug('[%s] Prehook invoked %o', conversationId, { message: activity, context, prehookConfig });
      try {
        const prehookPayload = { ...body, conversationId };
        const prehookResult = await apiInvoke<{
          message: JsonMap;
          privateData?: JsonMap;
          context: CopilotSessionTable;
        }>(prehookConfig, prehookPayload, 'prehook');
        const privateDataFromPrehook = prehookResult.privateData || {};
        return {
          ...body,
          privateData: { ...privateData, ...privateDataFromPrehook },
          ..._.pick(prehookResult, ['message', 'context']),
        };
      } catch (error) {
        logger.error('[%s] Prehook Failed with message : %o ', conversationId, error.message);
        return body;
      }
    }
    return body;
  }

  async webhook(
    cpsConversationId: string,
    activities: Activity[],
    { conversationId, envConfig, context: cpsContext, privateData }: CopilotHookOptions,
    callCount = 0
  ): Promise<{ activities: Activity[]; privateData: JsonMap; context?: CopilotSessionTable }> {
    const webhookConfig = envConfig.webhook?.requestOptions;
    const webhookContext = getValueByTypeAndName(activities, 'event', WEBHOOK_REQUEST);
    let updatedPrivateData: JsonMap | undefined = privateData;
    if (webhookContext && webhookConfig && callCount < 10) {
      logger.debug('[%s] Webhook invoked %o', conversationId, {
        cpsContext,
        activities,
        context: webhookContext,
        webhookConfig,
      });
      let webhookResults: { success: boolean; [k: string]: any; privateData?: JsonMap } = { success: false };
      try {
        const webhookPayload = {
          context: {
            ...cpsContext,
            ...webhookContext,
            conversationId,
          },
          privateData,
        };
        webhookResults = await apiInvoke<{ success: boolean; [k: string]: any; privateData?: JsonMap }>(
          webhookConfig,
          webhookPayload,
          'webhook'
        );
        // TO DO: set private data received from webhookResults.privateData
        updatedPrivateData = webhookResults.privateData || {};
        delete webhookResults.privateData;
      } catch (error) {
        logger.error('[%s] webhookService error while invoking webhook :: %o', conversationId, error);
      } finally {
        const activity = {
          type: 'message' as const,
          text: 'SystemMessage - Webhook results',
          value: { ...webhookResults },
        };
        logger.debug('[%s] webhookService webhook results %o', conversationId, activity);
        const copilotConfig = {
          conversationId,
          copilotConversationId: cpsConversationId,
          botId: envConfig.botId,
          chat_session_id: cpsContext?.chatSessionId ?? '',
        };
        const azureMonitorLogsPreCopilot = [
          getLogsForAzureMonitor(copilotConfig, {
            userActivityStringified: JSON.stringify(webhookResults),
          }) as CopilotRequest,
        ];
        await azureMonitor(copilotChatLogsProvider, COPILOT_ACTIVITIES_CL, azureMonitorLogsPreCopilot);
        const webhookReplies = await this.client.getCopilotActivities(
          cpsConversationId,
          activity,
          envConfig,
          conversationId
        );
        const azureMonitorLogsPostCopilot = [
          getLogsForAzureMonitor(copilotConfig, { activities: webhookReplies }, LogType.RESPONSE) as CopilotResponse,
        ];
        await azureMonitor(copilotChatLogsProvider, COPILOT_ACTIVITIES_CL, azureMonitorLogsPostCopilot);
        const nonWebhookResponses = activities.filter((activityNode) => activityNode.name !== WEBHOOK_REQUEST);
        return this.webhook(
          cpsConversationId,
          [...nonWebhookResponses, ...webhookReplies],
          {
            conversationId,
            envConfig,
            context: cpsContext,
            privateData: { ...privateData, ...updatedPrivateData },
          },
          callCount + 1
        );
      }
    }
    return { activities, privateData: { ...privateData, ...updatedPrivateData }, context: cpsContext };
  }

  async postHook(activities: Activity[], { conversationId, envConfig, context, privateData }: CopilotHookOptions) {
    let posthookConfig = envConfig.posthooks?.[0]?.requestOptions;
    const body = { activities, context, privateData };
    if (posthookConfig) {
      logger.debug('[%s] Posthook invoked %o', conversationId, { context, activities, posthookConfig });
      try {
        const posthookPayload = { ...body, conversationId };
        const posthookResult = await apiInvoke<{ activities: Activity[] }>(posthookConfig, posthookPayload, 'posthook');
        return {
          ...body,
          activities: posthookResult.activities,
        };
      } catch (error) {
        logger.error('[%s] Posthook Failed with message : %o ', conversationId, error.message);
        return body;
      }
    }
    return body;
  }
}
