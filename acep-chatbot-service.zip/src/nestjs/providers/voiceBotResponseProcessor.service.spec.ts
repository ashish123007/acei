import { Test, TestingModule } from '@nestjs/testing';
import { VoiceBotResponseProcessor } from './voiceBotResponseProcessor.service';
import { CpsVoiceBotProcessor } from './cpsVoiceBotProcessor.service';
import { VoiceOrchestratorParams } from '../../types/voice';
import { logger } from '../../utils/logger';
import { BotEnvironment } from '../../types/bot';

jest.mock('./cpsVoiceBotProcessor.service');
jest.mock('../../utils/logger');

const botEnv: BotEnvironment = {
  admins: [],
  viewers: [],
  editors: [],
  logs: [],
  posthooks: [],
  prehooks: [],
  skills: [],
  name: '',
  appKey: '',
  masterSkill: {
    __typename: undefined,
    name: '',
    provider: '',
  },
  channel: {
    provider: 'msteams',
    debug: false,
    isSwagFormat: false,
    allowedEvents: [],
    inputMasking: false,
    renderers: [],
    connection: [
      { key: 'microsoftAppId', value: 'microsoftAppId' },
      { key: 'microsoftAppPassword', value: 'microsoftAppPassword' },
    ],
  },
  botId: '',
  conversationTtlSeconds: 0,
  cpsInstance: {
    name: 'cps-test',
    secretKey: 'secret-key',
    timeout: 7000,
  },
};

describe('VoiceBotResponseProcessor', () => {
  let service: VoiceBotResponseProcessor;
  let cpsVoiceBotProcessorMock: jest.Mocked<CpsVoiceBotProcessor>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        VoiceBotResponseProcessor,
        {
          provide: CpsVoiceBotProcessor,
          useValue: {
            process: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<VoiceBotResponseProcessor>(VoiceBotResponseProcessor);
    cpsVoiceBotProcessorMock = module.get(CpsVoiceBotProcessor);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should log a message on processing', async () => {
    const input = 'Hello';
    const voiceOrchestratorParams: VoiceOrchestratorParams = {
      callConnectionId: '123',
      contactId: '456',
      conversationId: '789',
      speechLanguage: 'en-US',
      target: {
        kind: 'phoneNumber',
        phoneNumber: { value: 'phoneNumber' },
      },
      env: botEnv,
      voiceName: 'voiceName',
      preIntent: 'testIntent',
      sipHeaders: {},
    };

    await service.process(input, voiceOrchestratorParams);

    expect(logger.info).toHaveBeenCalledWith('[%s] IVR call on cps ', '456');
  });

  it('should process a message activity when timeout is false', async () => {
    const input = 'Hello';
    const voiceOrchestratorParams: VoiceOrchestratorParams = {
      callConnectionId: '123',
      contactId: '456',
      conversationId: '789',
      speechLanguage: 'en-US',
      target: {
        kind: 'phoneNumber',
        phoneNumber: { value: 'phoneNumber' },
      },
      env: botEnv,
      voiceName: 'voiceName',
      preIntent: 'testIntent',
      sipHeaders: {},
    };

    await service.process(input, voiceOrchestratorParams, false);

    expect(cpsVoiceBotProcessorMock.process).toHaveBeenCalledWith({
      sessionId: '789',
      sipHeaderLanguage: 'en-US',
      envConfig: voiceOrchestratorParams.env,
      activityToSend: {
        type: 'message',
        value: {
          preIntent: 'testIntent',
          contactId: '456',
          chatbotConversationId: '789',
          sipHeaders: {},
        },
        text: input,
      },
    });
  });

  it('should process an event activity when timeout is true', async () => {
    const input = 'Hello';
    const voiceOrchestratorParams: VoiceOrchestratorParams = {
      callConnectionId: '123',
      contactId: '456',
      conversationId: '789',
      speechLanguage: 'en-US',
      target: {
        kind: 'phoneNumber',
        phoneNumber: { value: 'phoneNumber' },
      },
      env: botEnv,
      voiceName: 'voiceName',
      preIntent: 'testIntent',
      sipHeaders: {},
    };

    await service.process(input, voiceOrchestratorParams, true);

    expect(cpsVoiceBotProcessorMock.process).toHaveBeenCalledWith({
      sessionId: '789',
      sipHeaderLanguage: 'en-US',
      envConfig: voiceOrchestratorParams.env,
      activityToSend: {
        type: 'event',
        name: 'noInput',
      },
    });
  });
});
