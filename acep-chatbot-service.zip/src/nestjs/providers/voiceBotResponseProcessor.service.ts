import { Injectable } from '@nestjs/common';
import { CpsVoiceBotProcessor } from './cpsVoiceBotProcessor.service';
import { VoiceBotResponse, VoiceOrchestratorParams } from '../../types/voice';
import { ActivityToSend, CPS_CUSTOM_EVENTS } from '../../types/copilotApi.model';
import { logger } from '../../utils/logger';

@Injectable()
export class VoiceBotResponseProcessor {
  constructor(private cpsVoiceBotProcessor: CpsVoiceBotProcessor) {}

  public async process(
    input: string,
    voiceOrchestratorParams: VoiceOrchestratorParams,
    timeout = false
  ): Promise<VoiceBotResponse | null> {
    const { env, conversationId, contactId, preIntent, sipHeaders, speechLanguage } = voiceOrchestratorParams;
    logger.info('[%s] IVR call on cps ', contactId);
    let activity: ActivityToSend;
    if (timeout) {
      activity = {
        type: 'event',
        name: CPS_CUSTOM_EVENTS.NO_INPUT,
      };
    } else {
      activity = {
        type: 'message',
        value: { preIntent, contactId, chatbotConversationId: conversationId, sipHeaders },
        text: input,
      };
    }
    const { cpsInstance } = env;
    const { secretKey = '' } = cpsInstance || {};
    return this.cpsVoiceBotProcessor.process({
      sessionId: conversationId,
      envConfig: env,
      activityToSend: activity,
      sipHeaderLanguage: speechLanguage,
    });
  }
}
