import { Test, TestingModule } from '@nestjs/testing';
import { CopilotService } from './copilot.service';
import { AxiosResponse } from 'axios';
import config from '../../config';
import * as loggerUtils from '../../utils/logger';
import { HttpService } from '@nestjs/axios';
import { of, throwError } from 'rxjs';

jest.mock('../../utils/logger', () => ({
  logger: {
    error: jest.fn(),
    verbose: jest.fn(),
  },
}));

describe('Copilot Service Tests', () => {
  let service: CopilotService;
  let httpService: HttpService;
  const secretKey = 'xyz';
  const conversationId = 'xyz-123';
  const expectedId = '1234';
  const sessionId = '5678';
  const expectedMessageContent = 'message';
  const mockData = { data: {} } as AxiosResponse;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CopilotService, { provide: HttpService, useValue: { request: jest.fn() } }],
    }).compile();
    service = module.get<CopilotService>(CopilotService);
    httpService = module.get<HttpService>(HttpService);
  });
  afterEach(() => {
    jest.clearAllMocks();
  });
  it('should be defined', () => {
    expect(service).toBeDefined();
  });
  it('should make network request for initiate conversation', async () => {
    jest.spyOn(httpService, 'request').mockReturnValue(of(mockData));
    await service.initiateConversation(secretKey, conversationId);
    expect(httpService.request).toHaveBeenCalledWith(
      expect.objectContaining({ url: `${config.copilotApi.url}/conversations` })
    );
  });
  it('should make network request for get conversation', async () => {
    jest.spyOn(httpService, 'request').mockReturnValue(of(mockData));
    await service.getConversation(secretKey, expectedId);
    expect(httpService.request).toHaveBeenCalledWith(
      expect.objectContaining({ url: `${config.copilotApi.url}/conversations/${expectedId}` })
    );
  });
  it('should make network request for get activities', async () => {
    jest.spyOn(httpService, 'request').mockReturnValue(of(mockData));
    await service.getActivities(secretKey, expectedId, '0');
    expect(httpService.request).toHaveBeenCalledWith(
      expect.objectContaining({ url: `${config.copilotApi.url}/conversations/${expectedId}/activities?watermark=0` })
    );
  });
  it('should make network request for send activity without value', async () => {
    jest.spyOn(httpService, 'request').mockReturnValue(of(mockData));
    await service.sendActivity(secretKey, expectedId, { type: 'message', text: expectedMessageContent }, sessionId);
    expect(httpService.request).toHaveBeenCalledWith(
      expect.objectContaining({
        url: `${config.copilotApi.url}/conversations/${expectedId}/activities`,
        data: { type: 'message', text: expectedMessageContent, from: { id: sessionId } },
      })
    );
  });
  describe('error tests', () => {
    beforeEach(() => {
      jest.spyOn(httpService, 'request').mockReturnValue(throwError(() => new Error('error')));
    });
    it('should log errors in getActivities', async () => {
      await expect(service.getActivities(secretKey, 'test', '0')).rejects.toThrow();
      expect(loggerUtils.logger.error).toHaveBeenCalled();
    });
    it('should log errors in initiate conversation', async () => {
      await expect(service.initiateConversation(secretKey, conversationId)).rejects.toThrow();
      expect(loggerUtils.logger.error).toHaveBeenCalled();
    });
    it('should log errors in sendActivity', async () => {
      await expect(
        service.sendActivity(secretKey, 'test', { type: 'message', text: 'test' }, sessionId)
      ).rejects.toThrow();
      expect(loggerUtils.logger.error).toHaveBeenCalled();
    });
    it('should log errors in getConversation', async () => {
      await expect(service.getConversation(secretKey, 'test')).rejects.toThrow();
      expect(loggerUtils.logger.error).toHaveBeenCalled();
    });
  });
});
