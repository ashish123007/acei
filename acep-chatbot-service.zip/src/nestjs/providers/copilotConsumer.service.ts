import { forwardRef, Inject, Injectable } from '@nestjs/common';
import {
  Activity,
  ConversationResponse,
  CPS_CUSTOM_EVENTS,
  ActivityToSend,
  PostActivitiesResponse,
} from '../../types/copilotApi.model';
import loggerUtils from '../../utils/logger';
import { CopilotService } from './copilot.service';
import { DatabaseService } from './database.service';
import { BotEnvironment } from '../../types/bot';
import constants from '../../constants';
import { CopilotSession, CopilotSessionTable } from '../../types';
import { WebhookService } from './webhook.service';
import _ from 'lodash';
import { delay } from '../../utils/utilis/delay';
import { trackCustomDepedency } from '../../utils/appInsight';
import { replacePrivateData } from '../../utils-cps/replacePrivateData';
import { CopilotRequest, CopilotResponse, LogConfigProviders, LogType } from '../../azure-monitor/azureMonitorConfig';
import { getLogsForAzureMonitor } from '../../azure-monitor/azureMonitorService';
import azureMonitor from '../../azure-monitor';

const { TTL_ANNA_BOT_SESSION_SECONDS, DB_ITEM_TYPES } = constants;
const { logger } = loggerUtils;
const { START_CONVERSATION, SET_CONTEXT } = CPS_CUSTOM_EVENTS;

export const defaultActivityWithError = {
  type: 'message',
  id: '',
  timestamp: '',
  serviceUrl: '',
  channelId: '',
  from: {
    id: '',
    role: 'bot',
  },
  conversation: {
    id: '',
  },
  text: 'Dat heb ik niet herkend. Probeer het opnieuw met andere woorden. Wat is uw vraag?',
};
export const copilotChatLogsProvider = LogConfigProviders.AZURE_MONITOR;
export const COPILOT_ACTIVITIES_CL = 'COPILOT_ACTIVITIES_CL';

@Injectable()
export class ConsumeCopilot {
  constructor(
    private databaseService: DatabaseService,
    private copilotApiService: CopilotService,
    @Inject(forwardRef(() => WebhookService)) private hooks: WebhookService
  ) {}

  @trackCustomDepedency('fetchActivitiesFromPolling')
  private async fetchActivitiesFromPolling(
    secretKey: string,
    cpsConvId: string,
    newActivityId: string,
    timeout: number,
    pollingIntervalInMs: number
  ): Promise<Activity[]> {
    const self = this;
    const startTime = new Date().getTime();
    async function fetchActivitiesFromPollingRecursive(): Promise<Activity[]> {
      let endTime = new Date().getTime();
      let timePassed = endTime - startTime;
      if (timePassed > timeout) {
        throw new Error('Timeout hit in the execution of fetchActivitiesFromPollingRecursive function');
      }
      const watermark = newActivityId.split('|')[1] || '0';
      let activities: Activity[] = (await self.copilotApiService.getActivities(secretKey, cpsConvId, watermark))
        .activities;
      logger.debug(
        '[%s] fetchActivitiesFromPolling:: found activities (watermark=%s) %j',
        cpsConvId,
        watermark,
        activities
      );
      activities = activities.filter((activity) => (activity as any).replyToId === newActivityId);
      const endIndex = activities.findIndex(
        (activity: Activity) =>
          (activity.type === 'event' && activity.value === CPS_CUSTOM_EVENTS.ASK_FOR_CUSTOMER_INPUT) ||
          activity.channelData?.askForCustomerInput
      );
      logger.debug('[%s] fetchActivitiesFromPolling:: found indexes %j', cpsConvId, { endIndex });
      if (endIndex != -1) {
        logger.debug('[%s] fetchActivitiesFromPolling:: success %j', cpsConvId, activities);
        return activities;
      } else {
        await delay(pollingIntervalInMs);
        return fetchActivitiesFromPollingRecursive();
      }
    }
    return fetchActivitiesFromPollingRecursive();
  }

  public async getCPSSession(secretKey: string, botId: string, conversationId: string): Promise<CopilotSession> {
    const session = await this.databaseService.getSessionById(conversationId);
    if (session) {
      return {
        ...session,
        isNew: false,
      };
    } else {
      const conversation = await this.initiateNewConversation(secretKey, conversationId);
      const payload = {
        botId,
        partition: conversationId,
        type: DB_ITEM_TYPES.SESSION,
        copilotConversationId: conversation.conversationId,
        id: conversationId,
        ttl: TTL_ANNA_BOT_SESSION_SECONDS,
      };
      await this.databaseService.createSession(conversationId, payload);
      return {
        ...payload,
        isNew: true,
      };
    }
  }

  async getAllActivities(options: {
    activity: ActivityToSend;
    conversationId: string;
    envConfig: BotEnvironment;
    startConversationChannelData?: unknown;
  }) {
    const { conversationId, envConfig, startConversationChannelData } = options;
    let { activity } = options;

    if (!envConfig.cpsInstance?.secretKey) {
      throw Error('Secret key is missing!');
    }
    const session = await this.getCPSSession(envConfig.cpsInstance?.secretKey, envConfig.botId, conversationId);
    logger.debug('[%s] Received session %j', conversationId, session);
    const { copilotConversationId, privateData } = session;

    delete session?.privateData;
    /*
    In some cases, we don't know from provider if this is is a new conversation
    but if this is the first message of the session and there is no text we want to send START_CONVERSATION
     */
    if (this.isNewSessionWithEmptyActivity(session, activity)) {
      activity = {
        ...activity,
        type: 'event',
        name: START_CONVERSATION,
        value: { ...(activity.value as any), ...(startConversationChannelData as any) },
      };
    }
    const prehookResponse = await this.hooks.preHook(
      {
        ...activity,
        event: activity.type === 'event' && activity.name === START_CONVERSATION ? START_CONVERSATION : undefined,
      },
      {
        context: session,
        conversationId,
        envConfig,
        privateData,
      }
    );
    logger.debug('Prehook response: %o', prehookResponse);
    // For analytics: send user request to azure monitor
    const { RESPONSE } = LogType;
    const userRequests = [
      getLogsForAzureMonitor(
        {
          conversationId,
          copilotConversationId,
          botId: session.botId || '',
          chat_session_id: prehookResponse.context?.chatSessionId ?? '',
        },
        { userActivityStringified: JSON.stringify(prehookResponse.message) }
      ) as CopilotRequest,
    ];
    await azureMonitor(copilotChatLogsProvider, COPILOT_ACTIVITIES_CL, userRequests);
    let activities = await this.getCopilotActivities(
      copilotConversationId,
      prehookResponse.message,
      envConfig,
      conversationId
    );
    const botResponses = [
      getLogsForAzureMonitor(
        {
          conversationId,
          copilotConversationId,
          botId: session.botId || '',
          chat_session_id: prehookResponse.context?.chatSessionId ?? '',
        },
        { activities },
        RESPONSE
      ) as CopilotResponse,
    ];
    await azureMonitor(copilotChatLogsProvider, COPILOT_ACTIVITIES_CL, botResponses);
    if (!activities.length) {
      throw Error('Empty activities list fetched from copilot');
    }
    let updatedContext: CopilotSessionTable | undefined = prehookResponse.context;
    activities.forEach(({ name, value }: Activity) => {
      if (name === SET_CONTEXT) {
        const objectProps = (value as Partial<CopilotSessionTable>) ?? {};
        updatedContext = {
          ...updatedContext,
          ...objectProps,
        } as CopilotSessionTable;
      }
    });
    const hookResponse = await this.hooks.webhook(copilotConversationId, activities, {
      conversationId,
      envConfig,
      context: updatedContext,
      privateData: prehookResponse.privateData,
    });
    logger.debug('Webhook response: %o', hookResponse);
    const posthookResponse = await this.hooks.postHook(hookResponse.activities || [], {
      conversationId,
      envConfig,
      context: updatedContext,
      privateData: hookResponse.privateData,
    });
    logger.debug('posthookResponse: %o', posthookResponse);
    const isPrivateDataModified = !_.isEqual(privateData, hookResponse.privateData);
    const isSessionModified = !_.isEqual(session, posthookResponse.context);

    if (!_.isEmpty(posthookResponse.context) && (isSessionModified || isPrivateDataModified)) {
      await this.databaseService.updateSession(conversationId, {
        ...posthookResponse.context,
        privateData: posthookResponse.privateData,
      });
    }
    return posthookResponse.privateData
      ? replacePrivateData(
          _.isArray(posthookResponse.activities) ? posthookResponse.activities : [],
          posthookResponse.privateData
        )
      : posthookResponse.activities;
  }

  private isNewSessionWithEmptyActivity(session: CopilotSession, activity: ActivityToSend) {
    return session.isNew && activity.type === 'message';
  }

  public async initiateNewConversation(secretKey: string, conversationId: string) {
    const conversation = await this.copilotApiService.initiateConversation(secretKey, conversationId);
    if (!conversation) {
      throw new Error("copilotApiService initiateConversation didn't return a new cps conversation");
    }
    return conversation;
  }

  async getCopilotActivities(
    cpsConversationId: string,
    activity: ActivityToSend | undefined,
    envConfig: BotEnvironment,
    sessionId: string
  ) {
    if (!envConfig.cpsInstance?.secretKey) {
      throw new Error('fetchActivitiesFromPolling missing secret key');
    }
    if (!envConfig.cpsInstance?.timeout) {
      throw new Error('fetchActivitiesFromPolling missing timeout');
    }
    try {
      const { id: newActivityId } = await this.copilotApiService.sendActivity<PostActivitiesResponse>(
        envConfig.cpsInstance?.secretKey,
        cpsConversationId,
        activity || {},
        sessionId
      );
      const activities = await this.fetchActivitiesFromPolling(
        envConfig.cpsInstance?.secretKey,
        cpsConversationId,
        newActivityId,
        envConfig.cpsInstance?.timeout,
        envConfig.meta?.pollingInterval || 100
      );
      return activities;
    } catch (error) {
      logger.error(`[%s] copilotConsumer.service :: Error: %o`, cpsConversationId, error);
      return [
        { ...defaultActivityWithError, text: envConfig?.cpsInstance?.errorMessage || defaultActivityWithError.text },
      ] as Activity[];
    }
  }
}
