import { Test, TestingModule } from '@nestjs/testing';
import { CopilotSessionTable } from '../../types';
import { BotEnvironment } from '../../types/bot';
import { Activity, CopilotHookOptions } from '../../types/copilotApi.model';
import { ConsumeCopilot } from './copilotConsumer.service';
import { WebhookService } from './webhook.service';

const FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT: number = 7000;

jest.mock('../../utils/apiCall', () => ({
  ...jest.requireActual('../../utils/apiCall'),
  __esModule: true,
  default: jest.fn().mockImplementation((config, payload, type) => {
    if (type === 'prehook') {
      if (config.error) {
        throw new Error('Fake action error');
      }
      if (payload.message?.text === 'change text') {
        payload.message.text = 'Altered message';
      }
      if (payload.context.userDetails) {
        payload.context.userDetails = { updatedUserDetails: true };
      }
      return payload;
    } else if (type === 'webhook') {
      if (payload.context.test) {
        return { fakeData: true };
      } else if (payload.context.test2) {
        return { fakeData2: true };
      } else if (payload.context.error) {
        throw new Error('Fake webhook error');
      }
      return {};
    } else if (type === 'posthook') {
      if (config.error) {
        throw new Error('Fake action error');
      }
      if (payload.activities.some((activity: Activity) => activity.name === 'update posthook')) {
        payload.activities = [{ updatedListOfActivities: true }];
      }
      if (payload.context.userDetails) {
        payload.context.userDetails = { updatedUserDetails: true };
      }
      return payload;
    }
  }),
}));

describe('WebhookService tests', () => {
  let service: WebhookService;
  let getCopilotActivities: jest.Mock;

  beforeEach(async () => {
    getCopilotActivities = jest.fn();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        WebhookService,
        {
          provide: ConsumeCopilot,
          useValue: {
            getCopilotActivities,
          },
        },
      ],
    }).compile();

    service = module.get<WebhookService>(WebhookService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('prehook method', () => {
    it('Should return same body when no prehook configured', async () => {
      const message = { type: 'message', text: 'test' } as any;
      const result = await service.preHook(message, {
        context: {} as CopilotSessionTable,
        conversationId: 'conversationId',
        envConfig: { prehooks: [] } as unknown as BotEnvironment,
      });
      expect(result).toEqual({ message, context: {} });
    });

    it('Should override message if its altered and leave context intact', async () => {
      const message = { type: 'message', text: 'change text' } as any;
      const result = await service.preHook(message, {
        context: { asIs: true } as unknown as CopilotSessionTable,
        conversationId: 'conversationId',
        envConfig: { prehooks: [{ requestOptions: {} }] } as unknown as BotEnvironment,
      });
      const messageReceived = result.message;
      expect(messageReceived?.text).toEqual('Altered message');
      expect(result.context).toEqual({ asIs: true });
    });

    it('Should alter context if context provided', async () => {
      const body = {
        message: { type: 'message', text: 'random text' },
        context: { userDetails: true },
      } as any;
      const result = await service.preHook(body.message, {
        context: body.context,
        conversationId: 'conversationId',
        envConfig: { prehooks: [{ requestOptions: {} }] } as unknown as BotEnvironment,
      });
      const message = result.message;
      expect(message?.text).toEqual('random text');
      expect(result.context).toEqual({ userDetails: { updatedUserDetails: true } });
    });

    it('Should return same body in case prehook fails', async () => {
      const body = { type: 'message', text: 'test' } as any;
      const result = await service.preHook(body, {
        conversationId: 'conversationId',
        envConfig: { prehooks: [{ requestOptions: { error: true } }] } as unknown as BotEnvironment,
      } as CopilotHookOptions);
      expect(result).toEqual({ message: body, context: undefined });
    });
  });

  describe('Webhook method', () => {
    it('Should not call webhook if no webhook configured on bot, and return current activities', async () => {
      const activities = [{ fakeActivity: true }] as unknown as Activity[];
      const result = await service.webhook('abc123', activities, {
        conversationId: 'random id',
        envConfig: {
          webhook: { requestOptions: {} },
          cpsInstance: { timeout: FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT, secretKey: 'secretKey' },
        } as unknown as BotEnvironment,
        context: {} as CopilotSessionTable,
      });
      expect(result.activities).toEqual(activities);
    });

    it('Should not call webhook if its configured but no webhookRequest event came in', async () => {
      const activities = [{ fakeActivity: true }] as unknown as Activity[];
      const result = await service.webhook('abc123', activities, {
        conversationId: 'random id',
        envConfig: {
          webhook: { requestOptions: {} },
          cpsInstance: { timeout: FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT, secretKey: 'secretKey' },
        } as unknown as BotEnvironment,
      } as CopilotHookOptions);
      expect(result.activities).toEqual(activities);
    });

    it('Should not call webhook callcount 10 or higher', async () => {
      const activities = [
        { type: 'message', text: 'message 0' },
        { type: 'event', name: 'webhookRequest', value: { test: true } },
      ] as unknown as Activity[];
      const result = await service.webhook(
        'abc123',
        activities,
        {
          conversationId: 'random id',
          envConfig: {
            webhook: {},
            cpsInstance: { timeout: FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT, secretKey: 'secretKey' },
          } as unknown as BotEnvironment,
          context: {} as CopilotSessionTable,
        },
        10
      );
      expect(result.activities).toEqual(activities);
      expect(getCopilotActivities).not.toHaveBeenCalled();
    });

    it('Should call webhook if its configured & webhookRequest event came in', async () => {
      const cpsWebhookResponse = [
        { text: 'message 1', type: 'message' },
        { text: 'message 2', type: 'message' },
      ];
      getCopilotActivities.mockResolvedValueOnce(cpsWebhookResponse);
      const activities = [
        { type: 'message', text: 'message 0' },
        { type: 'event', name: 'webhookRequest', value: { test: true } },
      ] as unknown as Activity[];
      const result = await service.webhook('abc123', activities, {
        conversationId: 'random id',
        envConfig: {
          webhook: { requestOptions: {} },
          cpsInstance: { timeout: FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT, secretKey: 'secretKey' },
        } as unknown as BotEnvironment,
        context: {} as CopilotSessionTable,
      });

      expect(getCopilotActivities).toHaveBeenCalledWith(
        'abc123',
        {
          type: 'message',
          text: 'SystemMessage - Webhook results',
          value: { fakeData: true },
        },
        {
          webhook: { requestOptions: {} },
          cpsInstance: { timeout: FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT, secretKey: 'secretKey' },
        },
        'random id'
      );
      expect(result.activities).toEqual([{ type: 'message', text: 'message 0' }, ...cpsWebhookResponse]);
    });

    it('Should call webhook multiple times if cps returns webhookRequest again', async () => {
      const cpsWebhookResponse = [
        { text: 'message 1', type: 'message' },
        { text: 'message 2', type: 'message' },
        { type: 'event', name: 'webhookRequest', value: { test2: true } },
      ];
      const cpsWebhookResponse2 = [{ text: 'message 3', type: 'message' }];
      getCopilotActivities.mockResolvedValueOnce(cpsWebhookResponse).mockResolvedValueOnce(cpsWebhookResponse2);
      const activities = [
        { type: 'message', text: 'message 0' },
        { type: 'event', name: 'webhookRequest', value: { test: true } },
      ] as unknown as Activity[];
      const result = await service.webhook('abc123', activities, {
        conversationId: 'random id',
        envConfig: {
          webhook: { requestOptions: {} },
          cpsInstance: { timeout: FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT, secretKey: 'secretKey' },
        } as unknown as BotEnvironment,
        context: {} as CopilotSessionTable,
      });

      expect(getCopilotActivities).toHaveBeenCalledWith(
        'abc123',
        {
          type: 'message',
          text: 'SystemMessage - Webhook results',
          value: { fakeData: true },
        },
        {
          webhook: { requestOptions: {} },
          cpsInstance: { timeout: FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT, secretKey: 'secretKey' },
        },
        'random id'
      );
      expect(getCopilotActivities).toHaveBeenCalledWith(
        'abc123',
        {
          type: 'message',
          text: 'SystemMessage - Webhook results',
          value: { fakeData2: true },
        },
        {
          webhook: { requestOptions: {} },
          cpsInstance: { timeout: FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT, secretKey: 'secretKey' },
        },
        'random id'
      );
      expect(result.activities).toEqual([
        { type: 'message', text: 'message 0' },
        { text: 'message 1', type: 'message' },
        { text: 'message 2', type: 'message' },
        ...cpsWebhookResponse2,
      ]);
    });

    it('Should call webhook if its configured & webhookRequest event came in and send success false if webhook fails', async () => {
      const cpsWebhookResponse = [
        { text: 'message 1', type: 'message' },
        { text: 'message 2', type: 'message' },
      ];
      getCopilotActivities.mockResolvedValueOnce(cpsWebhookResponse);
      const activities = [
        { type: 'message', text: 'message 0' },
        { type: 'event', name: 'webhookRequest', value: { error: true } },
      ] as unknown as Activity[];
      const result = await service.webhook('abc123', activities, {
        conversationId: 'random id',
        envConfig: {
          webhook: { requestOptions: {} },
          cpsInstance: { timeout: FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT, secretKey: 'secretKey' },
        } as unknown as BotEnvironment,
        context: {} as CopilotSessionTable,
      });

      expect(getCopilotActivities).toHaveBeenCalledWith(
        'abc123',
        {
          type: 'message',
          text: 'SystemMessage - Webhook results',
          value: { success: false },
        },
        {
          webhook: { requestOptions: {} },
          cpsInstance: { timeout: FETCH_ACTIVITIES_TIMEOUT_MILLISECONDS_DEFAULT, secretKey: 'secretKey' },
        },
        'random id'
      );
      expect(result.activities).toEqual([{ type: 'message', text: 'message 0' }, ...cpsWebhookResponse]);
    });
  });

  describe('posthook method', () => {
    it('Should return same body when no posthook configured', async () => {
      const activities = [{ test: true, count: 1, gautier: 'hotty' }] as unknown as Activity[];
      const result = await service.postHook(activities, {
        conversationId: 'conversationId',
        envConfig: { posthooks: [] } as unknown as BotEnvironment,
      } as CopilotHookOptions);
      expect(result).toEqual({ activities, context: undefined });
    });

    it('Should alter context if context provided', async () => {
      const body = {
        activities: [{ type: 'message', text: 'random text' }],
        context: { userDetails: true },
      } as any;
      const result = await service.postHook(body.activities, {
        context: body.context,
        conversationId: 'conversationId',
        envConfig: { posthooks: [{ requestOptions: {} }] } as unknown as BotEnvironment,
      });
      expect(result.activities).toEqual([{ type: 'message', text: 'random text' }]);
      expect(result.context).toEqual({ userDetails: { updatedUserDetails: true } });
    });

    it('Should alter activities if activities provided', async () => {
      const body = {
        activities: [{ type: 'event', name: 'update posthook', text: 'random text' }],
        context: { randomContext: true },
      } as any;
      const result = await service.postHook(body.activities, {
        context: body.context,
        conversationId: 'conversationId',
        envConfig: { posthooks: [{ requestOptions: {} }] } as unknown as BotEnvironment,
      });
      expect(result.activities).toEqual([{ updatedListOfActivities: true }]);
      expect(result.context).toEqual(body.context);
    });

    it('Should return activities and context in case posthook fails', async () => {
      const activities = [{ test: true, count: 1 }] as unknown as Activity[];
      const result = await service.postHook(activities, {
        context: {} as CopilotSessionTable,
        conversationId: 'conversationId',
        envConfig: { posthooks: [{ requestOptions: { error: true } }] } as unknown as BotEnvironment,
      });
      expect(result).toEqual({ activities, context: {} });
    });
  });
});
