import { Test, TestingModule } from '@nestjs/testing';
import { CosmosV2 } from '../../utils/cosmos';
import { MSDSession, MSDSessionFactory } from './msdSession.service';

jest.mock('../../utils/cosmos');

const CosmosV2Mocked = CosmosV2 as jest.MockedClass<typeof CosmosV2>;

describe('MSDSession', () => {
  let service: MSDSessionFactory;
  let app: CosmosV2<MSDSession>;

  beforeEach(async () => {
    CosmosV2Mocked.mockReset();

    app = {
      get: jest.fn(),
      create: jest.fn(),
      patch: jest.fn(),
    } as unknown as CosmosV2<MSDSession>;

    CosmosV2Mocked.mockImplementation(() => {
      return app;
    });

    const module: TestingModule = await Test.createTestingModule({
      providers: [MSDSessionFactory],
    }).compile();

    service = module.get<MSDSessionFactory>(MSDSessionFactory);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should be able to create a service ', () => {
    service.createService('cid');
  });

  it('should be able createSession ', async () => {
    const i = service.createService('cid');

    await i.createSession({
      messageDeletionId: '123',
    });

    expect(app.create).toHaveBeenCalled();
  });

  it('should be able getSession', async () => {
    const i = service.createService('cid');

    await i.getSession();

    expect(app.get).toHaveBeenCalled();
  });

  it('should be able removeSchedulerId', async () => {
    const i = service.createService('cid');

    await i.replaceSession('');

    expect(app.patch).toHaveBeenCalled();
  });
});
