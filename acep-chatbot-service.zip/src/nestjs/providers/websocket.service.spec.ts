import { Test, TestingModule } from '@nestjs/testing';
import WebSocket, { WebSocketServer } from 'ws';
import { WebsocketService } from './websocket.service';
import * as activitiesWithChannelData from '../../../mocks/cps/activitiesWithChannelData.json';

describe('WebSocket Server tests', () => {
  let wss: WebSocketServer;

  let service: WebsocketService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [WebsocketService],
    }).compile();

    service = module.get<WebsocketService>(WebsocketService);
  });

  afterEach(() => {
    jest.clearAllMocks();
    wss.close();
  });

  it('Should return activities with channel Data', async () => {
    wss = new WebSocketServer({ port: 8080 });
    const activities = await service.fetchActivitiesFromWebSocket(
      'ws://localhost:8080',
      () => {
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(activitiesWithChannelData));
          }
        });
      },
      1000
    );

    expect(activities).toHaveLength(2);
  });

  it('Should hit timeout', async () => {
    wss = new WebSocketServer({ port: 8080 });
    const activities = await service.fetchActivitiesFromWebSocket('ws://localhost:8080', () => {}, 1000);

    expect(activities).toHaveLength(0);
  });

  it('Should handle event to ask for customer input', async () => {
    wss = new WebSocketServer({ port: 8080 });
    const activities = await service
      .fetchActivitiesFromWebSocket(
        'ws://localhost:8080',
        () => {
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send('{"activities":[{"type": "event", "value": "askForCustomerInput"}]}');
            }
          });
        },
        1000
      )
      .catch((error) => {
        expect(error).toBeDefined();
      });
  });
});
