import { Test, TestingModule } from '@nestjs/testing';
import { IVRSession, IVRSessionFactory } from './ivrSession.service';
import { CosmosV2 } from '../../utils/cosmos';

jest.mock('../../utils/cosmos');

const CosmosV2Mocked = CosmosV2 as jest.MockedClass<typeof CosmosV2>;

describe('IvrSesion', () => {
  let service: IVRSessionFactory;
  let app: CosmosV2<IVRSession>;

  beforeEach(async () => {
    CosmosV2Mocked.mockReset();

    app = {
      get: jest.fn(),
      create: jest.fn(),
      patch: jest.fn(),
    } as unknown as CosmosV2<IVRSession>;

    CosmosV2Mocked.mockImplementation(() => {
      return app;
    });

    const module: TestingModule = await Test.createTestingModule({
      providers: [IVRSessionFactory],
    }).compile();

    service = module.get<IVRSessionFactory>(IVRSessionFactory);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should be able to create a service ', () => {
    service.createService('cid');
  });

  it('should be able createSession ', async () => {
    const i = service.createService('cid');

    await i.createSession({
      conversationId: '123',
    });

    expect(app.create).toHaveBeenCalled();
  });

  it('should be able getSession', async () => {
    const i = service.createService('cid');

    await i.getSession();

    expect(app.get).toHaveBeenCalled();
  });

  it('should be able removeSchedulerId', async () => {
    const i = service.createService('cid');

    await i.removeSchedulerId();

    expect(app.patch).toHaveBeenCalled();
  });

  it('should be able closeSession with true to send two operations', async () => {
    const i = service.createService('cid');

    await i.closeSession(true);

    expect(app.patch).toHaveBeenCalledWith([expect.anything(), expect.anything()]);
  });

  it('should be able closeSession with false to send one operation', async () => {
    const i = service.createService('cid');

    await i.closeSession(false);

    expect(app.patch).toHaveBeenCalledWith([expect.anything()]);
  });
});
