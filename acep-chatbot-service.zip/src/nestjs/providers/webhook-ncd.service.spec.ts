import { Test, TestingModule } from '@nestjs/testing';
import { WebhookNCDService } from './webhook-ncd.service';
import { ConsumeCopilot } from './copilotConsumer.service';
import apiCall from '../../utils/apiCall';
import { CopilotSessionTable, PrehookRequest } from '../../types';
import { BotEnvironment } from '../../types/bot';
import { InternalServerErrorException } from '@nestjs/common';
import { Activity } from '../../types/copilotApi.model';

jest.mock('../../utils/apiCall', () => ({
  ...jest.requireActual('../../utils/apiCall'),
  __esModule: true,
  default: jest.fn(),
}));

jest.mock('../../azure-monitor');
jest.mock('../../utils/logger');
jest.mock('../../utils/apiCall');

describe('Webhook ncd service tests', () => {
  let service: WebhookNCDService;
  let getCopilotActivities: jest.Mock;

  beforeEach(async () => {
    getCopilotActivities = jest.fn();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        WebhookNCDService,
        {
          provide: ConsumeCopilot,
          useValue: {
            getCopilotActivities,
          },
        },
      ],
    }).compile();

    service = module.get<WebhookNCDService>(WebhookNCDService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('prehook method', () => {
    it('should invoke api in prehook when config is passed', async () => {
      const message = { context: { id: 'random_id' }, privateData: {} } as PrehookRequest;
      const envConfig = { prehooks: [{ requestOptions: {} }] } as BotEnvironment;
      const returnedPrehookValue = { returnedFromPrehook: true };
      (apiCall as jest.Mock).mockResolvedValueOnce(returnedPrehookValue);
      const response = await service.preHook(message, envConfig);
      expect(response).toEqual(returnedPrehookValue);
    });

    it('should throw error if api errors', async () => {
      const message = { context: { id: 'random_id' }, privateData: {} } as PrehookRequest;
      const hookConfig = { prehooks: [{ requestOptions: {} }] } as BotEnvironment;
      const rejectedError = new Error('Test error');
      (apiCall as jest.Mock).mockRejectedValueOnce(rejectedError);
      await expect(service.preHook(message, hookConfig)).rejects.toThrow(rejectedError);
    });

    it('should throw error if no prehook configured', async () => {
      const message = { context: { id: 'random_id' }, privateData: {} } as PrehookRequest;
      const hookConfig = {} as BotEnvironment;
      await expect(service.preHook(message, hookConfig)).rejects.toThrow(InternalServerErrorException);
    });
  });

  describe('webhook method', () => {
    it('should return everything when no webhookRequest was found in activities', async () => {
      const activities = [{ type: 'message', text: 'random text' }] as Activity[];
      const envConfig = { webhook: { requestOptions: {} } } as BotEnvironment;
      const cpsContext = { id: 'random_id' } as CopilotSessionTable;

      const result = await service.webhook('random_cps_id', activities, {
        conversationId: 'random_conversation_id',
        envConfig,
        context: cpsContext,
        privateData: { test: true },
      });
      expect(result).toBeDefined();
      expect(result.activities).toEqual(activities);
      expect(result.privateData).toEqual({ test: true });
      expect(result.context).toEqual(cpsContext);
    });

    it('should call cps with success false if api throws error', async () => {
      (apiCall as jest.Mock).mockRejectedValueOnce(new Error('Test error'));
      getCopilotActivities.mockResolvedValueOnce([{ type: 'message', text: 'added text' }]);
      const activities = [
        { type: 'message', text: 'random text' },
        { type: 'event', name: 'webhookRequest', value: {} },
      ] as Activity[];
      const envConfig = { webhook: { requestOptions: {} } } as BotEnvironment;
      const cpsContext = { id: 'random_id' } as CopilotSessionTable;

      const result = await service.webhook('random_cps_id', activities, {
        conversationId: 'random_conversation_id',
        envConfig,
        context: cpsContext,
        privateData: { test: true },
      });
      expect(apiCall).toHaveBeenCalled();
      expect(getCopilotActivities).toHaveBeenCalled();
      expect(result.activities).toEqual([
        { type: 'message', text: 'random text' },
        { type: 'message', text: 'added text' },
      ]);
      expect(result.privateData).toEqual({ test: true });
      expect(result.context).toEqual(cpsContext);
    });

    it('Should invoke webhook when config is there and webhook request is there', async () => {
      (apiCall as jest.Mock).mockResolvedValueOnce({ success: true, privateData: { updatedPrivateData: true } });
      getCopilotActivities.mockResolvedValueOnce([{ type: 'message', text: 'added text' }]);
      const activities = [
        { type: 'message', text: 'random text' },
        { type: 'event', name: 'webhookRequest', value: {} },
      ] as Activity[];
      const envConfig = { webhook: { requestOptions: {} } } as BotEnvironment;
      const cpsContext = { id: 'random_id' } as CopilotSessionTable;

      const result = await service.webhook('random_cps_id', activities, {
        conversationId: 'random_conversation_id',
        envConfig,
        context: cpsContext,
        privateData: { test: true },
      });
      expect(apiCall).toHaveBeenCalled();
      expect(getCopilotActivities).toHaveBeenCalledWith(
        'random_cps_id',
        { type: 'message', text: 'SystemMessage - Webhook results', value: { success: true } },
        envConfig,
        'random_conversation_id'
      );
      expect(result.activities).toEqual([
        { type: 'message', text: 'random text' },
        { type: 'message', text: 'added text' },
      ]);
      expect(result.privateData).toEqual({ test: true, updatedPrivateData: true });
      expect(result.context).toEqual(cpsContext);
    });
  });

  describe('posthook method', () => {
    it('should call posthook if configured', async () => {
      const activities = [{ type: 'message', text: 'random text' }] as Activity[];
      const envConfig = { posthooks: [{ requestOptions: {} }] } as BotEnvironment;
      const cpsContext = { id: 'random_id', privateData: { test: true } } as unknown as CopilotSessionTable;

      (apiCall as jest.Mock).mockResolvedValueOnce({
        activities: { someResult: true },
        context: { updatedContext: true },
        privateData: { updatedPrivateData: true },
      });

      const result = await service.postHook(activities, cpsContext, envConfig);
      expect(apiCall).toHaveBeenCalled();
      expect(result.activities).toEqual({ someResult: true });
      expect(result.context).toEqual({ ...cpsContext, updatedContext: true });
      expect(result.privateData).toEqual({ test: true, updatedPrivateData: true });
    });

    it('should return everything when no posthook configured', async () => {
      const activities = [{ type: 'message', text: 'random text' }] as Activity[];
      const envConfig = { posthooks: undefined } as unknown as BotEnvironment;
      const cpsContext = { id: 'random_id', privateData: { test: true } } as unknown as CopilotSessionTable;

      const result = await service.postHook(activities, cpsContext, envConfig);
      expect(apiCall).not.toHaveBeenCalled();
      expect(result.activities).toEqual(activities);
      expect(result.context).toEqual(cpsContext);
    });
  });
});
