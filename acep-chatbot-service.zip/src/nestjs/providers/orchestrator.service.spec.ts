import { Test, TestingModule } from '@nestjs/testing';
import { OrchestratorService } from './orchestrator.service';
import { WebhookNCDService } from './webhook-ncd.service';
import { ConsumeCopilot } from './copilotConsumer.service';
import { DatabaseService } from './database.service';
import { CopilotSessionTable, VahBody } from '../../types';
import { Activity, CPS_CUSTOM_EVENTS } from '../../types/copilotApi.model';
import { InternalServerErrorException } from '@nestjs/common';
import { BotEnvironment } from '../../types/bot';

const vahResponse = {
  branchName: 'PromptAndCollectNextResponse',
  nextPromptSequence: {
    prompts: [
      {
        transcript: 'hello, welcome to anna-test bot',
        mediaSpecificObject: {
          buttons: [],
          type: 'bot',
          contents: [
            {
              type: 'text',
              text: 'hallo sam',
            },
          ],
        },
      },
    ],
  },
};

jest.mock('applicationinsights', () => ({
  defaultClient: { trackDependency: jest.fn() },
}));

jest.mock('../../utils/logger');
jest.mock('../../azure-monitor');

jest.mock('../../azure-monitor/azureMonitorService');

describe('OrchestratorService', () => {
  let service: OrchestratorService;
  let updateSession = jest.fn();
  let getSessionById = jest.fn();
  let createSession = jest.fn();
  let initiateNewConversation = jest.fn();
  let preHook = jest.fn();
  let webhook = jest.fn();
  let postHook = jest.fn();
  let getCopilotActivities = jest.fn();

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        OrchestratorService,
        {
          provide: WebhookNCDService,
          useValue: {
            preHook,
            webhook,
            postHook,
          },
        },
        {
          provide: ConsumeCopilot,
          useValue: {
            getCopilotActivities,
            initiateNewConversation,
          },
        },
        {
          provide: DatabaseService,
          useValue: {
            getSessionById,
            createSession,
            updateSession,
          },
        },
      ],
    }).compile();

    service = module.get<OrchestratorService>(OrchestratorService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('handleRequest', () => {
    it('should go pre/cps/webhook/posthook flow in case of happy flow', async () => {
      const conversationId = 'randomId1234';
      const requestBody = { userInput: 'sammy', customPayload: {} } as unknown as VahBody;
      const envConfig = { cpsInstance: { secretKey: 'secret' } } as unknown as BotEnvironment;
      const context = { botId: 'anna-nice', id: conversationId, privateData: {} } as unknown as CopilotSessionTable;
      const activities = [
        {
          type: 'message',
          text: 'Hallo from Anna bot',
        },
        { type: 'event', name: 'setContext', value: { languageSelected: 'nl' } },
        { type: 'event', name: 'disableInputField', value: true },
      ];
      getSessionById.mockResolvedValueOnce(context);
      preHook.mockResolvedValueOnce({
        message: {
          text: 'hallo sam',
          type: 'message',
        },
        context,
        privateData: {},
      });
      getCopilotActivities.mockResolvedValueOnce(activities);
      webhook.mockResolvedValueOnce({
        activities,
        context,
        privateData: {},
      });
      postHook.mockResolvedValueOnce({
        activities: vahResponse,
        context,
        privateData: {},
      });
      const result = await service.handleRequest(conversationId, requestBody, envConfig);

      expect(result).toEqual(vahResponse);
    });

    it('should give default error message in case prehook returns no message', async () => {
      const conversationId = 'randomId1234';
      const requestBody = { userInput: 'sammy', customPayload: {} } as unknown as VahBody;
      const envConfig = { cpsInstance: { secretKey: 'secret' } } as unknown as BotEnvironment;
      const context = { botId: 'anna-nice', id: conversationId, privateData: {} } as unknown as CopilotSessionTable;
      const errorInPrehookMessage = {
        branchName: 'PromptAndCollectNextResponse',
        nextPromptSequence: {
          prompts: [
            {
              transcript: 'Er lijkt wat fout te gaan. Probeer het later nog eens.',
              mediaSpecificObject: {
                buttons: [],
                type: 'bot',
                contents: [
                  {
                    type: 'text',
                    text: 'Er lijkt wat fout te gaan. Probeer het later nog eens.',
                  },
                ],
              },
            },
          ],
        },
      };
      getSessionById.mockResolvedValueOnce(context);
      preHook.mockResolvedValueOnce(undefined);

      const result = await service.handleRequest(conversationId, requestBody, envConfig);

      expect(result).toEqual(errorInPrehookMessage);
    });

    it('should throw error in case of error scenario', async () => {
      const conversationId = 'randomId1234';
      const requestBody = { userInput: 'sammy', customPayload: {} } as unknown as VahBody;
      const envConfig = { cpsInstance: { secretKey: 'secret' } } as unknown as BotEnvironment;

      getSessionById.mockRejectedValueOnce({});

      await expect(service.handleRequest(conversationId, requestBody, envConfig)).rejects.toThrow(
        InternalServerErrorException
      );
    });
  });

  describe('setContext method', () => {
    it('Should do nothing if no setContext event is found', () => {
      const activities = [] as Activity[];
      const context = { botId: 'anna-nice' } as CopilotSessionTable;
      const updatedContext = service.handleSetContext(activities, context);
      expect(context).toEqual(updatedContext);
    });

    it('Should set context if setContext object is found', () => {
      const activities = [{ name: 'setContext', value: { languageSelected: 'en' } }] as Activity[];
      const context = { botId: 'anna-nice' } as CopilotSessionTable;
      const updatedContext = service.handleSetContext(activities, context);
      expect(updatedContext.languageSelected).toBe('en');
      expect(updatedContext.botId).toBe('anna-nice');
    });
  });

  describe('updateSession', () => {
    it('should update session if new is mutated', async () => {
      const newSession = { old: false } as unknown as CopilotSessionTable;
      const oldSession = { old: true } as unknown as CopilotSessionTable;
      await service.updateSession('random-id', oldSession, newSession);
      expect(updateSession).toHaveBeenCalledWith('random-id', newSession);
    });

    it('should not update if new is same as old', async () => {
      const newSession = { old: false } as unknown as CopilotSessionTable;
      const oldSession = { old: false } as unknown as CopilotSessionTable;
      await service.updateSession('random-id2', oldSession, newSession);
      expect(updateSession).not.toHaveBeenCalledWith('random-id2', newSession);
    });
  });

  describe('getOrCreateSession', () => {
    it('should error if no secret key found in config', async () => {
      const envConfig = {};
      await expect(service.getOrCreateSession('conv-id-1', envConfig as BotEnvironment)).rejects.toThrow(
        InternalServerErrorException
      );
    });

    it('should return existing session if available', async () => {
      const envConfig = { cpsInstance: { secretKey: 'secretkey' } } as unknown as BotEnvironment;
      getSessionById.mockResolvedValueOnce({ botId: 'anna-nice', id: 'kippetje' });
      const result = await service.getOrCreateSession('conv-id-2', envConfig);
      expect(result).toEqual({ botId: 'anna-nice', id: 'kippetje' });
    });

    it('should create new session if no session found in db', async () => {
      const envConfig = {
        cpsInstance: { secretKey: 'secretkey' },
        meta: { toggle: true },
      } as unknown as BotEnvironment;
      initiateNewConversation.mockResolvedValueOnce({ conversationId: 'conv-id-3' });
      getSessionById.mockResolvedValueOnce(null);
      const result = await service.getOrCreateSession('conv-id-3', envConfig);
      expect(result).toEqual({
        botId: undefined,
        copilotConversationId: 'conv-id-3',
        id: 'conv-id-3',
        isFirstMessage: true,
        noChannelData: true,
        partition: 'conv-id-3',
        privateData: {},
        ttl: 7800,
        type: 'session',
        meta: { toggle: true },
      });
    });
  });

  describe('removeCpsEvents method', () => {
    it('Should remove cps events', () => {
      const activities = [
        {
          name: CPS_CUSTOM_EVENTS.ASK_FOR_CUSTOMER_INPUT,
          value: 'Hollow Knight - sealed vessel',
        },
        {
          name: CPS_CUSTOM_EVENTS.CAAS_EVENT,
          value: 'Hollow Knight - sealed vessel',
        },
        {
          name: CPS_CUSTOM_EVENTS.METRICS,
          value: 'Hollow Knight - sealed vessel',
        },
        {
          name: CPS_CUSTOM_EVENTS.SET_CONTEXT,
          value: 'Hollow Knight - sealed vessel',
        },
        {
          name: CPS_CUSTOM_EVENTS.WEBHOOK_REQUEST,
          value: 'Hollow Knight - sealed vessel',
        },
        {
          text: 'hallo',
          type: 'message',
        },
      ] as Activity[];

      const result = service.removeCpsEvents(activities);

      expect(result).toEqual([
        {
          text: 'hallo',
          type: 'message',
        },
      ]);
    });
  });

  describe('handlePrivateInput method', () => {
    it('Should set privateData key-value when private input send', () => {
      const message = {
        text: '11-08-1993',
        type: 'message',
      } as Activity;
      const context = {
        privateInput: 'birthdate',
      } as CopilotSessionTable;
      const privateData = {};
      const {
        text,
        context: updatedContext,
        privateData: updatedPrivateData,
      } = service.handlePrivateInput(message, context, privateData);
      expect(text).toEqual('birthdate');
      expect(updatedContext).toEqual({ privateInput: '' });
      expect(updatedPrivateData).toEqual({
        birthdate: '11-08-1993',
      });
    });

    it('Should not do anything if privateInput not set', () => {
      const message = {
        text: 'Hallo, I am Sam!',
        type: 'message',
      } as Activity;
      const context = {
        privateInput: '',
      } as CopilotSessionTable;
      const privateData = {};
      const {
        text,
        context: updatedContext,
        privateData: updatedPrivateData,
      } = service.handlePrivateInput(message, context, privateData);
      expect(text).toEqual(message.text);
      expect(updatedContext).toEqual(context);
      expect(updatedPrivateData).toEqual(privateData);
    });

    it('Should reset privateInput key if conversation is restarted or language is changed', () => {
      const message = {
        text: '',
        name: 'resetConversation',
        type: 'event',
      } as Activity;
      const context = {
        privateInput: 'birthdate',
      } as CopilotSessionTable;
      const privateData = {};
      const {
        text,
        context: updatedContext,
        privateData: updatedPrivateData,
      } = service.handlePrivateInput(message, context, privateData);
      expect(text).toBeUndefined();
      expect(updatedContext).toEqual({ privateInput: '' });
      expect(updatedPrivateData).toEqual(privateData);

      const message2 = {
        text: '',
        name: 'languageChanged',
        type: 'event',
      } as Activity;
      const {
        text: text2,
        context: updatedContext2,
        privateData: updatedPrivateData2,
      } = service.handlePrivateInput(message2, context, privateData);
      expect(text2).toBeUndefined();
      expect(updatedContext2).toEqual({ privateInput: '' });
      expect(updatedPrivateData2).toEqual(privateData);
    });
  });
});
