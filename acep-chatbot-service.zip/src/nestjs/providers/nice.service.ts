import config from '../../config';
import { IagService } from '../../utils/iagRequest.service';
import { Injectable } from '@nestjs/common';
import loggerUtils from '../../utils/logger';
import { Mutex } from 'async-mutex';
import { NiceTokenInfo } from '../../types/utils';
import pRetry from 'p-retry';

const { logger } = loggerUtils;
const { niceApi } = config;
const MS_IN_SECONDS = 1000;
const THIRTY_SECONDS = 30 * MS_IN_SECONDS;
const IAG_RETRIES = 1;
const mutex = new Mutex();

@Injectable()
export class NiceService {
  private tokenInfo: NiceTokenInfo;

  constructor(private readonly iagService: IagService) {
    this.tokenInfo = {
      token: null,
      expiryDate: null,
    };
  }

  private async refreshToken() {
    logger.debug('[NiceApi] getting new token');

    const { access_token: accessToken, expires_in: expiresIn } = await this.iagService.iagRequest({
      method: 'post',
      url: '/third-party-api/nice/authentication/v1/auth/token',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: niceApi.authHeader,
      },
      data: `grant_type=password&username=${niceApi.authBodyUsername}&password=${niceApi.authBodyPassword}`,
    });

    this.tokenInfo = {
      token: accessToken,
      expiryDate: Date.now() + Number(expiresIn) * MS_IN_SECONDS,
    };
  }

  private async getToken() {
    const timeRemaining = this.tokenInfo.expiryDate ? this.tokenInfo.expiryDate - Date.now() : -1;

    // if the renewal process is not active
    if (!mutex.isLocked()) {
      if (
        // if token needs to be generated for the first time
        !this.tokenInfo.token ||
        // if token will expire in next 1 min
        timeRemaining <= 2 * THIRTY_SECONDS
      ) {
        await mutex.runExclusive(() =>
          pRetry(this.refreshToken.bind(this) as (attemptCount: number) => unknown, {
            maxRetryTime: THIRTY_SECONDS,
            retries: IAG_RETRIES,
          })
        );
      }
      return this.tokenInfo.token;
    }

    // if the renewal process is ongoing
    if (mutex.isLocked()) {
      // if token will expire in next 1 min
      if (timeRemaining <= 2 * THIRTY_SECONDS) {
        // close to expiration, wait for token to be renewed
        await mutex.waitForUnlock();
      }
      // existing token still has ample validity time
      return this.tokenInfo.token;
    }

    return this.tokenInfo.token;
  }

  async onSignal(contactId: string, handoverCode: string, handoverText: string) {
    logger.info(`[NiceApi] calling onSignal for contactId: ${contactId}`);
    const token = await this.getToken();
    logger.info('[NiceApi] Received token: ***');
    return await pRetry(
      async () => {
        return await this.iagService.iagRequest({
          method: 'post',
          url: `/third-party-api/nice/admin/v25/interactions/${contactId}/signal?P1=${handoverCode}&P5=${encodeURIComponent(handoverText)}`,
          headers: {
            Authorization: `Bearer ${token as string}`,
          },
          data: {
            // to be defined later
          },
        });
      },
      { maxRetryTime: THIRTY_SECONDS, retries: IAG_RETRIES }
    );
  }
}
