import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../../app.module';
import { NiceService } from './nice.service';
import { ServiceBusQueue } from '../../utils/serviceBusQueue';
import { ContentfulService } from './contentful.service';
import { IagService } from '../../utils/iagRequest.service';
import { HttpService } from '@nestjs/axios';
import { BotConfigService } from './botconfig.service';
import path from 'path';

const ServiceBusQueueMocked = ServiceBusQueue as jest.MockedClass<typeof ServiceBusQueue>;
const MOCKED_IAG_RESPONSE = { access_token: 'success', expires_in: 100 };

jest.mock('../../utils/serviceBusQueue');
jest.mock('../../config', () => ({
  ENVIRONMENT: 'jest',
  FEATURE_FLAGS: 'f1,f2',
  IVR_CALL_QUEUE_NAME: 'queue-name',
  MSD_QUEUE_NAME: 'queue-name',
  databaseOpts: {
    endpoint: 'https://local.cosmos',
  },
  niceApi: {
    authBody: 'Test Body',
    authHeader: 'Test Header',
  },
  iagApi: {
    localSanValue: '',
    cert: '',
    key: '',
    endpoint: '',
  },
}));
jest.mock('path');

describe('NiceService', () => {
  let service: NiceService;
  let iagService: IagService;
  let httpService: HttpService;
  beforeEach(async () => {
    ServiceBusQueueMocked.mockReset();
    const module: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
      providers: [
        IagService,
        NiceService,
        { provide: HttpService, useValue: { request: jest.fn() } },
        { provide: IagService, useValue: jest.fn() },
      ],
    })
      .overrideProvider(BotConfigService)
      .useValue({})
      .overrideProvider(ContentfulService)
      .useValue({})
      .compile();
    service = module.get<NiceService>(NiceService);
    httpService = module.get<HttpService>(HttpService);
    iagService = module.get<IagService>(IagService);
  });
  afterEach(() => {
    jest.clearAllMocks();
  });
  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should successfully invoke NICE onSignal', async () => {
    jest.spyOn(iagService, 'iagRequest').mockResolvedValue(MOCKED_IAG_RESPONSE);
    const result = await service.onSignal('testContactId', 'testHandoverCode', 'testHandoverText');
    expect(result.access_token).toEqual(MOCKED_IAG_RESPONSE.access_token);
  });
});
