import { Test, TestingModule } from '@nestjs/testing';
import { AcsClientFactory } from './acsCustomSdk.service';
import { parseClientArguments } from '@azure/communication-common';
import { createEmptyPipeline, Pipeline } from '@azure/core-rest-pipeline';
import * as coreClient from '@azure/core-client';
import { VoiceRequestUserType } from '../../types/voice';

jest.mock('@azure/communication-common');
jest.mock('@azure/core-rest-pipeline', () => {
  return {
    ...jest.requireActual('@azure/core-rest-pipeline'),
    createEmptyPipeline: jest.fn().mockReturnValue({
      addPolicy: jest.fn(),
    }),
  };
});
jest.mock('@azure/core-client');

const parseClientArgumentsMocked = parseClientArguments as jest.MockedFunction<typeof parseClientArguments>;
const createEmptyPipelineMocked = createEmptyPipeline as jest.MockedFunction<typeof createEmptyPipeline>;
const clientMocked = coreClient.ServiceClient as jest.MockedClass<typeof coreClient.ServiceClient>;

describe('AcsClientFactory', () => {
  let service: AcsClientFactory;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [AcsClientFactory],
    }).compile();

    service = module.get<AcsClientFactory>(AcsClientFactory);

    parseClientArgumentsMocked.mockReturnValue({
      url: 'http://acs.url.com',
      credential: { key: '' },
    });

    createEmptyPipelineMocked.mockReturnValue({
      addPolicy: jest.fn(),
    } as unknown as Pipeline);

    clientMocked.mockClear();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should be able to terminateCall', async () => {
    const client = service.createService('', 'fake-conv-id');

    const sendRequest = jest.fn().mockResolvedValue({
      status: 200,
    });
    clientMocked.mock.instances[0].sendRequest = sendRequest;

    await client.terminateCall();

    expect(sendRequest).toHaveBeenCalled();
  });

  it('should be able to play', async () => {
    const client = service.createService('', 'fake-conv-id');

    const sendRequest = jest.fn().mockResolvedValue({
      status: 200,
    });

    clientMocked.mock.instances[0].sendRequest = sendRequest;

    await client.play({
      kind: 'ssml',
      ssml: {
        ssmlText: 'hello!',
      },
    });

    expect(sendRequest).toHaveBeenCalled();
  });

  it('should be able to recognize speech', async () => {
    const client = service.createService('', 'fake-conv-id');

    const sendRequest = jest.fn().mockResolvedValue({
      status: 200,
    });

    clientMocked.mock.instances[0].sendRequest = sendRequest;

    await client.recognize({
      targetParticipantInfo: {
        kind: 'phoneNumber',
        phoneNumber: { value: '912' },
      },
      requestType: VoiceRequestUserType.SPEECH,
      bargeInEnabled: true,
    });

    expect(sendRequest).toHaveBeenCalled();
  });

  it('should be able to recognize dtmf', async () => {
    const client = service.createService('', 'fake-conv-id');

    const sendRequest = jest.fn().mockResolvedValue({
      status: 200,
    });

    clientMocked.mock.instances[0].sendRequest = sendRequest;

    await client.recognize({
      targetParticipantInfo: {
        kind: 'phoneNumber',
        phoneNumber: { value: '912' },
      },
      requestType: VoiceRequestUserType.DTMF,
      bargeInEnabled: true,
    });

    expect(sendRequest).toHaveBeenCalled();
  });

  it('should be able to acceptCall', async () => {
    const client = service.createService('', 'fake-conv-id');

    const sendRequest = jest.fn().mockResolvedValue({
      status: 200,
    });

    clientMocked.mock.instances[0].sendRequest = sendRequest;

    await client.acceptCall('ctx', 'callback');

    expect(sendRequest).toHaveBeenCalled();
  });

  it('should be able to acceptCall failure 500', async () => {
    const client = service.createService('', 'fake-conv-id');

    const sendRequest = jest.fn().mockResolvedValue({
      status: 500,
    });

    clientMocked.mock.instances[0].sendRequest = sendRequest;

    await expect(client.acceptCall('ctx', 'callback')).rejects.toThrow();
  });

  it('should be able to acceptCall failure thrown', async () => {
    const client = service.createService('', 'fake-conv-id');

    const sendRequest = jest.fn().mockRejectedValue(new Error('thrown'));

    clientMocked.mock.instances[0].sendRequest = sendRequest;

    await expect(client.acceptCall('ctx', 'callback')).rejects.toThrow();
  });
});
