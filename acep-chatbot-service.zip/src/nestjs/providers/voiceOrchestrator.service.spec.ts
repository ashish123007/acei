import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../../app.module';
import { BotEnvironment } from '../../types/bot';
import { AcsClientFactory } from './acsCustomSdk.service';
import { NiceService } from './nice.service';
import { VoiceOrchestrator } from './voiceOrchestrator.service';
import { ContentfulService } from './contentful.service';
import { ConsumeCopilot } from './copilotConsumer.service';
import { VoiceBotResponseProcessor } from './voiceBotResponseProcessor.service';
import { CPS_CUSTOM_EVENTS } from '../../types/copilotApi.model';
import { BotConfigService } from './botconfig.service';
import { VoiceOrchestratorParams, VoiceRequestUserType } from '../../types/voice';
import { IVRSessionFactory } from './ivrSession.service';
import { VoiceConstants } from '../../constants/voice';

jest.mock('../../utils/database');

const botEnv: BotEnvironment = {
  admins: [],
  viewers: [],
  editors: [],
  logs: [],
  posthooks: [],
  prehooks: [],
  skills: [],
  name: '',
  appKey: '',
  masterSkill: {
    __typename: undefined,
    name: '',
    provider: '',
  },
  channel: {
    provider: 'msteams',
    debug: false,
    isSwagFormat: false,
    allowedEvents: [],
    inputMasking: false,
    renderers: [],
    connection: [
      { key: 'microsoftAppId', value: 'microsoftAppId' },
      { key: 'microsoftAppPassword', value: 'microsoftAppPassword' },
    ],
  },
  botId: '',
  conversationTtlSeconds: 0,
  cpsInstance: {
    name: 'cps-test',
    secretKey: 'secret-key',
    timeout: 7000,
  },
};
const prodBotEnv = { ...botEnv, name: 'prod' };

describe('VoiceOrchestrator', () => {
  let service: VoiceOrchestrator;
  let acsClientFactory: AcsClientFactory;
  let voiceBotResponseProcessor: VoiceBotResponseProcessor;
  let niceService: NiceService;

  let terminateCall: jest.Mock;
  let onSignal: jest.Mock;
  let play: jest.Mock;
  let getAllActivities: jest.Mock;
  let process: jest.Mock;
  let recognize: jest.Mock;

  beforeEach(async () => {
    terminateCall = jest.fn();
    onSignal = jest.fn();
    play = jest.fn();
    getAllActivities = jest.fn();
    process = jest.fn();
    recognize = jest.fn();

    const module: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(NiceService)
      .useValue({
        onSignal,
      })
      .overrideProvider(AcsClientFactory)
      .useValue({
        createService: () => ({
          terminateCall,
          play,
          recognize,
        }),
      })
      .overrideProvider(BotConfigService)
      .useValue({})
      .overrideProvider(VoiceBotResponseProcessor)
      .useValue({ process })
      .overrideProvider(ContentfulService)
      .useValue({})
      .overrideProvider(ConsumeCopilot)
      .useValue({
        getAllActivities,
      })
      .compile();

    service = module.get<VoiceOrchestrator>(VoiceOrchestrator);
    acsClientFactory = module.get<AcsClientFactory>(AcsClientFactory);
    voiceBotResponseProcessor = module.get<VoiceBotResponseProcessor>(VoiceBotResponseProcessor);
    niceService = module.get<NiceService>(NiceService);

    jest.resetAllMocks();
  });
  describe('main method', () => {
    it('should handle none type and invoke handover', async () => {
      jest.spyOn(voiceBotResponseProcessor, 'process').mockResolvedValueOnce({
        type: 'none',
        bargeIn: false,
        payload: '',
        requestTypeFromUser: VoiceRequestUserType.SPEECH,
      });

      const input = 'test input';
      const voiceOrchestratorParams: VoiceOrchestratorParams = {
        callConnectionId: '123',
        contactId: '456',
        conversationId: '789',
        speechLanguage: 'en-US',
        target: {
          kind: 'phoneNumber',
          phoneNumber: { value: 'phoneNumber' },
        },
        env: botEnv,
        voiceName: 'voiceName',
        preIntent: 'testIntent',
      };

      await service.main(input, voiceOrchestratorParams);

      expect(niceService.onSignal).toHaveBeenCalledWith('456', VoiceConstants.DEFAULT_HANDOVER_CODE, '');
    });

    it('should recognize DTMF or SPEECH correctly', async () => {
      jest.spyOn(voiceBotResponseProcessor, 'process').mockResolvedValueOnce({
        type: 'ssml',
        payload: '<speak>Test</speak>',
        bargeIn: false,
        requestTypeFromUser: VoiceRequestUserType.DTMF,
      });

      const input = 'test input';
      const voiceOrchestratorParams: VoiceOrchestratorParams = {
        callConnectionId: '123',
        contactId: '456',
        conversationId: '789',
        speechLanguage: 'en-US',
        target: {
          kind: 'phoneNumber',
          phoneNumber: { value: 'phoneNumber' },
        },
        env: botEnv,
        voiceName: 'voiceName',
        preIntent: 'testIntent',
      };

      await service.main(input, voiceOrchestratorParams);

      expect(recognize).toHaveBeenCalledWith(
        expect.objectContaining({
          requestType: VoiceRequestUserType.DTMF,
        })
      );
    });

    it('should handle error and fallback to handover', async () => {
      jest.spyOn(voiceBotResponseProcessor, 'process').mockRejectedValueOnce(new Error('Test Error'));

      const input = 'test input';
      const voiceOrchestratorParams: VoiceOrchestratorParams = {
        callConnectionId: '123',
        contactId: '456',
        conversationId: '789',
        speechLanguage: 'en-US',
        target: {
          kind: 'phoneNumber',
          phoneNumber: { value: 'phoneNumber' },
        },
        env: botEnv,
        voiceName: 'voiceName',
        preIntent: 'testIntent',
      };

      await service.main(input, voiceOrchestratorParams);

      expect(niceService.onSignal).toHaveBeenCalledWith('456', VoiceConstants.DEFAULT_HANDOVER_CODE, '');
    });
  });
  describe('other tests', () => {
    it('should be defined', () => {
      expect(service).toBeDefined();
    });

    it('On lower environments, should be able to play static promot', async () => {
      await service.handover(
        {
          code: 'HDLF',
          handText: '',
          callConnectionId: '0611',
          conversationId: 'cid',
          contactId: '',
        },
        botEnv
      );
      expect(play).toHaveBeenCalled();
    });

    it('should be able to call terminate call on prod when contactId is missing', async () => {
      await service.handover(
        {
          code: '',
          handText: '',
          callConnectionId: '',
          conversationId: 'cid',
          contactId: '',
        },
        prodBotEnv
      );

      expect(terminateCall).toHaveBeenCalled();
    });

    it('On lower environments, should not terminate call when outside of contactId scope and play prompt', async () => {
      await service.handover(
        {
          code: 'HDLF',
          handText: '',
          callConnectionId: '0611',
          conversationId: 'cid',
          contactId: '',
        },
        botEnv
      );

      expect(terminateCall).not.toHaveBeenCalled();
      expect(play).toHaveBeenCalled();
    });

    it('On production, should be able to handover with contactId', async () => {
      await service.handover(
        {
          code: 'HDLF',
          handText: '',
          callConnectionId: '0611',
          conversationId: 'cid',
          contactId: '123',
        },
        prodBotEnv
      );

      expect(onSignal).toHaveBeenCalled();
      expect(getAllActivities).toHaveBeenCalledWith({
        activity: { type: 'event', name: CPS_CUSTOM_EVENTS.NICE_HANDOVER, value: 'HDLF' },
        conversationId: 'cid',
        envConfig: prodBotEnv,
      });
    });
  });
});
