import { Test, TestingModule } from '@nestjs/testing';
import { CpsVoiceBotProcessor } from './cpsVoiceBotProcessor.service';
import { ConsumeCopilot } from './copilotConsumer.service';
import { ContentfulService } from './contentful.service';
import { VoiceRequestUserType } from '../../types/voice';
import { BotEnvironment } from '../../types/bot';
import { ActivityToSend } from '../../types/copilotApi.model';
import { VoiceConstants } from '../../constants/voice';

jest.mock('../../utils/logger');

describe('CpsVoiceBotProcessor', () => {
  let service: CpsVoiceBotProcessor;
  let getCopilotActivitiesClient: jest.Mocked<ConsumeCopilot>;
  let contentfulService: jest.Mocked<ContentfulService>;

  beforeEach(async () => {
    const mockConsumeCopilot = {
      getAllActivities: jest.fn(),
    };

    const mockContentfulService = {
      getEntries: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CpsVoiceBotProcessor,
        { provide: ConsumeCopilot, useValue: mockConsumeCopilot },
        { provide: ContentfulService, useValue: mockContentfulService },
      ],
    }).compile();

    service = module.get<CpsVoiceBotProcessor>(CpsVoiceBotProcessor);
    getCopilotActivitiesClient = module.get(ConsumeCopilot);
    contentfulService = module.get(ContentfulService);
  });

  describe('process', () => {
    it('should handle process correctly with activities', async () => {
      const options = {
        sessionId: '123',
        envConfig: {} as BotEnvironment,
        activityToSend: {
          type: 'message',
          text: 'Hello',
          value: {},
        } as ActivityToSend,
        secretKey: 'secret',
        sipHeaderLanguage: 'en-US',
        timeout: 1000,
      };

      // Properly mock the method and cast it to a jest mock function
      getCopilotActivitiesClient.getAllActivities.mockResolvedValueOnce([
        { type: 'message', from: { id: '123', role: 'bot' }, text: 'contentfulId1,contentfulId2' },
      ]);

      contentfulService.getEntries.mockResolvedValueOnce([{ fields: { responses: [] } }]);

      const result = await service.process(options);

      expect(getCopilotActivitiesClient.getAllActivities).toHaveBeenCalledWith({
        conversationId: '123',
        envConfig: options.envConfig,
        activity: options.activityToSend,
      });
      expect(contentfulService.getEntries).toHaveBeenCalledWith(
        ['contentfulId1', 'contentfulId2'],
        options.sipHeaderLanguage
      );
      expect(result).not.toBeNull();
    });

    it('should handle an error in process gracefully', async () => {
      const options = {
        sessionId: '123',
        envConfig: {} as BotEnvironment,
        activityToSend: {
          type: 'message',
          text: 'Hello',
          value: { preIntent: 'testIntent' },
        } as ActivityToSend,
        secretKey: 'secret',
        sipHeaderLanguage: 'en-US',
        timeout: 1000,
      };

      getCopilotActivitiesClient.getAllActivities.mockRejectedValueOnce(new Error('Test Error'));

      const result = await service.process(options);

      expect(result).toEqual({
        requestTypeFromUser: VoiceRequestUserType.NONE,
        bargeIn: false,
        handoverCode: VoiceConstants.DEFAULT_HANDOVER_CODE,
        type: 'none',
        payload: '',
      });
    });
  });
});
