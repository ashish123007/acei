import {
  Injectable,
  CanActivate,
  ExecutionContext,
  createParamDecorator,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import createError from '../../utils/error';
import { BotConfigService } from '../providers/botconfig.service';
import constants from '../../constants';
import { MessageHubRequest } from '../../types';

const { TYPES, ERROR_MESSAGE } = constants;

@Injectable()
export class ApiKeyGuard implements CanActivate {
  constructor(private botConfigService: BotConfigService) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<MessageHubRequest>();
    const botEnvConfig = this.botConfigService.getBotEnvConfig(request.headers['x-api-key']);
    const { botId } = request.params;
    if (botEnvConfig) {
      request.botEnvConfig = botEnvConfig;
      // !botId is used for vah, has it doesn't have path param
      if (!botId || botEnvConfig.botId === botId) {
        return true;
      }
    }
    const err = createError(HttpStatus.UNAUTHORIZED, TYPES.ERROR, ERROR_MESSAGE.INVALID_AUTHENTICATION);
    throw new HttpException(err, HttpStatus.UNAUTHORIZED);
  }
}

export const BotEnvDecorator = createParamDecorator((_data: unknown, ctx: ExecutionContext) => {
  const request = ctx.switchToHttp().getRequest<MessageHubRequest>();
  return request.botEnvConfig;
});
