import { Test, TestingModule } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../../app.module';
import { BotConfigService } from '../providers/botconfig.service';
import { ContentfulService } from '../providers/contentful.service';

describe('ApiKeyGuard', () => {
  let module: TestingModule;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(BotConfigService)
      .useValue({
        getBotEnvConfig: () => null,
      })
      .overrideProvider(ContentfulService)
      .useValue({})
      .compile();
  });

  it(`send unauthorized when using empty config provider`, async () => {
    let app = module.createNestApplication();
    await app.init();

    await request(app.getHttpServer()).post('/message-hub/demobot/prod/voice/receive').send({}).expect(401);
  });
});
