import {
  Injectable,
  CanActivate,
  ExecutionContext,
  HttpException,
  HttpStatus,
  UnauthorizedException,
} from '@nestjs/common';
import { verify, JwtHeader, SigningKeyCallback, Secret } from 'jsonwebtoken';
import { JwksClient } from 'jwks-rsa';
import createError from '../../utils/error';
import { BotConfigService } from '../providers/botconfig.service';
import constants from '../../constants';
import { BotEnvironment } from '../../types/bot';
import { VoiceIVRCallbackRequests } from '../../types';
import loggerUtils from '../../utils/logger';
import config from '../../config';
import { trackCustomDepedency } from '../../utils/appInsight';

const { ACS_AUDIENCE, ACS_URL } = config;
const { logger } = loggerUtils;
const { TYPES, ERROR_MESSAGE } = constants;

const audience = ACS_AUDIENCE;
const issuer = 'https://acscallautomation.communication.azure.com';

@Injectable()
export class VoiceAcs implements CanActivate {
  private jwksClient;

  constructor(private botConfigService: BotConfigService) {
    try {
      this.jwksClient = new JwksClient({
        jwksUri: ACS_URL + 'calling/keys',
      });
    } catch (err) {
      logger.error('VoiceAcs: unable to fetch keys for voicebot error %o', err);
    }
  }

  private extractTokenFromHeader(request: VoiceIVRCallbackRequests): string | undefined {
    const [type, token] = request.headers.authorization?.split(' ') ?? [];
    return type === 'Bearer' ? token : undefined;
  }

  private async getKey(header: JwtHeader, callback: SigningKeyCallback) {
    if (!this.jwksClient) {
      callback(new Error('jwksClient not instantiated'));
    } else {
      try {
        const response = await this.jwksClient.getSigningKey(header.kid);
        const publicKey = response.getPublicKey();
        callback(null, publicKey);
      } catch (e) {
        logger.error('Unable to getSigningKey %o', e);
        callback(e);
      }
    }
  }

  @trackCustomDepedency('WebhookValidation')
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<VoiceIVRCallbackRequests>();
    const conversationId = request.query?.conversationId;
    const token = this.extractTokenFromHeader(request);
    if (!token) {
      logger.warn('[%s] ACS-webhook-auth-failure (token not provided)', conversationId);
      throw new UnauthorizedException();
    }
    try {
      const verifyPromisified = new Promise((resolve, reject) =>
        verify(token, this.getKey.bind(this) as Secret, { audience, issuer, algorithms: ['RS256'] }, (err, decoded) =>
          err ? reject(err) : resolve(decoded)
        )
      );
      await verifyPromisified;
      const { botId, channelEnv } = request.params;
      const botEnvConfig: BotEnvironment | undefined = this.botConfigService.getBotEnvConfigViaTeams(
        botId,
        channelEnv.toLowerCase()
      );
      if (!botEnvConfig) {
        logger.warn('[%s] VoiceAcs :: request has been denied with params %j', conversationId, request.params);
        const err = createError(HttpStatus.UNAUTHORIZED, TYPES.ERROR, ERROR_MESSAGE.INVALID_AUTHENTICATION);
        throw new HttpException(err, HttpStatus.UNAUTHORIZED);
      }
      request.botEnvConfig = botEnvConfig;
      logger.info('[%s] ACS-webhook-auth-success ', conversationId);
      return true;
    } catch (err) {
      logger.warn('[%s] ACS-webhook-auth-failure (error %o)', conversationId, err);
      throw new UnauthorizedException();
    }
  }
}
