import { Test, TestingModule } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../../app.module';
import { BotConfigService } from '../providers/botconfig.service';
import { verify } from 'jsonwebtoken';
import { JwksClient } from 'jwks-rsa';
import { ContentfulService } from '../providers/contentful.service';

jest.mock('jsonwebtoken');
jest.mock('jwks-rsa');
jest.mock('../../utils/appInsight', () => ({
  trackCustomDepedency:
    () =>
    (_target: any, _propertyKey: string, descriptor: TypedPropertyDescriptor<(...params: any[]) => Promise<any>>) => {
      const oldFunc = descriptor.value;
      descriptor.value = async function () {
        return await oldFunc?.apply(this, arguments);
      };
    },
}));

const jwksClientMocked = JwksClient as jest.MockedClass<typeof JwksClient>;
const verifyMocked = verify as jest.MockedFunction<typeof verify>;

const SOURCE_FROM_DATA_QP =
  'sourceFromData%5Bkind%5D=phoneNumber&sourceFromData%5BphoneNumber%5D%5Bvalue%5D=%2B31020&conversationId=fakeCid';
const CALLBACKS_QPS = `${SOURCE_FROM_DATA_QP}&sourceFromNumber=%2B31020`;

describe('ApiKeyGuard', () => {
  let module: TestingModule;

  beforeEach(async () => {
    jwksClientMocked.mockReset();
    verifyMocked.mockReset();
    module = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(BotConfigService)
      .useValue({
        getBotEnvConfig: () => ({ botId: 'voice' }),
        getBotEnvConfigViaTeams: () => ({ botId: 'voice' }),
      })
      .overrideProvider(ContentfulService)
      .useValue({})
      .compile();
  });

  it(`constructor is called`, async () => {
    let app = module.createNestApplication();
    await app.init();

    verifyMocked.mockImplementationOnce((_token, _secret, _params, callback) => {
      if (typeof callback === 'function') {
        callback(null, {});
      } else {
        console.error('not a function');
      }
    });

    await request(app.getHttpServer())
      .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
      .send([])
      .set({ Authorization: 'Bearer 123abc' })
      .expect(200);

    expect(jwksClientMocked).toHaveBeenCalled();
    expect(verifyMocked).toHaveBeenCalled();
  });

  it(`throw 401 error when no token is passed`, async () => {
    let app = module.createNestApplication();
    await app.init();

    verifyMocked.mockImplementationOnce((_token, _secret, _params, callback) => {
      if (typeof callback === 'function') {
        callback(null, {});
      } else {
        console.error('not a function');
      }
    });

    await request(app.getHttpServer())
      .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
      .send([])
      .set({ Authorization: '' })
      .expect(401);
  });

  it('should be able to support a jwksClientMocked throwing error', async () => {
    jwksClientMocked.mockImplementationOnce(() => {
      throw new Error('failing internal');
    });
    let app = module.createNestApplication();
    await app.init();

    verifyMocked.mockImplementationOnce((_token, _secret, _params, callback) => {
      if (typeof callback === 'function') {
        callback(new Error('failure') as any, {});
      } else {
        console.error('not a function');
      }
    });

    await request(app.getHttpServer())
      .post(`/voice-hub/voice-bot/prod/callbacks?${CALLBACKS_QPS}`)
      .send([])
      .set({ Authorization: 'Bearer 123abc' })
      .expect(401);
  });
});
