import { Activity } from '../types/copilotApi.model';
import { filterByCustomConditions } from './formatter';

describe('filterByCustomConditions', () => {
  it('should filter activities based on the provided conditions map', () => {
    const activities = [
      { id: '1', type: 'message', status: 'completed' },
      { id: '2', type: 'message', status: 'pending' },
      { id: '3', type: 'event', status: 'completed' },
    ];
    const conditionsMap = { type: 'message', status: 'completed' };

    const filteredActivities = filterByCustomConditions(activities as unknown as Activity[], conditionsMap);

    expect(filteredActivities).toEqual([{ id: '1', type: 'message', status: 'completed' }]);
  });

  it('should return an empty array if no activities match the conditions', () => {
    const activities = [
      { id: '1', type: 'message', status: 'completed' },
      { id: '2', type: 'message', status: 'pending' },
    ];
    const conditionsMap = { type: 'event', status: 'completed' };

    const filteredActivities = filterByCustomConditions(activities as unknown as Activity[], conditionsMap);

    expect(filteredActivities).toEqual([]);
  });

  it('should return all activities if the conditions map is empty', () => {
    const activities = [
      { id: '1', type: 'message', status: 'completed' },
      { id: '2', type: 'message', status: 'pending' },
    ];
    const conditionsMap = {};

    const filteredActivities = filterByCustomConditions(activities as unknown as Activity[], conditionsMap);

    expect(filteredActivities).toEqual(activities);
  });

  it('should return an empty array if activities array is empty', () => {
    const activities: unknown = [];
    const conditionsMap = { type: 'message', status: 'completed' };

    const filteredActivities = filterByCustomConditions(activities as unknown as Activity[], conditionsMap);

    expect(filteredActivities).toEqual([]);
  });
});
