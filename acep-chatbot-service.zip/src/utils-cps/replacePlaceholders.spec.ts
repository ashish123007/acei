import { replacePlaceholders } from './replacePlaceholders';

describe('Replace placeholders', () => {
  it('should replace text with data', () => {
    const result = replacePlaceholders('Should replace ((thisText))', { thisText: 'tada!' });
    expect(result).toEqual('Should replace tada!');
  });

  it('should handle non-matching keys', () => {
    const result = replacePlaceholders('Should not replace ((this))', { thisText: 'tada!' });
    expect(result).toEqual('Should not replace ((this))');
  });

  it('should handle null keys', () => {
    const result = replacePlaceholders('Should not replace ((this))', { thisText: null });
    expect(result).toEqual('Should not replace ((this))');
  });
});
