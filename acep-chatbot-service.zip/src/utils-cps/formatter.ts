import { Activity } from '../types/copilotApi.model';

export const filterByCustomConditions = (cpsActivities: Activity[], condtionsMap: Record<string, string>) => {
  return cpsActivities.filter((cpsActivity) => {
    for (let key in condtionsMap) {
      if (
        cpsActivity[key as keyof typeof cpsActivity] === undefined ||
        cpsActivity[key as keyof typeof cpsActivity] !== condtionsMap[key]
      ) {
        return false;
      }
    }
    return true;
  });
};
