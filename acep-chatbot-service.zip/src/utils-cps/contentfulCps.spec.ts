import { getContentfulEntries } from './contentfulCps';

jest.mock('../utils/redis', () => ({
  contentfulRedisClient: {
    getCacheList: async (_ids: any[]) => [null, null, null],
    setCacheList: async (_ids: any[]) => {},
  },
}));

const sampleEntryIds = ['709aX1NKUKJsuPN5pMJYUp', '7pmfyimxJCEIP6L2bgkND8', '6Rp5pYevUZNPTPm3o1u29F'];

class ContentfulClient {
  async getEntries(_obj: {}) {
    return {
      items: sampleEntryIds.map((sampleEntryId) => ({
        sys: {
          id: sampleEntryId,
        },
      })),
    };
  }
}

describe('Enabling redis', () => {
  it('should fetch contentful when no cache is set', async () => {
    const client = new ContentfulClient() as any;
    const result = await getContentfulEntries(sampleEntryIds, client, 'en-US');
    expect(result).toEqual([
      { sys: { id: sampleEntryIds[0] } },
      { sys: { id: sampleEntryIds[1] } },
      { sys: { id: sampleEntryIds[2] } },
    ]);
  });
});
