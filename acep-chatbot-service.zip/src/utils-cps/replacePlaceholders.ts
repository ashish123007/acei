import { JsonMap } from '../types/utils';

export const replacePlaceholders = (text: string, data: JsonMap): string => {
  /*
      text: This is sample test: (test), (notFound)
      data: {test: 'abc'}
      result: This is sample test: abc, (notFound)
    */
  const VALUE_WITHIN_BRACKETS_REGEX = /\(\((.*?)\)\)/g;
  return text.replace(VALUE_WITHIN_BRACKETS_REGEX, (match, p) => {
    return data[p] !== undefined ? data[p]?.toString() || '' : match;
  });
};
