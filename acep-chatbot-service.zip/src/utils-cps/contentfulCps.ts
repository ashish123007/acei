import _ from 'lodash';
import { ContentfulClientApi, EntriesQueries, FieldsType } from 'contentful';
import { contentfulRedisClient } from '../utils/redis';
import loggerUtils from '../utils/logger';

const { logger } = loggerUtils;

export const getContentfulEntries = async <T extends FieldsType>(
  ids: string[],
  contentfulClient: ContentfulClientApi,
  languagePreference: string
) => {
  const entriesToFetch: string[] = [];
  const idWithLanguage = ids.map((id) => id + ',' + languagePreference);
  const cachedEntries = await contentfulRedisClient.getCacheList(idWithLanguage);
  // Using Lodash fromPairs and zip to build the hash map
  // const ids= ["709aX1NKUKJsuPN5pMJYUp", "7pmfyimxJCEIP6L2bgkND8", "6Rp5pYevUZNPTPm3o1u29F"]
  // const cachedEntries = [null, null, null]
  // output --> {709aX1NKUKJsuPN5pMJYUp: null, 7pmfyimxJCEIP6L2bgkND8: null, 6Rp5pYevUZNPTPm3o1u29F: null}
  const contentfulIdsMap = _.fromPairs(_.zip(ids, cachedEntries));
  _.keys(contentfulIdsMap).map((contentfulId) => {
    const cachedEntry = contentfulIdsMap[contentfulId];
    if (!cachedEntry) {
      entriesToFetch.push(contentfulId);
    } else {
      const contentfulItem = JSON.parse(cachedEntry);
      contentfulIdsMap[contentfulId] = contentfulItem;
    }
  });
  if (entriesToFetch?.length) {
    logger.info('list of entries to be fetched from contentful api :: %j', entriesToFetch);
    try {
      const entryIds = entriesToFetch.join(',');
      logger.info('Preferred language by user %s', languagePreference.slice(0, 2));
      const { items: fetchedItems } = await contentfulClient.getEntries<T>({
        'sys.id[in]': entryIds,
        locale: languagePreference.slice(0, 2),
        include: 2,
      } as EntriesQueries<T>);
      if (fetchedItems.length) {
        logger.debug('Contentful items response: %j', fetchedItems);
        const contentfulCached: Array<{ id: string; value: string }> = [];
        fetchedItems.map((fetchedItem) => {
          const contentfulEntriesId = fetchedItem.sys.id;
          contentfulIdsMap[contentfulEntriesId] = fetchedItem;
          contentfulCached.push({
            id: contentfulEntriesId + ',' + languagePreference,
            value: JSON.stringify(fetchedItem),
          });
        });
        await contentfulRedisClient.setCacheList(contentfulCached);
      }
    } catch (error) {
      logger.error('unable to get ids from contentful %o', error);
      throw error;
    }
  }
  const contentfulItems = _.keys(contentfulIdsMap).map((contentfulId) => {
    return contentfulIdsMap[contentfulId];
  });
  return contentfulItems;
};
