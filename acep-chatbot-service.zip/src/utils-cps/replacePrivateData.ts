import { Activity } from '../types/copilotApi.model';
import { JsonMap } from '../types/utils';
import { replacePlaceholders } from './replacePlaceholders';

export const replacePrivateData = (activities: Activity[], privateData: JsonMap) =>
  activities.map((activity) => {
    const updatedText = activity.text && privateData ? replacePlaceholders(activity.text, privateData) : activity.text;
    return {
      ...activity,
      text: updatedText,
    };
  });
