import { Test } from '@nestjs/testing';
import { AppModule } from './app.module';
import { BotConfigService } from './nestjs/providers/botconfig.service';
import { ContentfulService } from './nestjs/providers/contentful.service';

describe('AppModule', () => {
  it('should compile the module', async () => {
    const module = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(ContentfulService)
      .useValue({})
      .compile();

    expect(module).toBeDefined();
    expect(module.get(BotConfigService)).toBeInstanceOf(BotConfigService);
  });
});
