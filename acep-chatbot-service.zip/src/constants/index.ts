const TTL_IVR_SESSION_MINS = 3600;
const TTL_ANNA_BOT_SESSION_SECONDS = 7800;
const TTL_CACHE_CONTENTFUL_DAYS = 60 * 60 * 72; // 3 days
const API_TIMEOUT = 7000;
const AZURE_SDK_SERVICE_TIMEOUT = 3000;
const IVR_CALL_TIMEOUT_MINS = 15;
const API_CALL_DEFAULT_TIMEOUT = 2000;

const TYPES = {
  MESSAGE: 'message',
  ERROR: 'error',
};

const GENERIC_MESSAGE = {
  '139b4707': 'Oh jee, ik ben even in de war. Heeft u een andere vraag, start mij dan opnieuw op.',
  default:
    'The server encountered an internal error or misconfiguration and was unable to complete your request. Can I help you with a different question?',
};

const ERROR_MESSAGE = {
  MISSING_CONVERSATION_ID: 'Field conversationId missing in request body',
  AUTHENTICATION: 'Set valid authentication headers under X-API-ID and X-API-KEY.',
  INVALID_AUTHENTICATION: 'Set valid authentication headers under X-API-ID and X-API-KEY.',
  DEFAULT: 'The server encountered an internal error or misconfiguration and was unable to complete your request.',
};

export const EVENTS = {
  MESSAGE: 'message',
  EVENT: 'event',
  START_CONVERSATION: 'startConversation',
  NEW_USER_QUERY: 'newUserQuery',
  ENGLISH_BUTTON_CLICKED: 'englishButtonClicked',
};

const VAH = {
  PROMPT_AND_COLLECT_NEXT_RESPONSE: 'PromptAndCollectNextResponse',
  RETURN_CONTROL_TO_SCRIPT: 'ReturnControlToScript',
};

const DB_ITEM_TYPES = {
  SESSION: 'session',
};

const ADAPTIVE_CARD_TYPE = 'application/vnd.microsoft.card.adaptive' as const;
const ADAPTIVE_CARD_CONTENT = 'AdaptiveCard';

export const constants = {
  DB_ITEM_TYPES,
  TYPES,
  GENERIC_MESSAGE,
  ERROR_MESSAGE,
  EVENTS,
  API_TIMEOUT,
  AZURE_SDK_SERVICE_TIMEOUT,
  IVR_CALL_TIMEOUT_MINS,
  API_CALL_DEFAULT_TIMEOUT,
  TTL_IVR_SESSION_MINS,
  TTL_ANNA_BOT_SESSION_SECONDS,
  TTL_CACHE_CONTENTFUL_DAYS,
  VAH,
  ADAPTIVE_CARD_TYPE,
  ADAPTIVE_CARD_CONTENT,
};

export default constants;
