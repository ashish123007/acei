import { NestFactory } from '@nestjs/core';
import { FastifyAdapter, NestFastifyApplication } from '@nestjs/platform-fastify';
import { AppModule } from './app.module';
import config from './config';
import loggerUtils from './utils/logger';
import { startAppInsight } from './utils/appInsight';

const { logger } = loggerUtils;
const { PORT } = config;

async function bootstrap() {
  try {
    startAppInsight();
    const adapter = new FastifyAdapter();
    const app = await NestFactory.create<NestFastifyApplication>(AppModule, adapter);
    app.enableCors();
    await app.listen(PORT, '0.0.0.0');
    logger.info('listening on port %s', PORT);
  } catch (err) {
    logger.error('unable to start nest %o', err);
  }

  // this is not recomanded so disabled by default, all error should be caught and not cause container crash
  // if one is missed on production this could cause all pods/container to crash and affect all project
  // this flag can then be enabled as temporary mesure
  if (process.env.UNSAFE_NODEJS_CATCH_ALL) {
    process
      .on('unhandledRejection', (reason, p) => {
        logger.error('Unhandled Rejection at Promise %o from promise %j', reason, p);
      })
      .on('uncaughtException', (err) => {
        logger.error('Uncaught Exception thrown %o', err);
      });
  }
}

// eslint-disable-next-line @typescript-eslint/no-floating-promises
bootstrap();
