import { NestFactory } from '@nestjs/core';

jest.mock('@nestjs/core');

const mockedNestJsFactory = NestFactory as jest.Mocked<typeof NestFactory>;

describe('main', () => {
  it('should instanciate app', () => {
    const listen = jest.fn();

    mockedNestJsFactory.create.mockResolvedValue({
      listen,
    } as any);

    require('./main');

    expect(mockedNestJsFactory.create).toHaveBeenCalled();
  });
});
