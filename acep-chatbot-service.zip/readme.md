# Chatbot-service

[Botkit Docs](https://botkit.ai/docs/v4)

This bot is powered by [a folder full of modules](https://botkit.ai/docs/v4/core.html#organize-your-bot-code).
Edit the samples, and add your own in the [features/](features/) folder.

## Getting Started

- `npm i`
- create local-setup/chatbot-service-secret.env file
- export $(cat ./local-setup/chatbot-service.env | xargs) && export $(cat ./local-setup/chatbot-service-secret.env | xargs) && npm run start:dev

## Web Channel

```bash
 curl --location --request POST 'http://localhost:1000/message-hub/demobot/prod/web/receive' \
--header 'X-API-KEY: 58f58bbd-de99-4d51-b012-dbb5e9710431' \
--header 'X-API-ID: demobot' \
--header 'Content-Type: application/json' \
--data-raw '{
        "type": "message",
        "message": {
                "text": ""
                },
        "conversationId": "local-123",
        "userId": "user1123"
}'
```

## VAH Channel

Start chat:

```bash
curl --location --request POST 'http://localhost:1000/text-messages' \
--header 'X-API-KEY: 98b93684-5829-43ba-baee-48d88d774948' \
--header 'Content-Type: application/json' \
--data-raw '{
    "virtualAgentId": "chatbot-anna",
    "userInput": "WELCOME",
    "userInputType": 5,
    "executionInfo": {
        "contactId": "vah-testing-01"
    },
    "customPayload": {
        "userId": "postman-test",
        "bcNumber": "mockbcNumber",
        "uvid": "mockUVID"
    }
}'
```

Send message:

```bash
curl --location --request POST 'http://localhost:1000/text-messages' \
--header 'X-API-KEY: e0a081a6-3022-41bc-8780-9730df71595f' \
--header 'Content-Type: application/json' \
--data-raw '{
    "virtualAgentId": "chatbot-anna",
    "userInput": "Hi",
    "userInputType": 1,
    "executionInfo": {
        "contactId": "vah-testing-01"
    },
    "customPayload": {
        "userId": "postman-test",
        "bcNumber": "mockbcNumber",
        "uvid": "mockUVID"
    }
}'
```

## Contentful

In case you want to run locally and you get the error "[warning] Connection error occurred. Waiting for 2050 ms before retrying..", put the
following command in the command line: export NODE_TLS_REJECT_UNAUTHORIZED=0

## Test integration tests locally

1. cd integration
2. newman run collection.json -e env/{{env}}.json
