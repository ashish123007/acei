# Release notes

## 1.0.0

CBaaS first version of the chatbot service

### Added

CIEDC-14681

    Create first version of chatbot service with xstate

CIEDC-16024

    Dynamo DB for session aand context table

CIEDC-15455

    Added Abby's response to emoticons correlation logic

CIEDC-17009

    First version released to ST (AWS-D, AWS-T)environment

CIEDC-15607

    Prehook and posthook implementation

CIEDC-16801

    Production First release of chatbot-service (09-09-2020)

CIEDC-18084

    Add integration test cases for prehook and posthook

CIEDC-17796

    Send BCNumber to webhoook

CIEDC-18404

    Bug-fix for emoticons write issues in dynamo db

CIEDC-17951

    Chatbot service should ignore special characters like new-line in user utterance

CIECD-18428

    Passed conversation and user id to WAAT Api

CIEDC-18314

    Removed masking for numerals(0-10) to measure NPR for chats

CIEDC-18298

    Removed anna specific code for startConversation event

CIEDC-18642

    Error handling for xstate machine failure

CIEDC-19639

     Added pre-hooks for lint and unit-test

CIEDC-19541

    Abby on teams prod bug- Increased machine and service api timeouts from 10seconds and 7 seconds to 2 mins and 60 seconds

CIEDC-19192

    Consume Channel & Business Line Details from SF , pass it to WAAT Model

CIEDC-20404

    Added .dockerignore file for reducing docker build time in CI stages.

CIEDC-20836

    Support handling private data coming from Web, Pre, Post Hooks & replace them in Watson answers

CIEDC-2261

    Fix: PII visible in the logs

CIEDC-18778

    Feature: Added unit tests for 80% coverage

CIEDC-22250

    Reset Abby conversation state after error message

CIEDC-22531

    conversationId-consisitent-shard

CIEDC-23104

     increase timeout abby web

CIEDC-20828

    Support buttons and link for VA Bot

CIEDC-22708

     Allow whatsapp bot to send extra custom param

CIEDC-18880

    Replaced "/paramService" API with BotStudio equivalent

CIEDC-23854

     Environment variable WATSON_API_URL adjusted to new credentials

CIEDC-24177

     Bug fix for Abby prod emoticons. Added length check for answersForLog list.

CIEDC-24824

     Bug fix for Abby prod emoticons. Added channel debug check.

CIEDC-291437

    Change number filtering of CB bot to match Retail bot

CIEDC-255752

     Update VA API credentials for higher Env

CIEDC-24571

    Implemented disambiguation feature for WEB bots that use SWAG format

CIEDC-375250

    Support reset conversation for ANNA bots

CIEDC-255496

    Update the user utterance in the request body for storing the logs into splunk

CIEDC-380278
Hotfix: Implemented Abby error messages logging to splunk

CIEDC-486820
Bug fix: Implemented incoming system messages handling logic when Abby gets conected to a live agent.

CIEDC-511198
Increase cloudwatch log rentention to 4 weeks

CIEDC-493019
change reply logs to debug to remove pii from prod

CIEDC-521392
Abby-Bot2Bot bug fix- sanitized incoming url from live agent to the user

Az-613904
Abby-Bot2Bot Forward attachments to agents

az-690937
bugfix sqs-timeout-on-sqs

CIEDC-585478
Migrate from DynamoDB to CosmosDB

CIEDC-753016
SQS to azure queue (service bus)
CIEDC-753026
Implemented send-message-to-logging-service-queue functionality(using Azure Service Bus)

AZ-962506
Newman integration tests added in the pipeline flow for UAT and Prod environments

AZ-961662
Adjusted initial number of pod replicas

AZ-1096632
Smoke test added in the pipeline flow for UAT and Prod environments

AZ-1312434
Added Contentful integration with rich text paragraph new line logic
Added Anna WA MAU logic

AZ-1252588
Added missing Abby-bot2bot features + DB update changes + Missing services + missing actions

AZ-1395261
Added using Contentful preview for dev and test channel

AZ-1378996
Added VAH Channel for NICE

AZ-1482347
Virtual agent URLs and credentials now fetched from BS BE config

AZ-2014562
Sending message reaction as a text to the live agent in ServiceNow Portal

AZ-2230367
Added NICE OnSignal API invocation

AZ-2501075
Set one retry upon unsuccessful IAG request for onSignal endpoints

AZ-2503439
CosmosDB logging logic moved to logging-service

AZ-2864771
Fixed timestamp in Abby chat history

AZ-3393439
Added handover note for agents when the global agentNotes is filled

AZ-3423725
Fixed private data not being send properly to customer

AZ-3403722
Fixed pathfinder input on newUserQuery event
