

jest.mock('redis', () => {
    return {
        createClient: jest.fn().mockReturnValue({
            connect: jest.fn().mockResolvedValue(),
            on: jest.fn()
        })
    }
});


process.env.IVR_CALL_QUEUE_NAME = 'ivr-queue-name'
process.env.FEATURE_FLAGS = 'redis,pushtoMsdQueue'
process.env.IS_JEST = '1'

