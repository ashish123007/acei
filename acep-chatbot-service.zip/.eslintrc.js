module.exports = {
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:@typescript-eslint/recommended-requiring-type-checking',
    'prettier',
  ],
  plugins: ['@typescript-eslint', 'prettier'],
  parser: '@typescript-eslint/parser',
  rules: {
    "@typescript-eslint/no-misused-promises": [
      "error",
      {
        "checksVoidReturn": false
      }
    ],
    "no-constant-condition": ["error", { "checkLoops": false }],
    "no-multiple-empty-lines": ["error", { "max": 2 }],
    "brace-style": ["error"],
    "no-trailing-spaces": ["error"],
    "prettier/prettier": ["error", {
      "semi": true,
      "endOfLine": "crlf"
    }],
  },
  parserOptions: {
    project: ['./tsconfig.json'],
    tsconfigRootDir: __dirname,
  },
  root: true,
}
