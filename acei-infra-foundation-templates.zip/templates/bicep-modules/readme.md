# About this folder:
This folder containens bicep templates that are referenced by bicep templates.

# Preferred bicep template file naming convention:

<resource-name>.bicep Use lowercase letters.
Example: ple.bicep