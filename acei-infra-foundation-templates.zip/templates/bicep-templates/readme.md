# About this folder:
This folder containens bicep templates that are referenced by YAML templates.

# Preferred bicep template file naming convention:

<resource-name>-template.bicep Use lowercase letters.
Example: keyvault-template.bicep
