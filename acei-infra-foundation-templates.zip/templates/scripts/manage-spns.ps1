[CmdLetBinding()]
Param (
    [Parameter(Mandatory = $true)]
    [String] $filePath,
    [Parameter(Mandatory = $true)]
    [String] $kvName,
    [Parameter(Mandatory = $true)]
    [String] $emailId
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest


function Push-SecretToKV($key, $value, $expireDate) {
 
    Write-Host "Push-SecretToKV KEY : $key value : $value expireDate : $expireDate"
    try {
        $secret = Get-AzKeyVaultSecret -VaultName $kvName -Name $key -ErrorAction Stop
        $isExists = $true
    } catch {
        $isExists = $false
    } 
    Write-Host "Push-SecretToKV isExists : $isExists"
    if ($isExists) {
        $versions = Get-AzKeyVaultSecret -VaultName $kvName -Name $key -IncludeVersions
        foreach ($version in $versions) {
            Update-AzKeyVaultSecret -VaultName $kvName -Name $key -Version $version.Version -Enable $false
        }
    }
 
    if ([string]::IsNullOrEmpty($expireDate)) {
        $expireDate = (Get-Date).AddYears(1).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        Write-Host "Default Key Expire Date : $expireDate"
    }
    $expiryDateTime = [datetime]::Parse($expireDate) 
    Set-AzKeyVaultSecret -VaultName $kvName -Name $key -SecretValue (ConvertTo-SecureString $value -AsPlainText -Force) `
        -Expires $expiryDateTime -Tags @{ source = "InfraSecret" }
}


function Get-SPNDetails($spnName) {
    Write-Host "Get-SPNDetails SPN = $spnName"
    $spn = Get-AzADServicePrincipal -DisplayName $spnName -ErrorAction Stop
    $clientId      = "$($spn.AppId)"
    $spnObjectId   = "$($spn.Id)"
    $appObj = Get-AzADApplication -ApplicationId $clientId -ErrorAction SilentlyContinue
    if (-not $appObj) {
        Write-Error "App with clientId $clientId not found"
        return $null
    }
    $appObjectId = "$($appObj.Id)"
    $spnObj = [PSCustomObject]@{
        clientId      = $clientId        # AppId
        appObjectId   = $appObjectId     # App registration object ID
        spnObjectId   = $spnObjectId     # SPN object ID
        name          = $spnName
    }
    Write-Host "spnObj: $($spnObj | ConvertTo-Json -Compress)"
    return $spnObj
 }

function Get-Header($uri) {
    Write-Host "Get-Header For  : $uri"
    [SecureString]$secureToken = (Get-AzAccessToken -ResourceUrl $uri -AsSecureString).Token
    [String]$token = (ConvertFrom-SecureString -SecureString $secureToken -AsPlainText)
    $headers = @{
        "Authorization" = "Bearer $token"
        "Content-Type"  = "application/json"    
    }
    return $headers
    }
   
function Create-Secret($spnName, $appObjectId) {

    Write-Host "Create-Secret SPN : $spnName"

    $headers = Get-Header "https://graph.microsoft.com"

    # Get the application details
    $uri = "https://graph.microsoft.com/v1.0/applications/$appObjectId"
    Write-Host $uri
    try {
        $appDetails = Invoke-RestMethod -Uri $uri -Method 'GET' -Headers $headers -UseBasicParsing
        Write-Host "Application details retrieved successfully."
    } catch {
        Write-Error "Failed to retrieve application details: $($_.Exception.Message)"
        exit 1
    }

    # Check for existing client secret
    $existingSecret = $appDetails.passwordCredentials | Where-Object { $_.displayName -eq "$spnName" }
    if ($existingSecret) {
        Write-Host "Client secret already exists. Exiting gracefully."       
    } else {
        Write-Host "Client secret Not exists. creating new."    
        # Create a new client secret
        $body = @{
            "passwordCredential" = @{
                "displayName"   = "$spnName"
                "startDateTime" = (Get-Date).ToUniversalTime().ToString("o")
                "endDateTime"   = (Get-Date).AddDays(365).ToUniversalTime().ToString("o")
            }
        } | ConvertTo-Json -Depth 10 -Compress

        try {
            $result = Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/applications/$appObjectId/addPassword" -Method 'POST' -Headers $headers -Body $body -UseBasicParsing
            $secretText = $($result).secretText
            $endDateTime = $($result).endDateTime
            $expireDateTime = ([DateTimeOffset]::Parse($endDateTime)).ToString("yyyy-MM-ddTHH:mm:ssZ")

            Push-SecretToKV "$spnName-password" $secretText $expireDateTime
        } catch {
            Write-Error "Failed to create client secret: $($_.Exception.Message)"
            exit 1
        }
    }
}


 function App-Permission($spnObj,$spnAppId)  {

    $spnName = $spnObj.name
    Write-Host "App-Permission : $spnName"
    $delegatedPermissions = $spnObj.delegatedPermissions
    $applicationPermissions = $spnObj.applicationPermissions

    $body = @{
        "ApplicationObjectId" = "$spnAppId"
        "EmailAddress"        = "$emailId"
        "ApplicationPermissions" = $applicationPermissions
        "DelegatedPermissions" = $delegatedPermissions
        
     } | ConvertTo-Json -Depth 10 -Compress

    $headers = Get-Header "https://managedsp-sp.abnamro.com"

    $uri = "https://it4it.abnamro.com/tierafunctions/managedsp/Request-AppPermissions"
    
    try {
        Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -Body $body -UseBasicParsing
        Write-Host "App permissions request sent successfully for SPN: $spnName"
    } catch {
        Write-Error "Failed to request app permissions. Error: $($_.Exception.Message)"
        exit 1
    }
}
  
function App-Role($spnObj, $appObjectId) {
    $spnName = $spnObj.name
    Write-Host "App-Role : $spnName spnAppId: $appObjectId "

    $appRoles = @{}
    if($spnObj.PSObject.Properties.Name -contains "appRoles"){
        $appRoles = $spnObj.appRoles
    }
    # Check if app roles are required
    if (-not $appRoles -or $appRoles.Count -eq 0 ) {
        Write-Host "App roles are not required for this SPN. Exiting gracefully."
        return
    }

    $headers = Get-Header "https://graph.microsoft.com"
    $uri = "https://graph.microsoft.com/v1.0/applications/$appObjectId"
    Write-Host "App-Role uri : $uri"
    $body = @{ 
        "appRoles" = $appRoles 
    } | ConvertTo-Json -Depth 10 -Compress
    Write-Host "App-Role body : $body"

    # Send the JSON content directly in the PATCH request
    try {
        Invoke-RestMethod -Uri $uri -Method "PATCH" -Headers $headers -Body $body -UseBasicParsing
        Write-Host "Successfully applied app roles for SPN $spnName"
    } catch {
        Write-Error "Failed to apply app roles for SPN $spnName. Error: $($_.Exception.Message)"
        Write-Error "Request Body JSON: $body"
    }
} 

function Authentication-Settings($spnObj, $spnObjId) {
    $spnName = $spnObj.name
    Write-Host "App-UserAssignments for spn: $spnName"
 
    $headers = Get-Header "https://graph.microsoft.com"
    $uri = "https://graph.microsoft.com/v1.0/applications/$spnObjId/"
    Write-Host $uri
 
    $body = @{}
 
    if ($spnObj.PSObject.Properties.Name -contains "groupMembershipClaims") {
        $groupMembershipClaims = $spnObj.groupMembershipClaims
 
        if (![string]::IsNullOrWhiteSpace($groupMembershipClaims)) {
            $body["groupMembershipClaims"] = $groupMembershipClaims
        } else {
            $body["groupMembershipClaims"] = "None"
        }
    }
 
    $jsonBody = $body | ConvertTo-Json -Depth 99 -Compress
 
    Try {
        Invoke-RestMethod -Uri $uri -Method "Patch" -Headers $headers -Body $jsonBody -UseBasicParsing
        Write-Host "Set Authentication Settings for SPN '$spnName'."
    } catch {
        Write-Error "Failed to Set Authentication Settings for SPN '$spnName'. Error: $($_.Exception.Message)"
    }
}

function App-UserAssignments($spnObj, $spnObjId) {

    $spnName = $spnObj.name
    Write-Host "App-UserAssignments : $spnName"

    $headers = Get-Header "https://graph.microsoft.com"
    $appRoleAssignmentRequired = $spnObj.appRoleAssignmentRequired

    # Check if App Role Assignment is Required
    $uri = "https://graph.microsoft.com/v1.0/servicePrincipals/$spnObjId"
    $body = @{ "appRoleAssignmentRequired" = $appRoleAssignmentRequired } | ConvertTo-Json -Depth 99 -Compress

    try {
        Invoke-RestMethod -Uri $uri -Method "PATCH" -Headers $headers -Body $body -UseBasicParsing
        Write-Host "Set appRoleAssignmentRequired to $appRoleAssignmentRequired for SPN '$spnName'."
    } catch {
        Write-Error "Failed to update appRoleAssignmentRequired for SPN '$spnName'. Error: $($_.Exception.Message)"
    }

    $appRolePermissions = @{}
    if($spnObj.PSObject.Properties.Name -contains "appRolePermissions"){
        $appRolePermissions = $spnObj.appRolePermissions
    }
    # Skip assignment if no appRolePermissions are defined
    if (-not $appRolePermissions -or $appRolePermissions.Count -eq 0) {
        Write-Host "No appRolePermissions defined for SPN '$spnName'. Skipping role assignments."
        return
    }

    # Assign Groups to App Roles
    $uriAssignments = "$uri/appRoleAssignedTo"
    foreach ($appRole in $appRolePermissions) {
        $appRoleId = $appRole.appRoleId
        $groups = $appRole.groups

        if (-not $groups -or $groups.Count -eq 0) {
            Write-Host "No groups defined for appRoleId $appRoleId. Skipping."
            continue
        }

        # Get current assignments
        $existingAssignments = Invoke-RestMethod -Uri $uriAssignments -Method "GET" -Headers $headers -UseBasicParsing
        foreach ($groupId in $groups) {
            # Check if the group is already assigned
            $alreadyAssigned = $existingAssignments.value | Where-Object {
                $_.appRoleId -eq $appRoleId -and $_.principalId -eq $groupId
            }
            if ($alreadyAssigned) {
                Write-Host "Group $groupId is already assigned to role $appRoleId. Skipping."
                continue
            }

            # Assign the role to the group
            $assignmentBody = @{
                principalId = $groupId
                resourceId = "$spnObjId"
                appRoleId = $appRoleId
            } | ConvertTo-Json -Depth 10 -Compress

            try {
                Invoke-RestMethod -Uri $uriAssignments -Method "POST" -Headers $headers -Body $assignmentBody -UseBasicParsing
                Write-Host "Successfully assigned group $groupId to role $appRoleId."
            } catch {
                Write-Error "Error assigning group $groupId to role $appRoleId. Error: $($_.Exception.Message)"
            }
        }
    }
}

function Set-RedirectURI($spnObj, $spnAppId) {
    $spnName = $spnObj.name
    Write-Host "Set-RedirectURI : $spnName"

    $redirectType = $spnObj.redirectType
    if($spnObj.PSObject.Properties.Name -contains "redirectUrl"){
        $redirectUris = $spnObj.redirectUrl
    }

    # Edge Case: Check if both redirectType and redirectUrl are empty or undefined
    if (-not $redirectType -and (-not $redirectUris -or $redirectUris.Count -eq 0)) {
        Write-Host "No redirectType or redirectUrl defined for SPN '$spnName'. Exiting gracefully."
        return
    }
    Write-Host "Redirect Type: $redirectType Redirect URIs: $($redirectUris -join ',')"

    # Construct Body
    $body = @{}
    if ($redirectType -eq "spa") {
        $body.spa = @{ "redirectUris" = $redirectUris }
    } elseif ($redirectType -eq "web") {
        $body.web = @{ "redirectUris" = $redirectUris }
    } else {
        Write-Error "Invalid redirectType: $redirectType"
        exit 1
    }

    # Ensure the body is not empty
    $bodyJson = $body |  ConvertTo-Json -Depth 10 -Compress
    Write-Host "Request Body JSON: $bodyJson"

    # Send the Request    
    $uri = "https://graph.microsoft.com/v1.0/applications/$spnAppId"
    $headers = Get-Header "https://graph.microsoft.com"
    try {
        Invoke-RestMethod -Uri $uri -Method "PATCH" -Headers $headers -Body $bodyJson -UseBasicParsing
        Write-Host "Redirect URI set successfully."
    } catch {
        Write-Error "Failed to set redirect URI. Error: $($_.Exception.Message)"
    }
}

function Create-SPN($spnObj) {

    $spnName = $spnObj.name
    Write-Host "Create SPN : '$spnName' "

    $uri = "https://it4it.abnamro.com/tierafunctions/managedsp/New-ServicePrincipal"
    $headers = Get-Header "https://managedsp-sp.abnamro.com" 

    $body = @{
        "DisplayName" = $spnName
    } | ConvertTo-Json -Compress

    Try {
        Invoke-RestMethod -Uri $uri -Method "Post" -Headers $headers -Body $body -UseBasicParsing -SkipHttpErrorCheck
        $seconds = 30
        Write-Host "Sleep $seconds s"
        Start-sleep -Seconds $seconds
        Write-Host "Service Principal '$spnName' created successfully."


        $spnReturnObj = Get-SPNDetails $spnName
        $spnAppId = $spnReturnObj.appObjectId
        $spnAppKey = "$spnName-appId"
        # Push SPN App ID to KV
        Push-SecretToKV $spnAppKey $spnAppId ''
        
        $spnObjId = $spnReturnObj.spnObjectId
        $spnObjKey = "$spnName-objectId"
        # Push SPN Obj ID to KV
        Push-SecretToKV $spnObjKey $spnObjId ''
    } catch {
        Write-Error "Exception encountered while setting Single Sign-on mode to SAML on Application . Error: $($_.Exception.Message)"
    }
}

function create($spnObj) {
    $spnName = $spnObj.name
    Write-Host "Create SPN : '$spnName' Action : '$($spnObj.action)'"

    try {
        $spns = Get-AzADServicePrincipal -DisplayName $spnName -ErrorAction Stop

        if ($spns.Count -gt 0) {
            $spn = $spns[0]
            Write-Host "Service Principal '$spnName' already exists. ID: $($spn.Id)"
        } else {
            Write-Host "Service Principal '$spnName' not found. Creating..."
            Create-SPN $spnObj
        }
    } catch {
        Write-Host "Error retrieving SPN. Assuming it does not exist. Creating..."
        Create-SPN $spnObj
    }


    $spnReturnObj = Get-SPNDetails $spnName
    $clientId     = $spnReturnObj.clientId       # AppId / ClientId → used for login & auth (publicly visible ID)
    $appObjectId  = $spnReturnObj.appObjectId    # Application Object ID → internal ID of the App Registration in AAD
    $spnObjectId  = $spnReturnObj.spnObjectId    # Service Principal Object ID → internal ID of the SPN instance in AAD

    Create-Secret           $spnName     $appObjectId         # Store app secrets securely with reference to App Object
    App-Permission          $spnObj      $appObjectId         # Grant required app-level permissions
    App-Role                $spnObj      $appObjectId         # Assign app roles (RBAC or custom roles)
    App-UserAssignments     $spnObj      $spnObjectId         # Assign users/groups to the SPN
    Set-RedirectURI         $spnObj      $appObjectId         # Set redirect URIs for the App Registration
    Authentication-Settings $spnObj      $appObjectId         # Configure platform authentication settings (e.g. OAuth2)
}

function delete($spnObj) {
    $spnName = $spnObj.name
    Write-Host "Delete SPN : '$spnName' Action : '$($spnObj.action)'"

    $spnObjectId = (Get-AzADServicePrincipal -DisplayName $spnName).Id
    Write-Host "Azure Cli Return : $spnObjectId"

    if ($spnObjectId) {
        Write-Host "Service Principal '$spnName' exists."
        Remove-AzADServicePrincipal -ObjectId $spnObjectId.Id -Force
        $keys = @("appId", "objectId", "password")
        foreach ($key in $keys) {
            Write-Host "delete key : $spnName-$key"
            $isExists = az keyvault secret show --name $key --vault-name "$spnName-$key"  --query "id" -o tsv
            if($isExists) {
                az keyvault secret delete --vault-name $kvName --name "$spnName-$key"
            }
        }
        Write-Host "Service Principal '$spnName' deleted successfully."
    } else {
        Write-Host "Service Principal '$spnName' does not exists to delete."
    }
}

# Reading SPN config JSON file
try {
    $spnData = Get-Content -Raw -Path $filePath | ConvertFrom-Json
    Write-Host "SPN data successfully read from $filePath."
} catch {
    Write-Error "Failed to read JSON file at "$filePath": $($_.Exception.Message)"
    exit 1
}

Write-Host "FileContent After Try : $spnData"

foreach( $spnObj in $spnData.servicePrincipals ) {
    switch ( $spnObj.action.ToLower()){
        'create' { create $spnObj }
        'update' { create $spnObj }
        'delete' { delete $spnObj }
        default { Write-Warning " Unknown Action '$($spnObj.action)' No Action"}
    }
}