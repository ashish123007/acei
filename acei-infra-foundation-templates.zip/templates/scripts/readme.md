Please follow the latest changes in SPN Components : https://dev.azure.com/cbsp-abnamro/GRD0001007/_git/ftt-accelerators-artifacts?path=/Scenarios/servicePrincipal/infra-pipeline.yml



🔐 Token Retrieval Process Updated
Note: Microsoft has recently updated the process for retrieving tokens. Tokens must now be handled as secure strings to comply with the latest authentication standards.
If you are running PowerShell scripts, ensure that the token value is passed securely using a secure string format.
To view and follow the updated implementation, please refer to the pipeline YAML file below:
🔗 [Azure DevOps YAML🔐 Token Retrieval Process Updated](https://dev.azure.com/cbsp-abnamro/GRD0001007/_git/ftt-accelerators-artifacts?path=/Scenarios/servicePrincipal/infra-pipeline.yml)
