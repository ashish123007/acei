function parse_semver() {
    local token="$1"
    local major=0
    local minor=0
    local patch=0

    if egrep '^[0-9]+\.[0-9]+\.[0-9]+' <<<"$token" >/dev/null 2>&1 ; then
        local n=${token//[!0-9]/ }
        local a=(${n//\./ })
        major=${a[0]}
        minor=${a[1]}
        patch=${a[2]}
    fi
    
    echo "$major $minor $patch"
}

baseBranchName=$(echo $BUILD_SOURCE_BRANCH | cut -d'/' -f3)
trunkBranchName=$(git remote show origin | sed -n '/HEAD branch/s/.*: //p') # main | master
# trunkBranchName="fscp3" # only for fscp3 branch

aab_version_bumped=true
aab_is_release_version=false
aab_application_version=""

foundSnapshot=""
currentHead=$(git rev-parse HEAD)
while [ -z "$foundSnapshot" ] && [ ! -z "$currentHead" ]
do
    echo "looking for a Snapshot tag at: $currentHead"
    # if [ "$baseBranchName" = "release" ]; then
    #     foundSnapshot=$(git tag --points-at $currentHead | sort -r | head -1 )
    # else
    foundSnapshot=$(git tag --points-at $currentHead | grep '\-SNAPSHOT$' | sort -r | head -1 )
    # fi

    parentHash=$(git log --no-merges --pretty=%P -n 1 $currentHead)
    currentHead=$parentHash
done
if [ -z "$foundSnapshot" ]; then
    echo "no snapshot foundSnapshot, using default"
    foundSnapshot=$DEFAULT_TAG
fi

echo "Latest used tags $foundSnapshot Head $currentHead"
semver=($(parse_semver "$foundSnapshot"))
major=${semver[0]}
minor=${semver[1]}
patch=${semver[2]}

if [ "$BUILD_REASON" = "PullRequest" ]; then
    echo "Creating version for PullRequest"
    aab_application_version=$( printf "%d.%d.%d-%s.%d" $major $minor $patch "PullRequest" $BUILD_PR_ID )
    aab_version_bumped=false
elif [ "$baseBranchName" = "main" ] || [ "$baseBranchName" = "master" ]; then
    echo "Creating Snapshot build from mainline"
    if [ "$BUILD_REASON" != "Manual" ] ; then 
        echo "bumping main version"
        patch=$(($patch+1))
    fi
    aab_application_version=$( printf "%d.%d.%d-SNAPSHOT" $major $minor $patch )  
elif [ "$baseBranchName" = "feature" ] || [ "$baseBranchName" = "fix" ]; then
    echo "Creating $baseBranchName build"
    commitCount=$( git rev-list --count HEAD ^origin/$trunkBranchName )
    aab_application_version=$( printf "%d.%d.%d-%s.%d" $major $minor $patch $BUILD_SOURCE_BRANCHNAME $commitCount )
elif [ "$baseBranchName" = "release" ]; then
    echo "Release branch temporarily not supported"
    exit 1
    # commitCount=$( git rev-list --count HEAD ^origin/$trunkBranchName )
    # patch=$commitCount 
    # if [ "$patch" = "0" ] && [ "$BUILD_REASON" != "Manual" ] ; then 

    #     echo "New release branch, creating a minor bump on $trunkBranchName"
    #     trunkBranchNextTag=$( printf "%d.%d.%d-SNAPSHOT" $major $(($minor+1)) 0 )  
    #     echo "$trunkBranchName will now be tagged with $trunkBranchNextTag"
    #     currentHead=$(git rev-parse HEAD)
    #     git fetch
    #     git checkout origin/main 2>/dev/null || exit 1

    #     git config --local user.email "$BUILD_RERQUESTED_FOR_EMAIL"
    #     git config --local user.name "$BUILD_RERQUESTED_FOR"

    #     git tag $trunkBranchNextTag 2>/dev/null || exit 1
    #     git push origin $trunkBranchNextTag 2>/dev/null || exit 1 
    #     git checkout $currentHead 2>/dev/null || exit 1  #go back to previous
    # fi
    # aab_application_version=$( printf "%d.%d.%d" $major $minor $patch )
    # aab_is_release_version=true
else
    echo "Unsupported base branch: $baseBranchName"
    exit 1;
fi

echo "next version:: $aab_application_version"
echo "tag suffix:: $VERSION_TAG_SUFFIX"

# stp output vars
echo "##vso[task.setvariable variable=aab_application_version]$aab_application_version$VERSION_TAG_SUFFIX"
echo "##vso[task.setvariable variable=aab_version_bumped]$aab_version_bumped"
echo "##vso[task.setvariable variable=aab_is_release_version]$aab_is_release_version"

# stp other output
semverVersionOnly=$( printf "%d.%d.%d" $major $minor $patch )
echo "##vso[task.setvariable variable=semverVersionOnly;isOutput=true]$semverVersionOnly"
echo "##vso[task.setvariable variable=pipeline_version_title;isOutput=true]$aab_application_version" # Example version
echo "##vso[task.setvariable variable=SemVer]$semverVersionOnly"
