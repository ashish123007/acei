

aab_is_release_version=false
baseBranchName=$(echo $BUILD_SOURCE_BRANCH | cut -d'/' -f3)
if [ "$baseBranchName" = "main" ] || [ "$baseBranchName" = "master" ]; then
    aab_is_release_version=true
fi

# when CD, we don't create a version, we find the one
if [ "$BUILD_REASON" = "Manual" ]; then
    aab_version_bumped=false
    
    currentHead=$(git rev-parse HEAD)
    foundTags=$(git tag --points-at $currentHead | wc -l)
    echo "found $foundTags at $currentHead"
    if [ "$foundTags" != "1" ]; then
        echo "head should have exactly one tag"
        exit 1
    fi
    aab_application_version=$(git tag --points-at $currentHead | head -1)
    echo "using tag $aab_application_version"
    semVer=$(echo $aab_application_version | cut -d'-' -f1)
else
    aab_version_bumped=true

    # generate semver like version based on date
    # example: 2025.0305.1109
    semVer=$(date "+%Y.%m%d.%H%M")
    echo "Generated semver $semVer"
    cleanBranchName=$(echo "$BUILD_SOURCE_BRANCH" | cut -d'/' -f3-4 | sed 's/[^a-zA-Z0-9]/-/g')
    echo "formatted branch name: $cleanBranchName with base: $baseBranchName"

    if [ "$baseBranchName" = "main" ] || [ "$baseBranchName" = "master" ]; then
        aab_is_release_version=true
    fi




    aab_application_version=$( printf "%s-%s" $semVer $cleanBranchName)
fi

echo "next version:: $aab_application_version"
echo "semVer version:: $semVer"
echo "tag suffix:: $VERSION_TAG_SUFFIX"

echo "##vso[task.setvariable variable=aab_application_version]$aab_application_version$VERSION_TAG_SUFFIX"
echo "##vso[task.setvariable variable=aab_version_bumped]$aab_version_bumped"
echo "##vso[task.setvariable variable=aab_is_release_version]$aab_is_release_version"

echo "##vso[task.setvariable variable=semverVersionOnly;isOutput=true]$semVer"
echo "##vso[task.setvariable variable=pipeline_version_title;isOutput=true]$aab_application_version" # Example version
echo "##vso[task.setvariable variable=SemVer]$semVer"
