$resourceGroupName = "lzftt-d-rg"
$backupVaultName = "vk-backupvault"
$backupPolicyName = "ram-policy-ps"
# Get Backup Vault
$TestBkpVault = Get-AzDataProtectionBackupVault -VaultName $backupVaultName -ResourceGroupName $resourceGroupName
# Get Policy template for azure disk
$policyDefn = Get-AzDataProtectionPolicyTemplate -DatasourceType AzureDisk
# creat backup policy
New-AzDataProtectionBackupPolicy -ResourceGroupName $resourceGroupName -VaultName $TestBkpVault.Name -Name $backupPolicyName -Policy $policyDefn

# Remove backup policy
$policy = Get-AzDataProtectionBackupPolicy -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -Name $backupPolicyName
Remove-AzDataProtectionBackupPolicy -Name $policy.Name -ResourceGroupName $resourceGroupName -VaultName $backupVaultName