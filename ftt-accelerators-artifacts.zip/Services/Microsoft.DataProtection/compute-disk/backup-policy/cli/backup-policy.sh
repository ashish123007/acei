# Below command will generate Policy.json
az dataprotection backup-policy get-default-policy-template --datasource-type AzureDisk > policy.json


# update policy.json and then create policy as per your requirement using below command
az dataprotection backup-policy create -g lzftt-d-rg --vault-name vk-backupvault -n disk-bkp-policy --policy policy.json