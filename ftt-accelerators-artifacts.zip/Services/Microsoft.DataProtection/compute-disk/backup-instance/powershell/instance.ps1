$resourceGroupName = "lzftt-d-rg"
$backupVaultName = "vk-backupvault"
$backupPolicyName = "ram-policy-ps1"
$computeDiskName = "ftt-ram-d-vm-log-disk"
$uamiName = "lzftt-umi"
$backupInstanceName = $computeDiskName
# get disk
$disk = Get-AzDisk -ResourceGroupName $resourceGroupName -DiskName $computeDiskName
Write-Host "-----Disk---------"
$disk | fl

# get snapshot resource group
$snapshotrg = Get-AzResourceGroup -Name $resourceGroupName
Write-Host "-----Snapshot RG---------"
$snapshotrg | fl

# Get Backup Vault
$BkpVault = Get-AzDataProtectionBackupVault -VaultName $backupVaultName -ResourceGroupName $resourceGroupName
Write-Host "-----Backup Vault---------"
$BkpVault | fl

# get disk backup policy
$diskBkpPol = Get-AzDataProtectionBackupPolicy -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -Name $backupPolicyName
Write-Host "-----Disk Policy---------"
$diskBkpPol | fl

# get vaults user assigned identity
$uami = Get-AzUserAssignedIdentity -ResourceGroupName $resourceGroupName -Name $uamiName
Write-Host "-----Disk Policy---------"
$uami | fl

# create backup instance 
$instance = Initialize-AzDataProtectionBackupInstance -DatasourceType AzureDisk -DatasourceLocation $BkpVault.Location -PolicyId $diskBkpPol[0].Id -DatasourceId $disk.Id -UseSystemAssignedIdentity $False -UserAssignedIdentityArmId $uami.Id  
$instance.Property.PolicyInfo.PolicyParameter.DataStoreParametersList[0].ResourceGroupId = $snapshotrg.ResourceId
$instance.BackupInstanceName = $backupInstanceName
$instance.Property.IdentityDetail.UserAssignedIdentityArmUrl = $uami.Id
Write-Host "-----Instance---------"
$instance | fl

New-AzDataProtectionBackupInstance -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -BackupInstance $instance