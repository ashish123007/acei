$resourceGroupName = "lzftt-d-rg"
$backupVaultName = "vk-backupvault"
$computeDiskName = "ftt-ram-d-vm-tempdb-disk"
$backupInstanceName = $computeDiskName
$instance = Get-AzDataProtectionBackupInstance -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -Name $backupInstanceName
# Run on Demand Backup 
Backup-AzDataProtectionBackupInstanceAdhoc -BackupInstanceName $instance[0].BackupInstanceName -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -BackupRuleOptionRuleName "Default"

# Delete Backup Instance
# Remove-AzDataProtectionBackupInstance -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -Name $instance.Name
$resourceGroupName = "lzftt-d-rg"
$backupVaultName = "vk-backupvault"
$AllInstances = Get-AzDataProtectionBackupInstance -ResourceGroupName $resourceGroupName -VaultName $backupVaultName
Backup-AzDataProtectionBackupInstanceAdhoc -BackupInstanceName $AllInstances[2].Name -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -BackupRuleOptionRuleName "Default"