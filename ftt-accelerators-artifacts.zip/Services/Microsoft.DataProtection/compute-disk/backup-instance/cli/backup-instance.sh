$resourceGroupName = "lzftt-d-rg"
$backupVaultName = "vk-backupvault"
$backupPolicyName = "ram-policy-cli"
$computeDiskName = "ftt-ram-d-vm-db-disk"

# get policy Id
$policId = az dataprotection backup-policy show --name $backupPolicyName --resource-group $resourceGroupName --vault-name $backupVaultName --query "id"

# get compute disk Id
$diskId = az disk show --disk-name $computeDiskName --resource-group $resourceGroupName --query "id"

# Initialize backup instance
az dataprotection backup-instance initialize --datasource-type AzureDisk  -l westeurope --policy-id $policId --datasource-id $diskId --friendly-name $computeDiskName > backup_instance.json

# create bakcup instance
az dataprotection backup-instance create -g $resourceGroupName --vault-name $backupVaultName --backup-instance backup_instance.json

# --------------------------------------------------------

# run on demand backup
$resourceGroupName = "lzftt-d-rg"
$backupVaultName = "vk-backupvault"
$computeDiskName = "ftt-ram-d-vm-db-disk"
$backupPolicyRuleName = "BackupHourly"
$backupInstanceName = $computeDiskName
$diskId = az disk show --disk-name $computeDiskName --resource-group $resourceGroupName --query "id"
# Below command will show the backup Instance name in case you don't know it.
az dataprotection backup-instance list-from-resourcegraph --datasource-type AzureDisk --datasource-id $diskId --query "[].name"
az dataprotection backup-instance adhoc-backup --name $backupInstanceName --rule-name $backupPolicyRuleName --resource-group $resourceGroupName --vault-name $backupVaultName --retention-tag-override "default"