$resourceGroupName = "lzftt-d-rg"
$backupVaultName = "vk-backupvault"
$backupInstanceName = "ftt-ram-d-vm-log-disk"
$uamiName= "lzftt-umi"

$backupVault = Get-AzDataProtectionBackupVault -VaultName $backupVaultName -ResourceGroupName $resourceGroupName

Write-Host "-------Backup Vault---------"
$backupVault | fl

# Use can below command to get backup instance name for you disk in vault.
$AllInstances = Get-AzDataProtectionBackupInstance -ResourceGroupName $resourceGroupName -VaultName $backupVault.Name
Write-Host "-------All Backedup Instances in Vault---------"
$AllInstances | fl

$rp = Get-AzDataProtectionRecoveryPoint -ResourceGroupName $resourceGroupName -VaultName $backupVault.Name -BackupInstanceName $backupInstanceName
Write-Host "-------Available recovery points for our instance---------"
$rp | fl 

$targetresourceGroupName = "lzftt-a-rg"
$targetSubcriptionId = "b728b629-2600-4fe8-8c75-5f9b4064ec5a"
$targetdiskName = "ftt-ram-a-vm-log-disk-restore"

$targetDiskId = "/subscriptions/" + $targetSubcriptionId + "/resourceGroups/" + $targetresourceGroupName + "/providers/Microsoft.Compute/disks/" + $targetdiskName
Write-Host "--------Target Disk Id-------------"
$targetDiskId 

$uami = Get-AzUserAssignedIdentity -ResourceGroupName $resourceGroupName -Name $uamiName
Write-Host "--------User Identity-----------"
$uami | fl

$restorerequest = Initialize-AzDataProtectionRestoreRequest -DatasourceType AzureDisk -SourceDataStore OperationalStore -RestoreLocation $backupVault.Location  -RestoreType AlternateLocation -TargetResourceId $targetDiskId -RecoveryPoint $rp[0].Name
$restorerequest.IdentityDetailUseSystemAssignedIdentity = $false
$restorerequest.IdentityDetailUserAssignedIdentityArmUrl = $uami.Id
Write-Host "--------Restore request----------"
$restorerequest | fl

Start-AzDataProtectionBackupInstanceRestore -BackupInstanceName $backupInstanceName -ResourceGroupName $resourceGroupName -VaultName $backupVault.Name -Parameter $restorerequest