$resourceGroupName = "lzftt-d-rg"
$backupVaultName = "vk-backupvault"
$computeDiskName = "ftt-ram-d-vm-tempdb-disk"
$backupInstanceName = "ftt-ram-d-vm-db-disk"

# get compute disk Id
$diskId = az disk show --disk-name $computeDiskName --resource-group $resourceGroupName --query "id"

# Below command will help you to identify the backup Instance for the Source Disk
$AllInstnaces = az dataprotection backup-instance list-from-resourcegraph --datasource-type AzureDisk --datasource-id $diskId --query "[].name"
$AllInstnaces

# Get available recovery point for backup instances
$rp = az dataprotection recovery-point list --backup-instance-name $backupInstanceName -g $resourceGroupName --vault-name $backupVaultName --query "[].name"
$rp

$targetresourceGroupName = "lzftt-d-rg"
$targetSubcriptionId = "eadb9dfd-2100-4b4d-981a-3225eb77daa7"
$targetdiskName = "ftt-ram-d-vm-db-disk-restore"

# create target Disk Id using target subscription Id, target resource group name, target disk name
$targetDiskId = "/subscriptions/" + $targetSubcriptionId + "/resourceGroups/" + $targetresourceGroupName + "/providers/Microsoft.Compute/disks/" + $targetdiskName
$targetDiskId

# initialize the restore data recovery request
az dataprotection backup-instance restore initialize-for-data-recovery --datasource-type AzureDisk --restore-location westeurope --source-datastore OperationalStore --recovery-point-id "1b1f7b751a924e9d8097511e19dd0909" --target-resource-id $targetDiskId > restore.json

# validate the restore request before actual restore
az dataprotection backup-instance validate-for-restore -g $resourceGroupName --vault-name $backupVaultName --backup-instance-name $backupInstanceName --restore-request-object restore.json

# trigger the restore of a disk 
az dataprotection backup-instance restore trigger -g $resourceGroupName --vault-name $backupVaultName --backup-instance-name $backupInstanceName --restore-request-object restore.json