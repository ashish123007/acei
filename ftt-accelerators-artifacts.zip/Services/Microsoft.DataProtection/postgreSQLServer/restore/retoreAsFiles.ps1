

[CmdletBinding()]
Param (
    [Parameter(Mandatory = $true)]
    [String] $resourceGroupName,

    [Parameter(Mandatory = $true)]
    [String] $backupVaultName,

    [Parameter(Mandatory = $true)]
    [String] $backupInstanceName,

    [Parameter(Mandatory = $true)]
    [String] $containerURI
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Fetch details of backup vault to retrieve parameters like location
$getBkpVaultDetails = Get-AzDataProtectionBackupVault -VaultName $backupVaultName -ResourceGroupName $resourceGroupName

# # Fetch the specific instance
# $GetInstanceDetails = Get-AzDataProtectionBackupInstance -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -Name $backupInstanceName

Write-Output "Before fetching recovery point"

# Fetch the relevant recovery point
$rps = Get-AzDataProtectionRecoveryPoint -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -BackupInstanceName $backupInstanceName

# Fetch the URI of the container, within the storage account to which permissions were assigned
$contURI = $containerURI

Write-Output "Preparaing the restore request"

# Prepare the restore request with all relevant details.
$OssRestoreAsFilesReq = Initialize-AzDataProtectionRestoreRequest -DatasourceType AzureDatabaseForPGFlexServer -SourceDataStore VaultStore -RestoreLocation $getBkpVaultDetails.Location -RestoreType RestoreAsFiles -RecoveryPoint $rps[0].Property.RecoveryPointId -TargetContainerURI $contURI

Write-Output "Triggering the restore"

# Trigger the restore with the request prepared above.
$triggeredRestoreObj = Start-AzDataProtectionBackupInstanceRestore -BackupInstanceName $backupInstanceName -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -Parameter $OssRestoreAsFilesReq

Write-Output "Triggered restore operation"
# Write-Output $triggeredRestoreObj
Write-Output "Tracking a restored job"

$job = Search-AzDataProtectionJobInAzGraph -Subscription "eadb9dfd-2100-4b4d-981a-3225eb77daa7" -ResourceGroup $resourceGroupName -Vault $backupVaultName -DatasourceType AzureDatabaseForPGFlexServer -Operation Restore

Write-Output $job[0].Status

if ($job[0].Status == 'Failed') {
    throw "There is some error in restore operation, Please check backup items in portal for more details"
}

# Get-AzDataProtectionJob -SubscriptionId "eadb9dfd-2100-4b4d-981a-3225eb77daa7" -ResourceGroupName $resourceGroupNam -VaultName $backupVaultName -Id 4abaea8c-f53a-4bb1-9963-59f96b597165
