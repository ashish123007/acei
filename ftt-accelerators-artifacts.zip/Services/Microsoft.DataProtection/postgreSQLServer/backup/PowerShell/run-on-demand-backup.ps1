

[CmdletBinding()]
Param (
    [Parameter(Mandatory = $true)]
    [String] $resourceGroupName,

    [Parameter(Mandatory = $true)]
    [String] $backupVaultName,

    [Parameter(Mandatory = $true)]
    [String] $backupInstanceN
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Write-Output "in ps"

# Fetch specififc instance
# $instance = Get-AzDataProtectionBackupInstance -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -Name $backupInstanceName
# Write-Output "Retrieved Backup Instance"

Write-Output "Intiating Backup"

# Run on Demand Backup  for specific instance
Backup-AzDataProtectionBackupInstanceAdhoc -BackupInstanceName $backupInstanceN -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -BackupRuleOptionRuleName "Default"

Write-Output "Backup command executed. Check Backup Jobs in Portal for more details."

# Run on Demand backup for all instances.
# $AllInstances = Get-AzDataProtectionBackupInstance -ResourceGroupName $resourceGroupName -VaultName $backupVaultName
# Backup-AzDataProtectionBackupInstanceAdhoc -BackupInstanceName $AllInstances[2].Name -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -BackupRuleOptionRuleName "Default"

# Delete Backup Instance
# Remove-AzDataProtectionBackupInstance -ResourceGroupName $resourceGroupName -VaultName $backupVaultName -Name $instance.Name