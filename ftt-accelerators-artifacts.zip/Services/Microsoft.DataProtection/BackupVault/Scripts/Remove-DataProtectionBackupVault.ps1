<#
.SYNOPSIS
    Deletes a Backup Vault.

.DESCRIPTION
    Deletes a Backup Vault, after performing the following actions:

    1. Disables immutability on the Backup Vault, if immutability is not locked.
    2. Disables soft delete on the Backup Vault.
    3. Undeletes Backup Instances in soft deleted state.
    4. Deletes all Backup Instances.
    5. Deletes all Backup Policies.

.PARAMETER Id
    The resource ID of the Backup Vault.

.PARAMETER VaultName
    The name of the Backup Vault.

.PARAMETER ResourceGroupName
    The name of the Resource Group.

.PARAMETER SubscriptionId
    Optional. The ID of the Subscription.

.INPUTS
    System.String

.EXAMPLE
    Remove-DataProtectionBackupVault -Id $vaultResourceId

.EXAMPLE
    Remove-DataProtectionBackupVault -VaultName $vaultName -ResourceGroupName $resourceGroupName

.EXAMPLE
    Remove-DataProtectionBackupVault -VaultName $vaultName -ResourceGroupName $resourceGroupName -SubscriptionId $subscriptionId
#>

[CmdletBinding(SupportsShouldProcess = $true, DefaultParameterSetName = "ById")]
Param (
    [Parameter(Mandatory = $true, ParameterSetName = "ById", ValueFromPipelineByPropertyName = $true)]
    [Alias("ResourceId")]
    [String] $Id,

    [Parameter(Mandatory = $true, ParameterSetName = "ByName")]
    [Alias("Name")]
    [String] $VaultName,

    [Parameter(Mandatory = $true, ParameterSetName = "ByName")]
    [String] $ResourceGroupName,

    [Parameter(Mandatory = $false, ParameterSetName = "ByName")]
    [String] $SubscriptionId
)

Process {
    If ($PSCmdlet.ParameterSetName -eq "ById") {
        $parameters = [Ordered] @{
            VaultName         = $Id.Split("/")[-1]
            ResourceGroupName = $Id.Split("/")[4]
            SubscriptionId    = $Id.Split("/")[2]
        }
    }
    Else {
        $parameters = $PSBoundParameters

        # Remove 'WhatIf' from parameters because it is unsupported by relevant cmdlets
        $parameters.Remove("WhatIf") | Out-Null
    }

    Write-Verbose "Retrieving Backup Vault '$($parameters.VaultName)' in Resource Group '$($parameters.ResourceGroupName)'."
    $backupVault = Get-AzDataProtectionBackupVault @parameters -ErrorAction Stop

    $parameters.SubscriptionId = $backupVault.Id.Split("/")[2]

    If ($backupVault.ImmutabilityState -eq "Locked") {
        Write-Error "Cannot delete Backup Vault '$($backupVault.Name)' as immutability is enabled and locked."
        Return
    }

    If ($backupVault.ImmutabilityState -eq "Unlocked") {
        Write-Verbose "Disabling immutability on Backup Vault '$($backupVault.Name)'."
        If ($PSCmdlet.ShouldProcess($backupVault.Name, "Update-AzDataProtectionBackupVault")) {
            Update-AzDataProtectionBackupVault -ImmutabilityState "Disabled" @parameters -ErrorAction Stop | Out-Null
        }
    }

    If ($backupVault.SoftDeleteState -ne "Off") {
        Write-Verbose "Disabling soft delete on Backup Vault '$($backupVault.Name)'."
        If ($PSCmdlet.ShouldProcess($backupVault.Name, "Update-AzDataProtectionBackupVault")) {
            Update-AzDataProtectionBackupVault -SoftDeleteState "Off" @parameters -ErrorAction Stop | Out-Null
        }
    }

    Write-Verbose "Retrieving soft deleted Backup Instances on Backup Vault '$($backupVault.Name)'."
    $deletedBackupInstances = Get-AzDataProtectionSoftDeletedBackupInstance @parameters -ErrorAction Stop

    ForEach ($deletedBackupInstance In $deletedBackupInstances) {
        Write-Verbose "Undoing deletion of Backup Instance '$($deletedBackupInstance.Name)'."
        If ($PSCmdlet.ShouldProcess($deletedBackupInstance.Name, "Undo-AzDataProtectionBackupInstanceDeletion")) {
            Undo-AzDataProtectionBackupInstanceDeletion -BackupInstanceName $deletedBackupInstance.Name @parameters -ErrorAction Stop
        }
    }

    Write-Verbose "Retrieving Backup Instances on Backup Vault '$($backupVault.Name)'."
    $backupInstances = Get-AzDataProtectionBackupInstance @parameters -ErrorAction Stop

    ForEach ($backupInstance In $backupInstances) {
        Write-Verbose "Deleting Backup Instance '$($backupInstance.Name)'."
        If ($PSCmdlet.ShouldProcess($backupInstance.Name, "Remove-AzDataProtectionBackupInstance")) {
            Remove-AzDataProtectionBackupInstance -Name $backupInstance.Name @parameters -ErrorAction Stop
        }
    }

    Write-Verbose "Retrieving Backup Policies on Backup Vault '$($backupVault.Name)'."
    $backupPolicies = Get-AzDataProtectionBackupPolicy @parameters -ErrorAction Stop

    ForEach ($backupPolicy In $backupPolicies) {
        Write-Verbose "Deleting Backup Policy '$($backupPolicy.Name)'."
        If ($PSCmdlet.ShouldProcess($backupPolicy.Name, "Remove-AzDataProtectionBackupPolicy")) {
            Remove-AzDataProtectionBackupPolicy -Name $backupPolicy.Name @parameters -ErrorAction Stop
        }
    }

    Write-Verbose "Deleting Backup Vault '$($backupVault.Name)'."
    If ($PSCmdlet.ShouldProcess($backupVault.Name, "Remove-AzDataProtectionBackupVault")) {
        Remove-AzDataProtectionBackupVault @parameters -ErrorAction Stop
    }
}