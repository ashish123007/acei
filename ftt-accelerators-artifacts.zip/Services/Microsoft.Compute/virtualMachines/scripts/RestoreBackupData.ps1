[CmdletBinding()]
Param (
    $PPResourceGroupName,
    $PPVirtualMachineName,
    $PPRecoveryServicesVault,
    $PPStorageAccountName
)

$ResourceGroupName = $PPResourceGroupName
$VirtualMachineName = $PPVirtualMachineName
$RecoveryServicesVault = $PPRecoveryServicesVault
$StorageAccountName = $PPStorageAccountName

#Set-AzContext -SubscriptionName $(SubscriptionName)
#Get-AzRecoveryServicesVault -Name $(RecoveryServicesVault) | Set-AzRecoveryServicesVaultContext

Stop-AzVM -ResourceGroupName $ResourceGroupName -Name $VirtualMachineName -Force

$targetVault = Get-AzRecoveryServicesVault -ResourceGroupName $ResourceGroupName -Name $RecoveryServicesVault

$namedContainer = Get-AzRecoveryServicesBackupContainer -ContainerType "AzureVM" -Status "Registered" -FriendlyName $VirtualMachineName -VaultId $targetVault.ID
$backupitem = Get-AzRecoveryServicesBackupItem -Container $namedContainer -WorkloadType "AzureVM" -VaultId $targetVault.ID

$startDate = (Get-Date).AddDays(-4)
$endDate = (Get-Date).AddDays(-4)
$rp = Get-AzRecoveryServicesBackupRecoveryPoint -Item $backupitem -StartDate $startdate.ToUniversalTime() -EndDate $enddate.ToUniversalTime() -VaultId $targetVault.ID
$rp[0]

$restorejob = Restore-AzRecoveryServicesBackupItem -RecoveryPoint $RP[0] -StorageAccountName $StorageAccountName -StorageAccountResourceGroupName $ResourceGroupName -VaultId $targetVault.ID -VaultLocation $targetVault.Location

Wait-AzRecoveryServicesBackupJob -Job $restorejob -Timeout 43200

