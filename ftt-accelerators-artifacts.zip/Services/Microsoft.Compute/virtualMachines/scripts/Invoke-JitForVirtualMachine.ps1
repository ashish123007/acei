<#
.SYNOPSIS
    Enables JIT for a Virtual Machine.

.DESCRIPTION
    Enables JIT for a Virtual Machine.

.PARAMETER VMName
    The name of the Virtual Machine to enable JIT for.

.PARAMETER ResourceGroupName
    The name of the Resource Group which the Virtual Machine belongs to.

.EXAMPLE
    Enable-JitForVirtualMachine-Prod -VMName <VMName> -ResourceGroupName <ResourceGroupname>
#>

[CmdletBinding()]
Param (
    [Parameter(Mandatory = $true)]
    [String] $VMName,

    [Parameter(Mandatory = $true)]
    [String] $ResourceGroupName
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$resourceId = (Get-AzVM -Name $VMName -ResourceGroupName $ResourceGroupName).Id

$body = @{ ResourceId = $resourceId } | ConvertTo-Json

$accessToken = (Get-AzAccessToken).Token
$headers = @{
    Authorization = "Bearer $accessToken"
}

Write-Host "Enabling JIT for Virtual Machine with resource ID '$resourceId'."
Invoke-RestMethod `
    -Uri "https://vm-jit-p-fa.azurewebsites.net/api/EnableJit" `
    -Body $body `
    -ContentType "application/json" `
    -Headers $headers `
    -Method Post `
    -UseBasicParsing
