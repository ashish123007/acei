[CmdletBinding()]
param (
    $PPResourceGroupName,
    $ppvmName,
    $ppSubscriptionName,
    $ppTenantId,
    $ppdiskEncryptionSetName,
    $ppDiskSizeInGB1,
    $ppDiskSizeInGB2,
    $ppDiskSizeInGB3,
    $ppDiskSizeInGB4
)

$ErrorActionPreference = "Stop"

#================================================================================================================================== 
#SET These Variables as needed 
#==================================================================================================================================
$ResourceGroupName=$PPResourceGroupName
$vmName=$ppvmName
$SubscriptionName=$ppSubscriptionName
$TenantId=$ppTenantId
$diskEncryptionSetName=$ppdiskEncryptionSetName
$Disks=4                #Number of Disks to Add #
$DiskSizeInGB=0
$DiskSizeInGB1=$ppDiskSizeInGB1 #Size of Disks in GB-500
$DiskSizeInGB2=$ppDiskSizeInGB2 #Size of Disks in GB-150
$DiskSizeInGB3=$ppDiskSizeInGB3 #Size of Disks in GB-250
$DiskSizeInGB4=$ppDiskSizeInGB4 #Size of Disks in GB-150
$Caching="ReadWrite"    #Caching Policy None|ReadOnly|ReadWrite # 
$StartingLUN =0         #Set this to zero for First Disks and max LUN for not new VM

#================================================================================================================================== 
#Authenticate to Azure if required (not in cloudshell)
#==================================================================================================================================
if (!(Get-AzContext)) {
    Connect-AzAccount -TenantId $TenantId  -SubscriptionName $SubscriptionName
}

#================================================================================================================================== 
#Set Contect to correct Subsription for VM
#==================================================================================================================================
Set-AzContext -Tenant $TenantId -SubscriptionName $SubscriptionName

#================================================================================================================================== 
#Get Azure VM Context. Will Fail if not found
#==================================================================================================================================
$VM=Get-AzVM -ResourceGroupName $ResourceGroupName -Name $vmName

#==================================================================================================================================
#Get DES details
#==================================================================================================================================
$diskEncryptionSet=Get-AzDiskEncryptionSet -ResourceGroupName $ResourceGroupName -Name $diskEncryptionSetName

#================================================================================================================================== 
#Create and Attach Disks in a Loop for required Number of Disks
#==================================================================================================================================
for ($i=1; $i -le $Disks; $i++) {
    
    If($i -eq 1){$DiskSizeInGB=$DiskSizeInGB1}
    ElseIf($i -eq 2){$DiskSizeInGB=$DiskSizeInGB2}
    ElseIf($i -eq 3){$DiskSizeInGB=$DiskSizeInGB3}
    Else{$DiskSizeInGB=$DiskSizeInGB4}

    Add-AzVMDataDisk -VM $VM -Name $($VMName + "_Datadisk_0" + $i) -Caching $Caching -DiskSizeInGB $DiskSizeInGB  -StorageAccountType StandardSSD_LRS -CreateOption Empty -Lun ($StartingLUN  + $i-1) -DiskEncryptionSetId $diskEncryptionSet.Id
}
Update-AzVM -VM $VM -ResourceGroupName $ResourceGroupName

#================================================================================================================================== 
#Initialize the Disks, format & assign drive letters
#==================================================================================================================================
Get-Disk |
Where-Object PartitionStyle -eq 'RAW' |
Initialize-Disk -PartitionStyle MBR -PassThru |
New-Partition -AssignDriveLetter -UseMaximumSize |
Format-Volume -FileSystem NTFS -Confirm:$false
 
 
#Sample script to delete if rollback needed
#Note: Careful deleting disks as need to detach AND physically remove from resource group (or will still be billed)
#Remove-AzVMDataDisk -VM $VM  -Name TestDisk2
#Update-AzVM -VM $VM -ResourceGroupName $ResourceGroupName