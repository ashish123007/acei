# Introduction 
This repository provides a collection of sample arm, bicep and pipeline templates  which can be used as reference when deploying Azure resources. The templates in this repository are not life cycle managed and are only meant as base templates from where you can build on.

# Getting Started
life cycle managed templates and solutions are available in the folowing locations
1.	[SecureContextBaseCatalog](https://dev.azure.com/cbsp-abnamro/Azure/_git/SecureContextBaseCatalog)
2.	[SecureContext](https://dev.azure.com/cbsp-abnamro/Azure/_git/SecureContext)
3.	[Azure Scenario Market Place](https://confluence.aws.abnamro.org/display/AZURE/Azure+Scenario+Market+Place)

Also please check out our [Cookbooks](https://confluence.aws.abnamro.org/display/AZURE/FSCP+3.0+Services+cookbook) for help and information regarding deployment of the resources provided in this repository. 


# Table of contents
In this repository you wil find 5 folders, each folder has its own functionality and is provided with its own readme. A short discription for each folder can be find below.

<details>
  <summary>BaseYamlFolder</summary>
  This folder containts examples of basic yaml Azure pipelines. 
</details>
<details>
  <summary>Exploration</summary>
  This folder contains experimental resources where the FSCP Transition Team is exploring new resources.
</details>
<details>
  <summary>NetworkYamls</summary>
  This folder contains examples of complete network Azure pipelines.
</details>
<details>
  <summary>Scenarios</summary>
  This folder contains solutions for scenarios where multiple resources are used.
</details>
<details>
  <summary>Services</summary>
  This folder contains example arm and bicep templates of Azure resources.
</details>

# Contribute
This repository is managed by the FSCP Transition Team. New content wil only be provided by the FSCP Transition Team. We create templates mainly on request from onboarding teams, the templates are therefor suited for certen scenarios and cant be seen as a standard solution. 