Function LogAction
{
    <#
        .SYNOPSIS
            Write to screen and Log (using Logaction)
        .DESCRIPTION
            Writes $i to screen and given logfile using format 'date | time | $i'
        .PARAMETER text
            The text to write to the logfile
        .PARAMETER LogFileName
            $LogFileName = logpath + "\LogFile"
        .PARAMETER NoLog
            When this switch is applied, $text is output indent "`t[$((Get-Date).ToString("HH:mm:ss"))] >"
        .PARAMETER NoConsole
            When this switch is applied, output to the console is omitted
        .PARAMETER Status
            provides log status which can be info, success, failure, warning and error
        .NOTES
            author: Siebrand Feenstra, s.feenstra@loginconsultants.nl
        .EXAMPLE
            LogAction -Logfilename C:\PPGLogs\logfile.log -text "Text to add to the logfile" -status Success
    #>
    [cmdletbinding(SupportsShouldProcess = $True)]
    Param(
        [parameter(Mandatory=$true, ParameterSetName='text')]
        [string]$text,
        [parameter(Mandatory=$true)]
        [string]$LogFileName,
        [parameter(Mandatory=$true)]
        [ValidateSet("Info", "Warning","Error","Success","Failed")]
        [string]$Status,
        [switch]$NoLog,
        [switch]$NoConsole
    )
    # Define Logbuffer
    If ($script:LogBuffer -isnot [system.object]){
        $script:LogBuffer = New-Object System.Collections.ArrayList
    }
    # Status color
    if ($status -eq "info"){[string]$statustag = "[INFORM]";$statuscolor = "Cyan"}
        elseif ($status -eq "Warning"){[string]$statustag = "[WARNING]";$statuscolor = "Yellow"}
        elseif ($status -eq "Error"){[string]$statustag = "[ERROR]";$statuscolor = "Red"}
        elseif ($status -eq "Success"){[string]$statustag = "[SUCCESS]";$statuscolor = "Green"}
        elseif ($status -eq "Failed"){[string]$statustag = "[FAILURE]";$statuscolor = "Red"}
    # Format date, time and message
    $TimeNumberSign = "[$(get-date -format "dd-MMM-yyyyTHH:mm:ss.fff")] `t$statustag `t#"
    $Message = "$TimeNumberSign $text"
    # Write Host
    If (!($NoConsole -eq $true)){
        Write-Host $Message -ForegroundColor $statuscolor
    }
    # Write Log
    If (!($nologfile -eq $true)){
        $LogMutex = New-Object System.Threading.Mutex($false, "LogMutex")
        $LogMutex.WaitOne()|out-null
        Add-Content -path $LogFileName -value $Message
        $LogMutex.ReleaseMutex()|out-null
    }
    # Write Logbuffer
    $null = $script:LogBuffer.Add($Message)
}