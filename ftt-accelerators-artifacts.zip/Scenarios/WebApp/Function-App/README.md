# Quickstart Pipeline

This is an example YAML pipeline that is provided by the FTT team since October 2022 to be used as a started pipeline for transition customers.
This YAML pipeline file can be used in FSCP 3.0 Landing Zone environments to deploy Azure Resources.

PIPE team have created reusable Templates and Mandatory Building blocks which can be used in the CI/CD Pipelines to save developers time and to be in control,
Please check PIPE wiki page for more information about all the templates and building blocks usage- https://dev.azure.com/cbsp-abnamro/GRD0001045/_wiki/wikis/PITA%20templates/11780/pipeline-templates

