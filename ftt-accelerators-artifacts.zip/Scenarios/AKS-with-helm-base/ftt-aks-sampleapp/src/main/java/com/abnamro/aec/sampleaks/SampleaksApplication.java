package com.abnamro.aec.sampleaks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleaksApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleaksApplication.class, args);
	}

}
