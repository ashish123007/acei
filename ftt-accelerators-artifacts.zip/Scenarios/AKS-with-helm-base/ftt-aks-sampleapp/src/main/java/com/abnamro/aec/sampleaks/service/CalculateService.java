package com.abnamro.aec.sampleaks.service;

import org.springframework.stereotype.Service;

/**
 * This is a Service Class which will make a call to Api
 */
@Service
public class CalculateService {

    public String add(String num1, String num2) {
        double result = 0.0;
        try {
            double a = Double.parseDouble(num1);
            double b = Double.parseDouble(num2);
            result = a + b;
        } catch (NumberFormatException numberFormatException) {
            System.out.println("Exception occured");
        }
        return Double.toString(result);
    }

    public String div(String num1, String num2) {
        double result = 0.0;
        try {
            double a = Double.parseDouble(num1);
            if (Integer.parseInt(num2) == 0) {
                return "Invalid Input :- Number 2 can't be Zero for Division";
            } else {
                double b = Double.parseDouble(num2);
                result = a / b;
            }
        } catch (NumberFormatException numberFormatException) {
            System.out.println("Exception occured");
        }
        return Double.toString(result);
    }

    public String sub(String num1, String num2) {
        double result = 0.0;
        try {
            double a = Double.parseDouble(num1);
            double b = Double.parseDouble(num2);
            result = a - b;
        } catch (NumberFormatException numberFormatException) {
            System.out.println("Exception occured");
        }
        return Double.toString(result);
    }

    public String mul(String num1, String num2) {
        double result = 0.0;
        try {
            double a = Double.parseDouble(num1);
            double b = Double.parseDouble(num2);
            result = a * b;
        } catch (NumberFormatException numberFormatException) {
            System.out.println("Exception occured");
        }
        return Double.toString(result);
    }

}
