package com.abnamro.aec.sampleaks.controller;

import java.net.URISyntaxException;

import javax.inject.Inject;

import com.abnamro.aec.sampleaks.service.CalculateService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * This is Calculator Controller Class
 */
@Controller
public class CalculateController {

    private static Logger log = LoggerFactory.getLogger(CalculateController.class);

    @Inject
    private CalculateService calculateService;

    /**
     * Returns String of Index Html Page
     *
     * @return String index html page
     */
    @RequestMapping("/")
    public String viewForm() {
        log.debug("Iag Consumer Home Page");
        return "index1";
    }

    /**
     * Returns String index with result for operation
     *
     * @param num1        String number 1 input
     * @param num2        String number 2 input
     * @param calculation String Calculation input operator
     * @param model       Model for displaying on html page
     * @throws URISyntaxException throws UriException
     * @return String index html page with result
     * @throws URISyntaxException
     */
    @RequestMapping("/operations")
    public String addForm(String num1, String num2, String calculation, Model model) throws URISyntaxException {

        String res;
        switch (calculation) {
            case "add":
                res = calculateService.add(num1, num2);
                break;
            case "sub":
                res = calculateService.sub(num1, num2);
                break;
            case "mul":
                res = calculateService.mul(num1, num2);
                break;
            case "div":
                res = calculateService.div(num1, num2);
                break;
            default:
                res = "Invalid Operation";
                break;
        }
        model.addAttribute("result", res);
        return "index";

    }
}
