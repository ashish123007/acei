\echo :rolename

SELECT EXISTS(SELECT 1 FROM pg_catalog.pg_roles WHERE ROLNAME = 'debasis.pati@nl.abnamro.com') as is_role_exist

\gset

\if :is_role_exist
    \echo 'Already role exists. Updating permission....'
    DO $$
        BEGIN
            GRANT azure_ad_user TO "debasis.pati@nl.abnamro.com";
        END
    $$;
\else
    \echo 'Need to create this role. Creating role....'
    DO $$
        BEGIN
            CREATE ROLE "debasis.pati@nl.abnamro.com";
            GRANT azure_ad_user TO "debasis.pati@nl.abnamro.com";
            /* CREATE USER "debasis.pati@nl.abnamro.com" IN ROLE azure_ad_user; */
        END
    $$;
\endif