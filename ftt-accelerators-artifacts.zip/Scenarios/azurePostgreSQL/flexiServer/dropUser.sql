\echo 'Connected to DB'
DO
$do$
BEGIN
    IF EXISTS (SELECT FROM pg_catalog.pg_roles WHERE ROLNAME = 'lzftt-umi') THEN
        RAISE NOTICE 'Delete the created user profile...';
        DROP ROLE "lzftt-umi";
    END IF;
END
$do$