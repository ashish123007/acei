\echo 'Connected to DB'
DO
$do$
BEGIN
    IF EXISTS (SELECT FROM pg_catalog.pg_roles WHERE ROLNAME = 'lzftt-umi') THEN
        RAISE NOTICE 'Already role exists. Updating permission....';
        GRANT azure_pg_admin TO "lzftt-umi";
    ELSE
        RAISE NOTICE 'Need to create this role. Creating role....';
        CREATE USER "lzftt-umi" WITH LOGIN;
        GRANT azure_pg_admin TO "lzftt-umi";
    END IF;
END
$do$