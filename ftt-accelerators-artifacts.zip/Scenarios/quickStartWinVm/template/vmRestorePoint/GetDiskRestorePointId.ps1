$rp = Get-AzRestorePoint -ResourceGroupName 'lzftt-d-rg' -RestorePointCollectionName 'ftt-ram-d-rpc' -Name 'ftt-ram-d-rp'
$rp.SourceMetadata.StorageProfile.DataDisks # get the disk
$rp.SourceMetadata.StorageProfile.DataDisks[0] # get the specific disk details 
$rp.SourceMetadata.StorageProfile.DataDisks[0].DiskRestorePoint.Id # get the Disk Restore Point Id