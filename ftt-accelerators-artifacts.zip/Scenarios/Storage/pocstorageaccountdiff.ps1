[CmdletBinding()]
param(
#  Storage Account Paramenter
[Parameter(Mandatory = $true)] 
[string]$SourceGroup,

[Parameter(Mandatory = $true)] 
[string]$SourceSA,

[Parameter(Mandatory = $true)] 
[string]$TargetGroup,  

[Parameter(Mandatory = $true)]
[string]$TargetSA,

[Parameter(Mandatory = $true)]
[string]$MaximumCountInCSV
)



$SourceGroup =$SourceGroup 
$SourceSA =$SourceSA 
$TargetGroup = $TargetGroup 
$TargetSA = $TargetSA
$MaxReturn = $MaximumCountInCSV

$filepath = ".\"
#New-Item -Path $filepath -Itemtype Directory

$Token = $null



$ArrayList=@{}

#This function add blob and md5 values row in excel
Function GetBlobContainerData($bloblist ,$fileName)   
	{

	$count =0
	$totallength

	New-Item -Path $filepath\$fileName.csv -Itemtype File
	Add-Content -Path $filepath\$fileName.csv -Value "BlobName;BlobSize;MD5Value"
		Write-Host "BlobCount" $bloblist.count 
		If(($bloblist.count -ne 0) -and ($bloblist.length -ne $null))
		{
			$bloblist | ForEach-Object {
			$Name=$_.Name
			$Length=$_.Length 
			$totallength = $totallength + $_.Length  
			if(($_.BlobProperties.ContentHash) -ne $null){
				$contenthash = [Convert]::ToBase64String($_.BlobProperties.ContentHash)
			}
			else{
				$contenthash =""
			}
			#adding row in CSV file
			Add-Content -Path $filepath\$fileName.csv -Value "$Name;$Length;$contenthash"
			$count++
			}
		}

	#retun a Total Length and BlobCount
	return $retunvalue=@($count, $totallength)
	}

Function GetStorageAccount($resourceGroup ,$storageAccountName ,$SAtype)
	{ 
	
	
	#$storageAccount = Get-AzStorageAccount `  -ResourceGroupName $resourceGroup `  -Name $storageAccountName

	#Storage context
    $ctx = New-AzStorageContext -StorageAccountName $storageAccountName -UseConnectedAccount
	$containers = Get-AzStorageContainer -Context $ctx 

	$fname=$SAtype + $storageAccountName
	New-Item -Path $filepath\$fname.csv -Itemtype File
	Add-Content -Path $filepath\$fname.csv -Value "ContainerName;BlobCount;TotalBolbSizeInContainer"

		Foreach ($container in $containers)
		{

		$containerName = $container.Name
		$countcontainer=01
		$SourceCSVFileNames=@()
		$TargetCSVFileNames=@()

			do
			{
			$listOfBlobs = Get-AzStorageBlob -Container $containerName -Context $ctx -MaxCount $MaxReturn -ContinuationToken $Token
			$Total += $listOfBlobs.Count

			$fileName = $SAtype + $containerName + $countcontainer

			if($SAtype -eq "Target") {  
			$TargetCSVFileNames += "$fileName" }
			elseif ($SAtype -eq "Source") {
			$SourceCSVFileNames += "$fileName" }

			#calling new Function for get blob details
			$temp, $temp2, $BlobCount, $Totallength= GetBlobContainerData $listOfBlobs $fileName $SAtype

			#Adding Row from container details retun value
			Add-Content -Path $filepath\$fname.csv -Value "$containerName;$BlobCount;$Totallength"
			$countcontainer++

			if($listOfBlobs.Length -le 0) { Break;}
			$Token = $listOfBlobs[$listOfBlobs.Count -1].ContinuationToken;
			}
			While ($null -ne $Token)
			#retun Array for Multiple CSV File
			
			if($SAtype -eq "Target") {
				
			$customobject +=@($ArrayList =@{'ContainerName'=$ContainerName; 'TargetCSVFiles'=@($TargetCSVFileNames); })
						
			}
			else{
				
			$customobject +=@($ArrayList =@{'ContainerName'=$ContainerName; 'SourceCSVFiles'=@($SourceCSVFileNames); }
			)
			}
			
			$customobject | ConvertTo-Json 
			$ArrayList | ConvertTo-Json 
			 
			
		}
	return $customobject
	}

Write-Host "Loading Source Storage Account..."
$temp1, $SourceArrayList= GetStorageAccount $SourceGroup $SourceSA source 

Write-Host "Loading Target Storage Account..."  
$temp1, $TargetArrayList= GetStorageAccount $TargetGroup $TargetSA target 
 
New-Item -Path $filepath\DifferentialReport.csv -Itemtype File
Add-Content -Path $filepath\DifferentialReport.csv -Value "ContainerName;SourceGroup;TargetGroup;IsMatched"

$Sa=$SourceArrayList | ConvertFrom-Json
$Ta=$TargetArrayList | ConvertFrom-Json
if($SourceArrayList.length -gt $TargetArrayList.length){$counterdiff=$SourceArrayList.length}else {$counterdiff=$TargetArrayList.length}
	for ($i=0; $i -lt $counterdiff; $i++ ){
		$ContainerName=$Sa[$i].ContainerName
		foreach ($row in $Ta | Where { $_.ContainerName -eq $Sa[$i].ContainerName } )
				{
					$src=$Sa[$i].SourceCSVFiles.split(" ")
					$tar=$row.TargetCSVFiles.split(" ")

					if($src.count -gt $tar.count){$counterdiff1=$src.count}else {$counterdiff1=$tar.count}
	
				for ($j=0; $j -lt $counterdiff1; $j++ ){
					if($src.count -eq 1){
						$srcfname=$src
						$tarfname=$tar
					}
					else{
						$srcfname=$src[$j]
						$tarfname=$tar[$j]
					}

					if(($srcfname -ne $null) -and ($tarfname -ne $null))
					{
						Write-Host "Generating Differential reports for Storage Account..." 
						#Generating MD5Value
						$srchash =Get-FileHash $filepath\$srcfname.csv -Algorithm MD5
						$tarhash =Get-FileHash $filepath\$tarfname.csv -Algorithm MD5

						#Write-Host "Source File Name:" $filepath\$srcfname.csv $srchash
						#Write-Host "Target File Name:" $filepath\$srcfname.csv $tarhash

						#Compare MD5 for multiple csv and adding result in Final CSV
						if ($srchash.Hash -ceq $tarhash.Hash){
							Add-Content -Path $filepath\DifferentialReport.csv -Value "$ContainerName;$srcfname;$tarfname;TRUE"
						}
						else{
						Add-Content -Path $filepath\DifferentialReport.csv -Value "$ContainerName;$srcfname;$tarfname;FALSE"
						}
					}
					else{
						Add-Content -Path $filepath\DifferentialReport.csv -Value "$ContainerName;$srcfname;$tarfname;FALSE"}
					}
			}
	}

Import-Csv -Path $filepath\DifferentialReport.csv
