param(
#  Storage Account Paramenter
[Parameter(Mandatory = $true)] 
[string]$SourceResourceGroupName,

[Parameter(Mandatory = $true)] 
[string]$SourceStorageAccName,

[Parameter(Mandatory = $true)] 
[string]$TargetResourceGroupName,  

[Parameter(Mandatory = $true)]
[string]$TargetStorageAccName
)


class StorageAccount {
    [string]$ContainerName
    [string]$BlobCount
    [string]$TotalSize
}


class FinalAccount {
    [string]$SourceContainerName
    [string]$SourceBlobCount
    [string]$SourceTotalSize
    [string]$TargetContainerName
    [string]$TargetBlobCount
    [string]$TargetTotalSize
}

#Getting Vaule from Pipeline
Write-Output "Source Resource Group Name : $SourceResourceGroupName "
Write-Output "Source Storage Account Name : $SourceStorageAccName "
Write-Output "Target Resource Group Name : $TargetResourceGroupName "
Write-Output "Target Stirage Account Name : $TargetStorageAccName "
       
Function GetAllStorageAccountData()   {

Param
  (
   [Parameter(Mandatory = $true)] [string] $resourceGroup,
   [Parameter(Mandatory = $true)] [string] $storageAccountName
  
  )

#Storage context
$ctx = New-AzStorageContext -StorageAccountName $storageAccountName -UseConnectedAccount

$containers = Get-AzStorageContainer -Context $ctx 

#account object
[StorageAccount[]]$accounts = [StorageAccount[]]::new($containers.length)
#[FinalAccount[]]$FinalAccounts = [FinalAccount[]]::new($containers.length)

# zero out our total
$containerCounter = 0

Foreach ($container in $containers) {
	# get a list of all of the blobs in the container 
	$listOfBlobs = Get-AzStorageBlob -Container $container.Name -Context $ctx 
    $blobcount = 0
	$blobsize = 0
	$listOfBlobs | ForEach-Object {    
		 $blobcount = $blobcount + 1
		 $blobsize = $blobsize + $_.Length
	 }
	
	#capture details
	$account = [StorageAccount]::new()
	$account.ContainerName = $container.Name
	$account.BlobCount = $blobcount
	$account.TotalSize = $blobsize
	$accounts[$containerCounter] = $account
	$containerCounter = $containerCounter + 1
 }
 return $accounts
}


Write-Output "Getting Source Storage Account Data....."
[StorageAccount[]]$SourceAccounts = GetAllStorageAccountData $SourceResourceGroupName $SourceStorageAccName

Write-Output "Getting Target Account Data......."
$TargetAccounts = GetAllStorageAccountData $TargetResourceGroupName $TargetStorageAccName


[FinalAccount[]]$FinalAccounts = [FinalAccount[]]::new($TargetAccounts.length)

Write-Output "Merging the result in to final account"

#Write-Host "Source Container Name, Source Blob Count, Source BlobSize, Target Container Name, Target Blob Count, Target BlobSize"
New-Item -Path .\VoluemtricReport.csv -ItemType File -Force
Add-Content -Path .\VoluemtricReport.csv -Value "Source Container Name; Source Blob Count; Source BlobSize(kb); Target Container Name; Target Blob Count; Target BlobSize(kb)"
$finalCounter = 0
Foreach ($sourceaccount in $SourceAccounts) { 
	# $finalaccount = [FinalAccount]::new()
	# $finalaccount.SourceContainerName = $sourceaccount.ContainerName 
	# $finalaccount.SourceBlobCount = $sourceaccount.BlobCount
	# $finalaccount.SourceTotalSize = $sourceaccount.TotalSize
	# $finalaccount.TargetContainerName = $TargetAccounts[$finalCounter].ContainerName
	# $finalaccount.TargetBlobCount = $TargetAccounts[$finalCounter].BlobCount
	# $finalaccount.TargetTotalSize = $TargetAccounts[$finalCounter].TotalSize 
	# $FinalAccounts[$finalCounter] = $finalaccount
	$SourceContainerName = $sourceaccount.ContainerName
	$SourceBlobCount = $sourceaccount.BlobCount
	$SourceTotalSize = $sourceaccount.TotalSize
	$TargetContainerName = $TargetAccounts[$finalCounter].ContainerName
	$TargetBlobCount = $TargetAccounts[$finalCounter].BlobCount
	$TargetTotalSize = $TargetAccounts[$finalCounter].TotalSize 
	$finalCounter = $finalCounter + 1
	Add-Content -Path .\VoluemtricReport.csv -Value "$SourceContainerName;$SourceBlobCount;$SourceTotalSize;$TargetContainerName;$TargetBlobCount;$TargetTotalSize"
}

#$FinalAccounts
Write-Output "Merging successful.... Exporting the Result...."
#New-Item -Path .\VoluemtricReport.csv -ItemType File -Force
#$FinalAccounts | Export-Csv -Path .\VoluemtricReport.csv -Delimiter ';'-NoTypeInformation -Force -Append 
Import-Csv -Path .\VoluemtricReport.csv
Write-Output "Export Result in VoluemtricReport.csv file Successfull"