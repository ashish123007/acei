# Introduction 
In this folder we store arm, bicep and yaml templates for azure resource deployments.

# Getting Started
The resources in this folder are additional to the [Azure Scenario Market Place](https://confluence.aws.abnamro.org/display/AZURE/Azure+Scenario+Market+Place).

Also please check out our [Cookbooks](https://confluence.aws.abnamro.org/display/AZURE/FSCP+3.0+Services+cookbook) for help and information regarding deployment of the resources provided in this folder. 


# Contribute
This repository is managed by the FSCP Transition Team. New content wil only be provided by the FSCP Transition Team. When explorations are finished, we merge the final product in to this folder and clean up the explorations folder.