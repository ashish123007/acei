# KeyVault secret copy from fscp 2.0 to fscp 3.0 pipeline

This is an example pipeline that is provided by the FTT team since januari 2023. This pipeline can help transition customers with the copy of secrets from a key vault in fscp 2.0 to a key vault in fscp 3.0. This pipeline is setup specifically for copying from fscp 2.0 to fscp 3.0.

This pipeline supports both RBAC and acces policy access configuration. When the source keyvault has RBAC enabled, you dont need the acces policy deployment in the pipeline, you can leave this condition unchecked. When the source keyvault does not have RBAC enabled, you need to enable the access policy deployment. 

This pipeline supports both the copy of one single secret, or multiple/all secret at once. 

This pipeline has a conditional deployment of a access policy, because of this conditional deployment we make use of two seperate parameter files. 
For the main deployment we have the main.parameters.json file. This file will always be needed. For the conditional deployment we have a second parameter file, key-vault-access-policy.parameters.json. The second parameter file will only be needed when deploying a access policy.
