

Function Restore-VMDisk {
    <#
    .SYNOPSIS
        Restores the managed disks of a Virtual Machine to a specified point in time.
 
    .DESCRIPTION
        Restores the managed disks of a Virtual Machine to a specified point in time, replacing the disks of the target Virtual Machine.
 
    .PARAMETER ResourceGroupName
        The name of the Resource Group that contains the Recovery Services Vault and the backed up Virtual Machine.
 
    .PARAMETER VaultName
        The name of the Recovery Services Vault.
 
    .PARAMETER VirtualMachineName
        The name of the backed up Virtual Machine.
 
    .PARAMETER TargetResourceGroupName
        The optional name of the target Resource Group to which the managed disks are restored and that contains the target Virtual Machine and Disk Encryption Set.
 
    .PARAMETER TargetVirtualMachineName
        The optional name of the target Virtual Machine.
 
        If there is no target Virtual Machine name specified, the disks of the backed up Virtual Machine will be replaced with the restored disks.
 
    .PARAMETER DiskEncryptionSetName
        The name of the Disk Encryption Set for the restored disks.
 
    .PARAMETER StorageAccountResourceGroupName
        The optional name of the Resource Group that contains the target Storage Account, or where the temporary Storage Account will be created.
 
    .PARAMETER StorageAccountName
        The optional name of the Storage Account, which will be used as staging location during the restore of the disks.
 
        Blob Storage and Zone Redundant Storage (ZRS) are not supported.
 
        When restoring a non-premium Virtual Machine, a premium Storage Account is not supported. When restoring a managed Virtual Machine, a premium Storage Account configured with network rules is not supported.
 
        If there is no Storage Account name specified, a temporary Storage Account will be created. Note: If this function is cancelled, the temporary Storage Account may not be removed automatically.
 
    .PARAMETER RestoreOnlyOSDisk
        Whether to restore only the OS disk of the backed up Virtual Machine.
 
    .PARAMETER RestoreDate
        The optional date of the restore point for the Virtual Machine.
 
        If there is no restore date specified, the disks of the Virtual Machine will be restored from the latest backup since yesterday.
 
    .PARAMETER TimeoutInMinutes
        The optional maximum time in minutes that this function waits for the restore job to finish. It is recommended to specify a timeout value.
 
    .EXAMPLE
        Restore-VMDisk `
            -ResourceGroupName $resourceGroupName `
            -VaultName $recoveryServicesVaultName `
            -VirtualMachineName $virtualMachineName `
            -DiskEncryptionSetName $diskEncryptionSetName `
            -StorageAccountName $storageAccountName `
            -RestoreDate $restoreDate `
            -TimeoutInMinutes 60
 
        This command will replace the disks of the source Virtual Machine.
 
    .EXAMPLE
        Restore-VMDisk `
            -ResourceGroupName $resourceGroupName `
            -VaultName $recoveryServicesVaultName `
            -VirtualMachineName $virtualMachineName `
            -TargetVirtualMachineName $targetVirtualMachineName `
            -DiskEncryptionSetName $diskEncryptionSetName `
            -StorageAccountName $storageAccountName `
            -RestoreDate $restoreDate `
            -TimeoutInMinutes 60
 
        This command will replace the disks of the specified target Virtual Machine.
    #>
 
    [CmdletBinding(SupportsShouldProcess = $true)]
    Param (
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias("SourceResourceGroupName")]
        [String] $ResourceGroupName,
 
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias("RecoveryServicesVaultName")]
        [String] $VaultName,
 
        [Parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias("Name", "ResourceName", "SourceVirtualMachineName", "VMName")]
        [String] $VirtualMachineName,
 
        [Parameter(Mandatory = $false)]
        [String] $TargetResourceGroupName = $ResourceGroupName,
 
        [Parameter(Mandatory = $false)]
        [String] $TargetVirtualMachineName,
 
        [Parameter(Mandatory = $false)]
        [Alias("TargetDiskEncryptionSetName")]
        [String] $DiskEncryptionSetName,
 
        [Parameter(Mandatory = $false)]
        [String] $StorageAccountResourceGroupName = $ResourceGroupName,
 
        [Parameter(Mandatory = $false, ValueFromPipelineByPropertyName = $true)]
        [String] $StorageAccountName,
 
        [Switch] $RestoreOnlyOSDisk,
 
        [Parameter(Mandatory = $false)]
        [Alias("RestorePoint")]
        [DateTime] $RestoreDate = (Get-Date).AddDays(-1).ToUniversalTime(),
 
        [Parameter(Mandatory = $false)]
        [ValidateRange(1, [int]::MaxValue)]
        [Alias("Timeout")]
        [Int] $TimeoutInMinutes
    )
 
    Process {

        Write-Verbose "Retrieving Recovery Services Vault '$VaultName' in Resource Group '$ResourceGroupName'."
        $recoveryServicesVault = Get-AzRecoveryServicesVault -Name $VaultName -ResourceGroupName $ResourceGroupName -ErrorAction Stop

        If ($UseSystemAssignedIdentity -and -not $recoveryServicesVault.Identity.PrincipalId) {
            Write-Error "System-Assigned Managed Identity is not enabled on Recovery Services Vault '$VaultName'." -ErrorAction Stop
        }

        Write-Verbose "Retrieving source Virtual Machine '$VirtualMachineName' in source Resource Group '$ResourceGroupName'."
        $sourceVm = Get-AzVM -Name $VirtualMachineName -ResourceGroupName $ResourceGroupName -ErrorAction Stop

        If ($TargetVirtualMachineName -eq $VirtualMachineName) {
            Write-Host "VM comparison"
            $targetVm = $sourceVm
        }
        Else {
            Write-Host "Retrieving target Virtual Machine '$TargetVirtualMachineName' in target Resource Group '$TargetResourceGroupName'."
            $targetVm = Get-AzVM -Name $TargetVirtualMachineName -ResourceGroupName $TargetResourceGroupName -ErrorAction Stop
        }

        If ($targetVm.Location -ne $recoveryServicesVault.Location) {
            Write-Error "Target Virtual Machine '$TargetVirtualMachineName' must be in same region as Recovery Services Vault '$VaultName', i.e., location '$($recoveryServicesVault.Location)'." -ErrorAction Stop
        }

        Write-Verbose "Retrieving target Virtual Machine '$TargetVirtualMachineName' power state."
        $targetVmStatus = Get-AzVM -ResourceId $targetVm.Id -Status
        $targetVmPowerState = $targetVmStatus.Statuses.Code | Where-Object -FilterScript { $_ -match "^PowerState/" }


        Write-Verbose "Retrieving backup item of source Virtual Machine '$VirtualMachineName' from Recovery Services Vault '$VaultName'."
        $backupItem = Get-AzRecoveryServicesBackupItem -BackupManagementType AzureVM -WorkloadType AzureVM -VaultId $recoveryServicesVault.ID | Where-Object -FilterScript { $_.SourceResourceId -eq $sourceVm.Id }

        If (-not $backupItem) {
            Write-Error "Cannot restore Virtual Machine. Backup item for source Virtual Machine '$VirtualMachineName' not found in Recovery Services Vault '$VaultName'." -ErrorAction Stop
        }

        $startDate = (Get-Date -Date $RestoreDate).ToUniversalTime()
        $endDate = (Get-Date).ToUniversalTime()

        Write-Verbose "Retrieving backup recovery points with restore date '$RestoreDate' for source Virtual Machine '$VirtualMachineName' from Recovery Services Vault '$VaultName'."
        $backupRecoveryPoints = Get-AzRecoveryServicesBackupRecoveryPoint -Item $backupItem -EndDate $endDate -StartDate $startDate -VaultId $recoveryServicesVault.ID

        If (-not $backupRecoveryPoints) {
            Write-Error "Cannot restore Virtual Machine. Backup recovery points with restore date '$RestoreDate' for source Virtual Machine '$VirtualMachineName' not found in Recovery Services Vault '$VaultName'." -ErrorAction Stop
        }

        $backupRecoveryPoint = $backupRecoveryPoints[0]

        Write-Verbose "Retrieving Disk Encryption Set '$DiskEncryptionSetName' in target Resource Group '$TargetResourceGroupName'."
        $diskEncryptionSetId = (Get-AzDiskEncryptionSet -Name $DiskEncryptionSetName -ResourceGroupName $TargetResourceGroupName -ErrorAction Stop).Id

        If ($StorageAccountName) {
            Write-Verbose "Retrieving Storage Account '$StorageAccountName' in Resource Group '$StorageAccountResourceGroupName'."
            Get-AzStorageAccount -Name $StorageAccountName -ResourceGroupName $StorageAccountResourceGroupName -ErrorAction Stop | Out-Null

            $temporaryStorageAccount = $false
        }
        Else {
            $StorageAccountName = "temporarystorage$(Get-Random -Maximum 1000000 -Minimum 100000)"

            $temporaryStorageAccount = $true
        }

        Try {

            If ($temporaryStorageAccount) {
                Write-Host "Creating temporary Storage Account '$StorageAccountName' in Resource Group '$StorageAccountResourceGroupName'."
                If ($PSCmdlet.ShouldProcess($StorageAccountName, "New-AzStorageAccount")) {
                    $storageAccount = New-AzStorageAccount `
                        -Location $recoveryServicesVault.Location `
                        -Name $StorageAccountName `
                        -ResourceGroupName $StorageAccountResourceGroupName `
                        -SkuName Standard_LRS `
                        -EnableHttpsTrafficOnly $true `
                        -ErrorAction Stop

                    Write-Verbose "Waiting for 1 minute to ensure temporary Storage Account '$StorageAccountName' is provisioned..."
                    Start-Sleep -Seconds 60
                }

                ForEach ($roleDefinitionName In "Storage Account Backup Contributor", "Storage Blob Data Contributor") {
                    Write-Host "Assigning role definition '$roleDefinitionName' to System-Assigned Managed Identity of Recovery Services Vault '$VaultName' on temporary Storage Account '$StorageAccountName'."
                    If ($PSCmdlet.ShouldProcess($recoveryServicesVault.Identity.PrincipalId, "New-AzRoleAssignment")) {
                        Try {
                            New-AzRoleAssignment `
                                -ObjectId $recoveryServicesVault.Identity.PrincipalId `
                                -RoleDefinitionName $roleDefinitionName `
                                -ObjectType "ServicePrincipal" `
                                -Scope $storageAccount.Id `
                                -ErrorAction Stop
                        }
                        Catch {
                            Write-Error "Failed to assign role definition '$roleDefinitionName' to System-Assigned Managed Identity of Recovery Services Vault '$VaultName' on temporary Storage Account '$StorageAccountName'. Error: $($_.Exception.Body.Error.Message)"
                        }
                    }
                }

                Write-Verbose "Waiting for 1 minute to ensure role definitions are assigned to System-Assigned Managed Identity of Recovery Services Vault '$VaultName' on temporary Storage Account '$StorageAccountName'..."
                Start-Sleep -Seconds 60
            }

            Write-Host "Restoring disks of source Virtual Machine '$VirtualMachineName' with recovery point time $($backupRecoveryPoint.RecoveryPointTime) to target Resource Group '$TargetResourceGroupName'."
            If ($PSCmdlet.ShouldProcess($backupRecoveryPoint.Id, "Restore-AzRecoveryServicesBackupItem")) {
                $restoreJob = Restore-AzRecoveryServicesBackupItem `
                    -RecoveryPoint $backupRecoveryPoint `
                    -StorageAccountName $StorageAccountName `
                    -StorageAccountResourceGroupName $StorageAccountResourceGroupName `
                    -TargetResourceGroupName $TargetResourceGroupName `
                    -DiskEncryptionSetId $diskEncryptionSetId `
                    -RestoreOnlyOSDisk:$RestoreOnlyOSDisk `
                    -UseSystemAssignedIdentity `
                    -VaultId $recoveryServicesVault.ID `
                    -VaultLocation $recoveryServicesVault.Location `
                    -ErrorAction Stop
            }

            If ($TimeoutInMinutes) {
                Write-Host "Waiting for $TimeoutInMinutes minutes for restore job to complete..."
                If ($PSCmdlet.ShouldProcess("Wait-AzRecoveryServicesBackupJob")) {
                    Wait-AzRecoveryServicesBackupJob -VaultID $recoveryServicesVault.ID -Job $restoreJob -Timeout ($TimeoutInMinutes * 60) | Out-Null
                }
            }
            Else {
                Write-Host "Waiting for restore job to complete..."
                If ($PSCmdlet.ShouldProcess("Wait-AzRecoveryServicesBackupJob")) {
                    Wait-AzRecoveryServicesBackupJob -VaultID $recoveryServicesVault.ID -Job $restoreJob | Out-Null
                }
            }

            Write-Verbose "Retrieving restore job details."
            If ($PSCmdlet.ShouldProcess("Get-AzRecoveryServicesBackupJobDetail")) {
                $restoreJobDetails = Get-AzRecoveryServicesBackupJobDetail -Job $restoreJob -VaultId $recoveryServicesVault.ID
                Write-Verbose "Restore job details:"
                $restoreJobDetails | Format-List | Out-String | Write-Verbose

                If ($restoreJobDetails.Status -eq "Failed") {
                    Write-Error "Failed to restore disks of source Virtual Machine '$VirtualMachineName' with recovery point time $($backupRecoveryPoint.RecoveryPointTime) to target Resource Group '$TargetResourceGroupName'." -ErrorAction Stop
                }

                If ($restoreJobDetails.Properties.Keys -notcontains "Config Blob Name" -or $restoreJobDetails.Properties.Keys -notcontains "Config Blob Container Name") {
                    Write-Verbose "Restore job details properties:"
                    $restoreJobDetails.Properties | Format-List | Out-String | Write-Verbose

                    If ($TimeoutInMinutes) {
                        Write-Error "Key 'Config Blob Name' or 'Config Blob Container Name' not found in restore job details properties. Please retry later with a timeout of more than $TimeoutInMinutes minutes." -ErrorAction Stop
                    }
                    Else {
                        Write-Error "Key 'Config Blob Name' or 'Config Blob Container Name' not found in restore job details properties." -ErrorAction Stop
                    }
                }

                $configBlobName = $restoreJobDetails.Properties."Config Blob Name"
                $configBlobContainerName = $restoreJobDetails.Properties."Config Blob Container Name"
            }

            Write-Verbose "Creating storage context for Storage Account '$StorageAccountName'."
            If ($PSCmdlet.ShouldProcess($StorageAccountName, "New-AzStorageContext")) {
                $storageContext = New-AzStorageContext -StorageAccountName $StorageAccountName -UseConnectedAccount
            }

            If ($PSCmdlet.ShouldProcess("Retrieving offline Virtual Machine configuration and restored OS disk.")) {
                Write-Host "Retrieving blob '$configBlobName' in container '$configBlobContainerName' from Storage Account '$StorageAccountName'."
                $configBlobContent = Get-AzStorageBlobContent -Blob $configBlobName -Container $configBlobContainerName -Context $storageContext -ErrorAction Stop

                Write-Host "Retrieving offline Virtual Machine configuration."
                $vmConfig = (Get-Content -Path $configBlobContent.Name -Encoding "Unicode" -Raw).TrimEnd([char]0x00) | ConvertFrom-Json

                $vmStorageProfile = $vmConfig."properties.storageProfile"
                $restoredOsDiskName = $vmStorageProfile.osDisk.name
                $restoredDataDisks = $vmStorageProfile.dataDisks

                Write-Host "Retrieving restored OS disk '$restoredOsDiskName' in target Resource Group '$TargetResourceGroupName'."
                $restoredOsDisk = Get-AzDisk -DiskName $restoredOsDiskName -ResourceGroupName $TargetResourceGroupName -ErrorAction Stop
            }

            $removeRestoredOsDisk = $true
            $removeRestoredDataDisks = $true

            # Get details of disks from target VM to delete existing attached disks from target virtual machine
            $targetvmosDiskName = $targetVm.StorageProfile.OsDisk.Name

            # check if virtual machine and target virtual machine are in same zone or not
            Write-Host "Replacing OS disk in offline Virtual Machine configuration."

            # Check if virtual machine and target virtual machine are in same zone or not 
            If ($targetVm.Zones -ne $sourceVm.Zones) { 
                # If zone of virtual machine and target virtual machine are not same then create a snapshot of the restored disk
                Write-Host "Creating snapshot of restored OS disk '$restoredOsDiskName' in Resource Group '$TargetResourceGroupName'."
                $snapshotName = "snapshot-$restoredOsDiskName"
                $snapshotConfig = New-AzSnapshotConfig -SourceUri $restoredOsDisk.Id -CreateOption Copy -Location $vmConfig.location
                $snapshot = New-AzSnapshot -Snapshot $snapshotConfig -SnapshotName $snapshotName -ResourceGroupName $TargetResourceGroupName -ErrorAction Stop

                # Removing restored OS disk from target resource group
                Write-Host "Removing restored OS disk $($restoredOsDisk.Name) from Resource Group '$TargetResourceGroupName'."
                Remove-AzDisk -DiskName $restoredOsDisk.Name -ResourceGroupName $TargetResourceGroupName -Force | Out-Null
                $removeRestoredOsDisk = $false

                # Create a disk from the snapshot
                Write-Host "Creating disk from snapshot $($snapshot.Name) in Resource Group '$TargetResourceGroupName'."
                $diskName = "restored-$restoredOsDiskName" 
                $diskConfig = New-AzDiskConfig -SourceResourceId $snapshot.Id -Location $snapshot.Location -CreateOption Copy -DiskSizeGB $snapshot.DiskSizeGB -Zone $targetVm.Zones
                $restoredDisk = New-AzDisk -DiskName $diskName -Disk $diskConfig -ResourceGroupName $TargetResourceGroupName -ErrorAction Stop

                Write-Host "Enabling Encryption At Rest With Customer-Managed Key for restored OS disk."
                If ($PSCmdlet.ShouldProcess($diskEncryptionSetId, "New-AzDiskUpdateConfig")) {
                    New-AzDiskUpdateConfig -DiskEncryptionSetId $diskEncryptionSetId -EncryptionType "EncryptionAtRestWithCustomerKey" |
                    Update-AzDisk -DiskName $restoredDisk.Name -ResourceGroupName $TargetResourceGroupName | Out-Null
                }

                # Adding restored disk to target vm
                Write-Host "Attaching the restored disk '$diskName' to the target Virtual Machine '$TargetVirtualMachineName'."
                $targetVm = Set-AzVMOSDisk -VM $targetVm -DiskEncryptionSetId $diskEncryptionSetId -ManagedDiskId $restoredDisk.Id -Name $restoredDisk.Name

                Write-Host "Removing snapshot $($snapshot.Name) from Resource Group '$TargetResourceGroupName'."
                Remove-AzSnapshot -SnapshotName $snapshot.Name -ResourceGroupName $TargetResourceGroupName -Force | Out-Null
            }
            Else {

                Write-Host "Enabling Encryption At Rest With Customer-Managed Key for restored OS disk."
                If ($PSCmdlet.ShouldProcess($diskEncryptionSetId, "New-AzDiskUpdateConfig")) {
                    New-AzDiskUpdateConfig -DiskEncryptionSetId $diskEncryptionSetId -EncryptionType "EncryptionAtRestWithCustomerKey" |
                    Update-AzDisk -DiskName $restoredOsDiskName -ResourceGroupName $TargetResourceGroupName | Out-Null
                }

                $targetVm = Set-AzVMOSDisk -VM $targetVm -DiskEncryptionSetId $diskEncryptionSetId -ManagedDiskId $restoredOsDisk.Id -Name $restoredOsDiskName
            }
        
            Write-Host "Detaching any data disks in offline Virtual Machine configuration."
            If ($PSCmdlet.ShouldProcess($targetVm.Id, "Remove-AzVMDataDisk")) {
                $targetVm = Remove-AzVMDataDisk -VM $targetVm
            }

            If ($targetVmPowerState -eq "PowerState/running") {
                Write-Host "Stopping target Virtual Machine '$TargetVirtualMachineName' to update disk configuration."
                If ($PSCmdlet.ShouldProcess($targetVm.Id, "Stop-AzVM")) {
                    Stop-AzVM -Id $targetVm.Id -Force -StayProvisioned | Out-Null
                }
            }

            Write-Host "Updating target Virtual Machine '$TargetVirtualMachineName' with restored OS disk."
            If ($PSCmdlet.ShouldProcess($targetVm.Id, "Update-AzVM")) {
                Update-AzVM -Id $targetVm.Id -VM $targetVm | Out-Null
            }

            #Delete original OS disk once attached to target VM 
            Write-Host "Removing existing restored OS disk $targetvmosDiskName from Target Virtual Machine '$($targetVm.name)'."
            Remove-AzDisk -DiskName $targetvmosDiskName -ResourceGroupName $TargetResourceGroupName -Force | Out-Null

            If (-not $RestoreOnlyOSDisk) {
                Write-Verbose "Adding any restored data disks to offline Virtual Machine configuration."
                If ($PSCmdlet.ShouldProcess($targetVm.Id, "Add-AzVMDataDisk")) {
                    If ($restoredDataDisks) {
                        ForEach ($dataDisk In $restoredDataDisks) {
                            $restoredDataDiskName = $dataDisk.name
                            $restoredDataDiskLun = $dataDisk.lun
                            $restoredDataDiskCaching = $dataDisk.caching

                            Write-Host "Retrieving restored data disk $restoredDataDiskName in target Resource Group '$TargetResourceGroupName'."
                            $restoredDataDisk = Get-AzDisk -DiskName $restoredDataDiskName -ResourceGroupName $TargetResourceGroupName -ErrorAction Stop

                            # check if virtual machine and target virtual machine are in same zone or not
                            If ($targetVm.Zones -ne $restoredDataDisk.Zones) {

                                #create a snapshot of the restored data disk
                                Write-Host "Creating snapshot of restored Data disk '$restoredDataDiskName' in Resource Group '$TargetResourceGroupName'."
                                $snapshotNameDataDisk = "snapshot-$restoredDataDiskName"
                                # $sourceuriDataDisk = $targetVm.StorageProfile.DataDisks.ManagedDisk.Id
                                $snapshotConfigDataDisk = New-AzSnapshotConfig -SourceUri $restoredDataDisk.Id -CreateOption Copy -Location $restoredDataDisk.Location
                                $snapshotDataDisk = New-AzSnapshot -Snapshot $snapshotConfigDataDisk -SnapshotName $snapshotNameDataDisk -ResourceGroupName $TargetResourceGroupName -ErrorAction Stop

                                # Removing restored data disk from target resource group
                                Write-Host "Removing restored data disk $restoredDataDiskName from Resource Group '$TargetResourceGroupName'."
                                Remove-AzDisk -DiskName $restoredDataDiskName -ResourceGroupName $TargetResourceGroupName -Force | Out-Null
                                $removeRestoredDataDisks = $false

                                #create a disk from the snapshot
                                Write-Host "Creating disk from snapshot $($snapshotDataDisk.Name) in Resource Group '$TargetResourceGroupName'."
                                $dataDiskConfig = New-AzDiskConfig -SourceResourceId $snapshotDataDisk.Id -Location $restoredDataDisk.Location -CreateOption Copy -DiskSizeGB $restoredDataDisk.DiskSizeGB -Zone $targetVm.Zones
                                $restoredDataDiskFromSnapshot = New-AzDisk -DiskName $restoredDataDiskName -Disk $dataDiskConfig -ResourceGroupName $TargetResourceGroupName -ErrorAction Stop

                                Write-Host "Enabling Encryption At Rest With Customer-Managed Key for restored data disk $($restoredDataDiskFromSnapshot.Name)."
                                New-AzDiskUpdateConfig -DiskEncryptionSetId $diskEncryptionSetId -EncryptionType "EncryptionAtRestWithCustomerKey" |
                                Update-AzDisk -DiskName $restoredDataDiskFromSnapshot.Name -ResourceGroupName $TargetResourceGroupName | Out-Null

                                # Adding restored data disk to target vm
                                $targetVm = Add-AzVMDataDisk -CreateOption "Attach" -Lun $restoredDataDiskLun -VM $targetVm -Caching $restoredDataDiskCaching -DiskEncryptionSetId $diskEncryptionSetId -ManagedDiskId $restoredDataDiskFromSnapshot.Id

                                Write-Host "Removing snapshot $($snapshotDataDisk.Name) from Resource Group '$TargetResourceGroupName'."
                                Remove-AzSnapshot -SnapshotName $snapshotDataDisk.Name -ResourceGroupName $TargetResourceGroupName -Force | Out-Null
                            }
                            Else {
                                Write-Host "Enabling Encryption At Rest With Customer-Managed Key for restored data disk $restoredDataDiskName."
                                New-AzDiskUpdateConfig -DiskEncryptionSetId $diskEncryptionSetId -EncryptionType "EncryptionAtRestWithCustomerKey" |
                                Update-AzDisk -DiskName $restoredDataDiskName -ResourceGroupName $TargetResourceGroupName | Out-Null

                                Write-Host "Adding restored data disk $restoredDataDiskName to offline Virtual Machine configuration."
                                $targetVm = Add-AzVMDataDisk -CreateOption "Attach" -Lun $restoredDataDiskLun -VM $targetVm -Caching $restoredDataDiskCaching -DiskEncryptionSetId $diskEncryptionSetId -ManagedDiskId $dataDisk.Id
                            }
                        }

                        Write-Host "Updating target Virtual Machine '$TargetVirtualMachineName' with any restored data disks."
                        Update-AzVM -Id $targetVm.Id -VM $targetVm | Out-Null
                    }
                    Else {
                        Write-Verbose "No restored data disks found to add to offline Virtual Machine configuration."
                    }
                }
            }
        }
        Finally {
            If ($temporaryStorageAccount) {
                Write-Host "Removing temporary Storage Account '$StorageAccountName' from Resource Group '$StorageAccountResourceGroupName'."
                If ($PSCmdlet.ShouldProcess($storageAccountName, "Remove-AzStorageAccount")) {
                    Remove-AzStorageAccount -Name $StorageAccountName -ResourceGroupName $StorageAccountResourceGroupName -Force | Out-Null
                }
            }

            If ($removeRestoredDataDisks) {
                ForEach ($dataDisk In $restoredDataDisks) {
                    # Removing restored data disk from target resource group
                    Write-Host "Finally Removing restored data disk '$($dataDisk.name)' from Resource Group '$TargetResourceGroupName'."
                    Remove-AzDisk -DiskName $dataDisk.name -ResourceGroupName $TargetResourceGroupName -Force | Out-Null
                }
            }

            If ($removeRestoredOsDisk) {
                # Removing restored OS disk from target resource group
                Write-Host "Finally Removing restored OS disk '$($restoredOsDisk.Name)' from Resource Group '$TargetResourceGroupName'."
                Remove-AzDisk -DiskName $restoredOsDisk.Name -ResourceGroupName $TargetResourceGroupName -Force | Out-Null
            }

            # Delete created blob during restoration from existing storage account. 
            If (-not $temporaryStorageAccount) {
                Write-Host "Deleting blob container $configBlobContainerName."
                Remove-AzStorageContainer -Container $configBlobContainerName -Context $storageContext
            }

            If ($targetVmPowerState -eq "PowerState/running") {
                Write-Host "Starting target Virtual Machine '$TargetVirtualMachineName'."
                If ($PSCmdlet.ShouldProcess($targetVm.Id, "Start-AzVM")) {
                    Start-AzVM -Id $targetVm.Id | Out-Null
                }
            }
        }
    }
}