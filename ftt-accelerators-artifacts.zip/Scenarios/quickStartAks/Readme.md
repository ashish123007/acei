# Quickstart AKS Pipeline

This is an example YAML pipeline that is provided by the FSCP Transition Team. This pipeline can help transition customers with the deployment of an Azure Kubernetes (AKS) cluster in a FSCP 3.0 Landing Zone.

**Be aware that AKS is not General Available in FSCP 3.0. Currently (January 2023) it is in Pre-Production phase and therefore not fit for production workloads.**

This pipeline consists of three deployment stage. First the required resource are deployed. Next the Self-Service Network Solution tasks are deployed. And finally the AKS cluster is deployed.
It supports the deployment of the same pipeline and templates to different environments.
It assumes that the virtual network should contain only one AKS subnet. If none exists it will create one. If there are more than one it will fail.
The templates in this repo deploy the bare-minimum required for a successful, compliant deployment and can be used by DevOps teams to kick-start their own Infrastructure-as-Code (IaC) code if using AKS.

**DISCLAIMER:** these are to be used as a sample/guidance, NOT to be imported directly. That's why not everything is configurable through parameters. The templates herein are provided without any support or guarantees that they'll work at all times. Teams MUST create their own templates to ensure full control and reliability.

The following resources are deployed in three stages by this pipeline.

1. Main bicep template
   - Key vault with Private Link Endpoint
   - Key Vault Access policies for the Service Principal, DevOps Group and the UMI.
   - Log analytics workspace
   - User assigned managed identity
   - Disk encryption set with Customer Managed Key
2. Self-Service Network Solution custom pipeline task
   - Subnet with AKS pattern
   - Inbound NSG rule for private agents
3. AKS bicep template
   - AKS cluster

## Limitations

This pipeline currently has the following identified limitations;

- Supports one AKS subnet.

## Deploy a cluster using

1. Copy the quickStartAks repo contents to your own repository.
2. Update 'parameters\global.variables.yml':
   - pipelineFolderRoot: _Reflect the relative path to your folder container the quickStartAks files._
3. Update 'parameter\\**EnvName**\variables.yml'
   - desKeyName: _Name of the Disk Encryption Set Key in the Key Vault._
   - aksSubnetName: _Subnet name for the AKS (Nodepool) Subnet. The pattern name needs to follow the naming standard aks##-subnet._
   - podSubnetName: _(__Optional__) Subnet name for the pod (delegated) Subnet. The pattern name follows the aksSubnetName with a higher (unused) number like 'aks02-subnet'._
   - location: _The location to deploy the cluster. default is 'westeurope'_
   - resourceGroupName: _Name of the resource group in your FSCP 3.0 Landing zone to deploy to._
   - roleDefinitionName: _Name of the RBAC role to assign to your RG SPN._
   - serviceConnectionName: _Name of the RG Azure Devops Service Connection._
   - SPNObjectID: _Object ID of your RG SPN._
   - virtualNetworkName: _Name of the Virtual Network the AKS Subnet should be created._
   - virtualNetworkResourcegroupName: _Name of the RG the 'virtualNetworkName' resides._
   - numberOfNodesAKS: _The number of nodepool Ip's in the AKS (Nodepool) subnet. 59 (/26), 123 (/25) or 251 (/24)._
   - numberOfPodIps: _(__Optional__) The number of pod Ip's in the pod subnet. none, 59 (/26), 123 (/25) or 251 (/24)._
4. Update 'parameter\\**EnvName**\main.infrastructure.parameters.json'_
   - "clusterName": _Name of your AKS cluster like qtxa01-d-aks01 (1-50)._
   - "groupId": _Object Id of the developer group from AAD to be added in access policy._
   - "keyVaultName": _Name of the keyvault for the Disk Encryption Set Key._
   - "logAnalyticsWorkspaceName": _Log Analytics workspace name._
   - "logAnalyticsWorkspaceSku": _Log Analytics workspace sku._
   - "pleSubnetName": _Name of the private link endpoint subnet._
   - "servicePrincipleObjectId": _Object ID of the Resource Group Service Principal to be assigned to the KV access policy._
   - "softDeleteRetentionInDays": _The number of days that the soft-deleted items should be retained._
   - "userAssignedManagedIdentityName": _User Assigned Managed Identity Name._
   - "vnetName": _Name of the vNet for the ple subnet._
   - "vnetRGName": _Name of the reource group for the ple subnet._
5. Update 'parameter\\**EnvName**\aksCluster.parameters.json'
   - "adminGroupObjectID": _AAD ObjectID of the admingroup being assigned a RBAC role._
   - "adminGroupRoleType": _Built-in role to assign to the AKS cluster for the adminGroup._
   - "applicationName": _Specifies the application name added as nodepool label._
   - "aksVersion": _Specifies the version of the AKS cluster._
   - "dnsPrefix": _Specifies the name of DNS Prefix._
   - "nodePoolVmSize": _Specifies the VM Size of Nodes._
   - "workloadIdentity": _Workload identity settings for the security profile._
6. Create a new pipeline and point to the 'infra-pipeline.yml' from #1.
7. Deploy your cluster using the pipeline.

## Note on adminGroupRoleTypes

Azure Kubernetes Service (AKS) offers two types of role-based access control (RBAC) roles: RBAC-enabled and non-RBAC.

1. RBAC-enabled roles allow you to grant granular permissions to users and service principals to perform specific tasks within AKS but not in Azure. This includes access to resources such as pods, services, and deployments. With RBAC, you can create custom roles with specific permissions, and assign those roles to users and service principals.
2. non-RBAC AKS roles let you manage AKS-related resources in Azure, but not inside Kubernetes.

- _Azure Kubernetes Service Cluster Admin Role_ - List cluster admin credential action.
- _Azure Kubernetes Service Cluster User Role_ - List cluster user credential action.
- _Azure Kubernetes Service Contributor Role_ - Grants access to read and write Azure Kubernetes Service clusters
- _Azure Kubernetes Service RBAC Admin_ - Allows admin access, intended to be granted within a namespace.
Allows read/write access to most resources in a namespace (or cluster scope), including the ability to create roles and role bindings within the namespace.
Doesn't allow write access to resource quota or to the namespace itself.
- _Azure Kubernetes Service RBAC Cluster Admin_ - Allows super-user access to perform any action on any resource.
Gives full control over every resource in the cluster and in all namespaces.
- _Azure Kubernetes Service RBAC Reader_ - Allows read-only access to see most objects in a namespace. It does not allow viewing roles or role bindings. This role does not allow viewing Secrets, since reading the contents of Secrets enables access to ServiceAccount credentials in the namespace, which would allow API access as any ServiceAccount in the namespace (a form of privilege escalation). Applying this role at cluster scope will give access across all namespaces.
- _Azure Kubernetes Service RBAC Writer_ - Allows read/write access to most objects in a namespace.This role does not allow viewing or modifying roles or role bindings. However, this role allows accessing Secrets and running Pods as any ServiceAccount in the namespace, so it can be used to gain the API access levels of any ServiceAccount in the namespace. Applying this role at cluster scope will give access across all namespaces.